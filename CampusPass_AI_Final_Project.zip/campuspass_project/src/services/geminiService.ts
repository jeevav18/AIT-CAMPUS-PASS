import { GoogleGenAI } from "@google/genai";
import { PassRequest, StudentProfile } from "@/types/campuspass";

// Safely obtain API key from Vite environment or process
const apiKey = import.meta.env.VITE_GEMINI_API_KEY || "";

let aiClient: GoogleGenAI | null = null;
if (apiKey) {
  try {
    aiClient = new GoogleGenAI({ apiKey });
  } catch (err) {
    console.warn("Failed to initialize GoogleGenAI client:", err);
  }
}

/**
 * Perform server-side AI evaluation on student pass request
 * Restricts sensitive details and returns actionable risk/policy summaries
 */
export async function analyzePassRequestAI(
  pass: Partial<PassRequest>,
  student: Partial<StudentProfile>
): Promise<{
  riskScore: 'LOW' | 'MEDIUM' | 'HIGH';
  riskSummary: string;
  missingInfoAlerts: string[];
  policyCompliance: boolean;
  recommendation: 'APPROVE' | 'FLAG_FOR_CALL' | 'FURTHER_VERIFICATION';
}> {
  // If no Gemini client is configured, provide institutional rule-based intelligence
  if (!aiClient) {
    return generateLocalRuleAnalysis(pass, student);
  }

  try {
    const prompt = `
You are the AI Campus Operations Auditor for Adithya Institute of Technology (AIT), Coimbatore (TNEA Code: 2744).
Evaluate this student hostel pass application according to college regulations:
- Regulations: Curfew is 19:30 on weekdays, 20:30 on weekends at Kurumbapalayam campus. Minimum attendance recommended is 75%.
- Reason must be specific, not vague (e.g. "going out" or "personal work" without details should be flagged).
- For Home Passes, parent contact verification is critical.

Pass Application Details:
Type: ${pass.passType}
Destination: ${pass.destination}
Stated Reason: ${pass.reason}
Departure Time: ${pass.departureDateTime}
Expected Return: ${pass.expectedReturnDateTime}
Student Attendance: ${student.attendancePercentage || 85}%
Disciplinary Remarks: ${(student.disciplinaryRemarks || []).join(", ") || "None"}
Parent Relation: ${pass.guardian?.relation || "Guardian"}

Return a pure JSON response in this exact format:
{
  "riskScore": "LOW" | "MEDIUM" | "HIGH",
  "riskSummary": "1-2 concise sentences explaining the assessment",
  "missingInfoAlerts": ["list any vague or missing details"],
  "policyCompliance": true | false,
  "recommendation": "APPROVE" | "FLAG_FOR_CALL" | "FURTHER_VERIFICATION"
}
`;

    const response = await aiClient.models.generateContent({
      model: "gemini-3.8-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
      },
    });

    const text = response.text?.trim() || "";
    const parsed = JSON.parse(text);
    return {
      riskScore: parsed.riskScore || "LOW",
      riskSummary: parsed.riskSummary || "Standard application within institution safety parameters.",
      missingInfoAlerts: Array.isArray(parsed.missingInfoAlerts) ? parsed.missingInfoAlerts : [],
      policyCompliance: parsed.policyCompliance !== false,
      recommendation: parsed.recommendation || "APPROVE",
    };
  } catch (err) {
    console.warn("Gemini API call failed, falling back to rule engine:", err);
    return generateLocalRuleAnalysis(pass, student);
  }
}

/**
 * Intelligent Rule-Engine fallback providing instant real-time audit
 */
function generateLocalRuleAnalysis(
  pass: Partial<PassRequest>,
  student: Partial<StudentProfile>
): {
  riskScore: 'LOW' | 'MEDIUM' | 'HIGH';
  riskSummary: string;
  missingInfoAlerts: string[];
  policyCompliance: boolean;
  recommendation: 'APPROVE' | 'FLAG_FOR_CALL' | 'FURTHER_VERIFICATION';
} {
  const alerts: string[] = [];
  let score: 'LOW' | 'MEDIUM' | 'HIGH' = 'LOW';
  let recommendation: 'APPROVE' | 'FLAG_FOR_CALL' | 'FURTHER_VERIFICATION' = 'APPROVE';

  const reason = (pass.reason || '').toLowerCase().trim();
  const dest = (pass.destination || '').toLowerCase().trim();

  if (reason.length < 10 || reason.includes("personal") || reason.includes("urgent work")) {
    alerts.push("Stated reason is vague. Detailed destination purpose requested.");
    score = 'MEDIUM';
    recommendation = 'FLAG_FOR_CALL';
  }

  if (dest.length < 3) {
    alerts.push("Exact destination address or landmark not provided.");
    score = 'MEDIUM';
  }

  if (student.attendancePercentage && student.attendancePercentage < 75) {
    alerts.push(`Low academic attendance detected (${student.attendancePercentage}%). Requires Tutor academic review.`);
    score = 'HIGH';
    recommendation = 'FURTHER_VERIFICATION';
  }

  if (pass.passType === 'home_pass') {
    alerts.push("Home Leave requires primary guardian telephonic or portal consent.");
    if (score === 'LOW') score = 'LOW';
  }

  const returnHour = pass.expectedReturnDateTime ? new Date(pass.expectedReturnDateTime).getHours() : 20;
  if (returnHour > 21) {
    alerts.push("Expected return time extends past 21:00 curfew. Warden late clearance required.");
    score = score === 'HIGH' ? 'HIGH' : 'MEDIUM';
  }

  const summary = alerts.length > 0 
    ? alerts[0] 
    : "Verified clean history, high attendance, destination clearly noted within perimeter guidelines.";

  return {
    riskScore: score,
    riskSummary: summary,
    missingInfoAlerts: alerts,
    policyCompliance: score !== 'HIGH',
    recommendation,
  };
}

/**
 * Ask Policy Assistant about campus rules, curfews, leave limits
 */
export async function askCampusPolicyAI(query: string): Promise<string> {
  if (!aiClient) {
    return getLocalPolicyAnswer(query);
  }

  try {
    const prompt = `
You are the official CampusPass AI Regulations Assistant for Adithya Institute of Technology (AIT), Kurumbapalayam, Coimbatore (TNEA Code: 2744).
Answer the user's question regarding hostel gate pass, outing limits, approval workflows, parent consent, and gate security.
College rules:
- Weekday general outing curfew is 19:30 HRS.
- Weekend outing curfew is 20:30 HRS.
- Outing workflow: Tutor -> HOD -> Warden -> Gate QR Scan.
- Home Pass requires verified Parent call or WhatsApp consent before Warden approval.
- Gates on Sathy Main Road, Kurumbapalayam are monitored 24/7 with dynamic QR validation. Overdue returns are escalated to Warden and Parents at +30 mins and Principal at +60 mins.
- Keep the response authoritative, welcoming, clear and formatted with bullet points if helpful. Max 3 concise paragraphs.

User Question: "${query}"
`;

    const response = await aiClient.models.generateContent({
      model: "gemini-3.8-flash",
      contents: prompt,
    });

    return response.text?.trim() || getLocalPolicyAnswer(query);
  } catch (err) {
    console.warn("AI Policy query failed:", err);
    return getLocalPolicyAnswer(query);
  }
}

function getLocalPolicyAnswer(query: string): string {
  const q = query.toLowerCase();
  if (q.includes("curfew") || q.includes("timing") || q.includes("time")) {
    return "Adithya Institute of Technology Outing Curfews:\n• Weekdays (Mon-Fri): Students must return by 19:30 HRS.\n• Weekends & Holidays: Return deadline is 20:30 HRS.\n• Late arrivals past 30 minutes trigger automatic SMS alerts to the Chief Warden and registered Parents.";
  }
  if (q.includes("approval") || q.includes("workflow") || q.includes("who")) {
    return "Standard Approval Sequence at Adithya Institute of Technology:\n1. Class Tutor (Verifies attendance & calls parent if needed)\n2. Department HOD (Verifies academic/lab schedule clearance)\n3. Hostel Chief Warden (Checks room register, issues valid cryptographic QR token)\n4. Gate Security Officer (Scans dynamic QR upon departure and arrival at Kurumbapalayam Gates).";
  }
  if (q.includes("parent") || q.includes("consent") || q.includes("father") || q.includes("mother")) {
    return "Parent Integration Protocols:\n• Automated SMS and WhatsApp notifications are dispatched instantly upon pass submission, approval, gate exit, and gate return.\n• For Home Passes, the Class Tutor or Warden must record verified verbal or digital consent from the registered primary guardian.";
  }
  return "Adithya Institute of Technology (TNEA Code: 2744) CampusPass Policy:\n• Pass types include General Outing, Weekend Home Pass, and Emergency Medical Outing.\n• Digital QR passes feature active countdown timers and anti-screenshot watermarks.\n• For emergency leave, the Chief Warden and Principal have immediate single-step bypass clearance.";
}

/**
 * Generate Daily Operational Summary for Principal & Chief Warden
 */
export async function generateDailyOperationsSummaryAI(stats: {
  totalResidents: number;
  currentlyOut: number;
  expectedReturnsTonight: number;
  overdueCount: number;
  approvedToday: number;
  parentCallsMade: number;
}): Promise<string> {
  if (!aiClient) {
    return `Hostel Operations Status: ${stats.totalResidents} total registered residents. Currently ${stats.currentlyOut} students are out on authorized passes. Tonight, ${stats.expectedReturnsTonight} students are scheduled to return prior to 20:00 curfew. ${stats.overdueCount > 0 ? `ALERT: ${stats.overdueCount} student(s) currently flagged overdue with guardian escalation initiated.` : 'Zero active curfew violations recorded.'} Verified parent confirmations logged: ${stats.parentCallsMade}.`;
  }

  try {
    const prompt = `
Generate a concise, professional 3-sentence Executive Operations Brief for the College Principal and Chief Warden based on these live metrics:
- Total Hostel Residents: ${stats.totalResidents}
- Currently Out on Pass: ${stats.currentlyOut}
- Passes Approved Today: ${stats.approvedToday}
- Scheduled Returns Tonight: ${stats.expectedReturnsTonight}
- Overdue Incidents: ${stats.overdueCount}
- Verified Parent Contact Logs: ${stats.parentCallsMade}

Highlight safety, gate discipline, and overdue escalation status concisely.
`;
    const response = await aiClient.models.generateContent({
      model: "gemini-3.8-flash",
      contents: prompt,
    });
    return response.text?.trim() || "Daily Operations Brief generated successfully.";
  } catch (err) {
    return `Operational Brief: ${stats.totalResidents} total residents monitored across 4 hostel blocks. ${stats.currentlyOut} students authorized out with parent notification logs verified. ${stats.overdueCount > 0 ? `Attention: ${stats.overdueCount} overdue incident(s) under security monitoring.` : 'All gate exits and returns operating normally within safety parameters.'}`;
  }
}
