import React from "react";
import {
  FileText,
  Download,
  Eye,
  CheckCircle2,
  Calendar,
  Sparkles,
  ShieldCheck,
} from "lucide-react";
import { PORTFOLIO_DATA } from "@/data/portfolioData";

interface ResumeSectionProps {
  onOpenResumeModal: () => void;
}

export const ResumeSection: React.FC<ResumeSectionProps> = ({ onOpenResumeModal }) => {
  return (
    <section id="resume" className="py-20 sm:py-24 bg-white dark:bg-slate-900 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="relative rounded-3xl bg-gradient-to-tr from-blue-900 via-indigo-900 to-slate-900 text-white p-8 sm:p-12 lg:p-16 overflow-hidden shadow-2xl">
          {/* Subtle background glow */}
          <div className="absolute top-0 right-0 w-96 h-96 bg-blue-500/20 rounded-full blur-3xl pointer-events-none" />

          <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            {/* Left Content */}
            <div className="lg:col-span-8 space-y-5">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/20 border border-blue-400/30 text-blue-200 text-xs font-semibold uppercase tracking-wider">
                <Sparkles className="w-3.5 h-3.5" />
                <span>Executive Curriculum Vitae</span>
              </div>

              <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-white">
                Download Official Resume
              </h2>

              <p className="text-sm sm:text-base text-blue-100/80 max-w-2xl leading-relaxed">
                Clean, ATS-compliant, and formatted for hiring committees, engineering directors, and technical recruiters. Includes full project breakdowns, verified certifications, and work history.
              </p>

              {/* Recruiter Quick Metrics */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 pt-2 text-xs">
                <div className="p-3 rounded-xl bg-white/10 backdrop-blur-sm border border-white/10">
                  <p className="text-blue-200">Availability</p>
                  <p className="font-bold text-white mt-0.5">Immediate / Active</p>
                </div>
                <div className="p-3 rounded-xl bg-white/10 backdrop-blur-sm border border-white/10">
                  <p className="text-blue-200">Experience</p>
                  <p className="font-bold text-white mt-0.5">Full-Stack & Cloud</p>
                </div>
                <div className="p-3 rounded-xl bg-white/10 backdrop-blur-sm border border-white/10 col-span-2 sm:col-span-1">
                  <p className="text-blue-200">Notice Period</p>
                  <p className="font-bold text-white mt-0.5">0 Days / Ready</p>
                </div>
              </div>
            </div>

            {/* Right Buttons */}
            <div className="lg:col-span-4 flex flex-col sm:flex-row lg:flex-col gap-3 justify-center">
              <button
                onClick={onOpenResumeModal}
                className="inline-flex items-center justify-center gap-2 px-6 py-4 rounded-xl font-bold text-sm text-slate-900 bg-white hover:bg-slate-100 active:scale-95 shadow-xl transition-all cursor-pointer"
                id="resume-section-preview-btn"
              >
                <Eye className="w-4 h-4 text-blue-600" />
                <span>Preview Resume Online</span>
              </button>

              <button
                onClick={onOpenResumeModal}
                className="inline-flex items-center justify-center gap-2 px-6 py-4 rounded-xl font-bold text-sm text-white bg-blue-600 hover:bg-blue-500 active:scale-95 border border-blue-400/40 shadow-lg shadow-blue-600/30 transition-all cursor-pointer"
                id="resume-section-download-btn"
              >
                <Download className="w-4 h-4" />
                <span>Download Resume (PDF / TXT)</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ResumeSection;
