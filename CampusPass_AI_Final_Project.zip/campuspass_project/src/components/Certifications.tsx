import { motion } from "framer-motion";
import { Award, ShieldCheck, Cpu } from "lucide-react";

const Certifications = () => {
  const certifications = [
    {
      title: "EcLearnix Hackthon 360",
      provider: "RSP Innovations",
      date: "December 2023",
      desc: "Certification highlighting collaborative problem-solving, real-time rapid software development, and UI/UX design skills."
    }
  ];

  return (
    <section id="certifications" className="py-24 px-4 relative">
      <div className="container mx-auto max-w-5xl relative z-10 font-mono">
        {/* Section Heading */}
        <motion.div
          initial={{ y: 30, opacity: 0 }}
          whileInView={{ y: 0, opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-5xl font-bold font-oxanium text-white tracking-widest uppercase text-glow-green">
            [ CERTIFICATE_REGISTRY ]
          </h2>
          <div className="w-24 h-1 bg-[#00FF66] mx-auto mt-3 rounded-full shadow-[0_0_10px_#00FF66]" />
        </motion.div>

        {/* Certifications Display */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-3xl mx-auto">
          {certifications.map((cert, idx) => (
            <motion.div
              key={idx}
              initial={{ scale: 0.95, opacity: 0 }}
              whileInView={{ scale: 1, opacity: 1 }}
              viewport={{ once: true }}
              className="bg-[#080808]/90 border border-[#00FF66]/20 hover:border-[#00FF66]/60 p-6 rounded-xl relative overflow-hidden transition-all duration-300 group hover:shadow-[0_0_15px_rgba(0,255,102,0.05)]"
            >
              {/* Background ambient lock icon */}
              <ShieldCheck className="absolute -right-6 -bottom-6 w-32 h-32 text-[#00FF66]/5 pointer-events-none" />

              <div className="flex items-start space-x-4">
                <div className="p-3 bg-[#00FF66]/10 text-[#00FF66] rounded-lg group-hover:bg-[#00FF66]/20 transition-all duration-300">
                  <Award className="w-6 h-6" />
                </div>
                <div className="space-y-2">
                  <h3 className="text-base md:text-lg font-bold text-white font-oxanium">
                    {cert.title}
                  </h3>
                  <div className="inline-block px-2.5 py-0.5 bg-[#00E5FF]/10 border border-[#00E5FF]/20 rounded-md text-[10px] text-[#00E5FF] font-bold uppercase">
                    {cert.provider}
                  </div>
                  <p className="text-xs text-gray-400 leading-relaxed pt-1">
                    {cert.desc}
                  </p>
                  <div className="text-[10px] text-[#FFC107] font-semibold pt-1">
                    DATE: {cert.date.toUpperCase()}
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Certifications;
