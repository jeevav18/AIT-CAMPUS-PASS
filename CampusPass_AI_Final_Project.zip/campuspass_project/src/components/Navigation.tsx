import { useState, useEffect } from "react";
import {
  Terminal,
  Volume2,
  VolumeX,
  Menu,
  X,
  Shield,
  Palette,
  ExternalLink,
  Lock,
} from "lucide-react";
import { playHover, playTick, toggleCyberAudio, getCyberAudioMuted } from "@/lib/cyberAudio";
import { PORTFOLIO_DATA } from "@/data/portfolioData";

interface NavigationProps {
  activeSection: string;
  onSectionClick: (id: string) => void;
  accentColor: "green" | "cyan" | "purple";
  onAccentChange: (accent: "green" | "cyan" | "purple") => void;
}

export const Navigation = ({
  activeSection,
  onSectionClick,
  accentColor,
  onAccentChange,
}: NavigationProps) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isMuted, setIsMuted] = useState(getCyberAudioMuted());

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 40);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navItems = [
    { id: "home", label: "HOME" },
    { id: "about", label: "ABOUT" },
    { id: "skills", label: "SKILLS" },
    { id: "projects", label: "PROJECTS" },
    { id: "experience", label: "EXPERIENCE" },
    { id: "certifications", label: "CERTS" },
    { id: "terminal", label: "CLI" },
    { id: "contact", label: "CONTACT" },
  ];

  const handleSoundToggle = () => {
    const muted = toggleCyberAudio();
    setIsMuted(muted);
    if (!muted) playTick();
  };

  const cycleAccent = () => {
    playTick();
    const order: ("green" | "cyan" | "purple")[] = ["green", "cyan", "purple"];
    const nextIdx = (order.indexOf(accentColor) + 1) % order.length;
    onAccentChange(order[nextIdx]);
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-[9000] transition-all duration-300 font-mono ${
        isScrolled
          ? "bg-black/90 backdrop-blur-md border-b border-[#00FF66]/30 py-3 shadow-[0_4px_20px_rgba(0,0,0,0.8)]"
          : "bg-transparent py-5"
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 flex items-center justify-between">
        {/* Brand Codename Logo & Avatar */}
        <button
          onClick={() => {
            playTick();
            onSectionClick("home");
          }}
          className="flex items-center space-x-2.5 text-left group cursor-pointer"
        >
          <div className="relative w-9 h-9 rounded-lg border border-[#00FF66] bg-black/80 flex items-center justify-center text-[#00FF66] font-mono font-bold text-xs shadow-[0_0_12px_rgba(0,255,102,0.3)] group-hover:scale-105 transition">
            JV
          </div>
          <div>
            <div className="font-bebas text-2xl tracking-widest text-white group-hover:text-[#00FF66] transition">
              &gt;_JEEVA_18
            </div>
            <div className="text-[9px] text-[#00E5FF] tracking-wider -mt-1 font-bold">
              SYS_OPERATING_PORTFOLIO
            </div>
          </div>
        </button>

        {/* Desktop Nav Links */}
        <nav className="hidden lg:flex items-center space-x-1 bg-black/60 border border-zinc-800 rounded-full px-3 py-1.5 backdrop-blur-sm">
          {navItems.map((item) => {
            const isActive = activeSection === item.id;
            return (
              <button
                key={item.id}
                onMouseEnter={playHover}
                onClick={() => {
                  playTick();
                  onSectionClick(item.id);
                }}
                className={`px-3 py-1 rounded-full text-xs font-bold uppercase transition duration-150 cursor-pointer ${
                  isActive
                    ? "bg-[#00FF66]/20 text-[#00FF66] border border-[#00FF66]/40 shadow-[0_0_10px_rgba(0,255,102,0.2)]"
                    : "text-gray-400 hover:text-white hover:bg-white/5 border border-transparent"
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </nav>

        {/* Action Controls: Sound & Theme Accent & Mobile Hamburger */}
        <div className="flex items-center space-x-2.5">
          {/* Accent Color Switcher */}
          <button
            onClick={cycleAccent}
            onMouseEnter={playHover}
            className="p-2 rounded-lg bg-black/70 border border-zinc-800 hover:border-[#00E5FF] text-gray-300 transition cursor-pointer flex items-center space-x-1 text-xs"
            title={`Current Accent: ${accentColor.toUpperCase()} (Click to toggle)`}
          >
            <Palette className="w-3.5 h-3.5" />
            <span
              className={`w-2 h-2 rounded-full ${
                accentColor === "green"
                  ? "bg-[#00FF66]"
                  : accentColor === "cyan"
                  ? "bg-[#00E5FF]"
                  : "bg-[#BF5AF2]"
              }`}
            />
          </button>

          {/* Sound Toggle */}
          <button
            onClick={handleSoundToggle}
            onMouseEnter={playHover}
            className="p-2 rounded-lg bg-black/70 border border-zinc-800 hover:border-[#00FF66] text-gray-300 hover:text-[#00FF66] transition cursor-pointer"
            title={isMuted ? "Unmute Cyber Audio" : "Mute Cyber Audio"}
          >
            {isMuted ? <VolumeX className="w-4 h-4 text-red-400" /> : <Volume2 className="w-4 h-4 text-[#00FF66]" />}
          </button>

          {/* Terminal Quick Button */}
          <button
            onClick={() => {
              playTick();
              onSectionClick("terminal");
            }}
            onMouseEnter={playHover}
            className="hidden sm:flex items-center space-x-1.5 px-3 py-1.5 rounded-lg bg-[#00FF66]/10 hover:bg-[#00FF66]/20 border border-[#00FF66]/40 text-[#00FF66] text-xs font-bold transition cursor-pointer"
          >
            <Terminal className="w-3.5 h-3.5" />
            <span>CLI</span>
          </button>

          {/* Mobile Menu Hamburger */}
          <button
            onClick={() => {
              playTick();
              setIsMobileMenuOpen(!isMobileMenuOpen);
            }}
            className="lg:hidden p-2 rounded-lg bg-black/70 border border-zinc-800 text-gray-300 hover:text-white"
          >
            {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {isMobileMenuOpen && (
        <div className="lg:hidden bg-black/95 border-b border-[#00FF66]/30 px-6 py-6 space-y-3 shadow-2xl backdrop-blur-lg">
          <div className="grid grid-cols-2 gap-2">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => {
                  playTick();
                  onSectionClick(item.id);
                  setIsMobileMenuOpen(false);
                }}
                className={`py-2.5 px-4 rounded-lg text-xs font-bold uppercase text-left transition border ${
                  activeSection === item.id
                    ? "bg-[#00FF66]/20 border-[#00FF66] text-[#00FF66]"
                    : "bg-zinc-950 border-zinc-800 text-gray-400"
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>
        </div>
      )}
    </header>
  );
};
export default Navigation;
