import React, { useRef } from "react";
import { PassRequest } from "@/types/campuspass";
import { QRCodeSVG } from "qrcode.react";
import { 
  X, 
  Printer, 
  Download, 
  Copy, 
  ShieldCheck, 
  Building, 
  CheckCircle2, 
  FileText,
  HeartHandshake
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { AdithyaLogo } from "./AdithyaLogo";
import { toast } from "sonner";

interface PaperPassSlipModalProps {
  pass: PassRequest | null;
  isOpen: boolean;
  onClose: () => void;
}

export const PaperPassSlipModal: React.FC<PaperPassSlipModalProps> = ({
  pass,
  isOpen,
  onClose,
}) => {
  const printRef = useRef<HTMLDivElement>(null);

  if (!isOpen || !pass) return null;

  const handlePrint = () => {
    window.print();
  };

  const handleCopySlipSummary = () => {
    const text = `
ADITHYA INSTITUTE OF TECHNOLOGY (TNEA: 2744)
OFFICIAL HOSTEL OUTING PASS: ${pass.passNumber}
Student: ${pass.studentName} (${pass.rollNumber})
Department: ${pass.department} - Year ${pass.year}
Hostel: ${pass.hostelBlock} - Room ${pass.roomNumber}
Destination: ${pass.destination}
Departure: ${new Date(pass.departureDateTime).toLocaleString()}
Return Curfew: ${new Date(pass.expectedReturnDateTime).toLocaleString()}
Parent: ${pass.guardian.name} (${pass.guardian.phone}) - Verified
Signatures: Tutor [OK], HOD [OK], Chief Warden [OK]
Token: ${pass.qrToken || "ISSUED"}
    `.trim();

    navigator.clipboard.writeText(text);
    toast.success("Paper pass details copied to clipboard.");
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/70 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-slate-100 rounded-3xl max-w-3xl w-full max-h-[95vh] flex flex-col shadow-2xl border border-slate-300 overflow-hidden dark:bg-slate-900 dark:border-slate-800">
        
        {/* Modal Controls Bar (hidden during physical print) */}
        <div className="p-4 bg-slate-900 text-white flex items-center justify-between border-b border-slate-800 print:hidden">
          <div className="flex items-center gap-2">
            <FileText className="h-5 w-5 text-orange-400" />
            <div>
              <h3 className="font-bold text-sm leading-tight">
                Official Paper Pass Slip Preview
              </h3>
              <p className="text-[11px] text-slate-400">
                Printable Institutional Outing / Home Leave Slip (Form AIT/HOSTEL/OP-04)
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Button
              size="sm"
              variant="outline"
              onClick={handleCopySlipSummary}
              className="text-xs bg-slate-800 border-slate-700 text-slate-200 hover:bg-slate-700 gap-1.5 h-8"
            >
              <Copy className="h-3.5 w-3.5" />
              Copy Text
            </Button>
            <Button
              size="sm"
              onClick={handlePrint}
              className="text-xs bg-orange-600 hover:bg-orange-700 text-white font-bold gap-1.5 h-8 shadow"
            >
              <Printer className="h-3.5 w-3.5" />
              Print Paper Slip (A4)
            </Button>
            <button
              onClick={onClose}
              className="text-slate-400 hover:text-white p-1.5 rounded-lg hover:bg-slate-800 ml-1"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* PRINTABLE PHYSICAL PAPER SLIP (Standard Institutional Form Layout) */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-8 bg-slate-200/60 dark:bg-slate-950 flex justify-center">
          
          <div
            ref={printRef}
            className="bg-white text-slate-900 max-w-2xl w-full p-6 sm:p-8 rounded-xl shadow-lg border border-slate-300 relative text-xs space-y-4 font-sans select-text print:p-0 print:border-none print:shadow-none"
            style={{ minHeight: "680px" }}
          >
            {/* Background Watermark */}
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-[0.03]">
              <span className="font-serif font-black text-7xl text-slate-900 rotate-[-30deg]">
                ADITHYA
              </span>
            </div>

            {/* Official Letterhead */}
            <div className="border-b-2 border-slate-900 pb-3 flex items-start justify-between gap-4">
              <div className="flex items-start gap-3">
                <AdithyaLogo size="lg" showText={false} />
                <div>
                  <h1 className="font-serif font-black text-base sm:text-lg text-slate-900 tracking-tight leading-tight">
                    ADITHYA INSTITUTE OF TECHNOLOGY
                  </h1>
                  <p className="text-[10px] text-slate-600 font-medium">
                    (Autonomous • Affiliated to Anna University • Approved by AICTE • NAAC Accredited)
                  </p>
                  <p className="text-[10px] text-slate-600">
                    SF No. 344, 349, Sathy Main Road, Kurumbapalayam Post, Coimbatore - 641107
                  </p>
                  <p className="text-[10px] font-mono text-orange-700 font-bold mt-0.5">
                    TNEA COUNSELLING CODE: 2744 • PHONE: 0422-2654504
                  </p>
                </div>
              </div>

              <div className="text-right shrink-0">
                <span className="inline-block bg-slate-900 text-white text-[9px] font-bold px-2 py-0.5 rounded uppercase tracking-wider">
                  STUDENT & GATE COPY
                </span>
                <div className="font-mono text-xs font-bold text-slate-900 mt-1">
                  {pass.passNumber}
                </div>
                <div className="text-[10px] text-slate-500 font-mono">
                  FORM: AIT/HOSTEL/OP-04
                </div>
              </div>
            </div>

            {/* Title Bar */}
            <div className="bg-slate-100 border border-slate-300 py-1.5 px-3 rounded text-center">
              <h2 className="font-bold text-xs uppercase tracking-wider text-slate-800">
                OFFICIAL HOSTEL OUTING & HOME LEAVE GATE PASS
              </h2>
            </div>

            {/* Student Profile & Pass Meta Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-12 gap-4 pb-2 border-b border-slate-200">
              
              {/* Photo Box */}
              <div className="sm:col-span-3 flex flex-col items-center justify-center p-2 border border-slate-300 rounded bg-slate-50">
                <img
                  src={pass.avatarUrl}
                  alt={pass.studentName}
                  className="h-24 w-20 object-cover rounded border border-slate-300"
                />
                <span className="text-[9px] text-emerald-700 font-bold uppercase tracking-wider mt-1">
                  ✓ VERIFIED RESIDENT
                </span>
              </div>

              {/* Data Table */}
              <div className="sm:col-span-9 space-y-1.5 text-xs">
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <span className="text-[10px] text-slate-500 font-semibold uppercase block">STUDENT NAME</span>
                    <strong className="text-slate-900 text-sm">{pass.studentName}</strong>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-500 font-semibold uppercase block">ROLL NUMBER</span>
                    <strong className="font-mono text-orange-700 text-sm">{pass.rollNumber}</strong>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2 pt-1">
                  <div>
                    <span className="text-[10px] text-slate-500 font-semibold uppercase block">DEPARTMENT & YEAR</span>
                    <span className="text-slate-800 font-medium">{pass.department} (Year {pass.year})</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-500 font-semibold uppercase block">HOSTEL & ROOM</span>
                    <span className="text-slate-800 font-medium">{pass.hostelBlock.split("(")[0]} — Room {pass.roomNumber}</span>
                  </div>
                </div>

                <div className="pt-1">
                  <span className="text-[10px] text-slate-500 font-semibold uppercase block">CATEGORY OF LEAVE</span>
                  <span className="inline-block bg-orange-100 text-orange-900 font-bold text-[10px] px-2 py-0.5 rounded capitalize">
                    {pass.passType.replace("_", " ")}
                  </span>
                </div>
              </div>

            </div>

            {/* Schedule & Movement Parameters */}
            <div className="grid grid-cols-2 gap-3 p-3 bg-slate-50 rounded border border-slate-200 text-xs">
              <div>
                <span className="text-[10px] font-bold text-slate-500 uppercase block">PERMITTED DEPARTURE</span>
                <span className="font-bold text-slate-900">
                  {new Date(pass.departureDateTime).toLocaleDateString([], { month: "short", day: "numeric", year: "numeric" })}
                </span>
                <div className="font-mono font-bold text-blue-700">
                  {new Date(pass.departureDateTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} HRS
                </div>
              </div>

              <div>
                <span className="text-[10px] font-bold text-slate-500 uppercase block">MANDATORY RETURN CURFEW</span>
                <span className="font-bold text-slate-900">
                  {new Date(pass.expectedReturnDateTime).toLocaleDateString([], { month: "short", day: "numeric", year: "numeric" })}
                </span>
                <div className="font-mono font-bold text-red-700">
                  {new Date(pass.expectedReturnDateTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} HRS
                </div>
              </div>
            </div>

            {/* Destination & Purpose */}
            <div className="space-y-1 text-xs p-2.5 border border-slate-200 rounded">
              <div>
                <strong className="text-slate-800">Authorized Destination: </strong>
                <span className="text-slate-700">{pass.destination}</span>
              </div>
              <div>
                <strong className="text-slate-800">Stated Purpose: </strong>
                <span className="text-slate-600">{pass.reason}</span>
              </div>
              <div>
                <strong className="text-slate-800">Contact Number While Out: </strong>
                <span className="font-mono text-slate-700">{pass.destinationContact || pass.studentPhone}</span>
              </div>
            </div>

            {/* Parent Guardian Verification Undertaking */}
            <div className="p-2.5 bg-teal-50 border border-teal-200 rounded text-xs text-teal-950 space-y-1">
              <div className="flex items-center justify-between">
                <span className="font-bold text-[11px] flex items-center gap-1.5">
                  <HeartHandshake className="h-3.5 w-3.5 text-teal-700" />
                  Primary Guardian Clearance Record
                </span>
                <Badge variant="outline" className="border-teal-400 text-teal-800 text-[9px]">
                  WhatsApp & Telephonic Consent ✓
                </Badge>
              </div>
              <p className="text-[11px] text-teal-900">
                Guardian: <strong>{pass.guardian.name}</strong> ({pass.guardian.relation}) • Phone: <span className="font-mono font-semibold">{pass.guardian.phone}</span>
              </p>
              <p className="text-[10px] text-teal-800 italic">
                Notes: {pass.parentConsentNotes || "Verbal call confirmation verified by Class Mentor."}
              </p>
            </div>

            {/* Three Institutional Clearance Seals (Tutor, HOD, Warden) */}
            <div className="pt-2">
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 block mb-1">
                Institutional Authority Signatures & Clearance Seals:
              </span>

              <div className="grid grid-cols-3 gap-2 text-center text-[10px]">
                
                {/* Tutor */}
                <div className="p-2 border border-slate-300 rounded bg-slate-50 space-y-1">
                  <span className="font-bold text-slate-700 block">CLASS TUTOR</span>
                  <div className="text-emerald-700 font-bold font-mono">
                    {pass.approvalWorkflow.tutor.status === "approved" ? "APPROVED ✓" : "PENDING"}
                  </div>
                  <div className="text-[9px] text-slate-500 truncate">
                    {pass.approvalWorkflow.tutor.officerName || "Class Mentor"}
                  </div>
                  <div className="border-t border-slate-300 pt-0.5 text-[8px] text-slate-400">
                    Attendance Verified
                  </div>
                </div>

                {/* HOD */}
                <div className="p-2 border border-slate-300 rounded bg-slate-50 space-y-1">
                  <span className="font-bold text-slate-700 block">DEPT HOD</span>
                  <div className="text-emerald-700 font-bold font-mono">
                    {pass.approvalWorkflow.hod.status === "approved" ? "CLEARED ✓" : "PENDING"}
                  </div>
                  <div className="text-[9px] text-slate-500 truncate">
                    {pass.approvalWorkflow.hod.officerName || "Head of Dept"}
                  </div>
                  <div className="border-t border-slate-300 pt-0.5 text-[8px] text-slate-400">
                    No Lab/Exam Conflict
                  </div>
                </div>

                {/* Chief Warden */}
                <div className="p-2 border-2 border-orange-400 rounded bg-orange-50/50 space-y-1">
                  <span className="font-bold text-orange-950 block">CHIEF WARDEN</span>
                  <div className="text-orange-700 font-bold font-mono">
                    {pass.approvalWorkflow.warden.status === "approved" ? "OFFICIAL SEAL ✓" : "PENDING"}
                  </div>
                  <div className="text-[9px] text-slate-700 truncate font-semibold">
                    {pass.approvalWorkflow.warden.officerName || "Hostel Warden"}
                  </div>
                  <div className="border-t border-orange-200 pt-0.5 text-[8px] text-orange-800">
                    Hostel Register Stamped
                  </div>
                </div>

              </div>
            </div>

            {/* Gate Security Checkpoint & QR Box */}
            <div className="p-3 border-2 border-dashed border-slate-300 rounded flex items-center justify-between gap-4 bg-slate-50">
              <div className="space-y-1 text-xs">
                <span className="font-bold text-slate-900 text-[11px] block">
                  SECURITY GATE CHECKPOINT (MAIN ENTRANCE / NORTH GATE)
                </span>
                <p className="text-[10px] text-slate-600">
                  Actual Exit Time: <span className="font-mono font-bold">{pass.actualExitDateTime ? new Date(pass.actualExitDateTime).toLocaleTimeString() : "________________"}</span> (Guard Initials: ________)
                </p>
                <p className="text-[10px] text-slate-600">
                  Actual Return Time: <span className="font-mono font-bold">{pass.actualEntryDateTime ? new Date(pass.actualEntryDateTime).toLocaleTimeString() : "________________"}</span> (Guard Initials: ________)
                </p>
                <p className="text-[9px] text-slate-400">
                  Security Officers: Scan dynamic QR on physical departure and arrival.
                </p>
              </div>

              <div className="shrink-0 text-center">
                <div className="p-1.5 bg-white border border-slate-300 rounded inline-block">
                  <QRCodeSVG
                    value={pass.qrToken || `AIT-${pass.passNumber}`}
                    size={80}
                    level="M"
                  />
                </div>
                <span className="text-[8px] font-mono block text-slate-500 mt-0.5">
                  {(pass.qrToken || pass.passNumber).slice(0, 16)}...
                </span>
              </div>
            </div>

            {/* Student Declaration & Footer */}
            <div className="text-[9px] text-slate-500 leading-tight border-t border-slate-200 pt-2 space-y-1">
              <p>
                <strong>Student Undertaking:</strong> I hereby declare that I will strictly abide by the rules of Adithya Institute of Technology, adhere to the curfew timing of 19:30 HRS, and take full personal responsibility during the outing.
              </p>
              <div className="flex justify-between items-end pt-3 text-slate-700">
                <span>Student Signature: _______________________</span>
                <span>Security Officer Seal: _______________________</span>
              </div>
            </div>

          </div>

        </div>

      </div>
    </div>
  );
};
