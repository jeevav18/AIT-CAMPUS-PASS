import React from "react";
import { UserRole, PassRequest } from "@/types/campuspass";
import { 
  GraduationCap, 
  UserCheck, 
  Building2, 
  KeyRound, 
  Crown, 
  Scan, 
  HeartHandshake
} from "lucide-react";

interface RoleSwitcherProps {
  currentRole: UserRole;
  onSelectRole: (role: UserRole) => void;
  passes: PassRequest[];
}

export const RoleSwitcher: React.FC<RoleSwitcherProps> = ({
  currentRole,
  onSelectRole,
  passes,
}) => {
  // Compute pending items for badge counts
  const tutorPending = passes.filter((p) => p.status === "pending_tutor").length;
  const hodPending = passes.filter((p) => p.status === "pending_hod").length;
  const wardenPending = passes.filter((p) => p.status === "pending_warden").length;
  const gateReady = passes.filter((p) => p.status === "approved" || p.status === "active_out").length;
  const parentAlerts = passes.filter((p) => p.parentConsentStatus === "pending").length;

  const roles = [
    {
      id: "student" as UserRole,
      title: "Student",
      subtitle: "Pass Application & QR View",
      name: "Aravind (22CS104)",
      icon: GraduationCap,
      color: "blue",
      badge: undefined,
    },
    {
      id: "parent" as UserRole,
      title: "Parent Portal",
      subtitle: "Consent & Movement Tracking",
      name: "Mr. Swaminathan (Father)",
      icon: HeartHandshake,
      color: "teal",
      badge: parentAlerts > 0 ? `${parentAlerts} Action` : undefined,
    },
    {
      id: "tutor" as UserRole,
      title: "Class Tutor",
      subtitle: "Attendance & Parent Call",
      name: "Dr. K. Senthil Kumar",
      icon: UserCheck,
      color: "indigo",
      badge: tutorPending > 0 ? `${tutorPending} Pending` : undefined,
    },
    {
      id: "hod" as UserRole,
      title: "Dept HOD",
      subtitle: "Lab & Academic Clearance",
      name: "Dr. M. Radhika",
      icon: Building2,
      color: "purple",
      badge: hodPending > 0 ? `${hodPending} Review` : undefined,
    },
    {
      id: "warden" as UserRole,
      title: "Chief Warden",
      subtitle: "Hostel Register & QR Issuance",
      name: "Prof. S. Ranganathan",
      icon: KeyRound,
      color: "amber",
      badge: wardenPending > 0 ? `${wardenPending} Issue QR` : undefined,
    },
    {
      id: "principal" as UserRole,
      title: "Principal",
      subtitle: "Oversight & Emergency Bypass",
      name: "Dr. K. Ramanathan",
      icon: Crown,
      color: "rose",
      badge: undefined,
    },
    {
      id: "guard" as UserRole,
      title: "Gate Security",
      subtitle: "Dynamic QR Scanner & Log",
      name: "Havaldar R. Murugesan",
      icon: Scan,
      color: "emerald",
      badge: gateReady > 0 ? `${gateReady} Ready` : undefined,
    },
  ];

  return (
    <div className="bg-slate-900 border-b border-slate-800 text-white py-2.5 px-4 overflow-x-auto shadow-inner">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-4 min-w-max">
        <div className="flex items-center gap-2 pr-3 border-r border-slate-800 shrink-0">
          <div className="h-2 w-2 rounded-full bg-emerald-400 animate-ping" />
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
            Switch Persona:
          </span>
        </div>

        <div className="flex items-center gap-2">
          {roles.map((r) => {
            const Icon = r.icon;
            const isSelected = currentRole === r.id;
            return (
              <button
                key={r.id}
                onClick={() => onSelectRole(r.id)}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all relative ${
                  isSelected
                    ? "bg-blue-600 text-white shadow-md shadow-blue-500/25 ring-2 ring-blue-400/50"
                    : "bg-slate-800/80 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-700/60"
                }`}
              >
                <Icon className={`h-3.5 w-3.5 ${isSelected ? "text-white" : "text-slate-400"}`} />
                <div className="text-left">
                  <div className="flex items-center gap-1.5">
                    <span>{r.title}</span>
                    {r.badge && (
                      <span className="bg-amber-500 text-black text-[9px] font-extrabold px-1.5 py-0.2 rounded-full">
                        {r.badge}
                      </span>
                    )}
                  </div>
                  <div className="text-[10px] text-slate-400 font-normal leading-tight hidden lg:block">
                    {r.name}
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
