import { useState, useEffect } from "react";
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar } from "recharts";
import { ShieldCheck, Cpu, Database, Award, Clock, ArrowUpRight, GitBranch } from "lucide-react";

const OSDashboard = () => {
  const [visitorCount, setVisitorCount] = useState(1337);
  const [salesforceHealth, setSalesforceHealth] = useState(99.9);
  const [cpuUsage, setCpuUsage] = useState(24);
  const [ramUsage, setRamUsage] = useState(48);

  // Simulated metrics updating
  useEffect(() => {
    const timer = setInterval(() => {
      setCpuUsage((prev) => {
        const val = prev + Math.floor(Math.random() * 11) - 5;
        return Math.min(Math.max(val, 8), 65);
      });
      setRamUsage((prev) => {
        const val = prev + Math.floor(Math.random() * 5) - 2;
        return Math.min(Math.max(val, 42), 55);
      });
      setSalesforceHealth((prev) => {
        const jitter = Math.random() < 0.1 ? (Math.random() * 0.2 - 0.1) : 0;
        return parseFloat(Math.min(Math.max(prev + jitter, 99.4), 100).toFixed(2));
      });
      setVisitorCount((prev) => prev + (Math.random() < 0.3 ? 1 : 0));
    }, 4000);

    return () => clearInterval(timer);
  }, []);

  const codingPerformanceData = [
    { name: "Mon", commits: 4, apex: 120, react: 80 },
    { name: "Tue", commits: 6, apex: 150, react: 110 },
    { name: "Wed", commits: 8, apex: 220, react: 95 },
    { name: "Thu", commits: 5, apex: 180, react: 130 },
    { name: "Fri", commits: 9, apex: 310, react: 170 },
    { name: "Sat", commits: 12, apex: 450, react: 240 },
    { name: "Sun", commits: 7, apex: 190, react: 150 },
  ];

  const skillRadarData = [
    { subject: "Apex Controllers", A: 90, fullMark: 100 },
    { subject: "LWC DOM", A: 85, fullMark: 100 },
    { subject: "SOQL Indexing", A: 88, fullMark: 100 },
    { subject: "React Hooks", A: 80, fullMark: 100 },
    { subject: "Flow Architectures", A: 95, fullMark: 100 },
    { subject: "REST Integrations", A: 85, fullMark: 100 },
  ];

  return (
    <div className="space-y-6 font-mono text-xs">
      {/* Upper Diagnostics Bento Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <div className="bg-black/60 border border-[#00FF66]/20 p-3.5 rounded-lg flex flex-col justify-between">
          <div className="flex items-center justify-between text-gray-500 font-bold uppercase text-[9px]">
            <span>SYSTEM_CPU:</span>
            <Cpu className="w-3.5 h-3.5 text-[#00FF66]" />
          </div>
          <div className="mt-2 text-xl font-bold text-white font-oxanium text-glow-green">
            {cpuUsage}% <span className="text-[10px] text-gray-500 font-mono">NOMINAL</span>
          </div>
        </div>

        <div className="bg-black/60 border border-[#00E5FF]/20 p-3.5 rounded-lg flex flex-col justify-between">
          <div className="flex items-center justify-between text-gray-500 font-bold uppercase text-[9px]">
            <span>RAM_BUFFER:</span>
            <Clock className="w-3.5 h-3.5 text-[#00E5FF]" />
          </div>
          <div className="mt-2 text-xl font-bold text-white font-oxanium text-glow-green">
            {ramUsage}% <span className="text-[10px] text-gray-500 font-mono">ACTIVE</span>
          </div>
        </div>

        <div className="bg-black/60 border border-[#FFC107]/20 p-3.5 rounded-lg flex flex-col justify-between">
          <div className="flex items-center justify-between text-gray-500 font-bold uppercase text-[9px]">
            <span>CRM_GRID_SFDC:</span>
            <Database className="w-3.5 h-3.5 text-[#FFC107]" />
          </div>
          <div className="mt-2 text-xl font-bold text-white font-oxanium text-glow-green">
            {salesforceHealth}% <span className="text-[10px] text-gray-500 font-mono">LIVE</span>
          </div>
        </div>

        <div className="bg-black/60 border border-[#00FF66]/20 p-3.5 rounded-lg flex flex-col justify-between">
          <div className="flex items-center justify-between text-gray-500 font-bold uppercase text-[9px]">
            <span>LOGGED_CLIENTS:</span>
            <ShieldCheck className="w-3.5 h-3.5 text-[#00FF66]" />
          </div>
          <div className="mt-2 text-xl font-bold text-[#00FF66] font-oxanium text-glow-green">
            0x{visitorCount.toString(16).toUpperCase()} <span className="text-[9px] text-gray-500 font-mono">({visitorCount})</span>
          </div>
        </div>
      </div>

      {/* Charts section split in two columns */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
        {/* Weekly Productivity Lines Chart */}
        <div className="md:col-span-7 bg-black/50 border border-[#00FF66]/15 rounded-lg p-4 space-y-3">
          <div className="flex items-center justify-between border-b border-[#00FF66]/10 pb-2">
            <span className="font-bold text-[#00FF66] uppercase text-[10px] tracking-wider font-oxanium">Productivity Matrix & Logs</span>
            <span className="text-[9px] text-gray-500 font-bold uppercase flex items-center space-x-1">
              <GitBranch className="w-3 h-3 text-[#00E5FF]" />
              <span>GITHUB STREAM: ACTIVE</span>
            </span>
          </div>
          <div className="h-44 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={codingPerformanceData} margin={{ top: 5, right: 5, left: -25, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorApex" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#00FF66" stopOpacity={0.2}/>
                    <stop offset="95%" stopColor="#00FF66" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorReact" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#00E5FF" stopOpacity={0.2}/>
                    <stop offset="95%" stopColor="#00E5FF" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <XAxis dataKey="name" stroke="#555" fontSize={9} />
                <YAxis stroke="#555" fontSize={9} />
                <Tooltip
                  contentStyle={{ backgroundColor: "#050505", border: "1px solid #00FF66", color: "#fff", fontFamily: "monospace", fontSize: 10 }}
                />
                <Area type="monotone" dataKey="apex" name="Apex Codes" stroke="#00FF66" fillOpacity={1} fill="url(#colorApex)" strokeWidth={1.5} />
                <Area type="monotone" dataKey="react" name="React Elements" stroke="#00E5FF" fillOpacity={1} fill="url(#colorReact)" strokeWidth={1.5} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Skill Core Focus Radar Diagram */}
        <div className="md:col-span-5 bg-black/50 border border-[#00FF66]/15 rounded-lg p-4 space-y-3 flex flex-col justify-between">
          <div className="flex items-center justify-between border-b border-[#00FF66]/10 pb-2">
            <span className="font-bold text-[#FFC107] uppercase text-[10px] tracking-wider font-oxanium">Skill Balance Vector</span>
            <Award className="w-3.5 h-3.5 text-[#FFC107]" />
          </div>
          <div className="h-44 w-full flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <RadarChart cx="50%" cy="50%" r="70%" data={skillRadarData}>
                <PolarGrid stroke="#222" />
                <PolarAngleAxis dataKey="subject" stroke="#777" fontSize={8} />
                <PolarRadiusAxis angle={30} domain={[0, 100]} stroke="#222" tick={false} />
                <Radar name="Proficiency" dataKey="A" stroke="#FFC107" fill="#FFC107" fillOpacity={0.15} />
              </RadarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Salesforce Governor Limits Telemetry HUD */}
      <div className="bg-black/40 border border-[#00FF66]/15 rounded-lg p-4 space-y-3">
        <h4 className="text-[10px] font-bold text-white uppercase tracking-wider font-oxanium text-glow-green border-b border-zinc-800 pb-2">
          SALESFORCE GOVERNOR HARDWARE BYPASS TELEMETRY
        </h4>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-[10px]">
          <div className="space-y-1.5">
            <div className="flex justify-between font-bold text-gray-400">
              <span>SOQL INDEX QUERY LIMIT:</span>
              <span className="text-[#00FF66]">18 / 100 QUERIES</span>
            </div>
            <div className="h-1.5 w-full bg-zinc-900 rounded-full overflow-hidden">
              <div className="h-full bg-[#00FF66]" style={{ width: "18%" }} />
            </div>
          </div>

          <div className="space-y-1.5">
            <div className="flex justify-between font-bold text-gray-400">
              <span>APEX TRANS HEAP METRIC:</span>
              <span className="text-[#00E5FF]">2.14 / 6.00 MB</span>
            </div>
            <div className="h-1.5 w-full bg-zinc-900 rounded-full overflow-hidden">
              <div className="h-full bg-[#00E5FF]" style={{ width: "35%" }} />
            </div>
          </div>

          <div className="space-y-1.5">
            <div className="flex justify-between font-bold text-gray-400">
              <span>ASYNC DML EXECUTIONS:</span>
              <span className="text-[#FFC107]">45 / 150 Limit</span>
            </div>
            <div className="h-1.5 w-full bg-zinc-900 rounded-full overflow-hidden">
              <div className="h-full bg-[#FFC107]" style={{ width: "30%" }} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default OSDashboard;
