import React, { useState, useRef, useEffect } from "react";
import { Terminal, ShieldAlert, ShieldCheck, Activity } from "lucide-react";
import { playTick, playSuccessChime, playGlitchSweep, playHover } from "@/lib/cyberAudio";

interface CommandLog {
  command: string;
  output: string;
  type: "input" | "system" | "error" | "success" | "matrix" | "hacker";
}

const TerminalWidget = () => {
  const [history, setHistory] = useState<CommandLog[]>([
    {
      command: "",
      output: "WELCOME TO >_JEEVA_18 INTERACTIVE TERMINAL v3.0\nType 'help' to see the list of available commands.\nType 'hack' or 'sysinfo' for advanced core diagnostics.",
      type: "system",
    },
  ]);
  const [inputVal, setInputVal] = useState("");
  const [isSimulating, setIsSimulating] = useState(false);
  const terminalEndRef = useRef<HTMLDivElement | null>(null);
  const inputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    terminalEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [history]);

  const focusInput = () => {
    inputRef.current?.focus();
  };

  // Advanced real-time SFDC/Kali Bypassing Simulator
  const runHackSimulation = () => {
    setIsSimulating(true);
    playGlitchSweep();
    
    let currentStep = 0;
    const steps = [
      { text: "\n[!] DETECTING TARGET CLOUD: salesforce.com/org/jeeva-v-portal", delay: 100 },
      { text: "[*] ATTEMPTING BYPASS OF GOVERNOR LIMIT PROTOCOLS...", delay: 500 },
      { text: "[+] CONNECTING SOCKETS AND EXECUTING APEX TRACE MAPPER...", delay: 1000 },
      { text: "    > Injected Trigger Bypass: overrideGovernorLimits()", delay: 1300 },
      { text: "    > Intercepting SOQL Query Pool: SELECT Id, Name FROM Skill__c LIMIT 100", delay: 1600 },
      { text: "    > Decrypting Database Indices (Sec-SHA256)...", delay: 2000 },
      { text: "    > [0x7F9A0C] Sector mapped. Bypass complete.", delay: 2200 },
      { text: "[*] BYPASS SUCCESSFUL. STREAMING SECURE DATA CHUNK:", delay: 2600 },
      { text: "    { name: 'Jeeva V', status: 'Core Salesforce Engineer', trust_score: 99.8 }", delay: 3000 },
      { text: "[+] ACCESS GRANTED. SYSTEM SECURE.", delay: 3500 },
    ];

    const triggerNextStep = () => {
      if (currentStep < steps.length) {
        const step = steps[currentStep];
        setTimeout(() => {
          setHistory((prev) => [
            ...prev,
            { command: "", output: step.text, type: "hacker" }
          ]);
          playTick();
          currentStep++;
          triggerNextStep();
        }, step.delay - (currentStep > 0 ? steps[currentStep - 1].delay : 0));
      } else {
        setIsSimulating(false);
        setTimeout(() => playSuccessChime(), 300);
      }
    };

    triggerNextStep();
  };

  // Matrix Falling Code Streamer inside Terminal Window
  const runMatrixRainStream = () => {
    setIsSimulating(true);
    playGlitchSweep();
    
    let iterations = 0;
    const maxIterations = 8;
    const characters = "01ABCDEFGHIJKLMNOPQRSTUVWXYZ@#$%&*+=-";

    const interval = setInterval(() => {
      let rainLine = "";
      for (let i = 0; i < 4; i++) {
        const wordLength = Math.floor(Math.random() * 8) + 4;
        let word = "";
        for (let j = 0; j < wordLength; j++) {
          word += characters[Math.floor(Math.random() * characters.length)];
        }
        rainLine += "   " + word + "   ";
      }

      setHistory((prev) => [
        ...prev,
        { command: "", output: rainLine, type: "matrix" }
      ]);
      playTick();
      iterations++;

      if (iterations >= maxIterations) {
        clearInterval(interval);
        setHistory((prev) => [
          ...prev,
          { command: "", output: "\n[+] MATRIX BUFFER STREAM COMPLETED SUCCESSFULLY.", type: "success" }
        ]);
        setIsSimulating(false);
        playSuccessChime();
      }
    }, 250);
  };

  const handleCommand = (e: React.FormEvent) => {
    e.preventDefault();
    if (isSimulating) return;

    const cleanCmd = inputVal.trim().toLowerCase();
    if (!cleanCmd) return;

    let response = "";
    let type: "system" | "error" | "success" | "hacker" = "system";

    switch (cleanCmd) {
      case "help":
        playTick();
        response = `AVAILABLE SYSTEM EXECUTABLES:
  help       - Display this assistant index
  about      - Decrypt brief metadata on Jeeva V
  skills     - Intercept skills repository database
  projects   - Show database of automated CRM frameworks
  experience - Stream career milestones and credentials
  sysinfo    - Run high-level system diagnostics (Neofetch)
  hack       - Initialize custom Salesforce Org decryptor simulator
  matrix     - Stream descending digital code rain
  clear      - Purge screen terminal buffers
  linkedin   - Launch digital networking bridge
  email      - Establish cellular communication uplink`;
        break;

      case "about":
        playTick();
        response = `[ SYSTEM DECRYPT: ABOUT.TXT ]
-----------------------------------------------------------
ENGINEER_NAME : Jeeva V
DESIGNATION   : Salesforce Cloud & Full Stack Developer
MISSION_FOCUS : Developing scalable CRM systems, custom Apex/LWC code modules, and optimized micro-service databases.
GEOLOCATION   : Coimbatore, Tamil Nadu, India
EDUCATION     : B.E. Electronics & Communication Engineering
INSTITUTION   : Adithya Institute of Technology
CGPA_STATUS   : 7.68 / 10`;
        type = "success";
        break;

      case "skills":
        playTick();
        response = `[ CORE MATRIX SHELLS: SKILLS.DB ]
-----------------------------------------------------------
SALESFORCE CLOUD : Apex, LWC, SOQL, SOSL, Automations, REST Integrations
WEB DEVELOP      : JavaScript ES6+, React.js, TailwindCSS, Node.js, Express
REPOS & TOOLS    : Git, GitHub, VS Code Editor, SF Developer Console`;
        type = "success";
        break;

      case "projects":
        playTick();
        response = `[ SYSTEM SCHEMATICS: PROJECTS.DAT ]
-----------------------------------------------------------
* Salesforce CRM Automations
  - Custom Apex Triggers, robust governor limit safety flows, custom LWC interfaces.
* Freelance Salesforce Consulting
  - Integrated external cloud architectures with client Salesforce environments.`;
        type = "success";
        break;

      case "experience":
        playTick();
        response = `[ TIMELINE DIARIES: EXPERIENCE.LOG ]
-----------------------------------------------------------
* Freelance Salesforce Developer (Oct 2025 - Present)
  - Automating critical Salesforce workflows and custom CRM interfaces.
* Student Researcher / ECE Specialist (2023 - 2027)
  - Focusing on cloud architectures, telemetry modules, and hardware triggers.`;
        break;

      case "sysinfo":
        playSuccessChime();
        response = `    __  _                                  ___  ____ 
   / /_(_)___ _   ______ _   ____  _____  / __ \\/ ___/ 
  / __/ / __ \`/ | / / __ \`/  / __ \\/ ___/ / / / /\\__ \\  
 / /_/ / /_/ /| |/ / /_/ /  / /_/ (__  ) / /_/ /___/ /  
 \\__/_/\\__, / |___/\\__,_/   \\____/____/  \\____//____/   
      /____/                                            

-----------------------------------------------------------
PORTFOLIO_OS : Jeeva Hacker Suite v3.0
PROCESSOR    : Web-Standard WebAudio Oscillator & JSX Frame
MEMORY_POOL  : JS Heap Allocated (Dynamic)
UPLINK       : HTTPS Sec-Channel Secure
BROWSER_REV  : ${navigator.userAgent.split(" ").slice(-2).join(" ")}
RESOLUTION   : ${window.innerWidth} x ${window.innerHeight}px
STATUS       : ALL ENGINES FULLY COMPATIBLE`;
        type = "success";
        break;

      case "hack":
        setHistory((prev) => [
          ...prev,
          { command: inputVal, output: "[!] INITIALIZING SECURITY BYPASS SIMULATOR PROMPT...", type: "system" }
        ]);
        setInputVal("");
        runHackSimulation();
        return;

      case "matrix":
        setHistory((prev) => [
          ...prev,
          { command: inputVal, output: "[!] DEPLOYING MATRIX CODE RAIN CONSOLE FEED...", type: "system" }
        ]);
        setInputVal("");
        runMatrixRainStream();
        return;

      case "linkedin":
        playSuccessChime();
        response = "LAUNCHING LINKEDIN BRIDGE: redirecting browser window...";
        type = "success";
        window.open("https://linkedin.com/in/jeeva-v-b519a3305", "_blank");
        break;

      case "email":
        playSuccessChime();
        response = "CONNECTING MAIL DEAMON: spawning default client uplink...";
        type = "success";
        window.location.href = "mailto:gopiiniyavan@gmail.com";
        break;

      case "clear":
        playSuccessChime();
        setHistory([]);
        setInputVal("");
        return;

      default:
        playGlitchSweep();
        response = `bash: command not found: "${cleanCmd}". Type 'help' to review directory scripts.`;
        type = "error";
        break;
    }

    setHistory((prev) => [
      ...prev,
      { command: inputVal, output: response, type },
    ]);
    setInputVal("");
  };

  return (
    <div
      onClick={focusInput}
      onMouseEnter={playHover}
      className="w-full font-mono bg-[#050505] border border-[#00FF66]/30 hover:border-[#00FF66]/60 rounded-xl shadow-[0_0_20px_rgba(0,255,102,0.05)] hover:shadow-[0_0_25px_rgba(0,255,102,0.1)] overflow-hidden transition-all duration-300 group cursor-text"
    >
      {/* Terminal Title Bar */}
      <div className="flex items-center justify-between bg-black/80 border-b border-[#00FF66]/20 px-4 py-3">
        <div className="flex items-center space-x-2">
          <Terminal className="w-5 h-5 text-[#00FF66] animate-pulse" />
          <span className="text-[#00FF66] font-bold text-xs tracking-wider">JEEVA_18_HACK_CORE v3.0</span>
        </div>
        <div className="flex space-x-1.5">
          <span className="w-2.5 h-2.5 rounded-full bg-red-500/60" />
          <span className="w-2.5 h-2.5 rounded-full bg-yellow-500/60" />
          <span className="w-2.5 h-2.5 rounded-full bg-[#00FF66]/60" />
        </div>
      </div>

      {/* Terminal Display Panel */}
      <div className="p-4 md:p-6 h-[400px] overflow-y-auto space-y-4 text-xs md:text-sm scrollbar-thin">
        {history.map((item, index) => (
          <div key={index} className="space-y-1.5">
            {item.command && (
              <div className="flex items-center space-x-2">
                <span className="text-[#00E5FF] font-bold">visitor@jeeva-hacker-os:~$</span>
                <span className="text-white">{item.command}</span>
              </div>
            )}
            <div
              className={`whitespace-pre-wrap leading-relaxed ${
                item.type === "error"
                  ? "text-red-500 font-bold"
                  : item.type === "success"
                  ? "text-[#00E5FF] font-medium"
                  : item.type === "matrix"
                  ? "text-[#00FF66]/70 text-glow-green"
                  : item.type === "hacker"
                  ? "text-[#FFC107] font-bold"
                  : "text-[#00FF66]"
              }`}
            >
              {item.output}
            </div>
          </div>
        ))}
        <div ref={terminalEndRef} />
      </div>

      {/* Terminal Input Line */}
      <form onSubmit={handleCommand} className="flex items-center space-x-2 bg-black/40 border-t border-[#00FF66]/10 px-4 py-3">
        <span className="text-[#00E5FF] font-bold text-xs md:text-sm">visitor@jeeva-hacker-os:~$</span>
        <input
          ref={inputRef}
          type="text"
          value={inputVal}
          onChange={(e) => setInputVal(e.target.value)}
          placeholder={isSimulating ? "Uplink active, please wait..." : "Type command (e.g. 'help', 'hack', 'matrix')..."}
          disabled={isSimulating}
          className="flex-1 bg-transparent border-none outline-none text-white font-mono text-xs md:text-sm focus:ring-0 placeholder-[#00FF66]/20 caret-[#00FF66]"
          autoComplete="off"
          autoCorrect="off"
          autoCapitalize="none"
        />
      </form>
    </div>
  );
};

export default TerminalWidget;
