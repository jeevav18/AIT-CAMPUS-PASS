import React, { useState } from "react";
import { PassRequest } from "@/types/campuspass";
import { 
  Building2, 
  CheckCheck, 
  CheckCircle2, 
  XCircle, 
  Clock, 
  AlertCircle, 
  Calendar,
  Layers,
  ArrowRight,
  FileText
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { PaperPassSlipModal } from "./PaperPassSlipModal";
import { toast } from "sonner";

interface HodDashboardProps {
  hodName: string;
  passes: PassRequest[];
  onApprove: (passId: string, remarks: string) => void;
  onReject: (passId: string, reason: string) => void;
}

export const HodDashboard: React.FC<HodDashboardProps> = ({
  hodName,
  passes,
  onApprove,
  onReject,
}) => {
  const [remarksMap, setRemarksMap] = useState<Record<string, string>>({});
  const [previewSlipPass, setPreviewSlipPass] = useState<PassRequest | null>(null);
  const pendingPasses = passes.filter((p) => p.status === "pending_hod");
  const clearedPasses = passes.filter((p) => p.approvalWorkflow.hod.status === "approved");

  const handleApprove = (passId: string) => {
    const remark = remarksMap[passId] || "Department curriculum and laboratory schedule verified.";
    onApprove(passId, remark);
    toast.success("Department clearance granted. Forwarded to Hostel Chief Warden for QR generation.");
  };

  const handleBatchApproveAll = () => {
    if (pendingPasses.length === 0) return;
    pendingPasses.forEach((p) => {
      onApprove(p.id, "Batch approved by HOD: No academic schedule conflict.");
    });
    toast.success(`Batch approved ${pendingPasses.length} departmental pass requests.`);
  };

  return (
    <div className="space-y-6">
      
      {/* Banner */}
      <div className="bg-gradient-to-r from-purple-800 via-indigo-900 to-slate-900 rounded-2xl p-6 text-white shadow-lg flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="h-14 w-14 rounded-2xl bg-white/10 backdrop-blur flex items-center justify-center text-white border border-white/20">
            <Building2 className="h-7 w-7 text-purple-200" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-bold tracking-tight">
                Department Head (HOD) Clearance Portal
              </h2>
              <Badge className="bg-purple-500/30 text-purple-100 border-white/20 text-xs">
                Stage 2 / 3
              </Badge>
            </div>
            <p className="text-xs text-purple-100/90 mt-0.5">
              Officer: {hodName} • Computer Science & Engineering Department
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {pendingPasses.length > 1 && (
            <Button
              onClick={handleBatchApproveAll}
              className="bg-white text-purple-900 hover:bg-purple-50 text-xs font-semibold gap-1.5 shadow"
            >
              <CheckCheck className="h-4 w-4 text-purple-600" />
              Batch Approve All ({pendingPasses.length})
            </Button>
          )}
          <div className="bg-black/25 backdrop-blur px-4 py-2 rounded-xl border border-white/10 text-center">
            <span className="text-[10px] text-purple-200 uppercase font-bold block">
              Pending Queue
            </span>
            <span className="text-xl font-extrabold text-white">
              {pendingPasses.length}
            </span>
          </div>
        </div>
      </div>

      {/* Main Table */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm dark:bg-slate-900 dark:border-slate-800">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-bold text-sm text-slate-900 flex items-center gap-2 dark:text-white">
            <Clock className="h-4 w-4 text-purple-600" />
            Applications Cleared by Tutor Awaiting HOD Approval
          </h3>
          <span className="text-xs text-slate-500">
            {pendingPasses.length} awaiting departmental sign-off
          </span>
        </div>

        {pendingPasses.length > 0 ? (
          <div className="divide-y divide-slate-100 dark:divide-slate-800">
            {pendingPasses.map((p) => (
              <div key={p.id} className="py-4 first:pt-0 last:pb-0 flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="flex items-start gap-3.5">
                  <img
                    src={p.avatarUrl}
                    alt={p.studentName}
                    className="h-12 w-12 rounded-xl object-cover border border-slate-200"
                  />
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-sm text-slate-900 dark:text-white">
                        {p.studentName}
                      </span>
                      <span className="font-mono text-xs font-bold text-purple-600 dark:text-purple-400">
                        {p.rollNumber}
                      </span>
                      <Badge className="capitalize text-[10px]">
                        {p.passType.replace("_", " ")}
                      </Badge>
                    </div>

                    <p className="text-xs text-slate-600 mt-1 dark:text-slate-400">
                      <strong>Destination:</strong> {p.destination} • <strong>Purpose:</strong> {p.reason}
                    </p>

                    <div className="flex flex-wrap items-center gap-3 mt-1.5 text-[11px] text-slate-500">
                      <span>Tutor Remark: <em>"{p.approvalWorkflow.tutor.remarks}"</em></span>
                      <span>•</span>
                      <span className="text-teal-600 font-medium">
                        Parent Contact: {p.approvalWorkflow.tutor.parentContactDetails || "Verified"}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => setPreviewSlipPass(p)}
                    className="border-orange-300 text-orange-700 bg-orange-50 hover:bg-orange-100 text-xs font-semibold gap-1 dark:bg-orange-950/30 dark:border-orange-800 dark:text-orange-300"
                  >
                    <FileText className="h-3.5 w-3.5" />
                    Paper Slip
                  </Button>
                  <Button
                    size="sm"
                    onClick={() => handleApprove(p.id)}
                    className="bg-purple-600 hover:bg-purple-700 text-white text-xs font-semibold gap-1.5"
                  >
                    <CheckCircle2 className="h-3.5 w-3.5" />
                    Approve → Route to Warden
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => onReject(p.id, "Declined by HOD due to scheduled laboratory examination.")}
                    className="border-red-300 text-red-600 hover:bg-red-50 text-xs"
                  >
                    Decline
                  </Button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="p-8 text-center text-slate-500">
            <CheckCircle2 className="h-10 w-10 text-emerald-500 mx-auto mb-2" />
            <h4 className="font-bold text-sm text-slate-800 dark:text-slate-200">
              Department Clearance Queue Empty
            </h4>
            <p className="text-xs text-slate-400 mt-1">
              All students have been cleared to the Hostel Warden.
            </p>
          </div>
        )}
      </div>

      {/* Official Paper Pass Slip Modal */}
      <PaperPassSlipModal
        pass={previewSlipPass}
        isOpen={!!previewSlipPass}
        onClose={() => setPreviewSlipPass(null)}
      />

    </div>
  );
};
