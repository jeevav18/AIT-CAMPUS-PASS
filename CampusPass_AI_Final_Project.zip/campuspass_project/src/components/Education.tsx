import { motion } from "framer-motion";
import { GraduationCap, Award, Calendar, BookOpen, ExternalLink } from "lucide-react";

const Education = () => {
  const educationHistory = [
    {
      institution: "Adithya Institute of Technology",
      board: "Anna University",
      course: "B.E. Electronics and Communication Engineering",
      score: "CGPA 7.68",
      duration: "2023–2027",
      link: "https://adithyatech.edu.in/"
    },
    {
      institution: "Marutham Matric Higher Secondary School",
      board: "Morappur",
      course: "HSC (Higher Secondary Certificate)",
      score: "88%",
      duration: "2022",
      link: "https://mmhss.vercel.app/"
    },
    {
      institution: "Marutham Matric Higher Secondary School",
      board: "Morappur",
      course: "SSLC (Secondary School Leaving Certificate)",
      score: "72.5%",
      duration: "2020",
      link: "https://mmhss.vercel.app/"
    }
  ];

  return (
    <section id="education" className="py-24 px-4 relative">
      <div className="container mx-auto max-w-5xl relative z-10">
        {/* Section Heading */}
        <motion.div
          initial={{ y: 30, opacity: 0 }}
          whileInView={{ y: 0, opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-3xl md:text-5xl font-bold font-oxanium text-white tracking-widest uppercase text-glow-green">
            [ ACADEMIC_REGISTRY ]
          </h2>
          <div className="w-24 h-1 bg-[#00FF66] mx-auto mt-3 rounded-full shadow-[0_0_10px_#00FF66]" />
        </motion.div>

        {/* Education Timeline */}
        <div className="space-y-8 font-mono">
          {educationHistory.map((edu, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, x: idx % 2 === 0 ? -30 : 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.1, duration: 0.5 }}
              className="relative bg-[#080808]/95 border border-[#00FF66]/20 hover:border-[#00FF66]/60 rounded-xl p-6 md:p-8 flex flex-col md:flex-row justify-between items-start md:items-center space-y-4 md:space-y-0 transition-all duration-300 group hover:shadow-[0_0_15px_rgba(0,255,102,0.05)]"
            >
              {/* Left Details */}
              <div className="flex items-start space-x-4">
                <div className="p-3 bg-[#00FF66]/10 text-[#00FF66] rounded-lg group-hover:bg-[#00FF66]/20 transition-colors">
                  <GraduationCap className="w-6 h-6" />
                </div>
                <div className="space-y-1">
                  <div className="flex items-center space-x-2">
                    <h3 className="text-base md:text-lg font-bold text-white tracking-wide font-oxanium">
                      {edu.institution}
                    </h3>
                    {edu.link && (
                      <a
                        href={edu.link}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-[#00E5FF] hover:text-[#00FF66] transition-colors"
                      >
                        <ExternalLink className="w-4 h-4" />
                      </a>
                    )}
                  </div>
                  <p className="text-xs text-[#00E5FF] font-bold uppercase tracking-wider">
                    {edu.course}
                  </p>
                  <p className="text-xs text-gray-500 font-semibold uppercase">
                    {edu.board}
                  </p>
                </div>
              </div>

              {/* Right Diagnostic Box */}
              <div className="flex flex-col items-start md:items-end space-y-1 bg-black/40 border border-[#00FF66]/10 p-3 rounded-lg min-w-[140px] text-left md:text-right">
                <div className="text-[10px] text-gray-500">MARK_SHEET_VAL:</div>
                <div className="text-base font-bold text-[#00FF66] text-glow-green">
                  {edu.score}
                </div>
                <div className="text-[11px] text-[#FFC107] font-semibold flex items-center space-x-1">
                  <Calendar className="w-3.5 h-3.5 inline mr-1" />
                  <span>{edu.duration}</span>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Education;
