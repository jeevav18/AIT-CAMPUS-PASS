import React, { useState } from "react";
import { PassRequest, StudentProfile } from "@/types/campuspass";
import { 
  UserCheck, 
  PhoneCall, 
  CheckCircle2, 
  XCircle, 
  Sparkles, 
  Clock, 
  MapPin, 
  Calendar, 
  Building,
  AlertTriangle,
  HeartHandshake,
  FileText
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { PaperPassSlipModal } from "./PaperPassSlipModal";
import { toast } from "sonner";

interface TutorDashboardProps {
  tutorName: string;
  passes: PassRequest[];
  students: StudentProfile[];
  onApprove: (passId: string, remarks: string, extra?: { parentContacted?: boolean; parentContactDetails?: string }) => void;
  onReject: (passId: string, reason: string) => void;
}

export const TutorDashboard: React.FC<TutorDashboardProps> = ({
  tutorName,
  passes,
  students,
  onApprove,
  onReject,
}) => {
  const [selectedPass, setSelectedPass] = useState<PassRequest | null>(null);
  const [remarks, setRemarks] = useState("");
  const [parentCallLogged, setParentCallLogged] = useState(false);
  const [parentNotes, setParentNotes] = useState("");

  const [isRejectModalOpen, setIsRejectModalOpen] = useState(false);
  const [rejectReason, setRejectReason] = useState("");
  const [previewSlipPass, setPreviewSlipPass] = useState<PassRequest | null>(null);

  const pendingPasses = passes.filter((p) => p.status === "pending_tutor");
  const approvedByTutor = passes.filter((p) => p.approvalWorkflow.tutor.status === "approved");

  const handleOpenReview = (pass: PassRequest) => {
    setSelectedPass(pass);
    setRemarks("Attendance verified. Recommended for outing.");
    setParentCallLogged(pass.parentConsentStatus === "verified_by_call" || pass.parentConsentStatus === "consented_portal");
    setParentNotes(`Spoke with ${pass.guardian.relation} (${pass.guardian.name}) - Confirmed.`);
  };

  const handleConfirmApproval = () => {
    if (!selectedPass) return;

    if (selectedPass.passType === "home_pass" && !parentCallLogged) {
      toast.warning("Institutional Policy: Home pass requires verbal or digital parent confirmation.");
    }

    onApprove(selectedPass.id, remarks, {
      parentContacted: parentCallLogged,
      parentContactDetails: parentNotes,
    });

    toast.success(`Pass ${selectedPass.passNumber} approved and forwarded to Department HOD.`);
    setSelectedPass(null);
  };

  const handleConfirmRejection = () => {
    if (!selectedPass || !rejectReason.trim()) {
      toast.error("Please enter a valid rejection reason.");
      return;
    }

    onReject(selectedPass.id, rejectReason);
    toast.error(`Pass ${selectedPass.passNumber} rejected.`);
    setIsRejectModalOpen(false);
    setSelectedPass(null);
    setRejectReason("");
  };

  return (
    <div className="space-y-6">
      
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-indigo-700 via-blue-800 to-slate-900 rounded-2xl p-6 text-white shadow-lg flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="h-14 w-14 rounded-2xl bg-white/10 backdrop-blur flex items-center justify-center text-white border border-white/20">
            <UserCheck className="h-7 w-7 text-indigo-200" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-bold tracking-tight">
                Class Tutor Portal
              </h2>
              <Badge className="bg-indigo-500/30 text-indigo-100 border-white/20 text-xs">
                Stage 1 / 3
              </Badge>
            </div>
            <p className="text-xs text-indigo-100/90 mt-0.5">
              Officer: {tutorName} • CSE Dept Section B Academic Mentor
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="bg-black/25 backdrop-blur px-4 py-2 rounded-xl border border-white/10 text-center">
            <span className="text-[10px] text-indigo-200 uppercase font-bold block">
              Pending Queue
            </span>
            <span className="text-xl font-extrabold text-white">
              {pendingPasses.length}
            </span>
          </div>
          <div className="bg-black/25 backdrop-blur px-4 py-2 rounded-xl border border-white/10 text-center">
            <span className="text-[10px] text-indigo-200 uppercase font-bold block">
              Cleared Today
            </span>
            <span className="text-xl font-extrabold text-emerald-300">
              {approvedByTutor.length}
            </span>
          </div>
        </div>
      </div>

      {/* Main Review Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left 2 Cols: Pending Queue */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-sm text-slate-900 flex items-center gap-2 dark:text-white">
              <Clock className="h-4 w-4 text-indigo-600" />
              Class Pass Applications Awaiting Tutor Verification
            </h3>
            <span className="text-xs text-slate-500">
              {pendingPasses.length} pending
            </span>
          </div>

          {pendingPasses.length > 0 ? (
            <div className="space-y-3">
              {pendingPasses.map((p) => {
                const student = students.find((s) => s.id === p.studentId);
                const isSelected = selectedPass?.id === p.id;
                return (
                  <div
                    key={p.id}
                    onClick={() => handleOpenReview(p)}
                    className={`p-4 rounded-2xl border transition-all cursor-pointer ${
                      isSelected
                        ? "bg-indigo-50/70 border-indigo-400 shadow-md ring-2 ring-indigo-300 dark:bg-indigo-950/30 dark:border-indigo-600"
                        : "bg-white border-slate-200 hover:border-slate-300 hover:shadow-sm dark:bg-slate-900 dark:border-slate-800"
                    }`}
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex items-start gap-3">
                        <img
                          src={p.avatarUrl}
                          alt={p.studentName}
                          className="h-12 w-12 rounded-xl object-cover border border-slate-200 shrink-0"
                        />
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-sm text-slate-900 dark:text-white">
                              {p.studentName}
                            </span>
                            <Badge className="font-mono text-[10px] bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300">
                              {p.rollNumber}
                            </Badge>
                            <Badge className="capitalize text-[10px]">
                              {p.passType.replace("_", " ")}
                            </Badge>
                          </div>
                          
                          <p className="text-xs text-slate-600 mt-1 line-clamp-1 dark:text-slate-400">
                            <strong>Destination:</strong> {p.destination}
                          </p>
                          <p className="text-[11px] text-slate-500 line-clamp-1 dark:text-slate-400">
                            <strong>Reason:</strong> {p.reason}
                          </p>

                          <div className="flex flex-wrap items-center gap-3 mt-2 text-[11px] text-slate-500">
                            <span>Departure: {new Date(p.departureDateTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                            <span>•</span>
                            <span className="text-red-600 font-semibold">Curfew: {new Date(p.expectedReturnDateTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                            {student && (
                              <>
                                <span>•</span>
                                <span className="text-emerald-600 font-semibold">Attendance: {student.attendancePercentage}%</span>
                              </>
                            )}
                          </div>
                        </div>
                      </div>

                      <div className="text-right shrink-0">
                        <Button
                          size="sm"
                          className="text-xs bg-indigo-600 hover:bg-indigo-700 text-white"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleOpenReview(p);
                          }}
                        >
                          Review & Verify
                        </Button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center text-slate-500 dark:bg-slate-900 dark:border-slate-800">
              <CheckCircle2 className="h-10 w-10 text-emerald-500 mx-auto mb-2" />
              <h4 className="font-bold text-sm text-slate-800 dark:text-slate-200">
                Tutor Clearance Queue Clean
              </h4>
              <p className="text-xs text-slate-400 mt-1">
                All submitted class passes have been reviewed.
              </p>
            </div>
          )}
        </div>

        {/* Right Col: Tutor Review & Parent Verification Panel */}
        <div className="space-y-4">
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm dark:bg-slate-900 dark:border-slate-800">
            <h3 className="font-bold text-sm text-slate-900 mb-2 dark:text-white">
              Tutor Clearance & Parent Call Desk
            </h3>

            {selectedPass ? (
              <div className="space-y-4 text-xs">
                
                {/* Selected Student Snapshot */}
                <div className="p-3 bg-indigo-50/70 rounded-xl border border-indigo-200 space-y-1.5 dark:bg-indigo-950/20 dark:border-indigo-800">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-900 text-sm dark:text-white">
                      {selectedPass.studentName}
                    </span>
                    <span className="font-mono text-indigo-700 font-bold dark:text-indigo-400">
                      {selectedPass.rollNumber}
                    </span>
                  </div>
                  <p className="text-slate-600 dark:text-slate-400">
                    {selectedPass.hostelBlock} • Room {selectedPass.roomNumber}
                  </p>
                  <p className="text-slate-700 pt-1 border-t border-indigo-200/60 dark:border-indigo-800">
                    <strong>Destination:</strong> {selectedPass.destination}
                  </p>
                </div>

                {/* Parent Contact Verification Call Box */}
                <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 space-y-2.5 dark:bg-slate-800/60 dark:border-slate-700">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-800 flex items-center gap-1.5 dark:text-slate-200">
                      <HeartHandshake className="h-4 w-4 text-teal-600" />
                      Guardian Contact & Consent
                    </span>
                    <Badge variant="outline" className="text-[10px]">
                      {selectedPass.guardian.relation}
                    </Badge>
                  </div>
                  
                  <div className="text-slate-700 space-y-1 dark:text-slate-300">
                    <div className="font-semibold">{selectedPass.guardian.name}</div>
                    <div className="font-mono text-slate-600 flex items-center justify-between dark:text-slate-400">
                      <span>{selectedPass.guardian.phone}</span>
                      <a
                        href={`tel:${selectedPass.guardian.phone}`}
                        className="inline-flex items-center gap-1 text-[11px] font-bold text-blue-600 hover:underline"
                      >
                        <PhoneCall className="h-3 w-3" /> Dial Now
                      </a>
                    </div>
                  </div>

                  <label className="flex items-start gap-2 pt-2 border-t border-slate-200 dark:border-slate-700 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={parentCallLogged}
                      onChange={(e) => setParentCallLogged(e.target.checked)}
                      className="mt-0.5 rounded text-indigo-600"
                    />
                    <span className="text-[11px] text-slate-700 font-medium dark:text-slate-300">
                      I have telephonically contacted the guardian and verified verbal consent.
                    </span>
                  </label>

                  <input
                    type="text"
                    placeholder="Call notes (e.g. 'Father acknowledged weekend function')"
                    value={parentNotes}
                    onChange={(e) => setParentNotes(e.target.value)}
                    className="w-full text-xs px-2.5 py-1.5 rounded-lg border border-slate-200 bg-white dark:bg-slate-900 dark:border-slate-700 dark:text-white"
                  />
                </div>

                {/* Tutor Approval Remarks */}
                <div>
                  <label className="font-semibold text-slate-700 block mb-1 dark:text-slate-300">
                    Tutor Mentor Remarks
                  </label>
                  <textarea
                    rows={2}
                    value={remarks}
                    onChange={(e) => setRemarks(e.target.value)}
                    placeholder="Enter academic observation or approval note"
                    className="w-full text-xs px-3 py-2 rounded-lg border border-slate-200 bg-white dark:bg-slate-900 dark:border-slate-700 dark:text-white"
                  />
                </div>

                  <div className="flex items-center gap-2 pt-2">
                    <Button
                      onClick={handleConfirmApproval}
                      className="flex-1 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold gap-1.5"
                    >
                      <CheckCircle2 className="h-3.5 w-3.5" />
                      Approve → Route to HOD
                    </Button>
                    <Button
                      variant="outline"
                      onClick={() => setPreviewSlipPass(selectedPass)}
                      className="text-xs border-orange-300 text-orange-700 bg-orange-50 hover:bg-orange-100 gap-1 font-semibold dark:bg-orange-950/30 dark:border-orange-800 dark:text-orange-300"
                    >
                      <FileText className="h-3.5 w-3.5" />
                      Paper Slip
                    </Button>
                    <Button
                      variant="outline"
                      onClick={() => setIsRejectModalOpen(true)}
                      className="border-red-300 text-red-600 hover:bg-red-50 text-xs font-semibold"
                    >
                      <XCircle className="h-3.5 w-3.5 mr-1" />
                      Decline
                    </Button>
                  </div>

              </div>
            ) : (
              <p className="text-xs text-slate-400 py-8 text-center">
                Select a pass request from the pending queue to review academic attendance and log parent verification.
              </p>
            )}
          </div>
        </div>

      </div>

      {/* Reject Modal */}
      {isRejectModalOpen && selectedPass && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div className="bg-white rounded-2xl max-w-sm w-full p-5 space-y-4 shadow-xl border border-slate-200 dark:bg-slate-900 dark:border-slate-800">
            <h3 className="font-bold text-sm text-slate-900 dark:text-white">
              Decline Pass Request: {selectedPass.studentName}
            </h3>
            <p className="text-xs text-slate-500">
              Specify reason for declining. This explanation will be logged and sent to the student and parent.
            </p>
            <textarea
              rows={3}
              placeholder="e.g. Mandatory internal test scheduled this afternoon / Parent requested withholding leave"
              value={rejectReason}
              onChange={(e) => setRejectReason(e.target.value)}
              className="w-full text-xs px-3 py-2 rounded-lg border border-slate-200 bg-white dark:bg-slate-800 dark:border-slate-700 dark:text-white"
            />
            <div className="flex items-center justify-end gap-2">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setIsRejectModalOpen(false)}
                className="text-xs"
              >
                Cancel
              </Button>
              <Button
                size="sm"
                onClick={handleConfirmRejection}
                className="bg-red-600 hover:bg-red-700 text-white text-xs"
              >
                Confirm Decline
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Official Paper Pass Slip Modal */}
      <PaperPassSlipModal
        pass={previewSlipPass}
        isOpen={!!previewSlipPass}
        onClose={() => setPreviewSlipPass(null)}
      />

    </div>
  );
};
