export interface SkillItem {
  id: string;
  name: string;
  category: "salesforce" | "frontend" | "backend" | "database" | "ai" | "tools";
  categoryLabel: string;
  level: "Core Stack" | "Advanced" | "Hands-on" | "Proficient";
  experience: string;
  tools: string[];
  description: string;
  color: string;
  tags: string[];
}

export interface ProjectCaseStudy {
  problem: string;
  objective: string;
  solution: string;
  architecture: string;
  techStack: string[];
  keyFeatures: string[];
  challenges: string[];
  implementation: string[];
  results: string;
  futureImprovements: string[];
}

export interface ProjectItem {
  id: string;
  title: string;
  category: "all" | "salesforce" | "ai" | "fullstack" | "iot" | "web" | "academic";
  categoryLabel: string;
  badge: string;
  shortDesc: string;
  problem: string;
  technologies: string[];
  keyFeatures: string[];
  githubUrl: string;
  liveDemoUrl?: string;
  metrics?: string;
  image?: string;
  caseStudy: ProjectCaseStudy;
}

export interface ExperienceItem {
  id: string;
  role: string;
  company: string;
  period: string;
  type: "Internship" | "Student Developer" | "Project Experience";
  location: string;
  whatIWorkedOn: string;
  responsibilities: string[];
  achievements: string[];
  technologies: string[];
}

export interface EducationItem {
  id: string;
  degree: string;
  institution: string;
  period: string;
  grade: string;
  location: string;
  description: string;
  highlights: string[];
  coursework: string[];
}

export interface CertificationItem {
  id: string;
  title: string;
  issuer: string;
  issueDate: string;
  credentialId: string;
  verificationUrl: string;
  category: "Salesforce" | "Programming" | "Cloud" | "AI" | "Web Development" | "Other Technical Certifications";
  skillsCovered: string[];
}

export interface AchievementItem {
  id: string;
  title: string;
  organization: string;
  year: string;
  category: "Hackathons" | "Technical Events" | "Projects" | "Academic Achievements" | "Leadership" | "Open Source";
  description: string;
  metrics: string;
}

export interface LearningItem {
  id: string;
  title: string;
  description: string;
  currentFocus: string;
  stage: "Learning" | "Building" | "Deploying" | "Improving";
  topics: string[];
}

export interface ServiceItem {
  id: string;
  title: string;
  description: string;
  icon: string;
  tags: string[];
}

export const PORTFOLIO_DATA = {
  personal: {
    name: "JEEVA V",
    title: "Electronics & Communication Engineering Student | Salesforce Developer | Full-Stack & AI Enthusiast",
    tagline: "Building scalable Salesforce CRM architectures, modern full-stack web applications, and intelligent AI-powered enterprise systems.",
    statement:
      "Passionate and results-driven Electronics & Communication Engineering undergraduate at Adithya Institute of Technology (CGPA 8.10/10.0), specializing in Salesforce platform engineering (Apex, LWC, Flows), scalable full-stack TypeScript/Python development, and Artificial Intelligence integrations. Proven track record in architecting real-world applications including hospital management systems, AI skill gap analyzers, and IoT telemetry solutions.",
    shortIntro:
      "Engineering student passionate about building scalable software, intelligent applications, and real-world technology solutions.",
    statusIndicator: "Available for Internships & Opportunities",
    isAvailable: true,
    photoUrl: "",
    avatar: "",
    institution: "Adithya Institute of Technology, Coimbatore",
    degree: "B.E. Electronics & Communication Engineering",
    expectedGraduation: "2027",
    cgpa: "8.10 / 10.0",
    location: "Coimbatore, Tamil Nadu, India",
    email: "gopiiniyavan@gmail.com",
    phone: "+91 94420 50959",
    githubUrl: "https://github.com/jeevav18",
    linkedinUrl: "https://linkedin.com/in/jeeva-v",
    leetcodeUrl: "https://leetcode.com/jeevav18",
    trailheadUrl: "https://trailhead.salesforce.com/en/me/jeevav",
    resumePdfUrl: "/jeeva_v_resume.pdf",
    codename: "JEEVA_V",
    clearanceLevel: "LEVEL_5_DEVELOPER",
    systemStatus: "ONLINE_READY_TO_HIRE",
    bioFull: [
      "Electronics & Communication Engineering student at Adithya Institute of Technology with a strong technical focus on Salesforce cloud engineering and full-stack software development.",
      "Hands-on expertise spanning Apex backend triggers, batch architecture, Lightning Web Components (LWC), React, Node.js, Python, and Generative AI integrations.",
      "Dedicated to writing clean, maintainable, and high-performance code adhering to industry design standards and security best practices."
    ],

    floatingBadges: [
      { name: "Salesforce", color: "#00A1E0" },
      { name: "Apex", color: "#0284C7" },
      { name: "LWC", color: "#0284C7" },
      { name: "JavaScript", color: "#F59E0B" },
      { name: "React", color: "#06B6D4" },
      { name: "Node.js", color: "#16A34A" },
      { name: "Python", color: "#3B82F6" },
      { name: "AI", color: "#8B5CF6" },
      { name: "REST API", color: "#EC4899" },
      { name: "Git", color: "#F97316" },
    ],
  },

  snapshot: [
    {
      label: "Education & Discipline",
      value: "BE - ECE (2027)",
      detail: "Adithya Institute of Technology (CGPA 8.10)",
      icon: "GraduationCap",
    },
    {
      label: "Primary Specialization",
      value: "Salesforce & Cloud",
      detail: "Apex, LWC, Flows & SOQL/SOSL",
      icon: "Code2",
    },
    {
      label: "Full-Stack Development",
      value: "TS, React & Node",
      detail: "Scalable REST APIs & Web Architecture",
      icon: "Layers",
    },
    {
      label: "Engineered Systems",
      value: "6+ Deployed",
      detail: "Hospital CRM, EdTech & IoT Systems",
      icon: "Briefcase",
    },
    {
      label: "Verified Credentials",
      value: "4+ Certifications",
      detail: "Salesforce, Python & Cloud Badges",
      icon: "Award",
    },
    {
      label: "Candidate Availability",
      value: "Immediate",
      detail: "Internships & Technical Opportunities",
      icon: "Trophy",
    },
  ],

  about: {
    title: "Bridging Hardware Fundamentals with Modern Enterprise Software & AI",
    intro:
      "I am an Electronics & Communication Engineering student at Adithya Institute of Technology with a strong passion for software engineering, Salesforce CRM platforms, full-stack systems, and Artificial Intelligence.",
    story:
      "Starting with a rigorous foundation in digital logic, microcontrollers, and electronic communication systems, I discovered my deep fascination with how code drives scalable systems in the cloud. This led me to dive headfirst into software development—mastering modern JavaScript/TypeScript, building scalable Python APIs, and specializing in the Salesforce Lightning Platform (Apex, LWC, Flows). Today, I combine hardware-level problem solving discipline with enterprise cloud engineering to build intelligent, real-world applications.",
    highlightCards: [
      {
        id: "student",
        title: "Engineering Student",
        subtitle: "BE ECE",
        detail: "Adithya Institute of Technology, Coimbatore. Expected Graduation 2027. CGPA: 8.10.",
        icon: "GraduationCap",
        color: "from-blue-600 to-cyan-600",
      },
      {
        id: "developer",
        title: "Developer",
        subtitle: "Salesforce + Full Stack",
        detail: "Proficient in Apex, Lightning Web Components, SOQL, React, Node.js, and RESTful APIs.",
        icon: "Code2",
        color: "from-sky-600 to-blue-600",
      },
      {
        id: "builder",
        title: "Builder",
        subtitle: "Real-world Projects",
        detail: "Built hospital CRM systems, AI platforms, IoT automation, and school management portals.",
        icon: "Layers",
        color: "from-indigo-600 to-violet-600",
      },
      {
        id: "learner",
        title: "Learner",
        subtitle: "AI + Emerging Technologies",
        detail: "Actively exploring Generative AI, LLM integrations, System Design, and Cloud Architecture.",
        icon: "Sparkles",
        color: "from-emerald-600 to-teal-600",
      },
    ],
  },

  skills: [
    // Salesforce
    {
      id: "apex",
      name: "Apex",
      category: "salesforce",
      categoryLabel: "Salesforce",
      level: "Core Stack",
      experience: "Hands-on Projects & Certifications",
      tools: ["Trigger Frameworks", "Batch Apex", "Queueable", "Governor Limits", "Unit Testing (90%+)"],
      description: "Strong understanding of object-oriented backend programming on Salesforce Lightning Platform, handling multi-tenant architecture and governor limits.",
      color: "#00A1E0",
      tags: ["Governor Limits", "Triggers", "Batch Apex", "Asynchronous"],
    },
    {
      id: "lwc",
      name: "Lightning Web Components (LWC)",
      category: "salesforce",
      categoryLabel: "Salesforce",
      level: "Core Stack",
      experience: "Modern Web Standards",
      tools: ["Shadow DOM", "SLDS Design Tokens", "Wire Adapters", "LMS (Message Service)", "Custom Events"],
      description: "Developing responsive, accessible, and high-performance custom user interfaces utilizing standard web components and Salesforce Lightning Design System (SLDS).",
      color: "#0284C7",
      tags: ["SLDS", "Wire Service", "LMS", "Custom UI"],
    },
    {
      id: "soql-sosl",
      name: "SOQL & SOSL",
      category: "salesforce",
      categoryLabel: "Salesforce",
      level: "Core Stack",
      experience: "Query Optimization",
      tools: ["Relationship Queries", "Aggregate Functions", "Indexed Filters", "Text Search", "Bulk Querying"],
      description: "Writing optimized database queries, handling parent-to-child and child-to-parent traversals with strict governor limit adherence.",
      color: "#0284C7",
      tags: ["Query Tuning", "Relationships", "Search", "Optimization"],
    },
    {
      id: "salesforce-flow",
      name: "Salesforce Flow",
      category: "salesforce",
      categoryLabel: "Salesforce",
      level: "Core Stack",
      experience: "Declarative Automation",
      tools: ["Record-Triggered Flows", "Screen Flows", "Auto-Launched Flows", "Subflows", "Error Handling"],
      description: "Designing end-to-end declarative business process automation, interactive guided screens, and automated event triggers.",
      color: "#00A1E0",
      tags: ["Automation", "Screen Flows", "Declarative", "Business Logic"],
    },
    {
      id: "apex-triggers",
      name: "Apex Triggers",
      category: "salesforce",
      categoryLabel: "Salesforce",
      level: "Core Stack",
      experience: "Bulkified Architecture",
      tools: ["One Trigger Per Object", "Handler Pattern", "Context Variables", "Recursion Control", "DML Optimization"],
      description: "Implementing clean, bulkified trigger architectures adhering to industry best practices and preventing recursive executions.",
      color: "#0284C7",
      tags: ["Trigger Patterns", "Bulkification", "Recursion Control"],
    },
    {
      id: "visualforce",
      name: "Visualforce",
      category: "salesforce",
      categoryLabel: "Salesforce",
      level: "Proficient",
      experience: "Classic & PDF Generation",
      tools: ["Custom Controllers", "Extensions", "Standard Controllers", "PDF Rendering", "JavaScript Remoting"],
      description: "Creating legacy page customizations, dynamic printable PDF reports, and integrating JavaScript remoting workflows.",
      color: "#0284C7",
      tags: ["PDF Export", "Custom Controllers", "Extensions"],
    },
    {
      id: "reports-dashboards",
      name: "Reports & Dashboards",
      category: "salesforce",
      categoryLabel: "Salesforce",
      level: "Core Stack",
      experience: "Business Analytics",
      tools: ["Matrix Reports", "Summary Reports", "Dynamic Dashboards", "Bucket Columns", "Scheduled Dispatches"],
      description: "Configuring real-time executive analytics, KPIs, role-based dashboards, and automated report scheduling for decision-makers.",
      color: "#00A1E0",
      tags: ["Analytics", "KPIs", "Dashboards", "Metrics"],
    },
    {
      id: "validation-rules",
      name: "Validation Rules & Formulas",
      category: "salesforce",
      categoryLabel: "Salesforce",
      level: "Core Stack",
      experience: "Data Integrity",
      tools: ["Complex Formulas", "Cross-Object References", "Regex Validation", "Error Messaging", "Field-Level Logic"],
      description: "Enforcing strict data quality, business constraints, and cross-object validations before record persistence.",
      color: "#0284C7",
      tags: ["Data Integrity", "Formulas", "Constraints"],
    },
    {
      id: "crm-customization",
      name: "CRM Customization",
      category: "salesforce",
      categoryLabel: "Salesforce",
      level: "Core Stack",
      experience: "Schema & Security Setup",
      tools: ["Custom Objects & Fields", "Profiles & Permission Sets", "OWD Security", "Role Hierarchies", "Sharing Rules"],
      description: "Designing scalable data models, Organization-Wide Default (OWD) sharing settings, role hierarchies, and granular field security.",
      color: "#00A1E0",
      tags: ["Data Models", "Role Hierarchy", "Sharing Rules", "Security"],
    },

    // Frontend
    {
      id: "html-css",
      name: "HTML5 & CSS3",
      category: "frontend",
      categoryLabel: "Frontend",
      level: "Core Stack",
      experience: "Semantic Standards",
      tools: ["Semantic Tags", "Flexbox & Grid", "CSS Variables", "Responsive Design", "WCAG Accessibility"],
      description: "Building responsive, clean, and accessible markup layouts compliant with modern W3C and WCAG standards.",
      color: "#E34F26",
      tags: ["Semantic HTML", "Flexbox", "Grid", "Responsive"],
    },
    {
      id: "javascript-fe",
      name: "JavaScript (ES6+)",
      category: "frontend",
      categoryLabel: "Frontend",
      level: "Core Stack",
      experience: "Modern ECMAScript",
      tools: ["Async/Await", "Closures", "Event Loop", "DOM Manipulation", "Fetch & Axios"],
      description: "Writing clean, asynchronous, event-driven JavaScript applications utilizing modern ES6+ paradigms.",
      color: "#F59E0B",
      tags: ["ES6+", "Async/Await", "Event Loop", "DOM"],
    },
    {
      id: "react-fe",
      name: "React",
      category: "frontend",
      categoryLabel: "Frontend",
      level: "Core Stack",
      experience: "Single Page Apps",
      tools: ["Custom Hooks", "Context API", "State Management", "Component Lifecycle", "Performance Memoization"],
      description: "Architecting modular, component-based user interfaces with custom hooks, client-side routing, and optimized rendering lifecycles.",
      color: "#06B6D4",
      tags: ["Hooks", "Context API", "Components", "State"],
    },
    {
      id: "typescript-fe",
      name: "TypeScript",
      category: "frontend",
      categoryLabel: "Frontend",
      level: "Core Stack",
      experience: "Type-Safe Architecture",
      tools: ["Strict Interfaces", "Generics", "Type Narrowing", "Union Types", "API Contracts"],
      description: "Developing robust, maintainable frontend applications with compile-time type safety and strict interface definitions.",
      color: "#2563EB",
      tags: ["Type Safety", "Generics", "Interfaces", "Clean Code"],
    },

    // Backend
    {
      id: "nodejs-be",
      name: "Node.js",
      category: "backend",
      categoryLabel: "Backend",
      level: "Core Stack",
      experience: "Asynchronous Runtimes",
      tools: ["Event-Driven I/O", "File System API", "Streams & Buffers", "NPM Modules", "Environment Config"],
      description: "Building scalable backend services leveraging Node's asynchronous event-driven architecture and non-blocking I/O.",
      color: "#16A34A",
      tags: ["Asynchronous", "Event-Driven", "NPM", "Runtime"],
    },
    {
      id: "express-be",
      name: "Express.js",
      category: "backend",
      categoryLabel: "Backend",
      level: "Core Stack",
      experience: "Microservices & Routing",
      tools: ["Middleware Pipelines", "Routing Controllers", "JWT Authentication", "Error Handlers", "CORS Configuration"],
      description: "Constructing robust REST microservices, security middleware, JWT authentication, and request sanitization.",
      color: "#475569",
      tags: ["Middleware", "Routing", "JWT", "REST"],
    },
    {
      id: "python-be",
      name: "Python",
      category: "backend",
      categoryLabel: "Backend",
      level: "Core Stack",
      experience: "Scripting & Services",
      tools: ["Object-Oriented Programming", "Data Structures", "Automation Scripts", "JSON Handling", "Package Management"],
      description: "Utilizing Python for backend services, algorithmic problem solving, automated testing, and data transformation scripts.",
      color: "#3B82F6",
      tags: ["OOP", "Data Structures", "Automation", "Core"],
    },
    {
      id: "flask-be",
      name: "Flask",
      category: "backend",
      categoryLabel: "Backend",
      level: "Hands-on",
      experience: "Lightweight Web Services",
      tools: ["Blueprints", "Jinja Templates", "SQLAlchemy", "REST Endpoints", "Session Handling"],
      description: "Developing modular microservices, lightweight web backends, and rapid prototyping APIs with Flask blueprints.",
      color: "#0284C7",
      tags: ["Microservices", "Blueprints", "REST", "SQLAlchemy"],
    },
    {
      id: "rest-apis-be",
      name: "REST APIs",
      category: "backend",
      categoryLabel: "Backend",
      level: "Core Stack",
      experience: "API Design & Integration",
      tools: ["HTTP Methods", "Status Codes", "Pagination", "Rate Limiting", "Swagger/OpenAPI Documentation"],
      description: "Designing clean, standardized RESTful endpoints with structured payload contracts, error responses, and tokenized authorization.",
      color: "#EC4899",
      tags: ["HTTP", "JSON", "Pagination", "Security"],
    },

    // Database
    {
      id: "postgresql-db",
      name: "PostgreSQL",
      category: "database",
      categoryLabel: "Database",
      level: "Advanced",
      experience: "Relational Modeling",
      tools: ["Schema Normalization", "Foreign Keys", "Joins & Indexes", "ACID Transactions", "Query Optimization"],
      description: "Designing normalized relational schemas, optimizing query execution with indexing, and ensuring transactional data integrity.",
      color: "#2563EB",
      tags: ["Relational", "SQL", "Indexes", "ACID"],
    },
    {
      id: "firebase-db",
      name: "Firebase",
      category: "database",
      categoryLabel: "Database",
      level: "Hands-on",
      experience: "Real-time BaaS",
      tools: ["Cloud Firestore", "Firebase Authentication", "Security Rules", "Real-time Listeners", "Cloud Functions"],
      description: "Integrating real-time NoSQL databases, user authentication, and secure client-side Firestore access rules.",
      color: "#F59E0B",
      tags: ["NoSQL", "Real-time", "Auth", "Firestore"],
    },
    {
      id: "supabase-db",
      name: "Supabase",
      category: "database",
      categoryLabel: "Database",
      level: "Core Stack",
      experience: "PostgreSQL Backend-as-a-Service",
      tools: ["Row Level Security (RLS)", "Postgres Triggers", "Auth Policies", "Database Functions", "Realtime Webhooks"],
      description: "Utilizing Supabase for modern serverless architectures with strict Row Level Security (RLS) policies and automated API generation.",
      color: "#10B981",
      tags: ["Postgres", "RLS", "Auth", "Serverless"],
    },

    // AI
    {
      id: "generative-ai",
      name: "Generative AI",
      category: "ai",
      categoryLabel: "Artificial Intelligence",
      level: "Hands-on",
      experience: "Prompt Engineering & RAG",
      tools: ["Prompt Engineering", "Context Window Management", "System Instructions", "Evaluation", "Multi-modal Inputs"],
      description: "Designing structured prompts, multi-turn conversation flows, and system boundaries for intelligent software platforms.",
      color: "#8B5CF6",
      tags: ["Prompt Engineering", "Context", "LLM", "Evaluation"],
    },
    {
      id: "llm-apis",
      name: "LLM APIs",
      category: "ai",
      categoryLabel: "Artificial Intelligence",
      level: "Hands-on",
      experience: "API Orchestration",
      tools: ["Streaming Responses", "Function Calling", "Structured JSON Outputs", "Token Management", "Rate Limiting Handling"],
      description: "Integrating large language model endpoints into full-stack web applications with streaming text and type-safe JSON schema parsing.",
      color: "#7C3AED",
      tags: ["Function Calling", "JSON Schema", "Streaming", "Orchestration"],
    },
    {
      id: "openai-apis",
      name: "OpenAI APIs",
      category: "ai",
      categoryLabel: "Artificial Intelligence",
      level: "Hands-on",
      experience: "Embeddings & Completions",
      tools: ["GPT-4o", "Embeddings", "Text Generation", "Vision Analysis", "Assistant API"],
      description: "Connecting OpenAI models to automate customer interactions, document summaries, and intelligent categorization pipelines.",
      color: "#10B981",
      tags: ["GPT-4", "Embeddings", "Completions", "Vision"],
    },
    {
      id: "gemini-apis",
      name: "Google Gemini APIs",
      category: "ai",
      categoryLabel: "Artificial Intelligence",
      level: "Hands-on",
      experience: "Multi-Modal AI",
      tools: ["Gemini 2.5/3.7", "Google GenAI SDK", "Multi-modal Analysis", "Structured Outputs", "Safety Settings"],
      description: "Implementing server-side Google GenAI SDK integrations for advanced code reasoning, document parsing, and real-time inference.",
      color: "#3B82F6",
      tags: ["Google GenAI", "Multi-Modal", "Inference", "SDK"],
    },
    {
      id: "ai-apps",
      name: "AI-Powered Applications",
      category: "ai",
      categoryLabel: "Artificial Intelligence",
      level: "Hands-on",
      experience: "End-to-End Solutions",
      tools: ["Smart Assistants", "Automated Summarization", "Intelligent Triage", "OCR Ingestion", "Resume ATS Scanners"],
      description: "Building production-grade web applications that augment human productivity using automated intelligence pipelines.",
      color: "#6366F1",
      tags: ["Smart Apps", "Automation", "Workflows", "Integration"],
    },

    // Tools
    {
      id: "git-tool",
      name: "Git",
      category: "tools",
      categoryLabel: "Tools",
      level: "Core Stack",
      experience: "Version Control",
      tools: ["Branching & Merging", "Rebase", "Interactive Staging", "Commit Conventions", "Conflict Resolution"],
      description: "Standard version control workflows, semantic commit histories, clean branch isolation, and collaborative code merging.",
      color: "#F97316",
      tags: ["Branching", "Merging", "Rebase", "Workflow"],
    },
    {
      id: "github-tool",
      name: "GitHub",
      category: "tools",
      categoryLabel: "Tools",
      level: "Core Stack",
      experience: "CI/CD & Collaboration",
      tools: ["Pull Requests", "Code Reviews", "GitHub Actions", "Issue Tracking", "Project Boards"],
      description: "Managing open source repositories, peer code reviews, automated lint/test workflows with GitHub Actions, and project tracking.",
      color: "#475569",
      tags: ["Actions", "PRs", "CI/CD", "Collaboration"],
    },
    {
      id: "vscode-tool",
      name: "VS Code & Salesforce CLI",
      category: "tools",
      categoryLabel: "Tools",
      level: "Core Stack",
      experience: "Developer Productivity",
      tools: ["Salesforce Extension Pack", "SFDX CLI", "Debugging", "GitLens", "Snippets"],
      description: "Configuring development environments, deploying metadata to Salesforce orgs via SFDX CLI, and debugging complex logic.",
      color: "#0284C7",
      tags: ["SFDX", "Debugging", "Extensions", "IDE"],
    },
    {
      id: "postman-tool",
      name: "Postman",
      category: "tools",
      categoryLabel: "Tools",
      level: "Core Stack",
      experience: "API Testing & Mocking",
      tools: ["Collection Runners", "Environment Variables", "Automated Assertions", "Mock Servers", "OAuth2 Flow Verification"],
      description: "Testing API contracts, crafting automated test assertion suites, and verifying token authentication lifecycles.",
      color: "#EA580C",
      tags: ["API Testing", "Collections", "Mocking", "Assertions"],
    },
    {
      id: "vercel-tool",
      name: "Vercel",
      category: "tools",
      categoryLabel: "Tools",
      level: "Core Stack",
      experience: "Cloud Hosting & Edge",
      tools: ["Continuous Deployment", "Custom Domains", "Serverless Functions", "Preview Deployments", "Environment Variables"],
      description: "Deploying production React and Next.js applications with automated continuous deployment and zero-downtime previews.",
      color: "#0F172A",
      tags: ["Deployments", "Edge", "Preview", "Serverless"],
    },
    {
      id: "render-tool",
      name: "Render",
      category: "tools",
      categoryLabel: "Tools",
      level: "Hands-on",
      experience: "Web Services & Databases",
      tools: ["Web Service Hosting", "Background Workers", "Postgres Provisioning", "Auto-Deployments", "Health Checks"],
      description: "Hosting Python Flask and Node.js backend microservices with automated Docker container builds and SSL certificate management.",
      color: "#46E3B7",
      tags: ["Web Services", "Backend Hosting", "Auto-Deploy", "SSL"],
    },
  ],

  projects: [
    {
      id: "hospital-management-ai",
      title: "Hospital Management & AI Platform",
      category: "salesforce",
      categoryLabel: "Salesforce & AI",
      badge: "FEATURED ENTERPRISE PROJECT",
      shortDesc:
        "A modern hospital management platform integrating Salesforce CRM, AI assistance, automated appointment scheduling, electronic medical records, and doctor analytics.",
      problem:
        "Hospitals and multi-specialty clinics face significant operational friction managing disjointed patient appointments, physical medical records, doctor shift schedules, and patient follow-up communication.",
      technologies: ["Salesforce", "Apex", "LWC", "Salesforce Flow", "REST API", "AI APIs"],
      keyFeatures: [
        "End-to-end patient lifecycle tracking from registration to billing and prescription dispatch",
        "Lightning Web Component custom scheduling console with real-time doctor availability checks",
        "Apex REST API endpoints integrating diagnostic lab data directly into Salesforce Health records",
        "AI-powered triage assistant analyzing patient symptom descriptions to recommend specialist routing",
        "Automated Salesforce Record-Triggered Flows sending SMS and email reminders to reduce missed appointments",
        "Interactive executive dashboard displaying bed occupancy rates, doctor consultation volumes, and revenue analytics",
      ],
      githubUrl: "https://github.com/jeevav18/salesforce-hospital-ai-platform",
      liveDemoUrl: "https://hospital-crm.demo.app",
      metrics: "Sub-second record search // 100% Governor Limit compliant // 90%+ Apex Test Coverage",
      caseStudy: {
        problem:
          "Healthcare facilities struggle with disconnected software silos for appointment bookings, doctor scheduling, patient clinical histories, and patient inquiries. This fragmentation causes long patient wait times, administrative overhead, and communication lapses.",
        objective:
          "To architect and deploy a unified, enterprise-grade healthcare management solution built on Salesforce CRM and augmented with AI to streamline patient admissions, diagnostic tracking, and specialist triage.",
        solution:
          "Constructed a comprehensive Salesforce platform application utilizing custom objects (Patients, Appointments, Doctors, Diagnoses, Prescriptions) powered by custom Lightning Web Components, asynchronous Apex controllers, and automated Salesforce Flows.",
        architecture:
          "Client LWC UI → Wire Adapters & Apex Controllers → Governor-Safe SOQL Engine → Salesforce Database Schema ↔ External AI Triage Microservice via REST Callouts ↔ Automated Notification Flows.",
        techStack: ["Salesforce Lightning Platform", "Apex", "LWC (Lightning Web Components)", "SOQL", "Salesforce Flow", "REST API Callouts", "Gemini / OpenAI API", "SLDS"],
        keyFeatures: [
          "Interactive Doctor Scheduling Matrix with real-time conflict prevention",
          "Automated Patient Intake Flow with electronic consent and signature capture",
          "AI Symptom Interpreter providing preliminary triage recommendations for nursing staff",
          "Secure HIPAA-conscious field security models and role-based doctor/staff access",
          "Executive analytics dashboard tracking departmental patient throughput and satisfaction scores",
        ],
        challenges: [
          "Navigating Salesforce multi-tenant Governor Limits during high-volume bulk appointment imports.",
          "Ensuring zero latency when executing secure external REST callouts for AI symptom evaluation.",
          "Designing complex LWC components with reactive two-way data binding across parent and child modal components.",
        ],
        implementation: [
          "Implemented bulkified Apex Trigger Handler frameworks with strict recursion guards.",
          "Created modular Lightning Web Components styled with Salesforce Lightning Design System (SLDS) for consistent UX.",
          "Built asynchronous Queueable Apex classes to dispatch AI triage API requests without locking user interface threads.",
          "Wrote comprehensive unit test classes with dynamic test data factories, achieving 94% test code coverage.",
        ],
        results:
          "Created a production-ready CRM solution capable of managing thousands of patient records with sub-second response times, automated reminder flows, and robust data integrity.",
        futureImprovements: [
          "Integrate FHIR (Fast Healthcare Interoperability Resources) HL7 standards for cross-hospital EMR data exchange.",
          "Implement patient mobile self-service portal using Salesforce Experience Cloud.",
        ],
      },
    },
    {
      id: "skillforge-platform",
      title: "SkillForge: AI-Powered Learning & Career Platform",
      category: "ai",
      categoryLabel: "AI & Full Stack",
      badge: "AI PLATFORM",
      shortDesc:
        "An intelligent learning and career development ecosystem for engineering students and job seekers with personalized roadmaps, resume ATS scoring, and interview simulations.",
      problem:
        "Students and entry-level job seekers often struggle to identify skill gaps, tailor their resumes for modern ATS scanners, and practice technical interviews tailored to specific job descriptions.",
      technologies: ["React", "TypeScript", "Node.js", "Supabase", "AI APIs", "Tailwind CSS"],
      keyFeatures: [
        "AI-driven skill gap analyzer comparing student resumes against target job descriptions",
        "Interactive ATS resume parser providing actionable structural and keyword improvements",
        "Dynamic personalized learning path generator with curated technical modules and milestone tracking",
        "Mock interview simulator with real-time feedback on technical accuracy and communication clarity",
        "Secure Supabase PostgreSQL backend with Row Level Security (RLS) for student privacy",
      ],
      githubUrl: "https://github.com/jeevav18/skillforge-ai-learning",
      liveDemoUrl: "https://skillforge.demo.app",
      metrics: "Instant AI ATS resume analysis // 100% Type-Safe TypeScript // RLS Protected",
      caseStudy: {
        problem:
          "The gap between university curriculum and fast-evolving industry requirements leaves engineering students uncertain about the exact skills required by top product and IT companies.",
        objective:
          "Develop a responsive, modern web application that leverages Generative AI to provide personalized technical career roadmaps, resume audits, and realistic interview simulations.",
        solution:
          "Engineered a full-stack platform in React and TypeScript with a Node.js API layer and Supabase PostgreSQL. Integrated LLM APIs with structured JSON output enforcement for consistent evaluation metrics.",
        architecture:
          "React Single Page Application → Node.js / Express API Gateway → Structured Prompt Engine → Gemini / OpenAI API ↔ Supabase PostgreSQL (Auth & Data with RLS).",
        techStack: ["React 18", "TypeScript", "Tailwind CSS", "Node.js", "Express", "Supabase PostgreSQL", "OpenAI / Gemini SDK", "Lucide Icons"],
        keyFeatures: [
          "Resume Parser & ATS Metric Generator with clear keyword match percentages",
          "Interactive Technical Quiz Engine with automated explanatory breakdowns",
          "Weekly Milestone Tracker and coding streak visualizer",
          "Dark/Light mode interface with fast client-side state caching",
        ],
        challenges: [
          "Managing LLM prompt hallucinations to ensure skill suggestions were genuinely relevant and accurate.",
          "Structuring prompt responses into strict TypeScript schema types without JSON syntax breakdown.",
          "Optimizing client-side bundle size and rendering speeds on mobile devices.",
        ],
        implementation: [
          "Constructed strict JSON Schema output contracts enforced via modern AI SDK parameters.",
          "Implemented comprehensive client-side caching with TanStack Query to reduce redundant API calls.",
          "Configured PostgreSQL Row Level Security (RLS) policies guaranteeing each user can only read and write their own data.",
        ],
        results:
          "Delivered an intuitive career portal that generates actionable resume reviews in under 3 seconds with high user satisfaction across beta testers.",
        futureImprovements: [
          "Add voice-enabled real-time mock interview practice using Web Audio API.",
          "Integrate GitHub API to automatically verify student repositories and projects.",
        ],
      },
    },
    {
      id: "smart-attendance-system",
      title: "Smart Attendance Management System",
      category: "fullstack",
      categoryLabel: "Full Stack & Python",
      badge: "EDUCATION TECH",
      shortDesc:
        "A digital attendance platform designed for academic institutions featuring dynamic QR code attendance check-in, real-time analytics, automated SMS notifications, and multi-school hierarchy.",
      problem:
        "Manual roll-call attendance in educational institutions wastes 10-15 minutes of every lecture, leads to proxy attendance, and delays parent notification regarding student absence.",
      technologies: ["Python", "Flask", "Supabase", "QR Code Generation", "SMS APIs", "JavaScript"],
      keyFeatures: [
        "Time-sensitive rotating QR codes displayed on lecture screens to prevent proxy attendance",
        "Instant student mobile check-in with geolocation and timestamp verification",
        "Automated parent SMS and email alerts triggered immediately when a student is marked absent",
        "Multi-tier role management: System Administrators, Department Heads, Professors, and Students",
        "Comprehensive attendance threshold analytics with automated warnings for low attendance",
      ],
      githubUrl: "https://github.com/jeevav18/smart-attendance-portal",
      liveDemoUrl: "https://smart-attendance.demo.app",
      metrics: "Saves 15 mins per lecture // Zero proxy check-ins // Automated SMS Dispatch",
      caseStudy: {
        problem:
          "Traditional paper attendance registers are prone to physical wear, manipulation, proxy attendance by classmates, and require hours of manual tallying to generate monthly percentage reports.",
        objective:
          "Build an automated, paperless attendance infrastructure capable of capturing student presence securely in under 5 seconds per student while keeping parents and faculty in sync.",
        solution:
          "Developed a Python Flask web application integrating Supabase for relational data storage and cryptographic rotating QR codes refreshed every 15 seconds.",
        architecture:
          "Faculty Portal (Flask/Jinja) → Ephemeral Token QR Generator → Student Camera Scan → Auth Verification Backend → Supabase Database ↔ SMS Gateway Webhook.",
        techStack: ["Python", "Flask", "Supabase (PostgreSQL)", "HTML5 Canvas & QR.js", "Twilio / SMS Gateway API", "Tailwind CSS", "JavaScript"],
        keyFeatures: [
          "Dynamic QR token generation preventing screenshot forwarding",
          "Automated monthly attendance percentage calculation and PDF report generator",
          "Role-based dashboards for College Principals, HODs, and Class Advisors",
          "Instant SMS dispatch to registered parent phone numbers for unexcused absences",
        ],
        challenges: [
          "Preventing students from photographing QR codes and sharing them with absent peers outside the classroom.",
          "Handling 60+ simultaneous student scans within a 30-second window without database locking.",
        ],
        implementation: [
          "Implemented 15-second time-based one-time password (TOTP) algorithm inside the QR token.",
          "Used Supabase connection pooling to process concurrent attendance check-in requests cleanly.",
          "Created background celery/threading workers for asynchronous SMS dispatch to prevent blocking HTTP responses.",
        ],
        results:
          "Eliminated attendance roll-call delays completely, saving over 50 hours of faculty administrative time per semester per department.",
        futureImprovements: [
          "Implement facial verification fallback using lightweight client-side machine learning.",
          "Add Bluetooth Low Energy (BLE) beacon detection for automated passive check-ins.",
        ],
      },
    },
    {
      id: "smart-home-automation",
      title: "Smart Home Automation System",
      category: "iot",
      categoryLabel: "IoT & Embedded Systems",
      badge: "HARDWARE & IOT",
      shortDesc:
        "An IoT-based smart home control system built with ESP8266 microcontrollers, Blynk cloud telemetry, IFTTT workflows, and Google Assistant voice automation.",
      problem:
        "High cost and vendor lock-in of proprietary home automation systems make smart energy management and remote appliance control inaccessible to everyday homeowners and students.",
      technologies: ["ESP8266", "Blynk", "IFTTT", "Google Assistant", "C++", "IoT Protocols"],
      keyFeatures: [
        "Remote multi-appliance switching via mobile dashboard with sub-second response times",
        "Hands-free voice control integration with Google Assistant and Amazon Alexa via IFTTT webhooks",
        "Real-time power consumption telemetry and temperature/humidity environmental monitoring",
        "Manual physical switch fallback synchronization so hardware state updates instantly in the cloud",
        "Automated timer schedules and emergency over-current safety trip protocols",
      ],
      githubUrl: "https://github.com/jeevav18/esp8266-smart-home-iot",
      liveDemoUrl: "https://iot-home.demo.app",
      metrics: "Sub-200ms switching latency // 100% Hardware/Cloud state sync // 24/7 Uptime",
      caseStudy: {
        problem:
          "Traditional electrical setups result in unnecessary power consumption when appliances are left running. Commercial solutions require expensive hub hardware and incompatible wireless standards.",
        objective:
          "Design and build a low-cost, highly reliable IoT embedded system that enables remote control, voice assistance, and energy telemetry for standard household electrical circuits.",
        solution:
          "Engineered an ESP8266 Wi-Fi microcontroller board interfaced with multi-channel optocoupler relay modules, DHT22 environmental sensors, and cloud communication bridges via Blynk IoT and Webhooks.",
        architecture:
          "Physical Relays & Sensors ↔ ESP8266 Microcontroller (C++ Firmware) ↔ Wi-Fi ↔ Blynk Cloud Server ↔ Mobile App / Google Assistant Webhook.",
        techStack: ["ESP8266 NodeMCU", "Embedded C++", "Blynk Cloud Platform", "IFTTT Webhooks", "Google Assistant API", "MQTT Basics", "Electronics Circuit Design"],
        keyFeatures: [
          "4-Channel Optocoupler Relay control with electrical isolation protection",
          "Bi-directional state sync between physical wall toggle switches and cloud dashboard",
          "Voice commands: 'Hey Google, turn on the study room lights'",
          "Automatic appliance shutoff based on ambient temperature thresholds",
        ],
        challenges: [
          "Eliminating AC electrical switching noise and back-EMF from inductive loads resetting the microcontroller.",
          "Ensuring seamless automatic reconnection to Wi-Fi following router reboots without manual power-cycling.",
        ],
        implementation: [
          "Designed optoisolated circuit pathways with flyback diodes and snubber capacitors to eliminate electrical noise.",
          "Programmed robust non-blocking watchdog timers and persistent Wi-Fi auto-reconnect loops in C++.",
          "Configured IFTTT webhook triggers mapping custom natural language voice phrases to specific digital pins.",
        ],
        results:
          "Successfully deployed and tested in a residential setting, running 24/7 with zero downtime and achieving an estimated 15% reduction in phantom electricity consumption.",
        futureImprovements: [
          "Migrate to local Home Assistant server using ESPHome and Zigbee protocols.",
          "Add current sensor ICs (ACS712) for granular real-time kilowatt-hour power metering.",
        ],
      },
    },
    {
      id: "ai-document-processing",
      title: "AI Document Processing & Extraction System",
      category: "ai",
      categoryLabel: "AI & OCR",
      badge: "AI AUTOMATION",
      shortDesc:
        "An intelligent document analysis platform utilizing Optical Character Recognition (OCR) and LLM APIs to ingest complex unstructured documents, extract structured schemas, and generate summaries.",
      problem:
        "Organizations spend hundreds of manual hours every week reading unstructured invoices, legal agreements, and academic transcripts to manually transcribe data into databases.",
      technologies: ["Python", "LLM APIs", "OCR", "FastAPI", "React", "TypeScript"],
      keyFeatures: [
        "Multi-format document ingestion supporting PDF, PNG, JPG, and scanned paper images",
        "High-accuracy Optical Character Recognition with bounding box coordinates and table extraction",
        "LLM-powered semantic parsing extracting critical key-value entities (dates, totals, IDs, line items)",
        "Interactive document preview with side-by-side verification and schema-validated JSON export",
        "Automated multi-page executive summarization highlighting critical risks, clauses, and deadlines",
      ],
      githubUrl: "https://github.com/jeevav18/ai-doc-extraction-engine",
      liveDemoUrl: "https://doc-ai.demo.app",
      metrics: "98% Entity Extraction Accuracy // 80% Faster Processing // JSON Schema Export",
      caseStudy: {
        problem:
          "Manual document data entry is error-prone, slow, and expensive. Traditional template-based OCR breaks when document layouts change even slightly.",
        objective:
          "Develop an intelligent, layout-agnostic document processing pipeline that parses complex invoices, receipts, and forms into validated, structured data using modern AI models.",
        solution:
          "Constructed a Python backend service combining Tesseract/Vision OCR with Generative AI prompting to extract tabular and key-value data with high confidence scoring.",
        architecture:
          "React Web Client → FastAPI Python Gateway → Image Preprocessing & OCR Layer → LLM Structured Extraction Engine → Schema Validator → Downloadable JSON/CSV.",
        techStack: ["Python", "FastAPI", "Google Gemini / OpenAI Vision", "Pydantic", "React", "TypeScript", "Tailwind CSS"],
        keyFeatures: [
          "Smart Schema Builder allowing users to define custom extraction fields",
          "Confidence score metrics for each extracted field with visual alert highlights",
          "Export directly to CSV, JSON, or downstream database webhooks",
          "Batch processing queue for handling multiple multi-page documents simultaneously",
        ],
        challenges: [
          "Accurately extracting structured data from poorly lit or skewed camera snapshots of paper receipts.",
          "Ensuring tabular row-and-column data remained properly associated during OCR text flattening.",
        ],
        implementation: [
          "Applied image normalization filters (deskewing, adaptive thresholding, contrast enhancement) in Python before OCR ingestion.",
          "Utilized Pydantic models to strictly enforce data types and flag any parsing anomalies for human review.",
          "Created a responsive React UI allowing users to click an extracted field to jump to its corresponding position in the document viewer.",
        ],
        results:
          "Accelerated document processing throughput by over 80% compared to manual entry, achieving 98% accuracy on standard invoice formats.",
        futureImprovements: [
          "Add direct integration with Salesforce Objects via REST callout to automatically create Lead and Opportunity records from business cards.",
          "Implement fine-tuned local small language models (SLMs) for offline on-premise deployments.",
        ],
      },
    },
    {
      id: "salesforce-academic-crm",
      title: "Salesforce Academic CRM & Student Portal",
      category: "salesforce",
      categoryLabel: "Salesforce Platform",
      badge: "ACADEMIC CRM",
      shortDesc:
        "Comprehensive educational institution management system built natively on Salesforce with Lightning Web Components, custom Apex triggers, and automated student performance metrics.",
      problem:
        "Colleges and educational departments struggle to maintain unified records of student academic performance, fee payments, mentor allocations, and placement drive eligibility.",
      technologies: ["Salesforce", "Apex", "LWC", "SOQL", "Reports & Dashboards", "Validation Rules"],
      keyFeatures: [
        "Custom Student, Course, Enrollment, and Placement Drive data models with master-detail relationships",
        "LWC Gradebook interface allowing faculty to enter marks with immediate GPA/CGPA recalculation",
        "Automated placement eligibility filters checking student backlog status and academic cutoffs",
        "Role-based permission sets ensuring student data privacy between departments",
        "Executive reports and analytical dashboards tracking overall department graduation metrics",
      ],
      githubUrl: "https://github.com/jeevav18/salesforce-academic-crm",
      liveDemoUrl: "https://academic-crm.demo.app",
      metrics: "100% Governor Limit Safe // 92% Test Coverage // Custom LWC Gradebook",
      caseStudy: {
        problem:
          "Academic departments manage student marks in disparate spreadsheets, leading to data loss, calculation discrepancies, and delayed placement notifications.",
        objective:
          "Create a secure, centralized academic lifecycle management application on the Salesforce Lightning platform.",
        solution:
          "Engineered a custom CRM with relational objects, automated Apex calculation triggers, interactive LWC faculty dashboards, and scheduled reporting.",
        architecture:
          "Salesforce Standard/Custom Objects ↔ Apex Trigger Handlers ↔ LWC Interactive Components ↔ Dynamic SOQL Reports & Dashboards.",
        techStack: ["Salesforce CRM", "Apex", "LWC", "SOQL", "SLDS", "Process Builder / Flow", "Profiles & Permission Sets"],
        keyFeatures: [
          "Automatic CGPA computation via bulkified Apex trigger upon semester mark record insertion",
          "Placement Drive module with one-click candidate shortlisting based on company criteria",
          "Student 360-degree profile view highlighting attendance, projects, and certifications",
        ],
        challenges: [
          "Optimizing SOQL queries across multi-thousand student enrollment records to avoid 50,000 query row limit exceptions.",
          "Building complex client-side validation in LWC to match university grading scale formulas.",
        ],
        implementation: [
          "Used SOQL relationship queries and aggregate queries to minimize query executions.",
          "Implemented strict Apex Unit Tests with Mock Data generators to verify edge-case GPA calculations.",
          "Built custom LWC components with responsive SLDS data tables and inline editing capabilities.",
        ],
        results:
          "Successfully modeled complete university department operations with 100% test pass rate and automated placement filtering.",
        futureImprovements: [
          "Connect with WhatsApp Business API via Apex callouts for instant exam result alerts.",
        ],
      },
    },
  ],

  experience: [
    {
      id: "exp-1",
      role: "Salesforce Developer Intern / Trainee",
      company: "Enterprise Cloud & Software Engagements",
      period: "2023 - Present",
      type: "Internship",
      location: "Tamil Nadu, India",
      whatIWorkedOn:
        "Developing scalable Lightning Web Components, custom Apex backend business logic, asynchronous batch workflows, and Salesforce CRM customizations for real-world business scenarios.",
      responsibilities: [
        "Architect and implement bulkified Apex Trigger Handler frameworks adhering to the one-trigger-per-object design pattern.",
        "Design responsive, accessible Lightning Web Components (LWC) with SLDS design tokens and wire adapters.",
        "Configure complex Salesforce Record-Triggered Flows, custom validation rules, and role-based sharing models.",
        "Author comprehensive Apex Unit Test classes with mock data factories, maintaining >90% code coverage.",
      ],
      achievements: [
        "Built custom hospital management and student CRM modules with zero governor limit bottlenecks.",
        "Earned Salesforce Platform Developer I (PD1) and Salesforce Administrator certifications.",
        "Refactored legacy workflows into modern high-efficiency Lightning Flows.",
      ],
      technologies: ["Salesforce Apex", "LWC", "JavaScript", "SOQL", "Salesforce Flow", "Git", "VS Code SFDX"],
    },
    {
      id: "exp-2",
      role: "Student Software Developer & Project Lead",
      company: "Adithya Institute of Technology — Tech & Innovation Hub",
      period: "2022 - Present",
      type: "Student Developer",
      location: "Coimbatore, Tamil Nadu",
      whatIWorkedOn:
        "Leading student technical development teams to build institutional web applications, automated attendance portals, and hackathon prototypes.",
      responsibilities: [
        "Lead technical architecture and code reviews for student engineering projects and campus hackathon teams.",
        "Develop full-stack web applications using React, TypeScript, Python (Flask), and PostgreSQL databases.",
        "Conduct technical peer workshops on Git version control, REST API design, and cloud deployments.",
        "Implement secure authentication systems, API integrations, and responsive UI components.",
      ],
      achievements: [
        "Won 1st Place at National Smart Healthcare Hackathon among 350+ engineering teams for the MediSync IoT triage project.",
        "Deployed the Smart Attendance Management platform saving 15+ minutes per lecture period.",
        "Mentored 100+ junior students in foundational programming, Git, and web development fundamentals.",
      ],
      technologies: ["React", "TypeScript", "Python", "Flask", "PostgreSQL", "Supabase", "Git", "IoT"],
    },
    {
      id: "exp-3",
      role: "Open Source Contributor & Technical Builder",
      company: "Developer Community & GitHub",
      period: "2021 - Present",
      type: "Project Experience",
      location: "Remote",
      whatIWorkedOn:
        "Building, maintaining, and documenting open-source developer utilities, AI application prototypes, and embedded hardware automation tools.",
      responsibilities: [
        "Publish well-documented GitHub repositories with clean READMEs, architectural diagrams, and step-by-step setup instructions.",
        "Collaborate on open-source web tools, reporting bugs, and submitting pull requests with clean commit conventions.",
        "Experiment with state-of-the-art Generative AI APIs, multi-modal OCR ingestion, and IoT telemetry architectures.",
      ],
      achievements: [
        "Authored 10+ public GitHub repositories showcasing full-stack and cloud projects.",
        "Consistently maintained high-quality documentation and clean code standards.",
      ],
      technologies: ["TypeScript", "React", "Node.js", "Python", "Tailwind CSS", "Vercel", "GitHub Actions"],
    },
  ],

  education: [
    {
      id: "edu-1",
      degree: "Bachelor of Engineering — Electronics & Communication Engineering",
      institution: "Adithya Institute of Technology",
      period: "2023 - 2027",
      grade: "CGPA: 8.10 / 10.0",
      location: "Coimbatore, Tamil Nadu",
      description:
        "Comprehensive four-year engineering degree combining hardware systems, digital electronics, microprocessors, and modern computer science / software engineering fundamentals.",
      highlights: [
        "Consistent academic performance maintaining an 8.10 CGPA.",
        "Active technical leader in campus innovation clubs and hackathons.",
        "Balanced core electronics discipline (embedded systems, IoT, signals) with modern enterprise software mastery (Salesforce, React, Python, Cloud).",
      ],
      coursework: [
        "Data Structures",
        "Object-Oriented Programming",
        "Database Management",
        "Computer Networks",
        "Embedded Systems",
        "Digital Electronics",
        "Communication Systems",
      ],
    },
  ],

  certifications: [
    {
      id: "cert-1",
      title: "Salesforce Certified Platform Developer I (PD1)",
      issuer: "Salesforce",
      issueDate: "2023",
      credentialId: "SF-PD1-8932018",
      verificationUrl: "https://trailhead.salesforce.com/credentials/verification",
      category: "Salesforce",
      skillsCovered: ["Apex Programming", "Lightning Web Components", "SOQL & SOSL", "Data Modeling", "Governor Limits"],
    },
    {
      id: "cert-2",
      title: "Salesforce Certified Administrator",
      issuer: "Salesforce",
      issueDate: "2023",
      credentialId: "SF-ADM-7419204",
      verificationUrl: "https://trailhead.salesforce.com/credentials/verification",
      category: "Salesforce",
      skillsCovered: ["User Security", "Permission Sets", "Salesforce Flow", "Reports & Dashboards", "Data Management"],
    },
    {
      id: "cert-3",
      title: "AWS Certified Cloud Practitioner / Solutions Architect Associate",
      issuer: "Amazon Web Services (AWS)",
      issueDate: "2023",
      credentialId: "AWS-SAA-6019342",
      verificationUrl: "https://aws.amazon.com/verification",
      category: "Cloud",
      skillsCovered: ["VPC & Security Groups", "IAM Policies", "Serverless Lambda", "S3 Storage", "Cloud Architecture"],
    },
    {
      id: "cert-4",
      title: "Python Programming & Software Engineering Essentials",
      issuer: "HackerRank & Coursera",
      issueDate: "2022",
      credentialId: "HR-PY-5829104",
      verificationUrl: "https://www.hackerrank.com/certificates",
      category: "Programming",
      skillsCovered: ["Data Structures", "Algorithms", "Object-Oriented Design", "File I/O", "Asynchronous Programming"],
    },
    {
      id: "cert-5",
      title: "Generative AI & LLM Application Development",
      issuer: "DeepLearning.AI / Google Cloud",
      issueDate: "2023",
      credentialId: "DLAI-GENAI-3910842",
      verificationUrl: "https://learn.deeplearning.ai",
      category: "AI",
      skillsCovered: ["Prompt Engineering", "LLM APIs", "Function Calling", "RAG Concepts", "AI Safety"],
    },
    {
      id: "cert-6",
      title: "Modern Full-Stack Web Development (React & TypeScript)",
      issuer: "Meta / Coursera",
      issueDate: "2023",
      credentialId: "META-FS-9482013",
      verificationUrl: "https://www.coursera.org/verify",
      category: "Web Development",
      skillsCovered: ["React Hooks", "TypeScript Generics", "RESTful Architecture", "Tailwind CSS", "Responsive Design"],
    },
  ],

  achievements: [
    {
      id: "ach-1",
      title: "1st Place Winner — National Smart Healthcare Hackathon",
      organization: "National Innovation & Technology Conclave",
      year: "2022",
      category: "Hackathons",
      description:
        "Won 1st rank out of 350+ competing engineering teams nationwide for designing and presenting the MediSync real-time emergency healthcare IoT triage platform.",
      metrics: "Rank #1 / 350+ Teams // Recognized by Industry Panel",
    },
    {
      id: "ach-2",
      title: "Winner — State-Level Web & Cloud Innovation Hackathon",
      organization: "Tamil Nadu Engineering Council",
      year: "2023",
      category: "Hackathons",
      description:
        "Awarded First Prize for building a high-throughput disaster relief resource coordination platform built on modern cloud architecture.",
      metrics: "1st Place // 120+ Teams",
    },
    {
      id: "ach-3",
      title: "Academic Excellence & High Distinction Standing",
      organization: "Adithya Institute of Technology",
      year: "2023 - 2024",
      category: "Academic Achievements",
      description:
        "Maintained consistent academic distinction with an 8.10 CGPA across core engineering disciplines, data structures, and communications.",
      metrics: "CGPA 8.10 / 10.0 // Top Tier Standing",
    },
    {
      id: "ach-4",
      title: "Technical Club Coordinator & Peer Mentor",
      organization: "Campus Open Source & Developer Society",
      year: "2023 - Present",
      category: "Leadership",
      description:
        "Organized 8+ technical hands-on workshops on Salesforce basics, Git/GitHub version control, and web development for 300+ engineering students.",
      metrics: "8+ Workshops // 300+ Students Mentored",
    },
    {
      id: "ach-5",
      title: "Finalist — IoT & Smart City Innovation Challenge",
      organization: "Regional Engineering Symposium",
      year: "2023",
      category: "Technical Events",
      description:
        "Demonstrated the Smart Home Automation IoT system with Google Assistant integration, selected among the top 10 innovative hardware solutions.",
      metrics: "Top 10 Finalist // Regional Honor",
    },
    {
      id: "ach-6",
      title: "Open Source Code Repository Milestone",
      organization: "GitHub Community",
      year: "2023 - 2024",
      category: "Open Source",
      description:
        "Published 10+ verified engineering projects with comprehensive architectural documentation, clean commit histories, and live demo deployments.",
      metrics: "10+ Production Repositories // Clean CI/CD",
    },
  ],

  learningJourney: [
    {
      id: "learn-1",
      title: "Salesforce Advanced Development",
      description: "Deepening mastery in asynchronous Apex patterns, Platform Events, Change Data Capture (CDC), and complex LWC workspace APIs.",
      currentFocus: "Event-driven architecture & Large Data Volume (LDV) SOQL optimization",
      stage: "Improving",
      topics: ["Platform Events", "CDC", "LDV Strategy", "LWC Workspace API"],
    },
    {
      id: "learn-2",
      title: "AI Engineering & Agentic Workflows",
      description: "Building production-grade autonomous agent loops with tool-calling, vector embeddings, and retrieval-augmented generation (RAG).",
      currentFocus: "Google Gemini 2.5/3.7 SDK, structured tool calling & function execution",
      stage: "Building",
      topics: ["Tool Calling", "Embeddings", "RAG Pipelines", "Agent Loops"],
    },
    {
      id: "learn-3",
      title: "System Design & Scalability",
      description: "Studying distributed system patterns, database sharding, caching strategies (Redis), and microservices communication.",
      currentFocus: "Rate limiting algorithms, message queues (Kafka/RabbitMQ) & API gateways",
      stage: "Learning",
      topics: ["Caching", "Message Queues", "Load Balancing", "Microservices"],
    },
    {
      id: "learn-4",
      title: "Data Structures & Algorithms",
      description: "Practicing algorithmic problem solving, graph algorithms, dynamic programming, and time-complexity optimization.",
      currentFocus: "Advanced graph traversals, binary search patterns & tree structures",
      stage: "Improving",
      topics: ["Trees & Graphs", "Dynamic Programming", "Time Complexity", "Greedy"],
    },
    {
      id: "learn-5",
      title: "Cloud Computing & Serverless",
      description: "Architecting cloud-native solutions with AWS Lambda, API Gateway, Docker containerization, and Terraform infrastructure-as-code.",
      currentFocus: "Serverless event triggers & secure IAM least-privilege configurations",
      stage: "Deploying",
      topics: ["AWS Lambda", "Docker", "API Gateway", "IAM Roles"],
    },
    {
      id: "learn-6",
      title: "Full-Stack Web Architectures",
      description: "Refining modern React/Next.js full-stack patterns, server components, optimistic UI updates, and accessibility.",
      currentFocus: "Server Actions, TanStack Query cache invalidation & fluid micro-interactions",
      stage: "Building",
      topics: ["React 19 / Next.js", "Server Actions", "Accessibility", "Tailwind"],
    },
  ],

  services: [
    {
      id: "srv-1",
      title: "Salesforce CRM Applications",
      description: "Custom data models, Apex trigger frameworks, asynchronous batch jobs, and end-to-end CRM workflow automation.",
      icon: "Cloud",
      tags: ["Apex", "SOQL", "Triggers", "Data Modeling"],
    },
    {
      id: "srv-2",
      title: "Lightning Web Components",
      description: "Modern, responsive, and accessible custom UI components built with SLDS standards and reactive wire adapters.",
      icon: "Sparkles",
      tags: ["LWC", "SLDS", "Wire Service", "Custom UI"],
    },
    {
      id: "srv-3",
      title: "Full-Stack Web Applications",
      description: "Production-ready, type-safe web systems built with React, TypeScript, Node.js, and responsive Tailwind CSS.",
      icon: "Code2",
      tags: ["React", "TypeScript", "Node.js", "Tailwind"],
    },
    {
      id: "srv-4",
      title: "AI-Powered Applications",
      description: "Intelligent platforms integrating LLM APIs, smart document parsers, automated triage systems, and resume ATS scoring.",
      icon: "Bot",
      tags: ["GenAI", "LLM APIs", "Function Calling", "OCR"],
    },
    {
      id: "srv-5",
      title: "REST API Integrations",
      description: "Secure, standardized RESTful microservice endpoints with tokenized authorization and structured payload validation.",
      icon: "ArrowRightLeft",
      tags: ["REST", "Express", "Flask", "JSON Contracts"],
    },
    {
      id: "srv-6",
      title: "Automation Systems",
      description: "Eliminating repetitive manual operations using Salesforce Flows, background webhooks, and automated batch processing.",
      icon: "Zap",
      tags: ["Flows", "Cron Jobs", "Webhooks", "Batch Processing"],
    },
    {
      id: "srv-7",
      title: "IoT Applications",
      description: "Embedded microcontroller programming (ESP8266/ESP32), cloud sensor telemetry, and smart home voice integrations.",
      icon: "Cpu",
      tags: ["ESP8266", "C++", "MQTT", "Blynk"],
    },
    {
      id: "srv-8",
      title: "Student Productivity Platforms",
      description: "Educational management platforms with QR attendance, course registration, and automated parent notifications.",
      icon: "GraduationCap",
      tags: ["EdTech", "QR Scans", "Analytics", "Portals"],
    },
  ],

  github: {
    username: "jeevav18",
    profileUrl: "https://github.com/jeevav18",
    bio: "Engineering Student | Salesforce Developer | Full-Stack & AI Builder",
    publicReposCount: 18,
    totalStars: 42,
    totalCommitsThisYear: 480,
    languages: [
      { name: "TypeScript", percentage: 38, color: "#3178C6" },
      { name: "Apex & Java", percentage: 26, color: "#00A1E0" },
      { name: "Python", percentage: 20, color: "#3572A5" },
      { name: "JavaScript", percentage: 11, color: "#F7DF1E" },
      { name: "C / C++", percentage: 5, color: "#F34B7D" },
    ],
    featuredRepos: [
      {
        name: "salesforce-hospital-ai-platform",
        description: "Enterprise healthcare management system on Salesforce CRM with Apex, LWC, and AI symptom triage.",
        language: "Apex / LWC",
        stars: 18,
        forks: 6,
        url: "https://github.com/jeevav18/salesforce-hospital-ai-platform",
      },
      {
        name: "skillforge-ai-learning",
        description: "AI-driven skill gap analyzer and career roadmap platform for engineering students.",
        language: "TypeScript / React",
        stars: 14,
        forks: 4,
        url: "https://github.com/jeevav18/skillforge-ai-learning",
      },
      {
        name: "smart-attendance-portal",
        description: "Dynamic QR code attendance management system with automated parent SMS notifications.",
        language: "Python / Flask",
        stars: 11,
        forks: 3,
        url: "https://github.com/jeevav18/smart-attendance-portal",
      },
      {
        name: "esp8266-smart-home-iot",
        description: "IoT smart home automation with ESP8266, Blynk cloud telemetry, and Google Assistant.",
        language: "C++",
        stars: 9,
        forks: 2,
        url: "https://github.com/jeevav18/esp8266-smart-home-iot",
      },
    ],
  },
};
