import React, { useState, useRef } from "react";
import { PassRequest } from "@/types/campuspass";
import { QRCodeSVG } from "qrcode.react";
import { 
  Printer, 
  Download, 
  Copy, 
  FileText, 
  ShieldCheck, 
  Building, 
  Clock, 
  User, 
  CheckCircle2, 
  HeartHandshake, 
  Phone, 
  Sparkles,
  ArrowRight,
  ExternalLink,
  Info
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { AdithyaLogo } from "./AdithyaLogo";
import { toast } from "sonner";

interface PaperPassPreviewViewProps {
  passes: PassRequest[];
  onNavigateToScanner?: (token: string) => void;
}

export const PaperPassPreviewView: React.FC<PaperPassPreviewViewProps> = ({
  passes,
  onNavigateToScanner,
}) => {
  const [selectedPassId, setSelectedPassId] = useState<string>(
    passes[0]?.id || ""
  );
  const [slipStyle, setSlipStyle] = useState<"dual" | "single">("dual");
  const printRef = useRef<HTMLDivElement>(null);

  const selectedPass = passes.find((p) => p.id === selectedPassId) || passes[0];

  if (!selectedPass) {
    return (
      <div className="bg-white rounded-2xl p-12 text-center border border-slate-200">
        <FileText className="h-12 w-12 text-slate-300 mx-auto mb-3" />
        <h3 className="text-lg font-bold text-slate-800">No Pass Records Found</h3>
        <p className="text-sm text-slate-500">Submit an outing or home pass request first to generate a printable slip.</p>
      </div>
    );
  }

  const handlePrint = () => {
    window.print();
  };

  const handleCopySlipSummary = () => {
    const text = `
ADITHYA INSTITUTE OF TECHNOLOGY (TNEA CODE: 2744)
Kurumbapalayam, Coimbatore - 641107 | Phone: 0422-2654504
============================================================
OFFICIAL HOSTEL OUTING / LEAVE GATE PASS: ${selectedPass.passNumber}
FORM: AIT/HOSTEL/OP-04 (AUTONOMOUS / ANNA UNIVERSITY)
------------------------------------------------------------
Student Name : ${selectedPass.studentName}
Roll Number  : ${selectedPass.rollNumber}
Department   : ${selectedPass.department} (Year ${selectedPass.year})
Hostel Room  : ${selectedPass.hostelBlock} — Room ${selectedPass.roomNumber}
Leave Type   : ${selectedPass.passType.toUpperCase()}
Departure    : ${new Date(selectedPass.departureDateTime).toLocaleString()}
Curfew Return: ${new Date(selectedPass.expectedReturnDateTime).toLocaleString()}
Destination  : ${selectedPass.destination}
Purpose      : ${selectedPass.reason}
------------------------------------------------------------
PARENT / GUARDIAN VERIFICATION:
Guardian     : ${selectedPass.guardian.name} (${selectedPass.guardian.relation})
Phone        : ${selectedPass.guardian.phone}
WhatsApp Log : Consent verified & logged in system
------------------------------------------------------------
INSTITUTIONAL AUTHORIZATION SIGNATURES:
1. Class Tutor   : APPROVED [${selectedPass.approvalWorkflow.tutor.officerName || "Class Mentor"}]
2. Dept HOD      : CLEARED  [${selectedPass.approvalWorkflow.hod.officerName || "Head of Dept"}]
3. Chief Warden  : AUTHORIZED [${selectedPass.approvalWorkflow.warden.officerName || "Chief Warden"}]
Security Token   : ${selectedPass.qrToken || "AIT-TOKEN-ISSUED"}
============================================================
    `.trim();

    navigator.clipboard.writeText(text);
    toast.success("Paper pass slip summary copied to clipboard.");
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      
      {/* Top Controls Header (Hidden in physical print) */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm print:hidden dark:bg-slate-900 dark:border-slate-800">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          
          <div>
            <div className="flex items-center gap-2.5">
              <div className="p-2 bg-orange-100 text-orange-700 rounded-xl dark:bg-orange-950/60 dark:text-orange-300">
                <FileText className="h-5 w-5" />
              </div>
              <div>
                <h2 className="text-lg font-extrabold text-slate-900 tracking-tight dark:text-white">
                  Official Paper Pass Slip Preview & Print Station
                </h2>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Adithya Institute of Technology • Standard Hostel Gate Clearance Form (AIT/HOSTEL/OP-04)
                </p>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex flex-wrap items-center gap-2">
            <div className="flex items-center bg-slate-100 p-1 rounded-xl text-xs font-medium dark:bg-slate-800">
              <button
                onClick={() => setSlipStyle("dual")}
                className={`px-3 py-1.5 rounded-lg transition-all ${
                  slipStyle === "dual"
                    ? "bg-white text-orange-700 shadow-sm font-bold dark:bg-slate-700 dark:text-orange-300"
                    : "text-slate-600 hover:text-slate-900 dark:text-slate-400"
                }`}
              >
                Dual Copy (Student + Gate)
              </button>
              <button
                onClick={() => setSlipStyle("single")}
                className={`px-3 py-1.5 rounded-lg transition-all ${
                  slipStyle === "single"
                    ? "bg-white text-orange-700 shadow-sm font-bold dark:bg-slate-700 dark:text-orange-300"
                    : "text-slate-600 hover:text-slate-900 dark:text-slate-400"
                }`}
              >
                Standard A4 Dossier
              </button>
            </div>

            <Button
              variant="outline"
              size="sm"
              onClick={handleCopySlipSummary}
              className="text-xs gap-1.5 h-9"
            >
              <Copy className="h-3.5 w-3.5" />
              Copy Text
            </Button>

            <Button
              size="sm"
              onClick={handlePrint}
              className="bg-orange-600 hover:bg-orange-700 text-white font-bold text-xs gap-2 h-9 shadow-md"
            >
              <Printer className="h-4 w-4" />
              Print Paper Pass (A4)
            </Button>

            {selectedPass.qrToken && onNavigateToScanner && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => onNavigateToScanner(selectedPass.qrToken!)}
                className="text-xs border-emerald-300 text-emerald-700 bg-emerald-50 hover:bg-emerald-100 dark:bg-emerald-950/40 dark:border-emerald-800 dark:text-emerald-300 gap-1.5 h-9"
              >
                <ShieldCheck className="h-3.5 w-3.5" />
                Test Gate Scan
              </Button>
            )}
          </div>

        </div>

        {/* Pass Selector Tabs */}
        <div className="mt-4 pt-4 border-t border-slate-100 flex flex-wrap items-center gap-2 dark:border-slate-800">
          <span className="text-xs font-semibold text-slate-500 mr-1 dark:text-slate-400">Select Resident Pass:</span>
          {passes.map((p) => (
            <button
              key={p.id}
              onClick={() => setSelectedPassId(p.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold border transition-all flex items-center gap-2 ${
                selectedPassId === p.id
                  ? "bg-orange-50 border-orange-500 text-orange-950 shadow-sm ring-1 ring-orange-400 dark:bg-orange-950/40 dark:border-orange-600 dark:text-orange-200"
                  : "bg-white border-slate-200 text-slate-700 hover:bg-slate-50 dark:bg-slate-800 dark:border-slate-700 dark:text-slate-300"
              }`}
            >
              <span>{p.studentName.split(" ")[0]} ({p.rollNumber})</span>
              <span className="font-mono text-[10px] text-slate-400">{p.passNumber}</span>
              <span className={`h-2 w-2 rounded-full ${
                p.status === "approved" ? "bg-emerald-500" :
                p.status === "active_out" ? "bg-amber-500" :
                p.status === "overdue" ? "bg-red-500" : "bg-blue-500"
              }`} />
            </button>
          ))}
        </div>
      </div>

      {/* PAPER SLIP VIEWPORT CONTAINER */}
      <div className="flex justify-center bg-slate-200/70 p-4 sm:p-8 rounded-2xl border border-slate-300 shadow-inner dark:bg-slate-950 dark:border-slate-800">
        
        {/* Printable Physical Paper Slip */}
        <div
          ref={printRef}
          className="bg-white text-slate-900 max-w-3xl w-full p-6 sm:p-10 rounded-xl shadow-xl border border-slate-300 relative space-y-5 font-sans select-text print:p-0 print:border-none print:shadow-none print:max-w-none print:w-full"
          style={{ minHeight: "820px" }}
        >
          {/* Watermark */}
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-[0.035]">
            <span className="font-serif font-black text-8xl text-slate-900 rotate-[-30deg]">
              ADITHYA
            </span>
          </div>

          {/* OFFICIAL INSTITUTIONAL LETTERHEAD */}
          <div className="border-b-2 border-slate-900 pb-3 flex items-start justify-between gap-4">
            <div className="flex items-start gap-3.5">
              <AdithyaLogo size="lg" showText={false} />
              <div>
                <h1 className="font-serif font-black text-base sm:text-xl text-slate-900 tracking-tight leading-tight">
                  ADITHYA INSTITUTE OF TECHNOLOGY
                </h1>
                <p className="text-[10px] sm:text-[11px] text-slate-700 font-semibold">
                  Autonomous Institution • Approved by AICTE • Affiliated to Anna University Chennai • NAAC Accredited
                </p>
                <p className="text-[10px] text-slate-600">
                  SF No. 344, 349, Sathy Main Road, Kurumbapalayam Post, Coimbatore - 641 107, Tamil Nadu, India
                </p>
                <div className="flex items-center gap-3 text-[10px] font-mono mt-0.5">
                  <span className="font-bold text-orange-700">TNEA COUNSELLING CODE: 2744</span>
                  <span>•</span>
                  <span>ADMIN: 0422-2654504</span>
                  <span>•</span>
                  <span>HOSTEL HELPLINE: +91 73737 00933</span>
                </div>
              </div>
            </div>

            <div className="text-right shrink-0">
              <span className="inline-block bg-slate-900 text-white text-[9px] font-bold px-2 py-0.5 rounded uppercase tracking-wider">
                {slipStyle === "dual" ? "OFFICIAL COMPOSITE SLIP" : "A4 LEAVE DOSSIER"}
              </span>
              <div className="font-mono text-sm font-black text-slate-900 mt-1">
                {selectedPass.passNumber}
              </div>
              <div className="text-[10px] text-slate-500 font-mono">
                FORM: AIT/HOSTEL/OP-04
              </div>
              <div className="text-[9px] text-slate-400 font-mono">
                ISSUE DATE: {new Date(selectedPass.createdAt).toLocaleDateString([], { month: "short", day: "numeric", year: "numeric" })}
              </div>
            </div>
          </div>

          {/* TITLE BANNER */}
          <div className="bg-slate-100 border border-slate-300 py-1.5 px-4 rounded text-center flex items-center justify-between">
            <span className="text-[9px] font-mono text-slate-500 uppercase tracking-widest">
              OFFICE OF CHIEF WARDEN & STUDENT AFFAIRS
            </span>
            <h2 className="font-extrabold text-xs uppercase tracking-wider text-slate-900">
              OFFICIAL HOSTEL OUTING / HOME LEAVE GATE VERIFICATION PASS
            </h2>
            <span className="text-[9px] font-mono font-bold text-orange-700 uppercase">
              STATUS: {selectedPass.status.toUpperCase()}
            </span>
          </div>

          {/* STUDENT IDENTIFICATION PROFILE GRID */}
          <div className="grid grid-cols-1 sm:grid-cols-12 gap-4 pb-2 border-b border-slate-200">
            
            {/* Student Photo */}
            <div className="sm:col-span-3 flex flex-col items-center justify-center p-2.5 border border-slate-300 rounded-lg bg-slate-50">
              <img
                src={selectedPass.avatarUrl}
                alt={selectedPass.studentName}
                className="h-28 w-24 object-cover rounded border-2 border-slate-400 shadow-sm"
              />
              <span className="text-[9px] text-emerald-800 font-bold uppercase tracking-wider mt-1.5 flex items-center gap-1">
                <CheckCircle2 className="h-3 w-3 text-emerald-600" />
                VERIFIED RESIDENT
              </span>
              <span className="text-[8px] font-mono text-slate-400">
                BIOMETRIC ID: AIT-{selectedPass.rollNumber}
              </span>
            </div>

            {/* Resident Information Data Table */}
            <div className="sm:col-span-9 space-y-2 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div className="p-2 bg-slate-50 border border-slate-200 rounded">
                  <span className="text-[10px] text-slate-500 font-semibold uppercase block">STUDENT NAME</span>
                  <strong className="text-slate-900 text-sm block">{selectedPass.studentName}</strong>
                  <span className="text-[10px] text-slate-600 font-mono">Mobile: {selectedPass.studentPhone}</span>
                </div>
                <div className="p-2 bg-slate-50 border border-slate-200 rounded">
                  <span className="text-[10px] text-slate-500 font-semibold uppercase block">ROLL NUMBER / TNEA ID</span>
                  <strong className="font-mono text-orange-700 text-sm block">{selectedPass.rollNumber}</strong>
                  <span className="text-[10px] text-slate-600">Email: {selectedPass.studentEmail}</span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="p-2 bg-slate-50 border border-slate-200 rounded">
                  <span className="text-[10px] text-slate-500 font-semibold uppercase block">DEPARTMENT & ACADEMIC YEAR</span>
                  <span className="text-slate-900 font-bold block">{selectedPass.department}</span>
                  <span className="text-[10px] text-slate-600">Year {selectedPass.year} • Section A</span>
                </div>
                <div className="p-2 bg-slate-50 border border-slate-200 rounded">
                  <span className="text-[10px] text-slate-500 font-semibold uppercase block">HOSTEL BLOCK & ROOM ALLOTMENT</span>
                  <span className="text-slate-900 font-bold block">{selectedPass.hostelBlock.split("(")[0]}</span>
                  <span className="text-[10px] text-slate-600">Room Number: <strong className="text-slate-800">{selectedPass.roomNumber}</strong> (Kurumbapalayam)</span>
                </div>
              </div>

              <div className="flex items-center justify-between p-2 bg-orange-50 border border-orange-200 rounded text-xs text-orange-950">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-bold uppercase text-orange-800">LEAVE CATEGORY:</span>
                  <span className="bg-orange-200/80 text-orange-900 font-extrabold text-[11px] px-2.5 py-0.5 rounded capitalize">
                    {selectedPass.passType.replace("_", " ")}
                  </span>
                </div>
                <div className="text-[10px] text-orange-800 font-mono">
                  Clearance Code: <strong>AUTH-AIT-{(selectedPass.qrToken || selectedPass.passNumber).slice(0, 10)}</strong>
                </div>
              </div>
            </div>

          </div>

          {/* SCHEDULE & MOVEMENT PARAMETERS */}
          <div className="grid grid-cols-2 gap-3 p-3 bg-slate-50 rounded-lg border border-slate-300 text-xs">
            <div className="border-r border-slate-200 pr-3">
              <span className="text-[10px] font-bold text-slate-500 uppercase block">PERMITTED DEPARTURE FROM HOSTEL</span>
              <div className="font-extrabold text-slate-900 text-sm mt-0.5">
                {new Date(selectedPass.departureDateTime).toLocaleDateString([], { weekday: "short", month: "short", day: "numeric", year: "numeric" })}
              </div>
              <div className="font-mono font-black text-blue-700 text-base">
                {new Date(selectedPass.departureDateTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} HRS
              </div>
              <span className="text-[9px] text-slate-500">Scheduled Outing Window</span>
            </div>

            <div className="pl-2">
              <span className="text-[10px] font-bold text-slate-500 uppercase block">MANDATORY RETURN CURFEW DEADLINE</span>
              <div className="font-extrabold text-slate-900 text-sm mt-0.5">
                {new Date(selectedPass.expectedReturnDateTime).toLocaleDateString([], { weekday: "short", month: "short", day: "numeric", year: "numeric" })}
              </div>
              <div className="font-mono font-black text-red-700 text-base">
                {new Date(selectedPass.expectedReturnDateTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} HRS
              </div>
              <span className="text-[9px] text-red-600 font-semibold">Strict Hostel Gate Curfew Enforced</span>
            </div>
          </div>

          {/* DESTINATION & REASON */}
          <div className="space-y-1.5 text-xs p-3 border border-slate-200 rounded-lg bg-white">
            <div className="flex items-start gap-1">
              <span className="font-bold text-slate-900 w-36 shrink-0">Authorized Destination:</span>
              <span className="text-slate-800 font-medium">{selectedPass.destination}</span>
            </div>
            <div className="flex items-start gap-1">
              <span className="font-bold text-slate-900 w-36 shrink-0">Stated Purpose / Event:</span>
              <span className="text-slate-700">{selectedPass.reason}</span>
            </div>
            <div className="flex items-start gap-1">
              <span className="font-bold text-slate-900 w-36 shrink-0">Emergency Contact No:</span>
              <span className="font-mono font-bold text-slate-800">{selectedPass.destinationContact || selectedPass.studentPhone}</span>
            </div>
          </div>

          {/* PARENT / GUARDIAN VERIFICATION CLEARANCE */}
          <div className="p-3 bg-teal-50 border border-teal-300 rounded-lg text-xs text-teal-950 space-y-1">
            <div className="flex items-center justify-between">
              <span className="font-bold text-[11px] flex items-center gap-1.5 text-teal-900">
                <HeartHandshake className="h-4 w-4 text-teal-700" />
                Parent & Guardian Consent Verification Record
              </span>
              <Badge className="bg-teal-700 text-white text-[9px] font-bold">
                WhatsApp Cloud Logged & Telephonically Verified ✓
              </Badge>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1 text-[11px]">
              <div>
                Primary Guardian: <strong>{selectedPass.guardian.name}</strong> ({selectedPass.guardian.relation})
              </div>
              <div>
                Registered Contact: <span className="font-mono font-bold">{selectedPass.guardian.phone}</span>
              </div>
            </div>
            <p className="text-[10px] text-teal-800 italic pt-0.5">
              Consent Notes: {selectedPass.parentConsentNotes || "Verbal call confirmation logged with Class Tutor & WhatsApp notification confirmed."}
            </p>
          </div>

          {/* THREE INSTITUTIONAL CLEARANCE SEALS & SIGNATURES */}
          <div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-600 block mb-1.5">
              Institutional Authority Signatures & Official Clearance Seals:
            </span>

            <div className="grid grid-cols-3 gap-2.5 text-center text-[10px]">
              
              {/* Tutor */}
              <div className="p-2.5 border border-slate-300 rounded-lg bg-slate-50 space-y-1">
                <span className="font-bold text-slate-800 block text-[11px]">1. CLASS TUTOR</span>
                <div className={`font-mono font-bold text-xs ${
                  selectedPass.approvalWorkflow.tutor.status === "approved" ? "text-emerald-700" : "text-amber-600"
                }`}>
                  {selectedPass.approvalWorkflow.tutor.status === "approved" ? "APPROVED ✓" : "PENDING"}
                </div>
                <div className="text-[9px] text-slate-600 font-semibold truncate">
                  {selectedPass.approvalWorkflow.tutor.officerName || "Class Mentor"}
                </div>
                <div className="border-t border-slate-300 pt-1 text-[8px] text-slate-500">
                  Attendance & Parent Call Verified
                </div>
              </div>

              {/* HOD */}
              <div className="p-2.5 border border-slate-300 rounded-lg bg-slate-50 space-y-1">
                <span className="font-bold text-slate-800 block text-[11px]">2. HEAD OF DEPT (HOD)</span>
                <div className={`font-mono font-bold text-xs ${
                  selectedPass.approvalWorkflow.hod.status === "approved" ? "text-emerald-700" : "text-amber-600"
                }`}>
                  {selectedPass.approvalWorkflow.hod.status === "approved" ? "CLEARED ✓" : "PENDING"}
                </div>
                <div className="text-[9px] text-slate-600 font-semibold truncate">
                  {selectedPass.approvalWorkflow.hod.officerName || "Head of Dept"}
                </div>
                <div className="border-t border-slate-300 pt-1 text-[8px] text-slate-500">
                  No Lab / Examination Conflict
                </div>
              </div>

              {/* Chief Warden */}
              <div className="p-2.5 border-2 border-orange-500 rounded-lg bg-orange-50/50 space-y-1">
                <span className="font-bold text-orange-950 block text-[11px]">3. CHIEF WARDEN</span>
                <div className={`font-mono font-bold text-xs ${
                  selectedPass.approvalWorkflow.warden.status === "approved" ? "text-orange-700" : "text-amber-600"
                }`}>
                  {selectedPass.approvalWorkflow.warden.status === "approved" ? "OFFICIAL SEAL ✓" : "PENDING"}
                </div>
                <div className="text-[9px] text-slate-800 font-bold truncate">
                  {selectedPass.approvalWorkflow.warden.officerName || "Hostel Warden"}
                </div>
                <div className="border-t border-orange-300 pt-1 text-[8px] text-orange-900 font-semibold">
                  Hostel Outing Register Stamped
                </div>
              </div>

            </div>
          </div>

          {/* GATE SECURITY CHECKPOINT & DYNAMIC QR TOKEN BOX */}
          <div className="p-3.5 border-2 border-dashed border-slate-400 rounded-lg flex flex-col sm:flex-row items-center justify-between gap-4 bg-slate-50">
            <div className="space-y-1.5 text-xs flex-1">
              <div className="flex items-center gap-2">
                <ShieldCheck className="h-4 w-4 text-slate-800" />
                <span className="font-extrabold text-slate-900 text-xs">
                  ADITHYA CAMPUS SECURITY GATE CONTROL (MAIN ENTRANCE / NORTH GATE)
                </span>
              </div>
              <div className="grid grid-cols-2 gap-2 text-[10px] text-slate-700 pt-1">
                <div className="p-1.5 bg-white border border-slate-300 rounded">
                  <span className="font-bold block text-slate-500">ACTUAL GATE DEPARTURE:</span>
                  <span className="font-mono font-bold text-slate-900">
                    {selectedPass.actualExitDateTime ? new Date(selectedPass.actualExitDateTime).toLocaleTimeString() : "________________ HRS"}
                  </span>
                  <span className="block text-[8px] text-slate-400 mt-0.5">Guard Signature: ________</span>
                </div>
                <div className="p-1.5 bg-white border border-slate-300 rounded">
                  <span className="font-bold block text-slate-500">ACTUAL GATE RETURN:</span>
                  <span className="font-mono font-bold text-slate-900">
                    {selectedPass.actualEntryDateTime ? new Date(selectedPass.actualEntryDateTime).toLocaleTimeString() : "________________ HRS"}
                  </span>
                  <span className="block text-[8px] text-slate-400 mt-0.5">Guard Signature: ________</span>
                </div>
              </div>
              <p className="text-[9px] text-slate-500 italic">
                * Security officer on duty must scan the optical QR below to trigger automated WhatsApp confirmation to parent.
              </p>
            </div>

            {/* Optical QR Code Box */}
            <div className="shrink-0 text-center p-2 bg-white border-2 border-slate-300 rounded-xl shadow-sm">
              <QRCodeSVG
                value={selectedPass.qrToken || `AIT-${selectedPass.passNumber}`}
                size={100}
                level="H"
                includeMargin={true}
              />
              <span className="text-[9px] font-mono font-bold block text-slate-700 mt-1">
                {(selectedPass.qrToken || selectedPass.passNumber).slice(0, 18)}...
              </span>
              <span className="text-[8px] text-emerald-700 font-bold block">
                AUTHENTIC AIT PASS
              </span>
            </div>
          </div>

          {/* DUAL COPY PERFORATION (If Dual Mode Selected) */}
          {slipStyle === "dual" && (
            <div className="pt-3 border-t-2 border-dashed border-slate-400 relative">
              <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-white px-3 text-[9px] font-mono font-bold text-slate-400 uppercase tracking-widest">
                ✂ CUT ALONG DOTTED LINE — DETACH GATE SECURITY RETENTION SLIP ✂
              </div>

              <div className="p-3 bg-slate-50 border border-slate-300 rounded-lg text-xs space-y-2 mt-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-[10px] text-slate-800 uppercase">
                      GATE SECURITY OFFICE SLIP (AUDIT ARCHIVE)
                    </span>
                    <Badge variant="outline" className="text-[9px] font-mono">
                      {selectedPass.passNumber}
                    </Badge>
                  </div>
                  <span className="text-[9px] font-mono text-slate-500">
                    ADITHYA INSTITUTE OF TECHNOLOGY • TNEA 2744
                  </span>
                </div>

                <div className="grid grid-cols-4 gap-2 text-[10px]">
                  <div>
                    <span className="text-slate-500 block">Resident:</span>
                    <strong>{selectedPass.studentName}</strong>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Roll No:</span>
                    <strong className="font-mono">{selectedPass.rollNumber}</strong>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Parent Phone:</span>
                    <strong className="font-mono">{selectedPass.guardian.phone}</strong>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Curfew Due:</span>
                    <strong className="text-red-700">{new Date(selectedPass.expectedReturnDateTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} HRS</strong>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-2 text-[9px] text-slate-600 border-t border-slate-200">
                  <span>Student Sign: ____________________</span>
                  <span>Exit Time Checked: ________________</span>
                  <span>Entry Time Checked: ________________</span>
                  <span>Security Stamp: [ SEAL ]</span>
                </div>
              </div>
            </div>
          )}

          {/* STUDENT DECLARATION & FORM FOOTER */}
          <div className="text-[9px] text-slate-500 leading-tight border-t border-slate-200 pt-2 space-y-1">
            <p>
              <strong>Student Undertaking:</strong> I hereby affirm that I will strictly observe all rules and regulations of Adithya Institute of Technology, Coimbatore. I will not engage in any unauthorized activity and will return to the hostel premises prior to the prescribed curfew (19:30 HRS).
            </p>
            <div className="flex justify-between items-end pt-2 text-slate-700 font-semibold">
              <span>Student Signature: _______________________</span>
              <span>Chief Warden Seal & Signature: _______________________</span>
            </div>
          </div>

        </div>

      </div>

    </div>
  );
};
