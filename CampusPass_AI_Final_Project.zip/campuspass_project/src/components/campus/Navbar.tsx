import React from "react";
import { 
  ShieldCheck, 
  Bell, 
  Sparkles, 
  FileText, 
  RefreshCw, 
  PhoneCall, 
  ExternalLink,
  MessageSquare,
  BookOpen,
  Info
} from "lucide-react";
import { UserRole } from "@/types/campuspass";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { AdithyaLogo } from "./AdithyaLogo";

interface NavbarProps {
  currentRole: UserRole;
  unreadCount: number;
  onOpenNotifications: () => void;
  onOpenAiAssistant: () => void;
  onOpenAuditLogs: () => void;
  onOpenDirectory: () => void;
  onResetData: () => void;
  activeView: string;
  setActiveView: (view: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentRole,
  unreadCount,
  onOpenNotifications,
  onOpenAiAssistant,
  onOpenAuditLogs,
  onOpenDirectory,
  onResetData,
  activeView,
  setActiveView,
}) => {
  const getRoleBadge = (role: UserRole) => {
    switch (role) {
      case "student":
        return <Badge className="bg-blue-600 text-white font-medium">Student View</Badge>;
      case "tutor":
        return <Badge className="bg-indigo-600 text-white font-medium">Class Tutor</Badge>;
      case "hod":
        return <Badge className="bg-purple-600 text-white font-medium">HOD Clearance</Badge>;
      case "warden":
        return <Badge className="bg-amber-600 text-white font-medium">Chief Warden</Badge>;
      case "principal":
        return <Badge className="bg-rose-600 text-white font-medium">Principal Oversight</Badge>;
      case "guard":
        return <Badge className="bg-emerald-600 text-white font-medium">Gate Security</Badge>;
      case "parent":
        return <Badge className="bg-teal-600 text-white font-medium">Parent Portal</Badge>;
    }
  };

  return (
    <header className="sticky top-0 z-40 w-full border-b border-slate-200 bg-white/95 backdrop-blur shadow-sm dark:bg-slate-900/95 dark:border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between gap-4">
          
          {/* Logo & Institution Branding */}
          <div 
            onClick={() => setActiveView("dashboard")} 
            className="flex items-center gap-3 cursor-pointer group select-none"
          >
            <AdithyaLogo size="md" showText={false} />
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold tracking-tight text-slate-900 text-base sm:text-lg dark:text-white">
                  ADITHYA <span className="text-orange-600">PASS</span>
                </span>
                <span className="bg-orange-100 text-orange-800 dark:bg-orange-950/60 dark:text-orange-300 text-[10px] font-bold px-1.5 py-0.5 rounded tracking-wider font-mono">
                  TNEA 2744
                </span>
              </div>
              <p className="text-[11px] text-slate-500 font-medium hidden sm:block dark:text-slate-400">
                Adithya Institute of Technology, Kurumbapalayam, Coimbatore
              </p>
            </div>
          </div>

          {/* Navigation Links */}
          <div className="hidden md:flex items-center gap-1">
            <button
              onClick={() => setActiveView("dashboard")}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
                activeView === "dashboard"
                  ? "bg-slate-100 text-orange-600 dark:bg-slate-800 dark:text-orange-400"
                  : "text-slate-600 hover:text-slate-900 hover:bg-slate-50 dark:text-slate-300"
              }`}
            >
              Control Panel
            </button>
            <button
              onClick={() => setActiveView("paper_pass")}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 ${
                activeView === "paper_pass"
                  ? "bg-orange-100 text-orange-800 font-bold ring-1 ring-orange-400 dark:bg-orange-950/60 dark:text-orange-300"
                  : "text-orange-700 bg-orange-50/80 hover:bg-orange-100 dark:bg-orange-950/30 dark:text-orange-300"
              }`}
            >
              <FileText className="h-3.5 w-3.5 text-orange-600" />
              <span>Paper Pass Preview</span>
            </button>
            <button
              onClick={() => setActiveView("landing")}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
                activeView === "landing"
                  ? "bg-slate-100 text-orange-600 dark:bg-slate-800 dark:text-orange-400"
                  : "text-slate-600 hover:text-slate-900 hover:bg-slate-50 dark:text-slate-300"
              }`}
            >
              Institutional Overview
            </button>
            <button
              onClick={() => setActiveView("overdue")}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
                activeView === "overdue"
                  ? "bg-red-50 text-red-600 dark:bg-red-950/40 dark:text-red-400"
                  : "text-slate-600 hover:text-red-600 hover:bg-red-50/50 dark:text-slate-300"
              }`}
            >
              Late-Return Radar
            </button>
            <button
              onClick={onOpenDirectory}
              className="px-3 py-1.5 text-xs font-semibold rounded-lg text-orange-700 bg-orange-50 hover:bg-orange-100 transition-colors flex items-center gap-1 dark:bg-orange-950/40 dark:text-orange-300"
            >
              <Info className="h-3.5 w-3.5" />
              <span>AIT Directory & Brochure</span>
            </button>
          </div>

          {/* Right Controls */}
          <div className="flex items-center gap-2">
            
            {/* Active Role Indicator */}
            <div className="hidden lg:flex items-center gap-2 pr-2 border-r border-slate-200 dark:border-slate-800">
              <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">Logged in as:</span>
              {getRoleBadge(currentRole)}
            </div>

            {/* AI Assistant Button */}
            <Button
              variant="outline"
              size="sm"
              onClick={onOpenAiAssistant}
              className="gap-1.5 text-xs border-indigo-200 text-indigo-700 bg-indigo-50/60 hover:bg-indigo-100 dark:bg-indigo-950/30 dark:border-indigo-800 dark:text-indigo-300"
            >
              <Sparkles className="h-3.5 w-3.5 text-indigo-600 animate-pulse dark:text-indigo-400" />
              <span className="hidden sm:inline">AI Operations & Policy</span>
            </Button>

            {/* Notifications Trigger */}
            <Button
              variant="ghost"
              size="icon"
              onClick={onOpenNotifications}
              className="relative text-slate-700 hover:text-slate-900 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800"
              title="Notifications & SMS/WhatsApp logs"
            >
              <Bell className="h-4 w-4" />
              {unreadCount > 0 && (
                <span className="absolute top-1.5 right-1.5 flex h-4 w-4 items-center justify-center rounded-full bg-red-600 text-[10px] font-bold text-white ring-2 ring-white dark:ring-slate-900">
                  {unreadCount}
                </span>
              )}
            </Button>

            {/* Audit Logs */}
            <Button
              variant="ghost"
              size="icon"
              onClick={onOpenAuditLogs}
              className="text-slate-700 hover:text-slate-900 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800"
              title="Cryptographic Audit Trail"
            >
              <FileText className="h-4 w-4" />
            </Button>

            {/* Reset Demo Data */}
            <Button
              variant="ghost"
              size="icon"
              onClick={onResetData}
              className="text-slate-500 hover:text-slate-700 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-800"
              title="Reset Demo State"
            >
              <RefreshCw className="h-3.5 w-3.5" />
            </Button>
          </div>

        </div>
      </div>
    </header>
  );
};
