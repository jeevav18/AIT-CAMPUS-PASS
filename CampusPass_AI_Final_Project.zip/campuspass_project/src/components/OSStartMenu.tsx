import { motion } from "framer-motion";
import { User, FileText, Orbit, History, Layout, Award, Activity, Terminal, FolderOpen, Mail, Settings, Power, Github, Linkedin, ExternalLink } from "lucide-react";
import { playTick, playHover } from "@/lib/cyberAudio";

interface OSStartMenuProps {
  isOpen: boolean;
  onClose: () => void;
  onLaunchApp: (appId: string) => void;
  onShutdown: () => void;
}

const OSStartMenu = ({ isOpen, onClose, onLaunchApp, onShutdown }: OSStartMenuProps) => {
  if (!isOpen) return null;

  const appItems = [
    { id: "about", label: "System Profile", desc: "View Jeeva's core objectives & details", icon: User, color: "text-[#00FF66]" },
    { id: "resume", label: "Resume Decryptor", desc: "Decrypt and print professional resume", icon: FileText, color: "text-[#00E5FF]" },
    { id: "skills", label: "Skills Matrix 3D", desc: "Explore technical skill coordinates", icon: Orbit, color: "text-[#FFC107]" },
    { id: "experience", label: "Experience Timeline", desc: "Browse freelance and education logs", icon: History, color: "text-[#00FF66]" },
    { id: "projects", label: "Project Explorer", desc: "Interact with customized Salesforce works", icon: Layout, color: "text-[#00E5FF]" },
    { id: "certificates", label: "Certificate Registry", desc: "View hackathon credentials", icon: Award, color: "text-[#FFC107]" },
    { id: "dashboard", label: "Analytics Monitor", desc: "Telemetry stats & live coding meters", icon: Activity, color: "text-[#00FF66]" },
    { id: "terminal", label: "Hacker Terminal", desc: "Direct interactive command line shell", icon: Terminal, color: "text-[#00E5FF]" },
    { id: "fileExplorer", label: "File Commander", desc: "Navigate directories and databases", icon: FolderOpen, color: "text-[#FFC107]" },
    { id: "contact", label: "Message Dispatcher", desc: "Transmit secure queries to Jeeva", icon: Mail, color: "text-[#00FF66]" },
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 15, scale: 0.98 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, y: 15, scale: 0.98 }}
      transition={{ duration: 0.15 }}
      className="absolute bottom-14 left-4 w-full max-w-[420px] bg-[#050505]/95 border border-[#00FF66]/25 rounded-lg shadow-[0_10px_35px_rgba(0,0,0,0.85)] backdrop-blur-md overflow-hidden z-50 font-mono text-xs text-white"
    >
      {/* Scanlines overlay effect */}
      <div className="absolute inset-0 bg-grid opacity-[0.02] pointer-events-none" />

      {/* Start Menu Header Profile Card */}
      <div className="flex items-center space-x-3.5 bg-black p-4 border-b border-[#00FF66]/15 relative">
        <div className="w-11 h-11 bg-zinc-900 border border-[#00FF66]/40 rounded-lg flex items-center justify-center text-[#00FF66] relative font-bold text-lg font-oxanium shadow-[0_0_8px_rgba(0,255,102,0.2)]">
          JV
          <span className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-[#00FF66] rounded-full border border-black animate-pulse" />
        </div>
        <div>
          <h4 className="font-bold text-white text-sm font-oxanium tracking-wide uppercase">Jeeva V</h4>
          <p className="text-[9px] text-[#00E5FF] uppercase tracking-wider font-extrabold mt-0.5">Salesforce Developer</p>
        </div>
        <span className="absolute top-3 right-4 text-[8px] text-gray-500 uppercase font-semibold">COGNITIVE_ACTIVE</span>
      </div>

      {/* Quick Launch Programs App List Grid */}
      <div className="p-3 max-h-[300px] overflow-y-auto scrollbar-thin space-y-1 bg-black/40">
        <div className="text-[9px] text-gray-500 font-bold uppercase tracking-wider px-2 pb-1.5 border-b border-zinc-900 mb-1.5">
          Programs & Applets
        </div>
        {appItems.map((app) => (
          <button
            key={app.id}
            onMouseEnter={playHover}
            onClick={() => {
              playTick();
              onLaunchApp(app.id);
              onClose();
            }}
            className="w-full text-left p-2 rounded hover:bg-[#00FF66]/10 border border-transparent hover:border-[#00FF66]/20 transition flex items-center space-x-3 group cursor-pointer"
          >
            <div className={`p-1.5 bg-black/60 rounded border border-zinc-800 ${app.color} group-hover:bg-[#00FF66]/15 group-hover:border-[#00FF66]/30 transition`}>
              <app.icon className="w-4 h-4" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="font-bold text-white group-hover:text-[#00FF66] transition text-[11px]">{app.label}</div>
              <div className="text-[9px] text-gray-400 truncate mt-0.5 font-mono">{app.desc}</div>
            </div>
          </button>
        ))}
      </div>

      {/* Quick Web Links Panel */}
      <div className="grid grid-cols-2 gap-2 p-3 bg-zinc-950/60 border-t border-[#00FF66]/15 text-[10px]">
        <a
          href="https://github.com/jeevav18"
          target="_blank"
          rel="noopener noreferrer"
          onMouseEnter={playHover}
          onClick={playTick}
          className="flex items-center justify-between p-2 rounded bg-black/50 border border-zinc-800 hover:border-[#00FF66]/30 hover:bg-[#00FF66]/5 text-gray-300 hover:text-[#00FF66] transition font-semibold"
        >
          <span className="flex items-center space-x-1.5">
            <Github className="w-4 h-4" />
            <span>GitHub Profile</span>
          </span>
          <ExternalLink className="w-3.5 h-3.5 opacity-50" />
        </a>

        <a
          href="https://linkedin.com/in/jeeva-v-b519a3305"
          target="_blank"
          rel="noopener noreferrer"
          onMouseEnter={playHover}
          onClick={playTick}
          className="flex items-center justify-between p-2 rounded bg-black/50 border border-zinc-800 hover:border-[#00FF66]/30 hover:bg-[#00FF66]/5 text-gray-300 hover:text-[#00FF66] transition font-semibold"
        >
          <span className="flex items-center space-x-1.5">
            <Linkedin className="w-4 h-4" />
            <span>LinkedIn Node</span>
          </span>
          <ExternalLink className="w-3.5 h-3.5 opacity-50" />
        </a>
      </div>

      {/* Start Menu Footer with Shutdown button */}
      <div className="flex items-center justify-between p-3 bg-black border-t border-[#00FF66]/15 text-[10px]">
        <span className="text-gray-500 font-bold uppercase text-[9px]">GUEST_SESSION</span>
        
        <button
          onMouseEnter={playHover}
          onClick={() => {
            playTick();
            onShutdown();
          }}
          className="flex items-center space-x-1.5 px-3 py-1.5 border border-red-500/30 hover:border-red-500 bg-red-500/10 hover:bg-red-500 text-red-500 hover:text-white rounded font-bold cursor-pointer transition-all uppercase text-[9px] tracking-wider"
        >
          <Power className="w-3.5 h-3.5 animate-pulse" />
          <span>Shutdown OS</span>
        </button>
      </div>
    </motion.div>
  );
};

export default OSStartMenu;
