import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Cloud, Server, Users, Award, Clock, ArrowUpRight, Zap, Target, Layers } from "lucide-react";

interface CounterProps {
  end: number;
  label: string;
  suffix?: string;
  icon: React.ComponentType<{ className?: string }>;
}

const AnimatedCounter = ({ end, label, suffix = "", icon: Icon }: CounterProps) => {
  const [count, setCount] = useState(0);

  useEffect(() => {
    let startTime: number | null = null;
    const duration = 2000; // 2 seconds

    const animate = (timestamp: number) => {
      if (!startTime) startTime = timestamp;
      const progress = timestamp - startTime;
      const current = Math.min(Math.floor((progress / duration) * end), end);
      setCount(current);

      if (progress < duration) {
        requestAnimationFrame(animate);
      }
    };

    requestAnimationFrame(animate);
  }, [end]);

  return (
    <div className="bg-[#080808]/90 border border-[#00FF66]/20 p-5 rounded-xl flex items-center space-x-4 hover:border-[#00FF66]/50 transition-all duration-300">
      <div className="p-3 bg-[#00FF66]/10 text-[#00FF66] rounded-lg">
        <Icon className="w-6 h-6 text-glow-green" />
      </div>
      <div className="font-mono">
        <div className="text-2xl md:text-3xl font-extrabold text-white">
          {count}
          {suffix}
        </div>
        <div className="text-[10px] text-gray-500 font-bold uppercase tracking-wider">
          {label}
        </div>
      </div>
    </div>
  );
};

const Achievements = () => {
  const experiences = [
    {
      title: "Freelance Salesforce Developer",
      duration: "October 2025 - Present",
      location: "Remote / Multiple Clients",
      desc: "Delivered highly optimized CRM custom logic, business workflow automation, customized reports & dashboards, Apex Triggers, and Lightning Web Components (LWC) configurations. Successfully optimized SOQL/SOSL indexing loops to bypass governor constraints."
    },
    {
      title: "Future Milestone: Full Stack & AI Integrations",
      duration: "Goal Horizon",
      location: "Research & Development",
      desc: "Continuing comprehensive research in combining Salesforce APIs with modern artificial intelligence layers, serverless Node.js endpoints, and modern client interfaces."
    }
  ];

  const projects = [
    {
      title: "Salesforce CRM System",
      desc: "Developed a comprehensive Salesforce CRM application to manage Leads, Accounts, Contacts, and Opportunities. Implemented Apex Triggers, Lightning Web Components, Flows, Validation Rules, Reports, Dashboards, and automated email notifications while optimizing SOQL/SOSL queries.",
      techs: ["Apex", "LWC", "SOQL/SOSL", "Flows", "Validations", "Salesforce"],
      icon: Cloud
    },
    {
      title: "Freelance Salesforce Developer",
      desc: "Worked with multiple clients delivering Salesforce CRM customization, automation, integrations, business process optimization, Apex development, Lightning components, and scalable enterprise solutions.",
      techs: ["Salesforce", "CRM Setup", "Integrations", "Apex", "Automations"],
      icon: Server
    }
  ];

  return (
    <div id="projects" className="py-24 px-4 relative">
      <div className="container mx-auto max-w-6xl relative z-10 space-y-24">
        {/* SECTION 1: ANIMATED OS STATS */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <AnimatedCounter end={12} label="Projects Completed" icon={Target} />
          <AnimatedCounter end={5} label="Happy Clients" icon={Users} />
          <AnimatedCounter end={25} label="Technical Skills" icon={Layers} />
          <AnimatedCounter end={420} label="Learning Hours" suffix="+" icon={Clock} />
        </div>

        {/* SECTION 2: EXPERIENCE TIMELINE */}
        <div className="space-y-12">
          <motion.div
            initial={{ y: 30, opacity: 0 }}
            whileInView={{ y: 0, opacity: 1 }}
            viewport={{ once: true }}
            className="text-center"
          >
            <h2 className="text-3xl md:text-5xl font-bold font-oxanium text-white tracking-widest uppercase text-glow-green">
              [ EXPERIENCE_LOG ]
            </h2>
            <div className="w-24 h-1 bg-[#00FF66] mx-auto mt-3 rounded-full shadow-[0_0_10px_#00FF66]" />
          </motion.div>

          <div className="relative border-l border-[#00FF66]/20 ml-4 md:ml-12 pl-6 md:pl-8 space-y-12 font-mono">
            {experiences.map((exp, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, x: -30 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: idx * 0.1 }}
                className="relative"
              >
                {/* Timeline node bullet */}
                <div className="absolute -left-[31px] md:-left-[39px] top-1.5 w-4 h-4 rounded-full bg-[#050505] border-2 border-[#00FF66] flex items-center justify-center">
                  <div className="w-1.5 h-1.5 rounded-full bg-[#00FF66] animate-ping" />
                </div>

                <div className="bg-[#080808]/90 border border-[#00FF66]/20 hover:border-[#00FF66]/50 p-6 rounded-xl space-y-3 transition-all duration-300">
                  <div className="flex flex-col md:flex-row justify-between items-start md:items-center">
                    <h3 className="text-base md:text-lg font-bold text-white font-oxanium">
                      {exp.title}
                    </h3>
                    <span className="text-xs text-[#FFC107] font-semibold">
                      {exp.duration}
                    </span>
                  </div>
                  <div className="text-xs text-[#00E5FF] font-bold uppercase">
                    {exp.location}
                  </div>
                  <p className="text-xs md:text-sm text-gray-400 leading-relaxed">
                    {exp.desc}
                  </p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* SECTION 3: PROJECTS GRID */}
        <div className="space-y-12">
          <motion.div
            initial={{ y: 30, opacity: 0 }}
            whileInView={{ y: 0, opacity: 1 }}
            viewport={{ once: true }}
            className="text-center"
          >
            <h2 className="text-3xl md:text-5xl font-bold font-oxanium text-white tracking-widest uppercase text-glow-green">
              [ CODE_STOREHOUSE ]
            </h2>
            <div className="w-24 h-1 bg-[#00FF66] mx-auto mt-3 rounded-full shadow-[0_0_10px_#00FF66]" />
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {projects.map((proj, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: idx * 0.1 }}
                className="bg-[#080808]/95 border border-[#00FF66]/20 hover:border-[#00FF66]/60 rounded-xl overflow-hidden shadow-elegant flex flex-col justify-between group transition-all duration-300 hover:scale-[1.01]"
              >
                <div className="p-6 md:p-8 space-y-4">
                  {/* Project Top HUD */}
                  <div className="flex items-center justify-between border-b border-[#00FF66]/10 pb-4">
                    <div className="flex items-center space-x-2.5">
                      <div className="p-2 bg-[#00FF66]/10 text-[#00FF66] rounded-md group-hover:bg-[#00FF66]/20 transition-colors">
                        <proj.icon className="w-5 h-5" />
                      </div>
                      <span className="text-xs font-mono text-gray-400 font-bold uppercase">
                        PROJ_INDEX_{idx + 1}
                      </span>
                    </div>
                    <div className="w-2.5 h-2.5 rounded-full bg-[#00FF66] animate-pulse" />
                  </div>

                  <h3 className="text-lg md:text-xl font-bold font-oxanium text-white tracking-wide group-hover:text-[#00FF66] transition-colors">
                    {proj.title}
                  </h3>

                  <p className="font-mono text-xs md:text-sm text-gray-400 leading-relaxed">
                    {proj.desc}
                  </p>
                </div>

                {/* Tech Badges & CTA */}
                <div className="px-6 md:px-8 pb-6 md:pb-8 pt-2 space-y-4 font-mono">
                  <div className="flex flex-wrap gap-1.5">
                    {proj.techs.map((t, tIdx) => (
                      <span
                        key={tIdx}
                        className="text-[10px] bg-[#00E5FF]/10 text-[#00E5FF] border border-[#00E5FF]/20 px-2 py-0.5 rounded-md font-bold uppercase"
                      >
                        {t}
                      </span>
                    ))}
                  </div>

                  <div className="flex items-center justify-between border-t border-[#00FF66]/10 pt-4">
                    <span className="text-[10px] text-gray-500 font-bold">STATUS: DEPLOYED</span>
                    <a
                      href="https://linkedin.com/in/jeeva-v-b519a3305"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-xs font-bold text-[#00FF66] hover:text-[#00E5FF] flex items-center space-x-1"
                    >
                      <span>LAUNCH</span>
                      <ArrowUpRight className="w-4 h-4" />
                    </a>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Achievements;
