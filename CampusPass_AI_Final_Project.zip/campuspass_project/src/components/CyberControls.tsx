import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Settings, Shield, Volume2, VolumeX, Monitor, Activity, Radio, Cpu, RotateCcw, Palette, Terminal } from "lucide-react";
import { toggleAudio, playTick, playSuccessChime } from "@/lib/cyberAudio";

type AccentColor = "green" | "cyan" | "amber" | "purple";

interface CyberControlsProps {
  onAccentChange: (color: AccentColor) => void;
}

const CyberControls = ({ onAccentChange }: CyberControlsProps) => {
  const [isOpen, setIsOpen] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(false);
  const [accent, setAccent] = useState<AccentColor>("green");
  const [crtEnabled, setCrtEnabled] = useState(false);
  const [cpuUsage, setCpuUsage] = useState([45, 52, 38, 61]);
  const [ramUsage, setRamUsage] = useState(42.8);

  // Load settings from localStorage
  useEffect(() => {
    const savedSound = localStorage.getItem("hacker_sound") === "true";
    const savedAccent = (localStorage.getItem("hacker_accent") as AccentColor) || "green";
    const savedCrt = localStorage.getItem("hacker_crt") === "true";

    setSoundEnabled(savedSound);
    toggleAudio(savedSound);

    setAccent(savedAccent);
    onAccentChange(savedAccent);
    updateDocumentTheme(savedAccent);

    setCrtEnabled(savedCrt);
    if (savedCrt) {
      document.body.classList.add("crt-simulation");
    } else {
      document.body.classList.remove("crt-simulation");
    }
  }, [onAccentChange]);

  // Update CPU core cycles simulated values
  useEffect(() => {
    const interval = setInterval(() => {
      setCpuUsage((prev) => prev.map((val) => {
        const delta = Math.floor(Math.random() * 15) - 7;
        return Math.min(Math.max(val + delta, 10), 99);
      }));
      setRamUsage((prev) => {
        const delta = (Math.random() * 1.2) - 0.6;
        return Math.min(Math.max(parseFloat((prev + delta).toFixed(1)), 35), 78);
      });
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  const handleSoundToggle = () => {
    const nextState = !soundEnabled;
    setSoundEnabled(nextState);
    localStorage.setItem("hacker_sound", String(nextState));
    toggleAudio(nextState);
    if (nextState) {
      setTimeout(() => playSuccessChime(), 100);
    }
  };

  const updateDocumentTheme = (color: AccentColor) => {
    const root = document.documentElement;
    // Map colors to real CSS configurations
    const themes = {
      green: { primary: "0 255 102", glow: "rgba(0, 255, 102, 0.4)" },
      cyan: { primary: "0 229 255", glow: "rgba(0, 229, 255, 0.4)" },
      amber: { primary: "255 193 7", glow: "rgba(255, 193, 7, 0.4)" },
      purple: { primary: "191 90 242", glow: "rgba(191, 90, 242, 0.4)" },
    };

    const activeTheme = themes[color];
    root.style.setProperty("--primary", activeTheme.primary);
    root.style.setProperty("--ring", activeTheme.primary);
    root.style.setProperty("--border", activeTheme.primary);
    
    // Create or edit a global style tag for custom overrides (glowing texts, etc.)
    let customStyleTag = document.getElementById("hacker-custom-theme");
    if (!customStyleTag) {
      customStyleTag = document.createElement("style");
      customStyleTag.id = "hacker-custom-theme";
      document.head.appendChild(customStyleTag);
    }
    
    customStyleTag.innerHTML = `
      .text-glow-green { text-shadow: 0 0 8px ${activeTheme.glow}; }
      .border-[#00FF66] { border-color: rgb(${activeTheme.primary}) !important; }
      .border-[#00FF66]/20 { border-color: rgba(${activeTheme.primary}, 0.2) !important; }
      .border-[#00FF66]/10 { border-color: rgba(${activeTheme.primary}, 0.1) !important; }
      .border-[#00FF66]/30 { border-color: rgba(${activeTheme.primary}, 0.3) !important; }
      .border-[#00FF66]/40 { border-color: rgba(${activeTheme.primary}, 0.4) !important; }
      .border-[#00FF66]/50 { border-color: rgba(${activeTheme.primary}, 0.5) !important; }
      .border-[#00FF66]/60 { border-color: rgba(${activeTheme.primary}, 0.6) !important; }
      .bg-[#00FF66]/10 { background-color: rgba(${activeTheme.primary}, 0.1) !important; }
      .bg-[#00FF66]/15 { background-color: rgba(${activeTheme.primary}, 0.15) !important; }
      .bg-[#00FF66]/5 { background-color: rgba(${activeTheme.primary}, 0.05) !important; }
      .text-[#00FF66] { color: rgb(${activeTheme.primary}) !important; }
      .bg-[#00FF66] { background-color: rgb(${activeTheme.primary}) !important; }
      .shadow-[0_0_10px_#00FF66] { box-shadow: 0 0 12px rgba(${activeTheme.primary}, 0.5) !important; }
      .shadow-[0_0_15px_rgba(0,255,102,0.1)] { box-shadow: 0 0 15px rgba(${activeTheme.primary}, 0.15) !important; }
      .shadow-[0_0_15px_rgba(0,255,102,0.05)] { box-shadow: 0 0 15px rgba(${activeTheme.primary}, 0.05) !important; }
    `;
  };

  const handleAccentChange = (color: AccentColor) => {
    if (soundEnabled) playTick();
    setAccent(color);
    localStorage.setItem("hacker_accent", color);
    onAccentChange(color);
    updateDocumentTheme(color);
  };

  const handleCrtToggle = () => {
    if (soundEnabled) playTick();
    const nextState = !crtEnabled;
    setCrtEnabled(nextState);
    localStorage.setItem("hacker_crt", String(nextState));
    if (nextState) {
      document.body.classList.add("crt-simulation");
    } else {
      document.body.classList.remove("crt-simulation");
    }
  };

  const resetAllSettings = () => {
    if (soundEnabled) playSuccessChime();
    handleAccentChange("green");
    setCrtEnabled(false);
    document.body.classList.remove("crt-simulation");
    localStorage.setItem("hacker_crt", "false");
    setSoundEnabled(false);
    toggleAudio(false);
    localStorage.setItem("hacker_sound", "false");
  };

  return (
    <div className="fixed right-5 bottom-5 z-40 font-mono text-xs">
      {/* Floating Gear Button */}
      <motion.button
        onClick={() => {
          if (soundEnabled) playTick();
          setIsOpen(!isOpen);
        }}
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        className="w-12 h-12 rounded-full border border-[#00FF66] bg-[#050505] text-[#00FF66] flex items-center justify-center cursor-pointer shadow-[0_0_15px_rgba(0,255,102,0.25)] hover:bg-[#00FF66]/10 transition-all duration-300"
      >
        <Settings className={`w-5 h-5 ${isOpen ? "animate-spin" : "animate-pulse"}`} />
      </motion.button>

      {/* Control Drawer Container */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 50, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 50, scale: 0.9 }}
            className="absolute bottom-16 right-0 w-80 bg-[#080808]/95 border border-[#00FF66] rounded-xl overflow-hidden shadow-[0_0_25px_rgba(0,255,102,0.15)] p-5 space-y-5"
          >
            {/* Header tag */}
            <div className="flex items-center justify-between border-b border-[#00FF66]/20 pb-3">
              <div className="flex items-center space-x-2">
                <Shield className="w-4.5 h-4.5 text-[#00FF66] animate-pulse" />
                <span className="font-oxanium font-bold tracking-wider text-white">SYS_CTRL_CENTER v3.0</span>
              </div>
              <span className="text-[9px] bg-[#00FF66]/10 text-[#00FF66] border border-[#00FF66]/30 px-1.5 py-0.5 rounded uppercase font-bold">
                Online
              </span>
            </div>

            {/* Accent Shifter Option */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-gray-500 uppercase font-bold text-[10px]">ACCENT_MATRIX:</span>
                <span className="text-white font-bold capitalize">{accent}</span>
              </div>
              <div className="grid grid-cols-4 gap-2">
                {[
                  { name: "green", color: "bg-[#00FF66]" },
                  { name: "cyan", color: "bg-[#00E5FF]" },
                  { name: "amber", color: "bg-[#FFC107]" },
                  { name: "purple", color: "bg-[#BF5AF2]" },
                ].map((col) => (
                  <button
                    key={col.name}
                    onClick={() => handleAccentChange(col.name as AccentColor)}
                    className={`h-7 rounded-lg border flex items-center justify-center transition-all ${
                      accent === col.name
                        ? "border-white bg-white/10 scale-105"
                        : "border-transparent hover:scale-102"
                    }`}
                  >
                    <span className={`w-3.5 h-3.5 rounded-full ${col.color}`} />
                  </button>
                ))}
              </div>
            </div>

            {/* CRT monitor screen scanlines simulation */}
            <div className="flex items-center justify-between border-t border-[#00FF66]/10 pt-3">
              <div className="space-y-0.5">
                <span className="text-white font-bold block text-[11px]">CRT SCAN_SIMULATOR</span>
                <span className="text-[9px] text-gray-500 uppercase">Simulates curved flicker phosphor</span>
              </div>
              <button
                onClick={handleCrtToggle}
                className={`w-12 h-6 rounded-full p-1 transition-all ${
                  crtEnabled ? "bg-[#00FF66]" : "bg-zinc-800"
                }`}
              >
                <div
                  className={`w-4 h-4 rounded-full bg-black transition-all ${
                    crtEnabled ? "translate-x-6" : "translate-x-0"
                  }`}
                />
              </button>
            </div>

            {/* Auditory synth feed toggle */}
            <div className="flex items-center justify-between border-t border-[#00FF66]/10 pt-3">
              <div className="space-y-0.5">
                <span className="text-white font-bold block text-[11px]">SYNTHETIC_AUDIO</span>
                <span className="text-[9px] text-gray-500 uppercase">Futuristic click sound oscillators</span>
              </div>
              <button
                onClick={handleSoundToggle}
                className={`p-2 rounded-lg border transition-all ${
                  soundEnabled
                    ? "border-[#00FF66] bg-[#00FF66]/15 text-[#00FF66]"
                    : "border-zinc-800 text-gray-600"
                }`}
              >
                {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
              </button>
            </div>

            {/* CPU / Diagnostic Real-Time monitors */}
            <div className="border-t border-[#00FF66]/10 pt-3 space-y-2">
              <span className="text-gray-500 uppercase font-bold text-[10px] block">REAL_TIME_PROCESSOR_CORES:</span>
              <div className="grid grid-cols-4 gap-1.5 text-center text-[10px] text-[#00FF66]">
                {cpuUsage.map((val, idx) => (
                  <div key={idx} className="bg-black/60 border border-[#00FF66]/10 p-1.5 rounded-md">
                    <div className="text-gray-500 font-bold uppercase text-[8px]">C{idx+1}</div>
                    <div className="font-bold text-white text-glow-green">{val}%</div>
                    <div className="h-1 w-full bg-zinc-900 rounded-full mt-1 overflow-hidden">
                      <div className="h-full bg-[#00FF66]" style={{ width: `${val}%` }} />
                    </div>
                  </div>
                ))}
              </div>
              <div className="flex justify-between items-center text-[10px] text-gray-400">
                <span>MEM_POOL: {ramUsage}%</span>
                <span>TEMP: 38.2°C</span>
              </div>
            </div>

            {/* Reset Defaults button */}
            <button
              onClick={resetAllSettings}
              className="w-full border border-red-500/30 bg-red-500/5 hover:bg-red-500/20 text-red-500 rounded-lg p-2 transition-all font-oxanium font-bold uppercase text-[10px] flex items-center justify-center space-x-1"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>PURGE_OVERRIDES_RESET</span>
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default CyberControls;
