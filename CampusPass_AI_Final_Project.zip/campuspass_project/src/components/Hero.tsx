import { useState, useEffect, useRef } from "react";
import { motion } from "framer-motion";
import {
  Shield,
  Terminal,
  Code,
  ArrowRight,
  Download,
  Github,
  Linkedin,
  Radio,
  Lock,
  Activity,
  Cpu,
  Eye,
  CheckCircle2,
  Sparkles,
} from "lucide-react";
import { PORTFOLIO_DATA } from "@/data/portfolioData";
import { playHover, playTick, playGlitchSweep, playSuccessChime } from "@/lib/cyberAudio";

interface HeroProps {
  onExploreClick: () => void;
  onProjectsClick: () => void;
  onOpenTerminal: () => void;
  accentColor?: "green" | "cyan" | "purple";
}

const TITLES = [
  PORTFOLIO_DATA.personal.title,
  "Ethical Hacker & SecOps Architect",
  "Salesforce Platform Developer (PD1)",
  "Full-Stack Cloud Engineer",
  "Autonomous AI Agent Builder",
];

export const Hero = ({
  onExploreClick,
  onProjectsClick,
  onOpenTerminal,
  accentColor = "green",
}: HeroProps) => {
  // Dynamic typing rotation for professional titles
  const [titleIndex, setTitleIndex] = useState(0);
  const [currentText, setCurrentText] = useState("");
  const [isDeleting, setIsDeleting] = useState(false);
  const [charIndex, setCharIndex] = useState(0);

  // Mouse parallax state for Holographic 3D Frame
  const [tilt, setTilt] = useState({ x: 0, y: 0 });

  useEffect(() => {
    const activeTarget = TITLES[titleIndex];
    const typingSpeed = isDeleting ? 30 : 65;

    const timer = setTimeout(() => {
      if (!isDeleting && charIndex < activeTarget.length) {
        setCurrentText(activeTarget.substring(0, charIndex + 1));
        setCharIndex((prev) => prev + 1);
      } else if (isDeleting && charIndex > 0) {
        setCurrentText(activeTarget.substring(0, charIndex - 1));
        setCharIndex((prev) => prev - 1);
      } else if (!isDeleting && charIndex === activeTarget.length) {
        setTimeout(() => setIsDeleting(true), 2000);
      } else if (isDeleting && charIndex === 0) {
        setIsDeleting(false);
        setTitleIndex((prev) => (prev + 1) % TITLES.length);
      }
    }, typingSpeed);

    return () => clearTimeout(timer);
  }, [charIndex, isDeleting, titleIndex]);

  const handleFrameMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width - 0.5) * 20;
    const y = ((e.clientY - rect.top) / rect.height - 0.5) * -20;
    setTilt({ x, y });
  };

  const handleFrameMouseLeave = () => {
    setTilt({ x: 0, y: 0 });
  };

  return (
    <section id="home" className="relative min-h-[92vh] flex items-center justify-center pt-24 pb-16 px-4 max-w-7xl mx-auto">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center w-full">
        {/* Left Column: Hero Content & Call to Actions */}
        <motion.div
          initial={{ opacity: 0, x: -30 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="lg:col-span-7 space-y-6 text-left"
        >
          {/* Cybersecurity Status Indicators Ribbon */}
          <div className="flex flex-wrap items-center gap-2 font-mono text-[10px] sm:text-xs">
            <div className="flex items-center space-x-1.5 px-3 py-1 bg-black/80 border border-[#00FF66]/40 rounded-full text-[#00FF66] shadow-[0_0_10px_rgba(0,255,102,0.2)]">
              <span className="w-2 h-2 rounded-full bg-[#00FF66] animate-pulse" />
              <span className="font-bold">SYSTEM: ONLINE</span>
            </div>

            <div className="flex items-center space-x-1.5 px-3 py-1 bg-black/80 border border-[#00E5FF]/40 rounded-full text-[#00E5FF]">
              <Lock className="w-3 h-3 text-[#00E5FF]" />
              <span>STATUS: AVAILABLE FOR OPPORTUNITIES</span>
            </div>

            <div className="flex items-center space-x-1.5 px-3 py-1 bg-black/80 border border-[#BF5AF2]/40 rounded-full text-[#BF5AF2]">
              <Shield className="w-3 h-3 text-[#BF5AF2]" />
              <span>CLEARANCE: LEVEL_5 // CYBER_DEFENSE</span>
            </div>
          </div>

          {/* Main Name & Dynamic Typist Title */}
          <div className="space-y-2">
            <div className="text-xs font-mono text-[#00FF66] tracking-widest uppercase flex items-center space-x-2 font-bold">
              <span>&gt; IDENTITY VERIFIED</span>
            </div>

            <h1 className="text-5xl sm:text-7xl lg:text-8xl font-bebas tracking-wide text-white leading-none">
              {PORTFOLIO_DATA.personal.name}
            </h1>

            <div className="h-9 sm:h-11 flex items-center font-oxanium text-lg sm:text-2xl font-bold text-[#00E5FF] text-glow-cyan">
              <span>{currentText}</span>
              <span className="inline-block w-2.5 h-6 bg-[#00FF66] ml-1.5 animate-pulse" />
            </div>
          </div>

          {/* Short Personal Introduction */}
          <p className="text-sm sm:text-base text-gray-300 font-mono leading-relaxed max-w-2xl">
            "Building secure, intelligent and futuristic digital experiences."
          </p>

          {/* Action Buttons */}
          <div className="flex flex-wrap items-center gap-4 pt-2 font-mono">
            {/* Explore System */}
            <button
              onMouseEnter={playHover}
              onClick={() => {
                playTick();
                onExploreClick();
              }}
              className="px-6 py-3.5 rounded-xl bg-[#00FF66]/15 hover:bg-[#00FF66]/25 border-2 border-[#00FF66] text-[#00FF66] font-bold text-xs sm:text-sm uppercase tracking-wider flex items-center space-x-2 transition duration-200 cursor-pointer shadow-[0_0_20px_rgba(0,255,102,0.3)] hover:shadow-[0_0_30px_rgba(0,255,102,0.5)]"
            >
              <span>[ EXPLORE SYSTEM ]</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            {/* View Projects */}
            <button
              onMouseEnter={playHover}
              onClick={() => {
                playTick();
                onProjectsClick();
              }}
              className="px-6 py-3.5 rounded-xl bg-black/80 hover:bg-zinc-900 border-2 border-zinc-700 hover:border-[#00E5FF] text-gray-200 hover:text-[#00E5FF] font-bold text-xs sm:text-sm uppercase tracking-wider flex items-center space-x-2 transition duration-200 cursor-pointer shadow-[0_0_15px_rgba(0,0,0,0.5)]"
            >
              <Code className="w-4 h-4" />
              <span>[ VIEW PROJECTS ]</span>
            </button>

            {/* Open Terminal */}
            <button
              onMouseEnter={playHover}
              onClick={() => {
                playGlitchSweep();
                onOpenTerminal();
              }}
              className="px-4 py-3.5 rounded-xl bg-black/80 hover:bg-zinc-900 border border-zinc-800 hover:border-[#BF5AF2] text-gray-400 hover:text-[#BF5AF2] text-xs uppercase tracking-wider flex items-center space-x-1.5 transition cursor-pointer"
              title="Launch Terminal"
            >
              <Terminal className="w-4 h-4" />
              <span className="hidden sm:inline">CLI</span>
            </button>
          </div>

          {/* Social Links & Resume Download Strip */}
          <div className="flex flex-wrap items-center gap-4 pt-4 border-t border-zinc-900 text-xs font-mono text-gray-400">
            <a
              href={PORTFOLIO_DATA.personal.githubUrl}
              target="_blank"
              rel="noopener noreferrer"
              onMouseEnter={playHover}
              className="flex items-center space-x-1.5 hover:text-[#00FF66] transition cursor-pointer"
            >
              <Github className="w-4 h-4" />
              <span>GitHub</span>
            </a>

            <a
              href={PORTFOLIO_DATA.personal.linkedinUrl}
              target="_blank"
              rel="noopener noreferrer"
              onMouseEnter={playHover}
              className="flex items-center space-x-1.5 hover:text-[#00E5FF] transition cursor-pointer"
            >
              <Linkedin className="w-4 h-4" />
              <span>LinkedIn</span>
            </a>

            <a
              href={PORTFOLIO_DATA.personal.resumeUrl}
              download="Jeeva_V_Resume.pdf"
              onClick={() => playSuccessChime()}
              onMouseEnter={playHover}
              className="flex items-center space-x-1.5 text-[#00FF66] hover:underline transition cursor-pointer ml-auto"
            >
              <Download className="w-4 h-4" />
              <span>Download CV (.PDF)</span>
            </a>
          </div>
        </motion.div>

        {/* Right Column: 3D Holographic Chamber & 3D Profile Identity Card */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="lg:col-span-5 flex flex-col items-center justify-center space-y-6 relative"
        >
          {/* Parallax Holographic Frame Container (Chamber) */}
          <div
            onMouseMove={handleFrameMouseMove}
            onMouseLeave={handleFrameMouseLeave}
            className="relative w-72 sm:w-84 h-84 sm:h-96 rounded-2xl p-3 bg-black/60 border-2 border-[#00FF66]/50 shadow-[0_0_50px_rgba(0,255,102,0.25)] transition-transform duration-200 ease-out backdrop-blur-md"
            style={{
              transform: `perspective(1000px) rotateX(${tilt.y}deg) rotateY(${tilt.x}deg)`,
            }}
          >
            {/* Rotating Holographic Outer Ring 1 */}
            <div className="absolute -inset-4 rounded-full border border-[#00FF66]/30 border-dashed animate-spin pointer-events-none opacity-40" style={{ animationDuration: "25s" }} />
            {/* Rotating Holographic Outer Ring 2 */}
            <div className="absolute -inset-8 rounded-full border border-[#00E5FF]/20 border-dotted animate-spin pointer-events-none opacity-30" style={{ animationDuration: "35s", animationDirection: "reverse" }} />

            {/* Cyan Data Streams Effect */}
            <div className="absolute -top-6 left-1/4 text-[9px] font-mono text-[#00E5FF] tracking-widest animate-pulse pointer-events-none opacity-70">
              ▲ STREAM_0x18: 9.8 GB/s TLS1.3
            </div>

            {/* Holographic HUD Grid & Scanlines Overlays */}
            <div className="absolute inset-0 rounded-2xl bg-grid opacity-20 pointer-events-none" />
            <div className="absolute inset-0 rounded-2xl bg-scanlines opacity-15 pointer-events-none" />

            {/* Futuristic Corner Brackets */}
            <div className="absolute -top-2 -left-2 w-6 h-6 border-t-2 border-l-2 border-[#00FF66]" />
            <div className="absolute -top-2 -right-2 w-6 h-6 border-t-2 border-r-2 border-[#00FF66]" />
            <div className="absolute -bottom-2 -left-2 w-6 h-6 border-b-2 border-l-2 border-[#00FF66]" />
            <div className="absolute -bottom-2 -right-2 w-6 h-6 border-b-2 border-r-2 border-[#00FF66]" />

            {/* Profile Monogram Display with Neon Rim */}
            <div className="relative w-full h-full rounded-xl overflow-hidden bg-zinc-950 border border-[#00FF66]/30 flex flex-col items-center justify-center p-6 text-center space-y-4 shadow-[inset_0_0_20px_rgba(0,255,102,0.15)]">
              <div className="w-24 h-24 rounded-2xl border-2 border-[#00FF66] flex items-center justify-center text-[#00FF66] font-mono font-extrabold text-3xl shadow-[0_0_25px_rgba(0,255,102,0.4)] bg-black/80">
                JV
              </div>
              <div>
                <div className="font-bebas text-3xl text-white tracking-widest">
                  {PORTFOLIO_DATA.personal.name}
                </div>
                <div className="text-xs font-mono text-[#00FF66] tracking-wider mt-1">
                  SALESFORCE & FULL-STACK ENGINEER
                </div>
                <div className="text-[11px] font-mono text-zinc-400 mt-2 flex items-center justify-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-[#00FF66] animate-pulse" />
                  <span>TEL: +91 94420 50959</span>
                </div>
              </div>

              {/* Scanner Line Effect */}
              <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-[#00FF66] to-transparent shadow-[0_0_15px_#00FF66] animate-pulse pointer-events-none" />

              {/* Live Biometric Tag Badge */}
              <div className="absolute bottom-3 left-3 right-3 bg-black/85 backdrop-blur-md border border-[#00FF66]/40 rounded-lg p-2 flex items-center justify-between text-[10px] font-mono text-white">
                <span className="text-[#00FF66] font-bold flex items-center space-x-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#00FF66] animate-ping" />
                  <span>BIOMETRIC: VERIFIED</span>
                </span>
                <span className="text-gray-400">0x18_SEC</span>
              </div>
            </div>
          </div>

          {/* 3D Floating Profile Identity Card */}
          <div
            className="w-full max-w-sm bg-black/85 border border-[#00FF66]/40 rounded-xl p-4 font-mono text-xs shadow-[0_10px_30px_rgba(0,0,0,0.8)] backdrop-blur-md relative overflow-hidden transition-all duration-300 hover:border-[#00E5FF]/60"
            style={{
              transform: `perspective(1000px) rotateX(${tilt.y * 0.5}deg) rotateY(${tilt.x * 0.5}deg)`,
            }}
          >
            <div className="absolute top-0 left-0 right-0 h-[1px] bg-gradient-to-r from-transparent via-[#00FF66] to-transparent" />
            <div className="flex items-center justify-between border-b border-zinc-800 pb-2 mb-2.5">
              <span className="text-[10px] text-[#00FF66] font-bold tracking-wider flex items-center space-x-1">
                <Shield className="w-3 h-3" />
                <span>3D PROFILE IDENTITY CARD</span>
              </span>
              <span className="text-[9px] text-[#00E5FF] px-1.5 py-0.2 bg-[#00E5FF]/10 rounded border border-[#00E5FF]/30 font-bold">
                ID_0x18
              </span>
            </div>

            <div className="space-y-2 text-[11px]">
              <div className="flex justify-between items-center">
                <span className="text-gray-500 font-bold">NAME:</span>
                <span className="text-white font-bold">{PORTFOLIO_DATA.personal.name}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-500 font-bold">ROLE:</span>
                <span className="text-[#00E5FF] font-bold truncate ml-2 text-right">{PORTFOLIO_DATA.personal.title}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-500 font-bold">LOCATION:</span>
                <span className="text-gray-300 truncate ml-2 text-right">{PORTFOLIO_DATA.personal.location}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-500 font-bold">STATUS:</span>
                <span className="text-[#00FF66] font-bold">AVAILABLE FOR OPPORTUNITIES</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-500 font-bold">SPECIALIZATION:</span>
                <span className="text-[#BF5AF2] font-bold truncate ml-2 text-right">Ethical Hacking, Apex & Cloud</span>
              </div>
              <div className="flex justify-between items-center border-t border-zinc-800/80 pt-1.5">
                <span className="text-gray-500 font-bold">SYSTEM:</span>
                <span className="text-[#00FF66] font-bold flex items-center space-x-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-[#00FF66] animate-pulse" />
                  <span>ONLINE</span>
                </span>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};
export default Hero;
