import { useEffect, useState } from "react";
import { motion } from "framer-motion";

export const CyberCursor = () => {
  const [mousePosition, setMousePosition] = useState({ x: -100, y: -100 });
  const [isHovered, setIsHovered] = useState(false);
  const [isClicking, setIsClicking] = useState(false);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    // Only enable custom cursor on non-touch devices
    if (window.matchMedia("(pointer: coarse)").matches) {
      return;
    }

    const onMouseMove = (e: MouseEvent) => {
      setMousePosition({ x: e.clientX, y: e.clientY });
      if (!isVisible) setIsVisible(true);
    };

    const onMouseDown = () => setIsClicking(true);
    const onMouseUp = () => setIsClicking(false);

    const onMouseOver = (e: MouseEvent) => {
      const target = e.target as HTMLElement | null;
      if (!target) return;
      
      const isInteractive =
        target.tagName === "BUTTON" ||
        target.tagName === "A" ||
        target.tagName === "INPUT" ||
        target.tagName === "TEXTAREA" ||
        target.closest("button") ||
        target.closest("a") ||
        target.classList.contains("cursor-pointer") ||
        target.getAttribute("role") === "button";

      setIsHovered(!!isInteractive);
    };

    window.addEventListener("mousemove", onMouseMove);
    window.addEventListener("mousedown", onMouseDown);
    window.addEventListener("mouseup", onMouseUp);
    window.addEventListener("mouseover", onMouseOver);

    return () => {
      window.removeEventListener("mousemove", onMouseMove);
      window.removeEventListener("mousedown", onMouseDown);
      window.removeEventListener("mouseup", onMouseUp);
      window.removeEventListener("mouseover", onMouseOver);
    };
  }, [isVisible]);

  if (!isVisible) return null;

  return (
    <div className="fixed inset-0 pointer-events-none z-[99999] overflow-hidden">
      {/* Primary Dot Target */}
      <motion.div
        className="fixed top-0 left-0 w-2 h-2 bg-[#00FF66] rounded-full shadow-[0_0_8px_#00FF66]"
        animate={{
          x: mousePosition.x - 4,
          y: mousePosition.y - 4,
          scale: isClicking ? 0.6 : isHovered ? 1.4 : 1,
        }}
        transition={{ type: "spring", damping: 30, stiffness: 450, mass: 0.1 }}
      />

      {/* Holographic HUD Outer Reticle */}
      <motion.div
        className={`fixed top-0 left-0 rounded-full border ${
          isHovered
            ? "border-[#00E5FF] shadow-[0_0_15px_rgba(0,229,255,0.4)]"
            : "border-[#00FF66]/40"
        }`}
        animate={{
          x: mousePosition.x - (isHovered ? 20 : 14),
          y: mousePosition.y - (isHovered ? 20 : 14),
          width: isHovered ? 40 : 28,
          height: isHovered ? 40 : 28,
          rotate: isHovered ? 90 : 0,
          scale: isClicking ? 0.8 : 1,
        }}
        transition={{ type: "spring", damping: 25, stiffness: 220, mass: 0.3 }}
      >
        {/* Reticle Corner Crosshair Accents */}
        <span className="absolute top-0 left-1/2 -translate-x-1/2 w-1 h-[2px] bg-[#00FF66]/60" />
        <span className="absolute bottom-0 left-1/2 -translate-x-1/2 w-1 h-[2px] bg-[#00FF66]/60" />
        <span className="absolute top-1/2 left-0 -translate-y-1/2 w-[2px] h-1 bg-[#00FF66]/60" />
        <span className="absolute top-1/2 right-0 -translate-y-1/2 w-[2px] h-1 bg-[#00FF66]/60" />
      </motion.div>

      {/* Trailing Coordinate readout */}
      {isHovered && (
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{
            opacity: 1,
            scale: 1,
            x: mousePosition.x + 18,
            y: mousePosition.y + 18,
          }}
          exit={{ opacity: 0 }}
          className="fixed top-0 left-0 px-1.5 py-0.5 bg-black/80 border border-[#00E5FF]/40 rounded text-[8px] font-mono text-[#00E5FF] tracking-wider select-none"
        >
          LOC_LOCK [{Math.round(mousePosition.x)},{Math.round(mousePosition.y)}]
        </motion.div>
      )}
    </div>
  );
};
export default CyberCursor;
