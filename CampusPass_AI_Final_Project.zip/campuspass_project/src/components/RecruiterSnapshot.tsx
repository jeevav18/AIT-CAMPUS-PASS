import React from "react";
import {
  Code2,
  Layers,
  Award,
  GraduationCap,
  Trophy,
  Briefcase,
  CheckCircle2,
} from "lucide-react";
import { PORTFOLIO_DATA } from "@/data/portfolioData";

export const RecruiterSnapshot: React.FC = () => {
  const iconMap: Record<string, React.ReactNode> = {
    Code2: <Code2 className="w-5 h-5 text-blue-600 dark:text-blue-400" />,
    Layers: <Layers className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />,
    Award: <Award className="w-5 h-5 text-amber-600 dark:text-amber-400" />,
    GraduationCap: <GraduationCap className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />,
    Trophy: <Trophy className="w-5 h-5 text-rose-600 dark:text-rose-400" />,
    Briefcase: <Briefcase className="w-5 h-5 text-sky-600 dark:text-sky-400" />,
  };

  return (
    <section className="py-12 bg-white dark:bg-slate-900 border-y border-slate-200/80 dark:border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-blue-600 dark:text-blue-400 mb-1">
              <span>Recruiter Quick View</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white tracking-tight">
              Professional Snapshot
            </h2>
          </div>
          <p className="text-sm text-slate-500 dark:text-slate-400 max-w-md">
            Key metrics and qualifications summarized for hiring managers and technical recruiters.
          </p>
        </div>

        {/* 6 Snapshot Metric Cards */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {(PORTFOLIO_DATA.snapshot || []).map((item, idx) => (
            <div
              key={idx}
              className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/70 dark:border-slate-700/60 hover:border-blue-500/40 dark:hover:border-blue-400/40 transition-all duration-200 hover:-translate-y-1 hover:shadow-md group"
            >
              <div className="w-10 h-10 rounded-xl bg-white dark:bg-slate-900 shadow-xs border border-slate-200/60 dark:border-slate-700/60 flex items-center justify-center mb-3 group-hover:scale-105 transition-transform">
                {iconMap[item.icon] || <CheckCircle2 className="w-5 h-5 text-blue-600" />}
              </div>
              <p className="text-xs font-medium text-slate-500 dark:text-slate-400">
                {item.label}
              </p>
              <p className="text-xl font-bold text-slate-900 dark:text-white mt-0.5">
                {item.value}
              </p>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 line-clamp-1">
                {item.detail}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default RecruiterSnapshot;
