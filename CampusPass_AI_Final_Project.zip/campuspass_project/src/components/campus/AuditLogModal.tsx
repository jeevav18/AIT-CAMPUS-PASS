import React, { useState } from "react";
import { AuditLogItem } from "@/types/campuspass";
import { 
  X, 
  FileText, 
  Search, 
  ShieldCheck, 
  Lock, 
  Download, 
  Filter 
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

interface AuditLogModalProps {
  isOpen: boolean;
  onClose: () => void;
  logs: AuditLogItem[];
}

export const AuditLogModal: React.FC<AuditLogModalProps> = ({
  isOpen,
  onClose,
  logs,
}) => {
  const [searchTerm, setSearchTerm] = useState("");

  if (!isOpen) return null;

  const filteredLogs = logs.filter(
    (l) =>
      l.action.toLowerCase().includes(searchTerm.toLowerCase()) ||
      l.actorName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      l.details.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-white rounded-2xl max-w-4xl w-full max-h-[85vh] flex flex-col shadow-2xl border border-slate-200 dark:bg-slate-900 dark:border-slate-800">
        
        {/* Header */}
        <div className="p-5 border-b border-slate-100 flex items-center justify-between dark:border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="h-9 w-9 rounded-xl bg-slate-900 text-white flex items-center justify-center dark:bg-white dark:text-slate-900">
              <Lock className="h-5 w-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-base text-slate-900 dark:text-white">
                  Cryptographic Institutional Audit Trail
                </h3>
                <Badge className="bg-emerald-600 text-white text-[10px]">
                  Tamper-Evident SHA-256
                </Badge>
              </div>
              <p className="text-xs text-slate-500">
                Immutable ledger of all approvals, parent calls, gate departures and arrival scans
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Search */}
        <div className="p-3 bg-slate-50 border-b border-slate-100 flex items-center gap-2 dark:bg-slate-800/40 dark:border-slate-800">
          <Search className="h-4 w-4 text-slate-400 ml-2" />
          <input
            type="text"
            placeholder="Search by actor, action name, or pass details..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="flex-1 text-xs bg-transparent border-none focus:outline-none dark:text-white"
          />
        </div>

        {/* Logs Table */}
        <div className="flex-1 overflow-y-auto p-4">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-100 text-slate-400 uppercase text-[10px] tracking-wider dark:border-slate-800">
                <th className="pb-3 font-semibold">Timestamp</th>
                <th className="pb-3 font-semibold">Actor / Officer</th>
                <th className="pb-3 font-semibold">Action</th>
                <th className="pb-3 font-semibold">Details</th>
                <th className="pb-3 font-semibold font-mono">IP Node</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-mono text-[11px]">
              {filteredLogs.map((l) => (
                <tr key={l.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/40">
                  <td className="py-2.5 text-slate-500 whitespace-nowrap">
                    {new Date(l.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                  </td>
                  <td className="py-2.5 text-slate-900 font-sans font-semibold whitespace-nowrap dark:text-slate-200">
                    {l.actorName} <span className="text-[10px] text-slate-400 font-normal">({l.actorRole})</span>
                  </td>
                  <td className="py-2.5">
                    <Badge variant="outline" className="text-[9px] font-mono">
                      {l.action}
                    </Badge>
                  </td>
                  <td className="py-2.5 font-sans text-slate-600 max-w-sm truncate dark:text-slate-400">
                    {l.details}
                  </td>
                  <td className="py-2.5 text-slate-400 text-[10px]">
                    {l.ipAddress}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Footer */}
        <div className="p-3 bg-slate-50 border-t border-slate-200 text-xs flex items-center justify-between text-slate-500 dark:bg-slate-800/40 dark:border-slate-800">
          <span>{filteredLogs.length} audit entries verified</span>
          <Button
            size="sm"
            variant="outline"
            className="text-xs h-7 gap-1"
            onClick={() => window.print()}
          >
            <Download className="h-3 w-3" />
            Export Forensic Ledger
          </Button>
        </div>

      </div>
    </div>
  );
};
