import {
  StudentProfile,
  PassRequest,
  LateReturnIncident,
  NotificationPayload,
  AuditLogItem,
  HostelSummary,
  GateMovementRecord,
  ExtensionRequest,
  UserRole
} from "@/types/campuspass";

const STORAGE_KEY = "adithya_campuspass_state_v4";

// Default Seed Students
export const SEED_STUDENTS: StudentProfile[] = [
  {
    id: "std-001",
    rollNumber: "22AD104",
    name: "Aravind Swaminathan",
    email: "aravind.22ad@adithyatech.edu.in",
    phone: "+91 98401 23456",
    avatarUrl: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80",
    department: "Artificial Intelligence & Data Science",
    degree: "B.Tech AI & DS",
    year: 3,
    section: "A",
    tutorId: "stf-tut-01",
    tutorName: "Dr. K. Senthil Kumar (Assoc. Prof - AI & DS)",
    hodId: "stf-hod-01",
    hodName: "Dr. K. Senthil Kumar (HOD AI & DS)",
    hostelBlock: "Kaveri Boys Hostel (Block A - Kurumbapalayam)",
    roomNumber: "A-304",
    wardenName: "Prof. S. Ranganathan",
    attendancePercentage: 88.5,
    disciplinaryRemarks: [],
    currentStatus: "IN_HOSTEL",
    guardian: {
      id: "grd-001",
      name: "Swaminathan Raman",
      relation: "Father",
      phone: "+91 94440 98765",
      alternatePhone: "+91 98400 11223",
      email: "swami.raman@gmail.com",
      whatsappEnabled: true,
      address: "No. 42, West Mambalam, Chennai, TN 600033",
      isPrimary: true,
    },
    localGuardian: {
      id: "grd-001-l",
      name: "R. Natarajan",
      relation: "Guardian",
      phone: "+91 98840 55443",
      email: "natarajan.r@yahoo.com",
      whatsappEnabled: true,
      address: "12/4 Gandhi Nagar, Kurumbapalayam, Coimbatore 641107",
      isPrimary: false,
    }
  },
  {
    id: "std-002",
    rollNumber: "23CS215",
    name: "Sneha Ramakrishnan",
    email: "sneha.23cs@adithyatech.edu.in",
    phone: "+91 97911 34567",
    avatarUrl: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80",
    department: "Computer Science and Engineering",
    degree: "B.E. CSE",
    year: 2,
    section: "B",
    tutorId: "stf-tut-02",
    tutorName: "Mrs. Revathi Sundaram (Asst. Prof - CSE)",
    hodId: "stf-hod-02",
    hodName: "Dr. M. Radhika (HOD CSE)",
    hostelBlock: "Nila Girls Hostel (Block C - Kurumbapalayam)",
    roomNumber: "C-210",
    wardenName: "Dr. Meenakshi Sundaram",
    attendancePercentage: 92.0,
    disciplinaryRemarks: [],
    currentStatus: "ON_OUTING",
    guardian: {
      id: "grd-002",
      name: "Ramakrishnan Vaidyanathan",
      relation: "Father",
      phone: "+91 94432 77889",
      alternatePhone: "+91 94432 77890",
      email: "ramki.vaidya@tcs.com",
      whatsappEnabled: true,
      address: "Plot 18, Anna Nagar West, Madurai 625020",
      isPrimary: true,
    }
  },
  {
    id: "std-003",
    rollNumber: "21ME078",
    name: "Vigneshwar Murugan",
    email: "vignesh.21me@adithyatech.edu.in",
    phone: "+91 98941 78901",
    avatarUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80",
    department: "Mechanical Engineering",
    degree: "B.E. Mechanical",
    year: 4,
    section: "A",
    tutorId: "stf-tut-03",
    tutorName: "Dr. V. Karthikeyan (Assoc. Prof - Mech)",
    hodId: "stf-hod-03",
    hodName: "Dr. S. Shanmugam (HOD Mechanical)",
    hostelBlock: "Vaigai Boys Hostel (Block B - Kurumbapalayam)",
    roomNumber: "B-112",
    wardenName: "Mr. G. Anand Babu",
    attendancePercentage: 74.2,
    disciplinaryRemarks: ["Prior late return warning recorded on 14-Aug-2025"],
    currentStatus: "OVERDUE",
    guardian: {
      id: "grd-003",
      name: "Murugan Palanisamy",
      relation: "Father",
      phone: "+91 98422 66778",
      email: "m.palanisamy.trichy@gmail.com",
      whatsappEnabled: true,
      address: "15, Salai Road, Tiruchirappalli 620018",
      isPrimary: true,
    }
  },
  {
    id: "std-004",
    rollNumber: "22IT142",
    name: "Divya Bharathi",
    email: "divya.22it@adithyatech.edu.in",
    phone: "+91 98845 67890",
    avatarUrl: "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&auto=format&fit=crop&q=80",
    department: "Information Technology",
    degree: "B.Tech IT",
    year: 3,
    section: "A",
    tutorId: "stf-tut-01",
    tutorName: "Dr. K. Senthil Kumar (Assoc. Prof)",
    hodId: "stf-hod-01",
    hodName: "Dr. P. Suresh (HOD IT)",
    hostelBlock: "Nila Girls Hostel (Block C - Kurumbapalayam)",
    roomNumber: "C-405",
    wardenName: "Dr. Meenakshi Sundaram",
    attendancePercentage: 86.4,
    disciplinaryRemarks: [],
    currentStatus: "IN_HOSTEL",
    guardian: {
      id: "grd-004",
      name: "Saradha Bharathi",
      relation: "Mother",
      phone: "+91 97890 12345",
      email: "saradha.bharathi@gmail.com",
      whatsappEnabled: true,
      address: "7/2 Cross Cut Road, Gandhipuram, Coimbatore 641012",
      isPrimary: true,
    }
  }
];

export const SEED_HOSTELS: HostelSummary[] = [
  {
    blockId: "hst-01",
    blockName: "Kaveri Boys Hostel (Block A)",
    gender: "BOYS",
    chiefWarden: "Prof. S. Ranganathan (+91 94441 55667)",
    totalRooms: 120,
    capacity: 360,
    currentResidents: 342,
    currentlyOut: 14,
    overdueCount: 0,
  },
  {
    blockId: "hst-02",
    blockName: "Vaigai Boys Hostel (Block B)",
    gender: "BOYS",
    chiefWarden: "Mr. G. Anand Babu (+91 98421 99881)",
    totalRooms: 110,
    capacity: 330,
    currentResidents: 318,
    currentlyOut: 19,
    overdueCount: 1,
  },
  {
    blockId: "hst-03",
    blockName: "Nila Girls Hostel (Block C)",
    gender: "GIRLS",
    chiefWarden: "Dr. Meenakshi Sundaram (+91 97910 22334)",
    totalRooms: 140,
    capacity: 420,
    currentResidents: 405,
    currentlyOut: 8,
    overdueCount: 0,
  },
  {
    blockId: "hst-04",
    blockName: "Thamirabarani PG Hostel",
    gender: "BOYS",
    chiefWarden: "Dr. N. Suresh (+91 98940 44556)",
    totalRooms: 60,
    capacity: 120,
    currentResidents: 112,
    currentlyOut: 3,
    overdueCount: 0,
  }
];

// Helper to make ISO dates offset from now
const now = new Date();
const isoOffset = (hours: number, minutes: number = 0) => {
  const d = new Date(now.getTime() + (hours * 60 + minutes) * 60 * 1000);
  return d.toISOString();
};

export const SEED_PASSES: PassRequest[] = [
  // 1. Approved Active Pass ready for QR Scan at gate
  {
    id: "pass-101",
    passNumber: "AIT-2025-0914",
    passType: "outing",
    studentId: "std-001",
    studentName: "Aravind Swaminathan",
    rollNumber: "22AD104",
    department: "Artificial Intelligence & Data Science",
    year: 3,
    hostelBlock: "Kaveri Boys Hostel (Block A - Kurumbapalayam)",
    roomNumber: "A-304",
    avatarUrl: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80",
    studentPhone: "+91 98401 23456",
    departureDateTime: isoOffset(0, 30), // departures in 30 mins
    expectedReturnDateTime: isoOffset(3, 30),
    destination: "Prozone Mall & Sathy Road Hardware Tech Hub, Coimbatore",
    reason: "Procurement of Jetson Nano AI edge compute modules & embedded sensors for AI & DS project.",
    destinationContact: "+91 98401 23456",
    transportMode: "College Shuttle / Sathy Road Bus",
    guardian: SEED_STUDENTS[0].guardian,
    parentConsentStatus: "consented_sms",
    parentConsentNotes: "Father confirmed via WhatsApp quick link at 11:15 AM.",
    parentConsentTimestamp: isoOffset(-2),
    currentStage: "gate",
    approvalWorkflow: {
      tutor: {
        role: "tutor",
        status: "approved",
        officerName: "Dr. K. Senthil Kumar",
        officerId: "stf-tut-01",
        timestamp: isoOffset(-3),
        remarks: "Attendance is 88.5%. Recommended for daytime AI research procurement.",
        parentContacted: true,
        parentContactDetails: "Dialed father (+91 94440 98765) - Confirmed.",
      },
      hod: {
        role: "hod",
        status: "approved",
        officerName: "Dr. K. Senthil Kumar",
        officerId: "stf-hod-01",
        timestamp: isoOffset(-2, 30),
        remarks: "No AI & Data Science laboratory conflict this afternoon.",
      },
      warden: {
        role: "warden",
        status: "approved",
        officerName: "Prof. S. Ranganathan",
        officerId: "stf-war-01",
        timestamp: isoOffset(-1),
        remarks: "Hostel register signed. Cryptographic QR token issued.",
      }
    },
    status: "approved",
    qrToken: "AIT-QR-SEC-TOKEN-ARAVIND-22AD104-ACTIVE",
    qrGeneratedAt: isoOffset(-1),
    qrExpiresAt: isoOffset(5),
    movements: [],
    extensions: [],
    aiAnalysis: {
      riskScore: "LOW",
      riskSummary: "Legitimate study procurement outing. High attendance (88.5%), parental consent registered, clear destination.",
      missingInfoAlerts: [],
      policyCompliance: true,
      recommendation: "APPROVE",
    },
    createdAt: isoOffset(-4),
    updatedAt: isoOffset(-1),
  },

  // 2. Active OUT Pass (student is currently in city, exit recorded)
  {
    id: "pass-102",
    passNumber: "AIT-2025-0899",
    passType: "outing",
    studentId: "std-002",
    studentName: "Sneha Ramakrishnan",
    rollNumber: "23CS215",
    department: "Computer Science and Engineering",
    year: 2,
    hostelBlock: "Nila Girls Hostel (Block C - Kurumbapalayam)",
    roomNumber: "C-210",
    avatarUrl: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80",
    studentPhone: "+91 97911 34567",
    departureDateTime: isoOffset(-2),
    expectedReturnDateTime: isoOffset(2),
    actualExitDateTime: isoOffset(-1, -45),
    destination: "KMCH Specialty Hospital & Medical Centre, Avinashi Road",
    reason: "Ophthalmology eye consultation and prescription checkup.",
    destinationContact: "+91 422 432 3800",
    transportMode: "Call Taxi / Uber",
    guardian: SEED_STUDENTS[1].guardian,
    parentConsentStatus: "verified_by_call",
    parentConsentNotes: "Tutor verified with father Mr. Ramakrishnan directly.",
    parentConsentTimestamp: isoOffset(-3),
    currentStage: "gate",
    approvalWorkflow: {
      tutor: {
        role: "tutor",
        status: "approved",
        officerName: "Mrs. Revathi Sundaram",
        officerId: "stf-tut-02",
        timestamp: isoOffset(-4),
        remarks: "Medical prescription appointment verified.",
        parentContacted: true,
        parentContactDetails: "Phone verified with Father.",
      },
      hod: {
        role: "hod",
        status: "approved",
        officerName: "Dr. M. Radhika",
        officerId: "stf-hod-02",
        timestamp: isoOffset(-3, 30),
        remarks: "Approved for medical consultation.",
      },
      warden: {
        role: "warden",
        status: "approved",
        officerName: "Dr. Meenakshi Sundaram",
        officerId: "stf-war-02",
        timestamp: isoOffset(-3),
        remarks: "Medical pass verified. Escort verified.",
      }
    },
    status: "active_out",
    qrToken: "AIT-QR-SEC-TOKEN-SNEHA-23CS215-DEPARTED",
    qrGeneratedAt: isoOffset(-3),
    qrExpiresAt: isoOffset(4),
    movements: [
      {
        id: "mov-001",
        passId: "pass-102",
        passNumber: "AIT-2025-0899",
        studentId: "std-002",
        studentName: "Sneha Ramakrishnan",
        rollNumber: "23CS215",
        movementType: "EXIT",
        gateId: "GATE-01",
        gateName: "Gate 1 (Sathy Road Entrance, Kurumbapalayam)",
        securityOfficerId: "sec-01",
        securityOfficerName: "Havaldar R. Murugesan",
        timestamp: isoOffset(-1, -45),
        status: "VERIFIED",
        notes: "Boarded registered Uber taxi. Parent WhatsApp exit notification delivered.",
      }
    ],
    extensions: [],
    aiAnalysis: {
      riskScore: "LOW",
      riskSummary: "Verified medical visit. Medical center phone provided, parental call logged.",
      missingInfoAlerts: [],
      policyCompliance: true,
      recommendation: "APPROVE",
    },
    createdAt: isoOffset(-5),
    updatedAt: isoOffset(-1, -45),
  },

  // 3. OVERDUE PASS — Student missed expected return deadline!
  {
    id: "pass-103",
    passNumber: "AIT-2025-0872",
    passType: "outing",
    studentId: "std-003",
    studentName: "Vigneshwar Murugan",
    rollNumber: "21ME078",
    department: "Mechanical Engineering",
    year: 4,
    hostelBlock: "Vaigai Boys Hostel (Block B - Kurumbapalayam)",
    roomNumber: "B-112",
    avatarUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80",
    studentPhone: "+91 98941 78901",
    departureDateTime: isoOffset(-5),
    expectedReturnDateTime: isoOffset(-1, -15), // Missed return by 75 minutes!
    actualExitDateTime: isoOffset(-4, -50),
    destination: "RS Puram Industrial Spares & Lathe Workshop",
    reason: "Fabrication workshop work for Baja SAE offroad vehicle project.",
    destinationContact: "+91 98422 66778",
    transportMode: "Two Wheeler",
    guardian: SEED_STUDENTS[2].guardian,
    parentConsentStatus: "consented_sms",
    parentConsentNotes: "Automated SMS consent acknowledged.",
    currentStage: "gate",
    approvalWorkflow: {
      tutor: {
        role: "tutor",
        status: "approved",
        officerName: "Dr. V. Karthikeyan",
        officerId: "stf-tut-03",
        timestamp: isoOffset(-6),
        remarks: "Fabrication project work.",
        parentContacted: true,
      },
      hod: {
        role: "hod",
        status: "approved",
        officerName: "Dr. S. Shanmugam",
        officerId: "stf-hod-03",
        timestamp: isoOffset(-5, 40),
        remarks: "Department SAE team member.",
      },
      warden: {
        role: "warden",
        status: "approved",
        officerName: "Mr. G. Anand Babu",
        officerId: "stf-war-03",
        timestamp: isoOffset(-5, 10),
        remarks: "Return strictly by 18:30 required.",
      }
    },
    status: "overdue",
    qrToken: "CP-QR-SEC-TOKEN-VIGNESH-21ME078-OVERDUE",
    qrGeneratedAt: isoOffset(-5, 10),
    qrExpiresAt: isoOffset(2),
    movements: [
      {
        id: "mov-002",
        passId: "pass-103",
        passNumber: "CP-2025-0872",
        studentId: "std-003",
        studentName: "Vigneshwar Murugan",
        rollNumber: "21ME078",
        movementType: "EXIT",
        gateId: "GATE-02",
        gateName: "Gate 2 (North Gate)",
        securityOfficerId: "sec-02",
        securityOfficerName: "Security Officer K. Selvan",
        timestamp: isoOffset(-4, -50),
        status: "VERIFIED",
        notes: "Left via motorcycle TN 38 BX 4412.",
      }
    ],
    extensions: [],
    aiAnalysis: {
      riskScore: "MEDIUM",
      riskSummary: "Student has prior late return warning on record. Outing period exceeds 4 hours.",
      missingInfoAlerts: ["Workshop supervisor direct phone number not listed."],
      policyCompliance: false,
      recommendation: "FLAG_FOR_CALL",
    },
    createdAt: isoOffset(-7),
    updatedAt: isoOffset(-1, -15),
  },

  // 4. Pending Tutor Approval (with parent call pending)
  {
    id: "pass-104",
    passNumber: "CP-2025-0920",
    passType: "home_pass",
    studentId: "std-004",
    studentName: "Divya Bharathi",
    rollNumber: "22IT142",
    department: "Information Technology",
    year: 3,
    hostelBlock: "Nila Girls Hostel (Block C)",
    roomNumber: "C-405",
    avatarUrl: "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&auto=format&fit=crop&q=80",
    studentPhone: "+91 98845 67890",
    departureDateTime: isoOffset(4),
    expectedReturnDateTime: isoOffset(52), // Home leave for 2 days
    destination: "Home Address: 7/2 Cross Cut Road, Gandhipuram, Coimbatore",
    reason: "Attending family function (Cousin marriage) and festival leave.",
    destinationContact: "+91 97890 12345",
    transportMode: "Parent pick-up by car",
    guardian: SEED_STUDENTS[3].guardian,
    parentConsentStatus: "pending",
    parentConsentNotes: "Automated WhatsApp consent notification sent to Mother. Verbal call verification pending by Tutor.",
    currentStage: "tutor",
    approvalWorkflow: {
      tutor: {
        role: "tutor",
        status: "pending",
      },
      hod: {
        role: "hod",
        status: "pending",
      },
      warden: {
        role: "warden",
        status: "pending",
      }
    },
    status: "pending_tutor",
    movements: [],
    extensions: [],
    aiAnalysis: {
      riskScore: "LOW",
      riskSummary: "Weekend family home pass. Regular destination, good attendance record (86.4%).",
      missingInfoAlerts: ["Parent telephonic verification must be logged by Tutor before routing to HOD."],
      policyCompliance: true,
      recommendation: "FLAG_FOR_CALL",
    },
    createdAt: isoOffset(-1),
    updatedAt: isoOffset(-1),
  }
];

export const SEED_LATE_INCIDENTS: LateReturnIncident[] = [
  {
    id: "inc-001",
    passId: "pass-103",
    passNumber: "CP-2025-0872",
    studentId: "std-003",
    studentName: "Vigneshwar Murugan",
    rollNumber: "21ME078",
    hostelBlock: "Vaigai Boys Hostel (Block B)",
    roomNumber: "B-112",
    studentPhone: "+91 98941 78901",
    guardianPhone: "+91 98422 66778",
    guardianName: "Murugan Palanisamy (Father)",
    expectedReturnTime: isoOffset(-1, -15),
    actualExitTime: isoOffset(-4, -50),
    overdueMinutes: 75,
    status: "ACTIVE_ALERT",
    severity: "HIGH",
    actionsTaken: [
      {
        timestamp: isoOffset(-0, -45),
        action: "Automated SMS & in-app curfew reminder triggered at +30 minutes.",
        officer: "CampusPass Watchdog Bot",
      },
      {
        timestamp: isoOffset(-0, -20),
        action: "Warden Mr. G. Anand Babu alerted. Attempted call to student - phone ringing unanswered.",
        officer: "Hostel Control Room",
      }
    ]
  }
];

export const SEED_NOTIFICATIONS: NotificationPayload[] = [
  {
    id: "notif-001",
    recipientRole: "parent",
    recipientName: "Swaminathan Raman",
    recipientPhone: "+91 94440 98765",
    channel: "WHATSAPP",
    title: "Pass Approved by Warden",
    message: "Adithya Tech (AIT 2744): Outing Pass CP-2025-0914 for Aravind Swaminathan approved. Expected return: Today 19:30 HRS.",
    timestamp: isoOffset(-1),
    read: true,
    passId: "pass-101",
    passNumber: "CP-2025-0914",
    type: "FINAL_APPROVED",
  },
  {
    id: "notif-002",
    recipientRole: "parent",
    recipientName: "Ramakrishnan Vaidyanathan",
    recipientPhone: "+91 94432 77889",
    channel: "SMS",
    title: "Campus Gate Departure Notice",
    message: "Adithya Tech (AIT 2744): Your ward Sneha Ramakrishnan (23CS215) has exited through Gate 1 at 14:15 HRS. Medical pass authorized.",
    timestamp: isoOffset(-1, -45),
    read: true,
    passId: "pass-102",
    passNumber: "CP-2025-0899",
    type: "EXIT_RECORDED",
  },
  {
    id: "notif-003",
    recipientRole: "warden",
    recipientName: "Mr. G. Anand Babu",
    channel: "IN_APP",
    title: "URGENT: Curfew Overdue Alert",
    message: "Student Vigneshwar Murugan (21ME078, Room B-112) is 75 minutes overdue. Expected return was 18:30 HRS.",
    timestamp: isoOffset(-0, -45),
    read: false,
    passId: "pass-103",
    passNumber: "CP-2025-0872",
    type: "OVERDUE_ALERT",
  },
  {
    id: "notif-004",
    recipientRole: "tutor",
    recipientName: "Dr. K. Senthil Kumar",
    channel: "IN_APP",
    title: "New Home Pass Request",
    message: "Student Divya Bharathi (22IT142) submitted Home Pass request for 2 days. Parent call verification required.",
    timestamp: isoOffset(-1),
    read: false,
    passId: "pass-104",
    passNumber: "CP-2025-0920",
    type: "PASS_SUBMITTED",
  }
];

export const SEED_AUDIT_LOGS: AuditLogItem[] = [
  {
    id: "aud-001",
    timestamp: isoOffset(-1, -45),
    actorName: "Havaldar R. Murugesan",
    actorRole: "guard",
    action: "GATE_EXIT_VERIFIED",
    entityType: "GATE",
    entityId: "pass-102",
    details: "Scanned QR CP-QR-SEC-TOKEN-SNEHA-23EC215-DEPARTED at Gate 1 Main. Parent SMS dispatched.",
    ipAddress: "192.168.10.45",
  },
  {
    id: "aud-002",
    timestamp: isoOffset(-1),
    actorName: "Prof. S. Ranganathan",
    actorRole: "warden",
    action: "WARDEN_PASS_APPROVED",
    entityType: "PASS",
    entityId: "pass-101",
    details: "Issued digital QR token for Outing Pass CP-2025-0914 after parent consent verification.",
    ipAddress: "192.168.1.108",
  },
  {
    id: "aud-003",
    timestamp: isoOffset(-2, 30),
    actorName: "Dr. M. Radhika",
    actorRole: "hod",
    action: "HOD_PASS_APPROVED",
    entityType: "PASS",
    entityId: "pass-101",
    details: "Verified department lab schedule and forwarded to Warden.",
    ipAddress: "192.168.1.52",
  },
  {
    id: "aud-004",
    timestamp: isoOffset(-3),
    actorName: "Dr. K. Senthil Kumar",
    actorRole: "tutor",
    action: "TUTOR_PARENT_VERIFICATION_LOGGED",
    entityType: "PASS",
    entityId: "pass-101",
    details: "Telephonic verification call logged with Father Swaminathan (+91 94440 98765). Approved.",
    ipAddress: "192.168.1.34",
  }
];

interface AppState {
  students: StudentProfile[];
  hostels: HostelSummary[];
  passes: PassRequest[];
  incidents: LateReturnIncident[];
  notifications: NotificationPayload[];
  auditLogs: AuditLogItem[];
  currentRole: UserRole;
  selectedStudentId: string;
}

class CampusDataManager {
  private state: AppState;

  constructor() {
    this.state = this.loadState();
  }

  private loadState(): AppState {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed.students) && parsed.students.length > 0 && Array.isArray(parsed.passes)) {
          return {
            students: parsed.students,
            hostels: Array.isArray(parsed.hostels) && parsed.hostels.length > 0 ? parsed.hostels : SEED_HOSTELS,
            passes: parsed.passes,
            incidents: Array.isArray(parsed.incidents) ? parsed.incidents : SEED_LATE_INCIDENTS,
            notifications: Array.isArray(parsed.notifications) ? parsed.notifications : SEED_NOTIFICATIONS,
            auditLogs: Array.isArray(parsed.auditLogs) ? parsed.auditLogs : SEED_AUDIT_LOGS,
            currentRole: parsed.currentRole || "student",
            selectedStudentId: parsed.selectedStudentId || SEED_STUDENTS[0].id,
          };
        }
      }
    } catch (e) {
      console.error("Failed to load campus state from storage", e);
    }
    return {
      students: SEED_STUDENTS,
      hostels: SEED_HOSTELS,
      passes: SEED_PASSES,
      incidents: SEED_LATE_INCIDENTS,
      notifications: SEED_NOTIFICATIONS,
      auditLogs: SEED_AUDIT_LOGS,
      currentRole: "student",
      selectedStudentId: "std-001",
    };
  }

  private saveState(): void {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(this.state));
    } catch (e) {
      console.error("Failed to save campus state to storage", e);
    }
  }

  public getState(): AppState {
    return this.state;
  }

  public resetToSeed(): void {
    this.state = {
      students: SEED_STUDENTS,
      hostels: SEED_HOSTELS,
      passes: SEED_PASSES,
      incidents: SEED_LATE_INCIDENTS,
      notifications: SEED_NOTIFICATIONS,
      auditLogs: SEED_AUDIT_LOGS,
      currentRole: "student",
      selectedStudentId: "std-001",
    };
    this.saveState();
  }

  public setRole(role: UserRole): void {
    this.state.currentRole = role;
    this.saveState();
  }

  public setSelectedStudent(studentId: string): void {
    this.state.selectedStudentId = studentId;
    this.saveState();
  }

  public getSelectedStudent(): StudentProfile {
    return (
      this.state.students.find((s) => s.id === this.state.selectedStudentId) ||
      this.state.students[0]
    );
  }

  // --- PASS LIFECYCLE METHODS ---

  public createPass(newPass: Omit<PassRequest, "id" | "passNumber" | "createdAt" | "updatedAt" | "movements" | "extensions" | "status" | "currentStage" | "approvalWorkflow">): PassRequest {
    const student = this.state.students.find((s) => s.id === newPass.studentId) || this.getSelectedStudent();
    const id = `pass-${Date.now().toString(36)}`;
    const passNumber = `AIT-2025-${Math.floor(1000 + Math.random() * 9000)}`;
    const timestamp = new Date().toISOString();

    const created: PassRequest = {
      ...newPass,
      id,
      passNumber,
      status: "pending_tutor",
      currentStage: "tutor",
      approvalWorkflow: {
        tutor: { role: "tutor", status: "pending" },
        hod: { role: "hod", status: "pending" },
        warden: { role: "warden", status: "pending" },
      },
      movements: [],
      extensions: [],
      createdAt: timestamp,
      updatedAt: timestamp,
    };

    this.state.passes.unshift(created);

    // Notify Tutor
    this.addNotification({
      recipientRole: "tutor",
      recipientName: student.tutorName,
      channel: "IN_APP",
      title: "New Pass Application Submitted",
      message: `${student.name} (${student.rollNumber}) submitted a ${created.passType.replace("_", " ")} request for department review.`,
      passId: created.id,
      passNumber: created.passNumber,
      type: "PASS_SUBMITTED",
    });

    // Notify Parent via SMS & WhatsApp
    this.addNotification({
      recipientRole: "parent",
      recipientName: student.guardian.name,
      recipientPhone: student.guardian.phone,
      channel: "WHATSAPP",
      title: "Hostel Pass Application Alert",
      message: `Adithya Inst of Tech (TNEA 2744): Your ward ${student.name} has applied for a ${created.passType.replace("_", " ")} to ${created.destination}. Review or provide consent via Parent Portal.`,
      passId: created.id,
      passNumber: created.passNumber,
      type: "PARENT_CONSENT_REQ",
    });

    // Audit Log
    this.addAuditLog({
      actorName: student.name,
      actorRole: "student",
      action: "PASS_APPLICATION_SUBMITTED",
      entityType: "PASS",
      entityId: created.id,
      details: `Submitted ${created.passType} pass request to ${created.destination}`,
    });

    this.saveState();
    return created;
  }

  // Multi-tier Workflow Approval
  public approveStage(
    passId: string,
    role: "tutor" | "hod" | "warden" | "principal",
    officerName: string,
    officerId: string,
    remarks: string,
    extra?: { parentContacted?: boolean; parentContactDetails?: string }
  ): PassRequest {
    const pass = this.state.passes.find((p) => p.id === passId);
    if (!pass) throw new Error("Pass not found");

    const nowIso = new Date().toISOString();

    if (role === "tutor") {
      pass.approvalWorkflow.tutor = {
        role: "tutor",
        status: "approved",
        officerName,
        officerId,
        timestamp: nowIso,
        remarks: remarks || "Attendance and academic standing verified.",
        parentContacted: extra?.parentContacted ?? true,
        parentContactDetails: extra?.parentContactDetails || "Verified with parent directly.",
      };
      pass.currentStage = "hod";
      pass.status = "pending_hod";

      this.addNotification({
        recipientRole: "hod",
        recipientName: "Head of Department",
        channel: "IN_APP",
        title: "Tutor Approved: HOD Clearance Needed",
        message: `${pass.studentName} (${pass.rollNumber}) approved by Tutor. Awaiting departmental clearance.`,
        passId: pass.id,
        passNumber: pass.passNumber,
        type: "STAGE_APPROVED",
      });
    } else if (role === "hod") {
      pass.approvalWorkflow.hod = {
        role: "hod",
        status: "approved",
        officerName,
        officerId,
        timestamp: nowIso,
        remarks: remarks || "Department academic and lab clearance granted.",
      };
      pass.currentStage = "warden";
      pass.status = "pending_warden";

      this.addNotification({
        recipientRole: "warden",
        recipientName: "Hostel Chief Warden",
        channel: "IN_APP",
        title: "HOD Approved: Warden Final Issuance Needed",
        message: `${pass.studentName} (${pass.rollNumber}) cleared by HOD. Ready for hostel register & QR generation.`,
        passId: pass.id,
        passNumber: pass.passNumber,
        type: "STAGE_APPROVED",
      });
    } else if (role === "warden" || role === "principal") {
      pass.approvalWorkflow.warden = {
        role: "warden",
        status: "approved",
        officerName,
        officerId,
        timestamp: nowIso,
        remarks: remarks || "Hostel records checked. Cryptographic QR pass generated.",
      };
      pass.currentStage = "gate";
      pass.status = "approved";

      // Generate Tamper-evident QR token
      pass.qrToken = `CP-QR-SEC-${pass.passNumber}-${pass.rollNumber}-${Date.now().toString(36).toUpperCase()}`;
      pass.qrGeneratedAt = nowIso;
      pass.qrExpiresAt = new Date(Date.now() + 24 * 3600 * 1000).toISOString();

      // Notify Student
      this.addNotification({
        recipientRole: "student",
        recipientName: pass.studentName,
        channel: "IN_APP",
        title: "Pass Approved! Digital QR Ready",
        message: `Your pass ${pass.passNumber} has been issued by Warden ${officerName}. Dynamic QR code is active for gate scanning.`,
        passId: pass.id,
        passNumber: pass.passNumber,
        type: "FINAL_APPROVED",
      });

      // Notify Parent via WhatsApp & SMS
      this.addNotification({
        recipientRole: "parent",
        recipientName: pass.guardian.name,
        recipientPhone: pass.guardian.phone,
        channel: "WHATSAPP",
        title: "Hostel Pass Approved Notice",
        message: `Adithya Tech (AIT 2744): Outing Pass ${pass.passNumber} for ${pass.studentName} has been APPROVED by Chief Warden. Expected return: ${new Date(pass.expectedReturnDateTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}.`,
        passId: pass.id,
        passNumber: pass.passNumber,
        type: "FINAL_APPROVED",
      });
    }

    pass.updatedAt = nowIso;

    this.addAuditLog({
      actorName: officerName,
      actorRole: role,
      action: `${role.toUpperCase()}_PASS_APPROVED`,
      entityType: "PASS",
      entityId: pass.id,
      details: `${role.toUpperCase()} approved pass ${pass.passNumber}. Remarks: ${remarks || "None"}`,
    });

    this.saveState();
    return pass;
  }

  // Reject Pass
  public rejectStage(
    passId: string,
    role: "tutor" | "hod" | "warden" | "principal",
    officerName: string,
    rejectionReason: string
  ): PassRequest {
    const pass = this.state.passes.find((p) => p.id === passId);
    if (!pass) throw new Error("Pass not found");

    const nowIso = new Date().toISOString();
    pass.status = "rejected";
    pass.rejectionReason = rejectionReason;
    pass.rejectedBy = `${role.toUpperCase()} (${officerName})`;
    pass.updatedAt = nowIso;

    if (role === "tutor") {
      pass.approvalWorkflow.tutor.status = "rejected";
      pass.approvalWorkflow.tutor.remarks = rejectionReason;
    } else if (role === "hod") {
      pass.approvalWorkflow.hod.status = "rejected";
      pass.approvalWorkflow.hod.remarks = rejectionReason;
    } else if (role === "warden") {
      pass.approvalWorkflow.warden.status = "rejected";
      pass.approvalWorkflow.warden.remarks = rejectionReason;
    }

    // Notify Student
    this.addNotification({
      recipientRole: "student",
      recipientName: pass.studentName,
      channel: "IN_APP",
      title: `Pass Request Declined by ${role.toUpperCase()}`,
      message: `Your pass ${pass.passNumber} was rejected. Reason: ${rejectionReason}`,
      passId: pass.id,
      passNumber: pass.passNumber,
      type: "STAGE_APPROVED",
    });

    this.addAuditLog({
      actorName: officerName,
      actorRole: role,
      action: `${role.toUpperCase()}_PASS_REJECTED`,
      entityType: "PASS",
      entityId: pass.id,
      details: `Declined pass ${pass.passNumber}. Reason: ${rejectionReason}`,
    });

    this.saveState();
    return pass;
  }

  // Parent Portal Consent
  public recordParentConsent(
    passId: string,
    consent: "consented" | "rejected",
    notes: string,
    parentName: string
  ): PassRequest {
    const pass = this.state.passes.find((p) => p.id === passId);
    if (!pass) throw new Error("Pass not found");

    const nowIso = new Date().toISOString();
    pass.parentConsentStatus = consent === "consented" ? "consented_portal" : "rejected_by_parent";
    pass.parentConsentNotes = notes || (consent === "consented" ? "Approved by parent via parent portal." : "Declined by parent.");
    pass.parentConsentTimestamp = nowIso;
    pass.updatedAt = nowIso;

    this.addNotification({
      recipientRole: "tutor",
      recipientName: "Class Tutor",
      channel: "IN_APP",
      title: `Parent ${consent === "consented" ? "Consented" : "Declined"} Leave`,
      message: `Guardian ${parentName} responded to pass ${pass.passNumber} for ${pass.studentName}: ${pass.parentConsentNotes}`,
      passId: pass.id,
      passNumber: pass.passNumber,
      type: "STAGE_APPROVED",
    });

    this.addAuditLog({
      actorName: parentName,
      actorRole: "parent",
      action: consent === "consented" ? "PARENT_CONSENT_GRANTED" : "PARENT_CONSENT_REFUSED",
      entityType: "PASS",
      entityId: pass.id,
      details: `Parent recorded ${consent}. Notes: ${notes}`,
    });

    this.saveState();
    return pass;
  }

  // --- SMART GATE SECURITY SCAN ENGINE ---

  public verifyAndProcessGateScan(
    scannedTokenOrPassNumber: string,
    gateId: string,
    gateName: string,
    officerName: string,
    securityOfficerId: string
  ): {
    success: boolean;
    movementType: "EXIT" | "ENTRY";
    pass: PassRequest;
    message: string;
    isOverdue?: boolean;
    overdueMinutes?: number;
  } {
    const trimmed = scannedTokenOrPassNumber.trim().toUpperCase();
    const pass = this.state.passes.find(
      (p) =>
        (p.qrToken && p.qrToken.toUpperCase() === trimmed) ||
        p.passNumber.toUpperCase() === trimmed ||
        trimmed.includes(p.passNumber.toUpperCase())
    );

    if (!pass) {
      throw new Error("INVALID_TOKEN: Scanned QR token does not match any registered pass in database.");
    }

    if (pass.status === "rejected" || pass.status === "draft" || pass.status === "cancelled") {
      throw new Error(`DENIED: Pass is in '${pass.status}' state. Departure not permitted.`);
    }

    if (pass.status.startsWith("pending")) {
      throw new Error(`UNAPPROVED: Pass is still awaiting approvals (${pass.currentStage.toUpperCase()}). Gate pass not issued.`);
    }

    const nowIso = new Date().toISOString();
    const student = this.state.students.find((s) => s.id === pass.studentId);

    // Case 1: First scan -> EXIT (Departure from campus)
    if (pass.status === "approved" && !pass.actualExitDateTime) {
      pass.status = "active_out";
      pass.actualExitDateTime = nowIso;
      if (student) student.currentStatus = pass.passType === "home_pass" ? "ON_HOME_PASS" : "ON_OUTING";

      const movement: GateMovementRecord = {
        id: `mov-${Date.now().toString(36)}`,
        passId: pass.id,
        passNumber: pass.passNumber,
        studentId: pass.studentId,
        studentName: pass.studentName,
        rollNumber: pass.rollNumber,
        movementType: "EXIT",
        gateId,
        gateName,
        securityOfficerId,
        securityOfficerName: officerName,
        timestamp: nowIso,
        status: "VERIFIED",
        notes: `Physical verification completed. Biometric & student photo matched.`,
      };

      pass.movements.push(movement);
      pass.updatedAt = nowIso;

      // Update Hostel counts
      const hostel = this.state.hostels.find((h) => h.blockName.includes(pass.hostelBlock.split(" ")[0]));
      if (hostel) {
        hostel.currentlyOut = Math.min(hostel.capacity, hostel.currentlyOut + 1);
      }

      // Instant Parent WhatsApp & SMS Dispatch
      this.addNotification({
        recipientRole: "parent",
        recipientName: pass.guardian.name,
        recipientPhone: pass.guardian.phone,
        channel: "WHATSAPP",
        title: "Campus Gate DEPARTURE Alert",
        message: `Adithya Tech (AIT 2744): Your ward ${pass.studentName} has EXITED campus via ${gateName} at ${new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}. Scheduled return: ${new Date(pass.expectedReturnDateTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}.`,
        passId: pass.id,
        passNumber: pass.passNumber,
        type: "EXIT_RECORDED",
      });

      this.addAuditLog({
        actorName: officerName,
        actorRole: "guard",
        action: "GATE_EXIT_VERIFIED",
        entityType: "GATE",
        entityId: pass.id,
        details: `Verified exit for ${pass.studentName} at ${gateName}. Real-time WhatsApp dispatched to parent ${pass.guardian.phone}.`,
      });

      this.saveState();
      return {
        success: true,
        movementType: "EXIT",
        pass,
        message: `Exit verified for ${pass.studentName}. Gate movement registered. Parent alert dispatched.`,
      };
    }

    // Case 2: Second scan -> ENTRY (Return to campus)
    if (pass.status === "active_out" || pass.status === "overdue") {
      const expectedTime = new Date(pass.expectedReturnDateTime).getTime();
      const actualTime = new Date(nowIso).getTime();
      const overdueMs = actualTime - expectedTime;
      const overdueMinutes = overdueMs > 0 ? Math.floor(overdueMs / 60000) : 0;
      const isLate = overdueMinutes > 15;

      pass.status = "completed";
      pass.actualEntryDateTime = nowIso;
      if (student) student.currentStatus = "IN_HOSTEL";

      const movement: GateMovementRecord = {
        id: `mov-${Date.now().toString(36)}`,
        passId: pass.id,
        passNumber: pass.passNumber,
        studentId: pass.studentId,
        studentName: pass.studentName,
        rollNumber: pass.rollNumber,
        movementType: "ENTRY",
        gateId,
        gateName,
        securityOfficerId,
        securityOfficerName: officerName,
        timestamp: nowIso,
        status: isLate ? "FLAGGED_LATE" : "VERIFIED",
        notes: isLate
          ? `Returned late by ${overdueMinutes} mins past deadline.`
          : `Returned on-time safely.`,
      };

      pass.movements.push(movement);
      pass.updatedAt = nowIso;

      // Update hostel counts
      const hostel = this.state.hostels.find((h) => h.blockName.includes(pass.hostelBlock.split(" ")[0]));
      if (hostel) {
        hostel.currentlyOut = Math.max(0, hostel.currentlyOut - 1);
        if (pass.status === "overdue") {
          hostel.overdueCount = Math.max(0, hostel.overdueCount - 1);
        }
      }

      // Close open incident if any
      const incident = this.state.incidents.find((inc) => inc.passId === pass.id);
      if (incident) {
        incident.status = "RESOLVED";
        incident.actionsTaken.push({
          timestamp: nowIso,
          action: `Student returned via ${gateName} at ${new Date().toLocaleTimeString()}. Incident resolved.`,
          officer: officerName,
        });
      }

      // Instant Parent WhatsApp & SMS Dispatch
      this.addNotification({
        recipientRole: "parent",
        recipientName: pass.guardian.name,
        recipientPhone: pass.guardian.phone,
        channel: "WHATSAPP",
        title: "Campus Gate RETURN Notice",
        message: `Adithya Tech (AIT 2744): Your ward ${pass.studentName} has RETURNED safely inside campus through ${gateName} at ${new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}. Pass marked completed.`,
        passId: pass.id,
        passNumber: pass.passNumber,
        type: "ENTRY_RECORDED",
      });

      this.addAuditLog({
        actorName: officerName,
        actorRole: "guard",
        action: isLate ? "GATE_ENTRY_FLAGGED_LATE" : "GATE_ENTRY_VERIFIED",
        entityType: "GATE",
        entityId: pass.id,
        details: `Verified return of ${pass.studentName}. Status: ${isLate ? `LATE by ${overdueMinutes}m` : "ON-TIME"}. Parent WhatsApp dispatched.`,
      });

      this.saveState();
      return {
        success: true,
        movementType: "ENTRY",
        pass,
        isOverdue: isLate,
        overdueMinutes,
        message: isLate
          ? `Return verified, but FLAGGED LATE by ${overdueMinutes} mins. Late entry incident logged for Warden review.`
          : `Safe on-time return verified for ${pass.studentName}. Pass completed.`,
      };
    }

    if (pass.status === "completed") {
      throw new Error(`DUPLICATE_SCAN_REJECTED: Pass ${pass.passNumber} was already completed upon return at ${new Date(pass.actualEntryDateTime || '').toLocaleTimeString()}. Token expired.`);
    }

    throw new Error(`CONFLICT: Unhandled pass state '${pass.status}'. Please contact Hostel Administration.`);
  }

  // Request Return Deadline Extension
  public requestDeadlineExtension(
    passId: string,
    requestedNewTime: string,
    reason: string
  ): PassRequest {
    const pass = this.state.passes.find((p) => p.id === passId);
    if (!pass) throw new Error("Pass not found");

    const ext: ExtensionRequest = {
      id: `ext-${Date.now().toString(36)}`,
      passId,
      previousExpectedReturn: pass.expectedReturnDateTime,
      requestedReturn: requestedNewTime,
      reason,
      requestedAt: new Date().toISOString(),
      status: "pending",
    };

    pass.extensions.push(ext);

    this.addNotification({
      recipientRole: "warden",
      recipientName: "Chief Warden",
      channel: "IN_APP",
      title: "Deadline Extension Requested",
      message: `${pass.studentName} (${pass.rollNumber}) requested return extension until ${new Date(requestedNewTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}. Reason: ${reason}`,
      passId: pass.id,
      passNumber: pass.passNumber,
      type: "STAGE_APPROVED",
    });

    this.saveState();
    return pass;
  }

  public approveDeadlineExtension(passId: string, extensionId: string, officerName: string): PassRequest {
    const pass = this.state.passes.find((p) => p.id === passId);
    if (!pass) throw new Error("Pass not found");

    const ext = pass.extensions.find((e) => e.id === extensionId);
    if (ext) {
      ext.status = "approved";
      ext.reviewedBy = officerName;
      ext.reviewedAt = new Date().toISOString();
      pass.expectedReturnDateTime = ext.requestedReturn;
      if (pass.status === "overdue") {
        pass.status = "active_out";
      }
    }

    this.addNotification({
      recipientRole: "student",
      recipientName: pass.studentName,
      channel: "IN_APP",
      title: "Return Extension Approved",
      message: `Your return extension until ${new Date(pass.expectedReturnDateTime).toLocaleTimeString()} was approved by ${officerName}.`,
      passId: pass.id,
      passNumber: pass.passNumber,
      type: "STAGE_APPROVED",
    });

    this.saveState();
    return pass;
  }

  // Notification helper
  private addNotification(notif: Omit<NotificationPayload, "id" | "timestamp" | "read">): void {
    const id = `notif-${Date.now().toString(36)}-${Math.random().toString(36).substring(2, 6)}`;
    const full: NotificationPayload = {
      ...notif,
      id,
      timestamp: new Date().toISOString(),
      read: false,
    };
    this.state.notifications.unshift(full);
  }

  // Audit log helper
  private addAuditLog(log: Omit<AuditLogItem, "id" | "timestamp" | "ipAddress">): void {
    const id = `aud-${Date.now().toString(36)}-${Math.random().toString(36).substring(2, 6)}`;
    const full: AuditLogItem = {
      ...log,
      id,
      timestamp: new Date().toISOString(),
      ipAddress: "192.168.1." + Math.floor(20 + Math.random() * 80),
    };
    this.state.auditLogs.unshift(full);
  }

  public markNotificationRead(id: string): void {
    const notif = this.state.notifications.find((n) => n.id === id);
    if (notif) notif.read = true;
    this.saveState();
  }

  public markAllNotificationsRead(): void {
    this.state.notifications.forEach((n) => (n.read = true));
    this.saveState();
  }
}

export const campusStore = new CampusDataManager();
