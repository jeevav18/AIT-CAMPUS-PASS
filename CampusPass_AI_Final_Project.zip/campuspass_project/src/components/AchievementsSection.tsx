import React, { useState } from "react";
import {
  Trophy,
  Award,
  Users,
  Star,
  TrendingUp,
  GitPullRequest,
  Sparkles,
  Zap,
} from "lucide-react";
import { PORTFOLIO_DATA, AchievementItem } from "@/data/portfolioData";

export const AchievementsSection: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState<string>("All");

  const categories = [
    "All",
    "Hackathons",
    "Academic Achievements",
    "Leadership",
    "Technical Events",
    "Open Source",
  ];

  const filteredAchievements =
    activeCategory === "All"
      ? PORTFOLIO_DATA.achievements
      : PORTFOLIO_DATA.achievements.filter(
          (ach) => ach.category === activeCategory
        );

  const getCategoryIcon = (category: AchievementItem["category"]) => {
    switch (category) {
      case "Hackathons":
        return <Trophy className="w-5 h-5 text-amber-500" />;
      case "Academic Achievements":
        return <Award className="w-5 h-5 text-blue-500" />;
      case "Leadership":
        return <Users className="w-5 h-5 text-emerald-500" />;
      case "Technical Events":
        return <Zap className="w-5 h-5 text-purple-500" />;
      case "Open Source":
        return <GitPullRequest className="w-5 h-5 text-sky-500" />;
      default:
        return <Star className="w-5 h-5 text-amber-500" />;
    }
  };

  return (
    <section id="achievements" className="py-20 sm:py-28 bg-slate-50/60 dark:bg-[#0B1120] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-50 dark:bg-blue-950/60 border border-blue-200 dark:border-blue-800 text-blue-700 dark:text-blue-300 text-xs font-semibold uppercase tracking-wider mb-3">
            <span>Recognition & Honors</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            Honors, Hackathons & Milestones
          </h2>
          <p className="mt-3 text-base sm:text-lg text-slate-600 dark:text-slate-300">
            Proven track record of high-stakes technical innovation, national hackathon podiums, and leadership contributions.
          </p>
        </div>

        {/* Category Filters */}
        <div className="flex flex-wrap items-center justify-center gap-2 mb-12">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all cursor-pointer ${
                activeCategory === cat
                  ? "bg-blue-600 text-white shadow-md shadow-blue-600/20"
                  : "bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800"
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Achievements Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredAchievements.map((ach) => (
            <div
              key={ach.id}
              className="p-6 sm:p-7 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-2xs hover:shadow-lg transition-all duration-300 flex flex-col justify-between group"
            >
              <div className="space-y-4">
                <div className="flex items-start justify-between gap-3">
                  <div className="w-11 h-11 rounded-2xl bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white flex items-center justify-center shrink-0 border border-slate-200/80 dark:border-slate-700/80 shadow-2xs group-hover:scale-105 transition-transform">
                    {getCategoryIcon(ach.category)}
                  </div>

                  <span className="text-xs font-semibold px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 border border-slate-200/60 dark:border-slate-700/60">
                    {ach.year}
                  </span>
                </div>

                <div>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400">
                    {ach.category}
                  </span>
                  <h3 className="text-base font-bold text-slate-900 dark:text-white tracking-tight mt-0.5">
                    {ach.title}
                  </h3>
                  <p className="text-xs font-semibold text-slate-500 dark:text-slate-400 mt-0.5">
                    {ach.organization}
                  </p>
                </div>

                <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                  {ach.description}
                </p>
              </div>

              {ach.metrics && (
                <div className="pt-3.5 mt-4 border-t border-slate-100 dark:border-slate-800 flex items-center gap-2 text-xs font-semibold text-emerald-600 dark:text-emerald-400">
                  <TrendingUp className="w-4 h-4 shrink-0" />
                  <span>{ach.metrics}</span>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default AchievementsSection;
