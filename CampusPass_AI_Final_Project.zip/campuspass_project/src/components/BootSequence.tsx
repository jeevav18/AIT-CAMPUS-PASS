import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Terminal, Shield, Cpu, Lock, CheckCircle2, FastForward } from "lucide-react";
import { playKeyStroke, playAccessGranted, playTick } from "@/lib/cyberAudio";
import { PORTFOLIO_DATA } from "@/data/portfolioData";

interface BootSequenceProps {
  onComplete: () => void;
}

const steps = [
  { title: "Loading neural interface", detail: "Synchronizing sensory synaptic bus & WebGL buffer", icon: Cpu },
  { title: "Loading security modules", detail: "Mounting zero-trust encryption enclaves & firewalls", icon: Shield },
  { title: "Loading developer profile", detail: `Decrypting profile telemetry for ${PORTFOLIO_DATA.personal.name}`, icon: Terminal },
  { title: "Loading skill matrix", detail: "Synthesizing 3D interactive polyhedral skill cores", icon: Cpu },
  { title: "Loading project database", detail: "Querying production repositories & live blueprints", icon: Terminal },
  { title: "Establishing secure connection", detail: "E2EE TLS 1.3 cryptographic tunnel verified", icon: Lock },
];

const subLogs = [
  "[SYS] BIOS POST check OK (32768MB RAM, 16 Cores)",
  "[SEC] Initializing cryptographic hardware enclave...",
  "[NET] Routing uplink: 192.168.1.0/24 -> Gateway OK",
  `[PRF] Binding profile: ${PORTFOLIO_DATA.personal.name} (${PORTFOLIO_DATA.personal.title})`,
  "[DEF] Threat radar active: 0 anomalies detected",
  "[UI] Mounting 3D WebGL renderer & Holographic HUD...",
];

export const BootSequence = ({ onComplete }: BootSequenceProps) => {
  const [currentStep, setCurrentStep] = useState(0);
  const [progress, setProgress] = useState(0);
  const [diagnosticLogs, setDiagnosticLogs] = useState<string[]>([]);
  const [isAccessGranted, setIsAccessGranted] = useState(false);

  useEffect(() => {
    // Keyboard listener to skip boot on Escape or Space
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape" || e.key === " " || e.key === "Enter") {
        playAccessGranted();
        onComplete();
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [onComplete]);

  useEffect(() => {
    // Step progression timer
    const stepInterval = setInterval(() => {
      setCurrentStep((prev) => {
        if (prev < steps.length - 1) {
          playTick();
          return prev + 1;
        } else {
          clearInterval(stepInterval);
          setIsAccessGranted(true);
          playAccessGranted();
          setTimeout(() => {
            onComplete();
          }, 1200);
          return prev;
        }
      });
    }, 850);

    // Progress counter
    const progressInterval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(progressInterval);
          return 100;
        }
        playKeyStroke();
        return Math.min(prev + Math.floor(Math.random() * 8) + 4, 100);
      });
    }, 120);

    // Sub-logs stream
    let logIndex = 0;
    const logInterval = setInterval(() => {
      if (logIndex < subLogs.length) {
        setDiagnosticLogs((prev) => [...prev, subLogs[logIndex]]);
        logIndex++;
      } else {
        clearInterval(logInterval);
      }
    }, 450);

    return () => {
      clearInterval(stepInterval);
      clearInterval(progressInterval);
      clearInterval(logInterval);
    };
  }, [onComplete]);

  return (
    <div className="fixed inset-0 z-[100000] bg-[#020202] text-white flex flex-col items-center justify-center p-4 font-mono select-none overflow-hidden">
      {/* Background Matrix/Grid scanlines */}
      <div className="absolute inset-0 bg-scanlines opacity-10 pointer-events-none" />
      <div className="absolute inset-0 bg-grid opacity-10 pointer-events-none" />

      {/* Outer Holographic Frame */}
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.4 }}
        className="relative w-full max-w-2xl bg-black/90 border border-[#00FF66]/30 rounded-xl p-6 sm:p-8 shadow-[0_0_50px_rgba(0,255,102,0.15)] backdrop-blur-md"
      >
        {/* Terminal Header */}
        <div className="flex items-center justify-between border-b border-[#00FF66]/20 pb-4 mb-6">
          <div className="flex items-center space-x-2">
            <span className="w-3 h-3 rounded-full bg-red-500/80 animate-pulse" />
            <span className="w-3 h-3 rounded-full bg-yellow-500/80" />
            <span className="w-3 h-3 rounded-full bg-[#00FF66]/80" />
            <span className="text-xs text-[#00FF66] tracking-widest ml-2 font-bold font-oxanium">
              SYSTEM INITIALIZATION
            </span>
          </div>

          <button
            onClick={() => {
              playAccessGranted();
              onComplete();
            }}
            className="flex items-center space-x-1.5 px-2.5 py-1 rounded bg-[#00FF66]/10 hover:bg-[#00FF66]/20 border border-[#00FF66]/30 text-[#00FF66] text-[11px] font-bold uppercase transition duration-150 cursor-pointer"
          >
            <FastForward className="w-3.5 h-3.5" />
            <span>Skip Boot [ESC]</span>
          </button>
        </div>

        {/* 4 Core Steps Sequence */}
        <div className="space-y-4 mb-8">
          {steps.map((step, idx) => {
            const isFinished = idx < currentStep || (idx === 3 && isAccessGranted);
            const isCurrent = idx === currentStep && !isAccessGranted;
            const Icon = step.icon;

            return (
              <motion.div
                key={step.title}
                initial={{ opacity: 0, x: -10 }}
                animate={{
                  opacity: idx <= currentStep ? 1 : 0.25,
                  x: 0,
                }}
                className={`flex items-start space-x-3 p-2.5 rounded-lg border transition-all ${
                  isCurrent
                    ? "bg-[#00FF66]/10 border-[#00FF66] text-[#00FF66]"
                    : isFinished
                    ? "bg-black/40 border-[#00FF66]/20 text-gray-300"
                    : "border-transparent text-gray-600"
                }`}
              >
                <div className="mt-0.5">
                  {isFinished ? (
                    <CheckCircle2 className="w-5 h-5 text-[#00FF66]" />
                  ) : (
                    <Icon
                      className={`w-5 h-5 ${
                        isCurrent ? "text-[#00E5FF] animate-pulse" : "text-gray-600"
                      }`}
                    />
                  )}
                </div>

                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <span
                      className={`text-xs sm:text-sm font-bold tracking-wider ${
                        idx === 3 && isAccessGranted
                          ? "text-[#00FF66] text-glow-green text-base"
                          : isCurrent
                          ? "text-[#00E5FF]"
                          : isFinished
                          ? "text-white"
                          : "text-gray-500"
                      }`}
                    >
                      &gt; {step.title}
                    </span>
                    {isCurrent && (
                      <span className="text-[10px] bg-[#00FF66]/20 text-[#00FF66] px-2 py-0.5 rounded animate-pulse">
                        PROCESSING
                      </span>
                    )}
                    {isFinished && (
                      <span className="text-[10px] text-[#00FF66] font-bold">
                        [ OK ]
                      </span>
                    )}
                  </div>
                  <p className="text-[11px] text-gray-400 mt-0.5">{step.detail}</p>
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* Progress Bar */}
        <div className="space-y-2 mb-6">
          <div className="flex justify-between text-xs text-gray-400">
            <span className="text-[#00FF66] font-bold">SYSTEM LOAD INTEGRITY</span>
            <span>{progress}%</span>
          </div>
          <div className="w-full h-2 bg-black/60 border border-[#00FF66]/30 rounded-full overflow-hidden p-[1px]">
            <motion.div
              className="h-full bg-gradient-to-r from-[#00FF66] via-[#00E5FF] to-[#00FF66] rounded-full shadow-[0_0_10px_#00FF66]"
              style={{ width: `${progress}%` }}
              transition={{ ease: "linear" }}
            />
          </div>
        </div>

        {/* Live Diagnostics Log Feed */}
        <div className="bg-black/60 border border-zinc-800 rounded-lg p-3 text-[11px] font-mono text-gray-400 max-h-24 overflow-y-auto space-y-1 scrollbar-thin">
          <div className="text-[10px] text-gray-500 uppercase tracking-wider mb-1">
            // Diagnostic Stream Telemetry
          </div>
          {diagnosticLogs.map((log, i) => (
            <div key={i} className="text-gray-300">
              <span className="text-[#00FF66] mr-2">›</span>
              {log}
            </div>
          ))}
        </div>

        {/* ACCESS GRANTED Glowing Stamp Banner */}
        <AnimatePresence>
          {isAccessGranted && (
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-black/80 backdrop-blur-sm rounded-xl flex flex-col items-center justify-center space-y-3 z-20"
            >
              <div className="text-xs text-[#00E5FF] font-mono tracking-widest uppercase">
                ACCESS LEVEL:
              </div>
              <motion.div
                initial={{ scale: 2, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                className="px-6 py-3 border-2 border-[#00FF66] bg-[#00FF66]/15 rounded-lg text-[#00FF66] font-bebas text-3xl sm:text-4xl tracking-widest shadow-[0_0_30px_#00FF66] text-glow-green"
              >
                AUTHORIZED
              </motion.div>
              <p className="text-xs text-gray-300 font-mono tracking-wider animate-pulse">
                ENTERING CYBERSECURITY COMMAND CENTER...
              </p>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    </div>
  );
};
export default BootSequence;
