import { useState, useRef } from "react";
import { motion } from "framer-motion";
import { Minus, Square, Copy, X } from "lucide-react";
import { playTick, playHover } from "@/lib/cyberAudio";

interface OSWindowProps {
  id: string;
  title: string;
  icon: React.ComponentType<{ className?: string }>;
  isOpen: boolean;
  isMinimized: boolean;
  onClose: () => void;
  onMinimize: () => void;
  onFocus: () => void;
  zIndex: number;
  children: React.ReactNode;
}

const OSWindow = ({
  id,
  title,
  icon: Icon,
  isOpen,
  isMinimized,
  onClose,
  onMinimize,
  onFocus,
  zIndex,
  children,
}: OSWindowProps) => {
  const [isMaximized, setIsMaximized] = useState(false);
  const constraintsRef = useRef<HTMLDivElement>(null);

  if (!isOpen) return null;

  const handleTitleDoubleClick = () => {
    playTick();
    setIsMaximized(!isMaximized);
  };

  return (
    <motion.div
      drag={!isMaximized}
      dragMomentum={false}
      dragElastic={0.02}
      dragHandleClassName="window-titlebar"
      onPointerDown={onFocus}
      initial={
        isMaximized
          ? { opacity: 0, scale: 0.95, x: 0, y: 0 }
          : { opacity: 0, scale: 0.95, x: Math.random() * 80 + 30, y: Math.random() * 60 + 30 }
      }
      animate={
        isMinimized
          ? { opacity: 0, scale: 0.7, y: 400, pointerEvents: "none" }
          : isMaximized
          ? {
              opacity: 1,
              scale: 1,
              x: 0,
              y: 0,
              width: "100%",
              height: "calc(100vh - 48px)",
              top: 0,
              left: 0,
              transition: { duration: 0.25 },
            }
          : {
              opacity: 1,
              scale: 1,
              width: "min(90vw, 750px)",
              height: "500px",
              pointerEvents: "auto",
              transition: { duration: 0.2 },
            }
      }
      style={{
        zIndex,
        position: isMaximized ? "fixed" : "absolute",
      }}
      className={`flex flex-col bg-[#050505]/95 border border-[#00FF66]/20 rounded-lg shadow-[0_15px_40px_rgba(0,0,0,0.8)] backdrop-blur-md overflow-hidden font-mono ${
        isMaximized ? "" : "min-w-[320px] min-h-[250px]"
      }`}
    >
      {/* Dynamic scanline grid layer */}
      <div className="absolute inset-0 bg-grid opacity-[0.02] pointer-events-none" />

      {/* Title Bar (Draggable trigger) */}
      <div
        onDoubleClick={handleTitleDoubleClick}
        className="window-titlebar flex items-center justify-between px-3 py-2 bg-black border-b border-[#00FF66]/15 cursor-grab active:cursor-grabbing select-none"
      >
        <div className="flex items-center space-x-2 pointer-events-none">
          <Icon className="w-4 h-4 text-[#00FF66] animate-pulse" />
          <span className="text-xs font-bold text-[#00FF66] tracking-wider uppercase truncate max-w-[180px] md:max-w-none font-oxanium text-glow-green">
            {title}
          </span>
        </div>

        {/* Window action controls */}
        <div className="flex items-center space-x-1.5 z-20">
          {/* Minimize button */}
          <button
            onMouseEnter={playHover}
            onClick={(e) => {
              e.stopPropagation();
              playTick();
              onMinimize();
            }}
            className="p-1 rounded hover:bg-[#00FF66]/10 text-gray-400 hover:text-[#00FF66] transition-colors"
          >
            <Minus className="w-3.5 h-3.5" />
          </button>

          {/* Maximize button */}
          <button
            onMouseEnter={playHover}
            onClick={(e) => {
              e.stopPropagation();
              playTick();
              setIsMaximized(!isMaximized);
            }}
            className="p-1 rounded hover:bg-[#00FF66]/10 text-gray-400 hover:text-[#00FF66] transition-colors"
          >
            {isMaximized ? <Copy className="w-3.5 h-3.5" /> : <Square className="w-3.5 h-3.5" />}
          </button>

          {/* Close button */}
          <button
            onMouseEnter={playHover}
            onClick={(e) => {
              e.stopPropagation();
              playTick();
              onClose();
            }}
            className="p-1 rounded hover:bg-red-500/20 text-gray-400 hover:text-red-500 transition-colors"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Main Window Client Workspace Area */}
      <div className="flex-1 overflow-y-auto scrollbar-thin text-white p-4 relative bg-[#060606]/90 select-text">
        {children}
      </div>
    </motion.div>
  );
};

export default OSWindow;
