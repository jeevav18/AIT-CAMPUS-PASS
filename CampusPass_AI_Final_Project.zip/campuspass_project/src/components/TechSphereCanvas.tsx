import React, { useRef, useEffect } from "react";

interface TechNode {
  name: string;
  category: string;
  color: string;
  theta: number;
  phi: number;
  radius: number;
}

export const TechSphereCanvas: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animationFrameId: number;
    let width = (canvas.width = canvas.parentElement?.clientWidth || 400);
    let height = (canvas.height = 360);

    const handleResize = () => {
      if (!canvas.parentElement) return;
      width = canvas.width = canvas.parentElement.clientWidth;
      height = canvas.height = 360;
    };

    window.addEventListener("resize", handleResize);

    const skills: { name: string; category: string; color: string }[] = [
      { name: "React", category: "Frontend", color: "#06B6D4" },
      { name: "TypeScript", category: "Language", color: "#2563EB" },
      { name: "Node.js", category: "Backend", color: "#16A34A" },
      { name: "Python", category: "Backend", color: "#3B82F6" },
      { name: "Next.js", category: "Frontend", color: "#475569" },
      { name: "PostgreSQL", category: "Database", color: "#3B82F6" },
      { name: "AWS Cloud", category: "Cloud", color: "#F97316" },
      { name: "Salesforce", category: "Enterprise", color: "#0284C7" },
      { name: "Docker", category: "DevOps", color: "#0EA5E9" },
      { name: "OWASP Sec", category: "Security", color: "#10B981" },
      { name: "FastAPI", category: "Backend", color: "#059669" },
      { name: "Tailwind CSS", category: "UI", color: "#38BDF8" },
      { name: "REST APIs", category: "API", color: "#6366F1" },
      { name: "Git CI/CD", category: "DevOps", color: "#EA580C" },
    ];

    const nodes: TechNode[] = skills.map((skill, index) => {
      const phi = Math.acos(-1 + (2 * index) / skills.length);
      const theta = Math.sqrt(skills.length * Math.PI) * phi;
      return {
        ...skill,
        theta,
        phi,
        radius: 130,
      };
    });

    let rotX = 0;
    let rotY = 0;
    let mouseX = 0;
    let mouseY = 0;
    let targetRotX = 0.003;
    let targetRotY = 0.003;

    const onMouseMove = (e: MouseEvent) => {
      const rect = canvas.getBoundingClientRect();
      mouseX = (e.clientX - rect.left - width / 2) * 0.00008;
      mouseY = (e.clientY - rect.top - height / 2) * 0.00008;
      targetRotX = mouseY;
      targetRotY = mouseX;
    };

    canvas.addEventListener("mousemove", onMouseMove);

    const render = () => {
      ctx.clearRect(0, 0, width, height);

      rotX += (targetRotX - rotX) * 0.1 + 0.002;
      rotY += (targetRotY - rotY) * 0.1 + 0.003;

      const centerX = width / 2;
      const centerY = height / 2;

      // Draw subtle background orbital rings
      ctx.save();
      ctx.strokeStyle = "rgba(37, 99, 235, 0.08)";
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.ellipse(centerX, centerY, 130, 60, rotY * 0.5, 0, Math.PI * 2);
      ctx.stroke();

      ctx.beginPath();
      ctx.ellipse(centerX, centerY, 130, 60, -rotY * 0.5, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();

      // Transform nodes in 3D
      const projectedNodes = nodes.map((node) => {
        // Rotate in 3D
        const x = node.radius * Math.sin(node.phi) * Math.cos(node.theta + rotY);
        let y = node.radius * Math.sin(node.phi) * Math.sin(node.theta + rotY);
        let z = node.radius * Math.cos(node.phi);

        // Apply X rotation
        const y1 = y * Math.cos(rotX) - z * Math.sin(rotX);
        const z1 = y * Math.sin(rotX) + z * Math.cos(rotX);
        y = y1;
        z = z1;

        // Perspective projection
        const scale = 300 / (300 + z);
        const projX = centerX + x * scale;
        const projY = centerY + y * scale;
        const alpha = Math.max(0.2, (z + node.radius) / (2 * node.radius));

        return {
          ...node,
          projX,
          projY,
          scale,
          z,
          alpha,
        };
      });

      // Sort by Z for proper depth
      projectedNodes.sort((a, b) => a.z - b.z);

      // Connect nodes with subtle lines
      ctx.save();
      for (let i = 0; i < projectedNodes.length; i++) {
        for (let j = i + 1; j < projectedNodes.length; j++) {
          const dx = projectedNodes[i].projX - projectedNodes[j].projX;
          const dy = projectedNodes[i].projY - projectedNodes[j].projY;
          const dist = Math.sqrt(dx * dx + dy * dy);

          if (dist < 85) {
            ctx.strokeStyle = `rgba(37, 99, 235, ${0.12 * Math.min(projectedNodes[i].alpha, projectedNodes[j].alpha)})`;
            ctx.lineWidth = 0.75;
            ctx.beginPath();
            ctx.moveTo(projectedNodes[i].projX, projectedNodes[i].projY);
            ctx.lineTo(projectedNodes[j].projX, projectedNodes[j].projY);
            ctx.stroke();
          }
        }
      }
      ctx.restore();

      // Draw nodes
      projectedNodes.forEach((node) => {
        const size = Math.max(3, 4.5 * node.scale);

        // Outer glow dot
        ctx.beginPath();
        ctx.arc(node.projX, node.projY, size, 0, Math.PI * 2);
        ctx.fillStyle = node.color;
        ctx.globalAlpha = node.alpha * 0.9;
        ctx.fill();

        // Label Tag
        const fontSize = Math.max(9, Math.round(11 * node.scale));
        ctx.font = `600 ${fontSize}px "Plus Jakarta Sans", sans-serif`;
        ctx.fillStyle = "#1E293B";
        
        // Draw pill background
        const textWidth = ctx.measureText(node.name).width;
        const paddingX = 6 * node.scale;
        const paddingY = 3 * node.scale;

        ctx.save();
        ctx.fillStyle = `rgba(255, 255, 255, ${node.alpha * 0.85})`;
        ctx.strokeStyle = `rgba(203, 213, 225, ${node.alpha * 0.8})`;
        ctx.lineWidth = 0.75;
        
        const pillX = node.projX + 8;
        const pillY = node.projY - fontSize / 2 - paddingY;
        const pillW = textWidth + paddingX * 2;
        const pillH = fontSize + paddingY * 2;

        ctx.beginPath();
        ctx.roundRect(pillX, pillY, pillW, pillH, 4);
        ctx.fill();
        ctx.stroke();

        ctx.fillStyle = `rgba(15, 23, 42, ${node.alpha})`;
        ctx.fillText(node.name, pillX + paddingX, pillY + fontSize);
        ctx.restore();
      });

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      window.removeEventListener("resize", handleResize);
      canvas.removeEventListener("mousemove", onMouseMove);
      cancelAnimationFrame(animationFrameId);
    };
  }, []);

  return (
    <div className="w-full flex flex-col items-center justify-center relative p-2">
      <canvas ref={canvasRef} className="w-full max-w-lg cursor-grab active:cursor-grabbing" />
      <p className="text-[11px] text-slate-400 dark:text-slate-500 font-medium text-center mt-1">
        Interactive 3D Technology Mesh • Move cursor to rotate
      </p>
    </div>
  );
};

export default TechSphereCanvas;
