import React, { useState, useEffect } from "react";
import { campusStore } from "@/services/campusData";
import { UserRole, PassRequest, CreatePassInput } from "@/types/campuspass";
import { Navbar } from "@/components/campus/Navbar";
import { RoleSwitcher } from "@/components/campus/RoleSwitcher";
import { LandingView } from "@/components/campus/LandingView";
import { StudentDashboard } from "@/components/campus/StudentDashboard";
import { ParentPortal } from "@/components/campus/ParentPortal";
import { TutorDashboard } from "@/components/campus/TutorDashboard";
import { HodDashboard } from "@/components/campus/HodDashboard";
import { WardenDashboard } from "@/components/campus/WardenDashboard";
import { PrincipalDashboard } from "@/components/campus/PrincipalDashboard";
import { GateSecurityDashboard } from "@/components/campus/GateSecurityDashboard";
import { LateReturnAlertCenter } from "@/components/campus/LateReturnAlertCenter";
import { NotificationDrawer } from "@/components/campus/NotificationDrawer";
import { AIAssistantDrawer } from "@/components/campus/AIAssistantDrawer";
import { AuditLogModal } from "@/components/campus/AuditLogModal";
import { InstitutionalDirectoryModal } from "@/components/campus/InstitutionalDirectoryModal";
import { PaperPassPreviewView } from "@/components/campus/PaperPassPreviewView";
import { toast } from "sonner";

interface IndexProps {
  initialView?: string;
}

export const Index: React.FC<IndexProps> = ({ initialView }) => {
  // Pull persistent state from store
  const [storeState, setStoreState] = useState(() => campusStore.getState());
  const [activeView, setActiveView] = useState<string>(() => {
    try {
      if (typeof window !== "undefined") {
        const params = new URLSearchParams(window.location.search);
        const queryView = params.get("view");
        if (queryView) return queryView;
        const path = window.location.pathname.toLowerCase();
        if (path.includes("paper") || path.includes("slip") || path.includes("preview")) {
          return "paper_pass";
        }
      }
    } catch {
      // ignore
    }
    return initialView || "dashboard";
  });
  const [initialScannerToken, setInitialScannerToken] = useState<string>("");

  // Modals & Drawers state
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [isAiAssistantOpen, setIsAiAssistantOpen] = useState(false);
  const [isAuditLogsOpen, setIsAuditLogsOpen] = useState(false);
  const [isDirectoryOpen, setIsDirectoryOpen] = useState(false);

  // Sync state helper
  const syncState = () => {
    setStoreState({ ...campusStore.getState() });
  };

  const currentRole = storeState.currentRole;
  const currentStudent = storeState.students.find((s) => s.id === storeState.selectedStudentId) || storeState.students[0];
  const unreadCount = storeState.notifications.filter((n) => !n.read).length;

  const handleSelectRole = (role: UserRole) => {
    campusStore.setRole(role);
    syncState();
    setActiveView("dashboard");
  };

  const handleResetData = () => {
    campusStore.resetToSeed();
    syncState();
    toast.success("Demo state reset to original institutional seed.");
  };

  // Pass actions
  const handleApplyPass = (passData: CreatePassInput) => {
    campusStore.createPass(passData);
    syncState();
    toast.success("Pass application created and routed to Class Tutor.");
  };

  const handleTutorApprove = (
    passId: string,
    remarks: string,
    extra?: { parentContacted?: boolean; parentContactDetails?: string }
  ) => {
    campusStore.approveStage(passId, "tutor", currentStudent.tutorName, "stf-tut-01", remarks, extra);
    syncState();
  };

  const handleTutorReject = (passId: string, reason: string) => {
    campusStore.rejectStage(passId, "tutor", currentStudent.tutorName, reason);
    syncState();
  };

  const handleHodApprove = (passId: string, remarks: string) => {
    campusStore.approveStage(passId, "hod", currentStudent.hodName, "stf-hod-01", remarks);
    syncState();
  };

  const handleHodReject = (passId: string, reason: string) => {
    campusStore.rejectStage(passId, "hod", currentStudent.hodName, reason);
    syncState();
  };

  const handleWardenApprove = (passId: string, remarks: string) => {
    campusStore.approveStage(passId, "warden", currentStudent.wardenName, "stf-war-01", remarks);
    syncState();
  };

  const handleWardenReject = (passId: string, reason: string) => {
    campusStore.rejectStage(passId, "warden", currentStudent.wardenName, reason);
    syncState();
  };

  const handleWardenApproveExtension = (passId: string, extId: string) => {
    campusStore.approveDeadlineExtension(passId, extId, currentStudent.wardenName);
    syncState();
    toast.success("Return deadline extension approved.");
  };

  const handlePrincipalBypass = (passId: string, remarks: string) => {
    campusStore.approveStage(passId, "principal", "Dr. K. Ramanathan (Principal)", "stf-prin-01", remarks);
    syncState();
  };

  const handleRecordParentConsent = (
    passId: string,
    consent: "consented" | "rejected",
    notes: string,
    parentName: string
  ) => {
    campusStore.recordParentConsent(passId, consent, notes, parentName);
    syncState();
  };

  const handleRequestExtension = (passId: string, newTime: string, reason: string) => {
    campusStore.requestDeadlineExtension(passId, newTime, reason);
    syncState();
  };

  const handleVerifyGateScan = (token: string, gateId: string, gateName: string) => {
    const res = campusStore.verifyAndProcessGateScan(
      token,
      gateId,
      gateName,
      "Havaldar R. Murugesan",
      "sec-01"
    );
    syncState();
    return res;
  };

  const handleNavigateToScanner = (token: string) => {
    setInitialScannerToken(token);
    campusStore.setRole("guard");
    syncState();
    setActiveView("dashboard");
    toast.info("Switched to Gate Security Scanner Station.");
  };

  const handleMarkAllNotificationsRead = () => {
    campusStore.markAllNotificationsRead();
    syncState();
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-sans dark:bg-slate-950 dark:text-slate-100">
      
      {/* Institutional Top Navbar */}
      <Navbar
        currentRole={currentRole}
        unreadCount={unreadCount}
        onOpenNotifications={() => setIsNotificationsOpen(true)}
        onOpenAiAssistant={() => setIsAiAssistantOpen(true)}
        onOpenAuditLogs={() => setIsAuditLogsOpen(true)}
        onOpenDirectory={() => setIsDirectoryOpen(true)}
        onResetData={handleResetData}
        activeView={activeView}
        setActiveView={setActiveView}
      />

      {/* Instant Persona Switcher Bar */}
      <RoleSwitcher
        currentRole={currentRole}
        onSelectRole={handleSelectRole}
        passes={storeState.passes}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {activeView === "landing" ? (
          <LandingView
            onSelectRole={handleSelectRole}
            onGoToDashboard={() => setActiveView("dashboard")}
            onOpenDirectory={() => setIsDirectoryOpen(true)}
            onOpenPaperPass={() => setActiveView("paper_pass")}
          />
        ) : activeView === "paper_pass" ? (
          <PaperPassPreviewView
            passes={storeState.passes}
            onNavigateToScanner={handleNavigateToScanner}
          />
        ) : activeView === "overdue" ? (
          <LateReturnAlertCenter
            incidents={storeState.incidents}
            passes={storeState.passes}
          />
        ) : (
          /* Role Dashboard Router */
          <>
            {currentRole === "student" && (
              <StudentDashboard
                student={currentStudent}
                passes={storeState.passes}
                onApplyPass={handleApplyPass}
                onRequestExtension={handleRequestExtension}
                onNavigateToScanner={handleNavigateToScanner}
              />
            )}

            {currentRole === "parent" && (
              <ParentPortal
                student={currentStudent}
                passes={storeState.passes}
                onRecordConsent={handleRecordParentConsent}
              />
            )}

            {currentRole === "tutor" && (
              <TutorDashboard
                tutorName={currentStudent.tutorName}
                passes={storeState.passes}
                students={storeState.students}
                onApprove={handleTutorApprove}
                onReject={handleTutorReject}
              />
            )}

            {currentRole === "hod" && (
              <HodDashboard
                hodName={currentStudent.hodName}
                passes={storeState.passes}
                onApprove={handleHodApprove}
                onReject={handleHodReject}
              />
            )}

            {currentRole === "warden" && (
              <WardenDashboard
                wardenName={currentStudent.wardenName}
                passes={storeState.passes}
                hostels={storeState.hostels}
                onApprove={handleWardenApprove}
                onReject={handleWardenReject}
                onApproveExtension={handleWardenApproveExtension}
                onNavigateToScanner={handleNavigateToScanner}
              />
            )}

            {currentRole === "principal" && (
              <PrincipalDashboard
                principalName="Dr. K. Ramanathan, Ph.D."
                passes={storeState.passes}
                hostels={storeState.hostels}
                incidents={storeState.incidents}
                onBypassApprove={handlePrincipalBypass}
              />
            )}

            {currentRole === "guard" && (
              <GateSecurityDashboard
                guardName="Havaldar R. Murugesan"
                passes={storeState.passes}
                onVerifyScan={handleVerifyGateScan}
                initialScannedToken={initialScannerToken}
              />
            )}
          </>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-200 bg-white py-6 text-center text-xs text-slate-500 dark:bg-slate-900 dark:border-slate-800 dark:text-slate-400">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <p>© 2026 Adithya Institute of Technology (Kurumbapalayam, Coimbatore • TNEA Code: 2744) — CampusPass AI Platform.</p>
          <div className="flex items-center gap-4">
            <span>Parent WhatsApp Gateway Active</span>
            <span>•</span>
            <span>24/7 Security Gate Control</span>
            <span>•</span>
            <span>Gemini AI Policy Auditor</span>
          </div>
        </div>
      </footer>

      {/* Slide-over Drawers & Modals */}
      <NotificationDrawer
        isOpen={isNotificationsOpen}
        onClose={() => setIsNotificationsOpen(false)}
        notifications={storeState.notifications}
        onMarkAllRead={handleMarkAllNotificationsRead}
      />

      <AIAssistantDrawer
        isOpen={isAiAssistantOpen}
        onClose={() => setIsAiAssistantOpen(false)}
      />

      <AuditLogModal
        isOpen={isAuditLogsOpen}
        onClose={() => setIsAuditLogsOpen(false)}
        logs={storeState.auditLogs}
      />

      <InstitutionalDirectoryModal
        isOpen={isDirectoryOpen}
        onClose={() => setIsDirectoryOpen(false)}
      />

    </div>
  );
};

export default Index;
