import { useState } from "react";
import { motion } from "framer-motion";
import { Mail, Send, Linkedin, Github, Award, Terminal, Shield, MessageSquare, Phone } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { z } from "zod";
import TerminalWidget from "./TerminalWidget";

const contactSchema = z.object({
  name: z.string().trim().min(1, "Name is required").max(100),
  email: z.string().trim().email("Invalid email address").max(255),
  message: z.string().trim().min(1, "Message is required").max(1000),
});

const Contact = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: "",
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const socialLinks = [
    {
      icon: Linkedin,
      href: "https://linkedin.com/in/jeeva-v-b519a3305",
      label: "LinkedIn",
      color: "hover:text-[#00E5FF] hover:border-[#00E5FF]/40"
    },
    {
      icon: Github,
      href: "https://github.com/jeevav18",
      label: "GitHub",
      color: "hover:text-[#00FF66] hover:border-[#00FF66]/40"
    },
    {
      icon: Award,
      href: "https://unstop.com/u/xlkdungt61346",
      label: "Unstop",
      color: "hover:text-[#FFC107] hover:border-[#FFC107]/40"
    },
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      const validatedData = contactSchema.parse(formData);
      setIsSubmitting(true);

      const { error } = await supabase.from("messages").insert([{
        name: validatedData.name,
        email: validatedData.email,
        message: validatedData.message,
      }]);

      if (error) throw error;

      toast.success("Packet received! Your transmission has been securely saved to DB.");
      setFormData({ name: "", email: "", message: "" });
    } catch (error) {
      if (error instanceof z.ZodError) {
        toast.error(error.errors[0].message);
      } else {
        toast.error("Packet delivery failed. Please retry transmission.");
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    setFormData((prev) => ({
      ...prev,
      [e.target.name]: e.target.value,
    }));
  };

  return (
    <section id="contact" className="py-24 px-4 relative">
      <div className="container mx-auto max-w-6xl relative z-10 space-y-16">
        {/* Section Heading */}
        <motion.div
          initial={{ y: 30, opacity: 0 }}
          whileInView={{ y: 0, opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center"
        >
          <h2 className="text-3xl md:text-5xl font-bold font-oxanium text-white tracking-widest uppercase text-glow-green">
            [ CONTACT_PORTAL ]
          </h2>
          <div className="w-24 h-1 bg-[#00FF66] mx-auto mt-3 rounded-full shadow-[0_0_10px_#00FF66]" />
        </motion.div>

        {/* Dual Mode Panel: Left Form, Right Terminal */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start font-mono">
          
          {/* Left Side: Secure Transmission Form */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="lg:col-span-5 bg-[#080808]/90 border border-[#00FF66]/20 rounded-xl overflow-hidden p-6 md:p-8 space-y-6"
          >
            {/* Header tag */}
            <div className="flex items-center space-x-2 border-b border-[#00FF66]/10 pb-4">
              <MessageSquare className="w-5 h-5 text-[#00FF66]" />
              <h3 className="text-sm font-bold text-white uppercase tracking-wider">SECURE_COMM_FORM</h3>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4 text-xs md:text-sm">
              <div className="space-y-1">
                <label className="text-[10px] text-gray-500 font-bold uppercase">SENDER_NAME:</label>
                <input
                  name="name"
                  placeholder="Enter Name..."
                  value={formData.name}
                  onChange={handleChange}
                  required
                  maxLength={100}
                  className="w-full bg-black/60 border border-[#00FF66]/20 focus:border-[#00FF66] focus:ring-1 focus:ring-[#00FF66]/20 rounded-lg p-3 text-white placeholder-gray-600 outline-none transition-all duration-200"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] text-gray-500 font-bold uppercase">SENDER_EMAIL:</label>
                <input
                  name="email"
                  type="email"
                  placeholder="Enter Email..."
                  value={formData.email}
                  onChange={handleChange}
                  required
                  maxLength={255}
                  className="w-full bg-black/60 border border-[#00FF66]/20 focus:border-[#00FF66] focus:ring-1 focus:ring-[#00FF66]/20 rounded-lg p-3 text-white placeholder-gray-600 outline-none transition-all duration-200"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] text-gray-500 font-bold uppercase">MESSAGE_BODY:</label>
                <textarea
                  name="message"
                  placeholder="Write message details..."
                  value={formData.message}
                  onChange={handleChange}
                  required
                  maxLength={1000}
                  rows={5}
                  className="w-full bg-black/60 border border-[#00FF66]/20 focus:border-[#00FF66] focus:ring-1 focus:ring-[#00FF66]/20 rounded-lg p-3 text-white placeholder-gray-600 outline-none resize-none transition-all duration-200"
                />
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full font-oxanium font-bold uppercase tracking-wider text-sm p-3.5 border border-[#00FF66] bg-[#00FF66]/15 text-[#00FF66] hover:bg-[#00FF66] hover:text-black transition-all duration-300 rounded-lg flex items-center justify-center space-x-2 cursor-pointer shadow-[0_0_15px_rgba(0,255,102,0.1)]"
              >
                {isSubmitting ? (
                  <span>TRANSMITTING...</span>
                ) : (
                  <>
                    <Send className="w-4.5 h-4.5" />
                    <span>TRANSMIT PACKET</span>
                  </>
                )}
              </button>
            </form>

            {/* Quick Hotline Direct Links */}
            <div className="border-t border-[#00FF66]/10 pt-4 flex flex-col space-y-2.5 text-[11px] text-[#00FF66]">
              <a href="mailto:gopiiniyavan@gmail.com" className="hover:underline flex items-center space-x-2">
                <Mail className="w-4 h-4 text-[#00FF66]/60" />
                <span>EMAIL: gopiiniyavan@gmail.com</span>
              </a>
              <a href="tel:+919442050959" className="hover:underline flex items-center space-x-2">
                <Phone className="w-4 h-4 text-[#00FF66]/60" />
                <span>TEL: +91 9442050959</span>
              </a>
            </div>

            {/* Social connections */}
            <div className="pt-2 flex items-center justify-center space-x-4">
              {socialLinks.map((link, idx) => (
                <a
                  key={idx}
                  href={link.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={`p-2.5 bg-black border border-[#00FF66]/10 rounded-full transition-all duration-300 ${link.color}`}
                  aria-label={link.label}
                >
                  <link.icon className="w-5 h-5" />
                </a>
              ))}
            </div>
          </motion.div>

          {/* Right Side: OS Interactive Terminal Sandbox */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="lg:col-span-7"
          >
            <TerminalWidget />
          </motion.div>
          
        </div>
      </div>
    </section>
  );
};

export default Contact;
