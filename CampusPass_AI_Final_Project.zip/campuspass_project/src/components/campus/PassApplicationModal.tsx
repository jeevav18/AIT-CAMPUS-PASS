import React, { useState } from "react";
import { StudentProfile, PassType, CreatePassInput } from "@/types/campuspass";
import { 
  X, 
  Sparkles, 
  Calendar, 
  MapPin, 
  ShieldAlert, 
  CheckCircle, 
  AlertCircle, 
  PhoneCall, 
  HeartHandshake,
  Send
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { analyzePassRequestAI } from "@/services/geminiService";
import { toast } from "sonner";

interface PassApplicationModalProps {
  student: StudentProfile;
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (passData: CreatePassInput) => void;
}

export const PassApplicationModal: React.FC<PassApplicationModalProps> = ({
  student,
  isOpen,
  onClose,
  onSubmit,
}) => {
  const [passType, setPassType] = useState<PassType>("outing");
  
  // Default departure today + 1 hour, return + 4 hours
  const now = new Date();
  const formatDateTimeInput = (d: Date) => {
    return new Date(d.getTime() - d.getTimezoneOffset() * 60000)
      .toISOString()
      .slice(0, 16);
  };

  const defaultDep = new Date(now.getTime() + 60 * 60 * 1000);
  const defaultRet = new Date(now.getTime() + 4 * 60 * 60 * 1000);

  const [departureDateTime, setDepartureDateTime] = useState(formatDateTimeInput(defaultDep));
  const [expectedReturnDateTime, setExpectedReturnDateTime] = useState(formatDateTimeInput(defaultRet));
  const [destination, setDestination] = useState("");
  const [reason, setReason] = useState("");
  const [transportMode, setTransportMode] = useState("College Bus / Public Transit");
  const [destinationContact, setDestinationContact] = useState(student.phone);

  const [isAuditingAI, setIsAuditingAI] = useState(false);
  const [aiResult, setAiResult] = useState<{
    riskScore: 'LOW' | 'MEDIUM' | 'HIGH';
    riskSummary: string;
    missingInfoAlerts: string[];
    policyCompliance: boolean;
    recommendation: string;
  } | null>(null);

  if (!isOpen) return null;

  const handleRunAiAudit = async () => {
    if (!destination || !reason) {
      toast.error("Please fill in destination and reason before running AI audit.");
      return;
    }

    setIsAuditingAI(true);
    try {
      const result = await analyzePassRequestAI(
        {
          passType,
          destination,
          reason,
          departureDateTime,
          expectedReturnDateTime,
          guardian: student.guardian,
        },
        student
      );
      setAiResult(result);
      if (result.riskScore === "LOW") {
        toast.success("AI Audit: Application compliant with safety policy.");
      } else {
        toast.warning("AI Audit: Review recommended suggestions.");
      }
    } catch (e) {
      toast.error("AI check error");
    } finally {
      setIsAuditingAI(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!destination.trim()) {
      toast.error("Destination is required.");
      return;
    }
    if (!reason.trim()) {
      toast.error("Reason is required.");
      return;
    }

    const payload = {
      passType,
      studentId: student.id,
      studentName: student.name,
      rollNumber: student.rollNumber,
      department: student.department,
      year: student.year,
      hostelBlock: student.hostelBlock,
      roomNumber: student.roomNumber,
      avatarUrl: student.avatarUrl,
      studentPhone: student.phone,
      departureDateTime: new Date(departureDateTime).toISOString(),
      expectedReturnDateTime: new Date(expectedReturnDateTime).toISOString(),
      destination,
      reason,
      transportMode,
      destinationContact,
      guardian: student.guardian,
      parentConsentStatus: passType === "home_pass" ? "pending" : "not_requested",
      parentConsentNotes: passType === "home_pass" ? "Automated WhatsApp consent dispatched to parent." : undefined,
      aiAnalysis: aiResult || {
        riskScore: "LOW",
        riskSummary: "Self-certified student pass application within institutional norms.",
        missingInfoAlerts: [],
        policyCompliance: true,
        recommendation: "APPROVE",
      },
    };

    onSubmit(payload);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-white rounded-2xl max-w-xl w-full max-h-[90vh] overflow-y-auto shadow-2xl border border-slate-200 dark:bg-slate-900 dark:border-slate-800">
        
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-slate-100 dark:border-slate-800">
          <div>
            <h3 className="font-bold text-lg text-slate-900 dark:text-white">
              Apply for Hostel Outing / Home Pass
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Multi-tier approval: Tutor → HOD → Warden → Gate QR Issuance
            </p>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 rounded-lg p-1.5 hover:bg-slate-100 dark:hover:bg-slate-800"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 space-y-4">
          
          {/* Pass Type Selector */}
          <div>
            <label className="text-xs font-semibold text-slate-700 block mb-1.5 dark:text-slate-300">
              Select Pass Category
            </label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setPassType("outing")}
                className={`py-2 px-3 rounded-xl text-xs font-semibold border text-center transition-all ${
                  passType === "outing"
                    ? "bg-blue-50 border-blue-600 text-blue-700 dark:bg-blue-950/40 dark:text-blue-300"
                    : "bg-white border-slate-200 text-slate-700 hover:bg-slate-50 dark:bg-slate-800 dark:border-slate-700 dark:text-slate-300"
                }`}
              >
                City Outing (Day)
              </button>
              <button
                type="button"
                onClick={() => setPassType("home_pass")}
                className={`py-2 px-3 rounded-xl text-xs font-semibold border text-center transition-all ${
                  passType === "home_pass"
                    ? "bg-blue-50 border-blue-600 text-blue-700 dark:bg-blue-950/40 dark:text-blue-300"
                    : "bg-white border-slate-200 text-slate-700 hover:bg-slate-50 dark:bg-slate-800 dark:border-slate-700 dark:text-slate-300"
                }`}
              >
                Home Pass (Leave)
              </button>
              <button
                type="button"
                onClick={() => setPassType("emergency_medical")}
                className={`py-2 px-3 rounded-xl text-xs font-semibold border text-center transition-all ${
                  passType === "emergency_medical"
                    ? "bg-rose-50 border-rose-600 text-rose-700 dark:bg-rose-950/40 dark:text-rose-300"
                    : "bg-white border-slate-200 text-slate-700 hover:bg-slate-50 dark:bg-slate-800 dark:border-slate-700 dark:text-slate-300"
                }`}
              >
                Medical Emergency
              </button>
            </div>
          </div>

          {/* Timing Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-semibold text-slate-700 block mb-1 dark:text-slate-300">
                Departure Date & Time
              </label>
              <input
                type="datetime-local"
                value={departureDateTime}
                onChange={(e) => setDepartureDateTime(e.target.value)}
                required
                className="w-full text-xs px-3 py-2 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white dark:bg-slate-800 dark:border-slate-700 dark:text-white"
              />
            </div>
            <div>
              <label className="text-xs font-semibold text-slate-700 block mb-1 dark:text-slate-300">
                Expected Return (Curfew Strict)
              </label>
              <input
                type="datetime-local"
                value={expectedReturnDateTime}
                onChange={(e) => setExpectedReturnDateTime(e.target.value)}
                required
                className="w-full text-xs px-3 py-2 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white dark:bg-slate-800 dark:border-slate-700 dark:text-white"
              />
              <span className="text-[10px] text-slate-400 mt-0.5 block">
                Standard weekday return cutoff: 19:30 HRS
              </span>
            </div>
          </div>

          {/* Destination */}
          <div>
            <label className="text-xs font-semibold text-slate-700 block mb-1 dark:text-slate-300">
              Specific Destination & Landmark
            </label>
            <input
              type="text"
              placeholder="e.g. Cross Cut Road, Gandhipuram OR Hometown Address"
              value={destination}
              onChange={(e) => setDestination(e.target.value)}
              required
              className="w-full text-xs px-3 py-2 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white dark:bg-slate-800 dark:border-slate-700 dark:text-white"
            />
          </div>

          {/* Reason */}
          <div>
            <label className="text-xs font-semibold text-slate-700 block mb-1 dark:text-slate-300">
              Detailed Reason / Purpose
            </label>
            <textarea
              rows={3}
              placeholder="Provide specific details (e.g. Purchase of lab components for robotics project, medical visit, cousin wedding)"
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              required
              className="w-full text-xs px-3 py-2 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white dark:bg-slate-800 dark:border-slate-700 dark:text-white"
            />
          </div>

          {/* Transport & Emergency Contact */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-semibold text-slate-700 block mb-1 dark:text-slate-300">
                Mode of Travel
              </label>
              <select
                value={transportMode}
                onChange={(e) => setTransportMode(e.target.value)}
                className="w-full text-xs px-3 py-2 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white dark:bg-slate-800 dark:border-slate-700 dark:text-white"
              >
                <option>College Bus / Public Transit</option>
                <option>Auto / Call Taxi (Ola/Uber)</option>
                <option>Personal Two-Wheeler</option>
                <option>Parent Escort / Family Car</option>
                <option>Train / Inter-city Bus</option>
              </select>
            </div>
            <div>
              <label className="text-xs font-semibold text-slate-700 block mb-1 dark:text-slate-300">
                Contact Phone During Outing
              </label>
              <input
                type="text"
                value={destinationContact}
                onChange={(e) => setDestinationContact(e.target.value)}
                className="w-full text-xs px-3 py-2 rounded-lg border border-slate-200 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white dark:bg-slate-800 dark:border-slate-700 dark:text-white"
              />
            </div>
          </div>

          {/* Parent Guardian Notice Card */}
          <div className="p-3 bg-teal-50 border border-teal-200 rounded-xl text-teal-900 text-xs dark:bg-teal-950/30 dark:border-teal-800 dark:text-teal-300">
            <div className="flex items-center gap-2 font-bold mb-1">
              <HeartHandshake className="h-4 w-4 text-teal-600 dark:text-teal-400" />
              <span>Parent Notification & Verification</span>
            </div>
            <p className="text-[11px] text-teal-800 leading-relaxed dark:text-teal-300/80">
              Upon submission, an automated SMS and WhatsApp alert will be dispatched to your registered parent:{" "}
              <strong className="font-semibold">{student.guardian.name} ({student.guardian.relation})</strong> at{" "}
              <strong className="font-mono">{student.guardian.phone}</strong>. For Home Passes, Tutor phone verification is required.
            </p>
          </div>

          {/* AI Pre-Check Panel */}
          <div className="pt-1">
            <div className="flex items-center justify-between mb-2">
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={handleRunAiAudit}
                disabled={isAuditingAI}
                className="text-xs gap-1.5 border-indigo-300 text-indigo-700 bg-indigo-50/50 hover:bg-indigo-100 dark:bg-indigo-950/30 dark:border-indigo-800 dark:text-indigo-300"
              >
                <Sparkles className="h-3.5 w-3.5 text-indigo-600 animate-pulse" />
                {isAuditingAI ? "Auditing Application..." : "AI Policy & Risk Pre-Check"}
              </Button>
              {aiResult && (
                <Badge
                  className={
                    aiResult.riskScore === "LOW"
                      ? "bg-emerald-600 text-white text-[10px]"
                      : aiResult.riskScore === "MEDIUM"
                      ? "bg-amber-600 text-white text-[10px]"
                      : "bg-red-600 text-white text-[10px]"
                  }
                >
                  Risk Score: {aiResult.riskScore}
                </Badge>
              )}
            </div>

            {aiResult && (
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 text-xs space-y-1.5 dark:bg-slate-800/60 dark:border-slate-700">
                <div className="font-semibold text-slate-800 flex items-center gap-1.5 dark:text-slate-200">
                  <CheckCircle className="h-3.5 w-3.5 text-emerald-600" />
                  <span>AI Assessment:</span>
                </div>
                <p className="text-slate-600 text-[11px] leading-relaxed dark:text-slate-400">
                  {aiResult.riskSummary}
                </p>
                {aiResult.missingInfoAlerts.length > 0 && (
                  <div className="mt-1 pt-1 border-t border-slate-200 dark:border-slate-700">
                    <span className="text-[10px] font-bold text-amber-700 dark:text-amber-400 block mb-0.5">
                      Suggested Improvements:
                    </span>
                    <ul className="list-disc pl-4 text-[10px] text-slate-500 space-y-0.5 dark:text-slate-400">
                      {aiResult.missingInfoAlerts.map((alert, idx) => (
                        <li key={idx}>{alert}</li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Form Actions */}
          <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
            <Button type="button" variant="ghost" onClick={onClose} className="text-xs">
              Cancel
            </Button>
            <Button type="submit" className="text-xs bg-blue-600 hover:bg-blue-700 text-white gap-1.5">
              <Send className="h-3.5 w-3.5" />
              Submit for Tutor Clearance
            </Button>
          </div>

        </form>

      </div>
    </div>
  );
};
