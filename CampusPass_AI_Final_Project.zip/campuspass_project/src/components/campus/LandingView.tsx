import React from "react";
import { UserRole } from "@/types/campuspass";
import { 
  ShieldCheck, 
  QrCode, 
  HeartHandshake, 
  Clock, 
  Building2, 
  Sparkles, 
  ArrowRight, 
  Lock, 
  CheckCircle2, 
  Bell, 
  PhoneCall, 
  Users, 
  ChevronRight,
  ShieldAlert,
  BookOpen
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { AdithyaLogo } from "./AdithyaLogo";

interface LandingViewProps {
  onSelectRole: (role: UserRole) => void;
  onGoToDashboard: () => void;
  onOpenDirectory?: () => void;
  onOpenPaperPass?: () => void;
}

export const LandingView: React.FC<LandingViewProps> = ({
  onSelectRole,
  onGoToDashboard,
  onOpenDirectory,
  onOpenPaperPass,
}) => {
  const workflowSteps = [
    {
      step: "01",
      title: "Student Request",
      desc: "Student submits Outing or Home Pass with destination, exact reason, and expected return curfew.",
      badge: "Student Portal",
      color: "blue",
    },
    {
      step: "02",
      title: "Parent Alert & Consent",
      desc: "Automated WhatsApp and SMS dispatched to registered primary guardian with one-click approval.",
      badge: "Parent Portal & WhatsApp",
      color: "teal",
    },
    {
      step: "03",
      title: "Tutor Verification",
      desc: "Class Tutor reviews attendance record (>75%), dials parent for verbal confirmation, logs remarks.",
      badge: "Academic Clearance",
      color: "indigo",
    },
    {
      step: "04",
      title: "HOD Clearance",
      desc: "Department Head checks lab/exam schedule collisions across 9 departments and grants clearance.",
      badge: "Department Clearance",
      color: "purple",
    },
    {
      step: "05",
      title: "Warden & Dynamic QR",
      desc: "Chief Warden signs hostel register and generates unique cryptographic QR pass with live watermarks.",
      badge: "Final Approval",
      color: "amber",
    },
    {
      step: "06",
      title: "Smart Gate Scan",
      desc: "Security Guard scans dynamic QR at Exit and Entry. Triggers instant WhatsApp arrival timestamps to parents.",
      badge: "Gate Security",
      color: "emerald",
    },
  ];

  return (
    <div className="space-y-16 py-6">
      
      {/* Hero Section */}
      <section className="relative overflow-hidden rounded-3xl bg-gradient-to-b from-slate-900 via-slate-950 to-slate-900 text-white p-8 sm:p-14 shadow-2xl border border-slate-800">
        <div className="absolute inset-0 opacity-15 bg-[radial-gradient(#f97316_1px,transparent_1px)] [background-size:24px_24px]" />
        
        <div className="relative z-10 max-w-4xl mx-auto text-center space-y-6">
          
          {/* Official Emblem Banner */}
          <div className="flex flex-col items-center justify-center gap-2">
            <AdithyaLogo size="xl" showText={false} />
            <div className="font-serif font-black text-2xl sm:text-3xl tracking-widest text-orange-500 drop-shadow">
              ADITHYA INSTITUTIONS
            </div>
            <div className="text-xs text-slate-300 font-semibold tracking-wider uppercase">
              Adithya Institute of Technology • Kurumbapalayam, Coimbatore (TNEA Code: 2744)
            </div>
          </div>

          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-orange-500/10 border border-orange-400/30 text-orange-300 text-xs font-semibold backdrop-blur">
            <ShieldCheck className="h-4 w-4 text-orange-400" />
            <span>Autonomous • AICTE Approved • Anna University Affiliated • NAAC Accredited</span>
          </div>

          <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight leading-tight">
            CAMPUS<span className="text-orange-500">PASS</span> AI
          </h1>

          <p className="text-base text-slate-300 max-w-2xl mx-auto leading-relaxed font-normal">
            Automating multi-tier college hostel approval workflows (<strong className="text-white">Tutor → HOD → Warden → Principal</strong>), integrated with verified parent WhatsApp contacts, dynamic anti-screenshot QR codes, and AI policy audit for AIT students.
          </p>

          {/* Quick CTA Launchers */}
          <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
            <Button
              size="lg"
              onClick={onGoToDashboard}
              className="bg-orange-600 hover:bg-orange-700 text-white font-bold px-6 py-2.5 shadow-lg shadow-orange-600/30 text-sm gap-2"
            >
              Enter Control Panel
              <ArrowRight className="h-4 w-4" />
            </Button>
            {onOpenPaperPass && (
              <Button
                size="lg"
                onClick={onOpenPaperPass}
                className="bg-white text-slate-900 hover:bg-slate-100 font-bold px-5 py-2.5 shadow-md text-sm gap-2"
              >
                <FileText className="h-4 w-4 text-orange-600" />
                Paper Pass Preview (Print Slip)
              </Button>
            )}
            {onOpenDirectory && (
              <Button
                size="lg"
                variant="outline"
                onClick={onOpenDirectory}
                className="border-orange-400/50 text-orange-300 bg-orange-950/30 hover:bg-orange-900/40 text-sm font-semibold gap-2"
              >
                <BookOpen className="h-4 w-4 text-orange-400" />
                AIT Brochure & 9 Departments
              </Button>
            )}
            <Button
              size="lg"
              variant="outline"
              onClick={() => onSelectRole("parent")}
              className="border-teal-400/50 text-teal-300 bg-teal-950/30 hover:bg-teal-900/40 text-sm font-semibold gap-2"
            >
              <HeartHandshake className="h-4 w-4 text-teal-400" />
              Parent Guardian Portal
            </Button>
            <Button
              size="lg"
              variant="outline"
              onClick={() => onSelectRole("guard")}
              className="border-emerald-400/50 text-emerald-300 bg-emerald-950/30 hover:bg-emerald-900/40 text-sm font-semibold gap-2"
            >
              <QrCode className="h-4 w-4 text-emerald-400" />
              Open Gate Scanner
            </Button>
          </div>

          {/* Institutional Trust Badges */}
          <div className="pt-8 border-t border-slate-800/80 grid grid-cols-2 sm:grid-cols-4 gap-4 text-center">
            <div>
              <div className="text-2xl font-extrabold text-orange-400">9 Core</div>
              <div className="text-xs text-slate-400 mt-0.5">Academic Departments</div>
            </div>
            <div>
              <div className="text-2xl font-extrabold text-emerald-400">100%</div>
              <div className="text-xs text-slate-400 mt-0.5">Parent WhatsApp Coverage</div>
            </div>
            <div>
              <div className="text-2xl font-extrabold text-amber-400">&lt; 3 Sec</div>
              <div className="text-xs text-slate-400 mt-0.5">Kurumbapalayam Gate QR Scan</div>
            </div>
            <div>
              <div className="text-2xl font-extrabold text-blue-400">2744</div>
              <div className="text-xs text-slate-400 mt-0.5">TNEA Counselling Code</div>
            </div>
          </div>
        </div>
      </section>

      {/* Interactive Multi-Tier Workflow Visualizer */}
      <section className="space-y-6">
        <div className="text-center max-w-2xl mx-auto space-y-2">
          <Badge className="bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300 text-xs">
            Zero-Trust Architectural Pipeline
          </Badge>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white">
            The Multi-Tier Approval & Gate Verification Engine
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400">
            Every hostel outing is strictly validated through a verified institutional chain of custody.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {workflowSteps.map((s, idx) => (
            <div
              key={idx}
              className="p-6 rounded-2xl bg-white border border-slate-200 shadow-sm hover:shadow-md hover:border-blue-300 transition-all space-y-3 dark:bg-slate-900 dark:border-slate-800"
            >
              <div className="flex items-center justify-between">
                <span className="font-mono text-2xl font-extrabold text-slate-300 dark:text-slate-700">
                  {s.step}
                </span>
                <Badge variant="outline" className="text-[10px] font-mono font-semibold">
                  {s.badge}
                </Badge>
              </div>

              <h3 className="font-bold text-base text-slate-900 dark:text-white">
                {s.title}
              </h3>

              <p className="text-xs text-slate-600 leading-relaxed dark:text-slate-400">
                {s.desc}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* Role Portals Grid */}
      <section className="space-y-6">
        <div className="text-center max-w-xl mx-auto space-y-1">
          <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white">
            Access Dedicated Persona Dashboards
          </h2>
          <p className="text-xs text-slate-500">
            Switch into any persona to test the live end-to-end operational workflow:
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <button
            onClick={() => {
              onSelectRole("student");
              onGoToDashboard();
            }}
            className="p-5 rounded-2xl bg-white border border-slate-200 hover:border-blue-500 hover:shadow-md transition-all text-left space-y-2 group dark:bg-slate-900 dark:border-slate-800"
          >
            <div className="h-10 w-10 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center font-bold group-hover:scale-105 transition-transform">
              🎓
            </div>
            <h3 className="font-bold text-sm text-slate-900 dark:text-white">
              Student Dashboard
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Apply for Outing, view active pass, anti-screenshot QR & extension requests.
            </p>
          </button>

          <button
            onClick={() => {
              onSelectRole("parent");
              onGoToDashboard();
            }}
            className="p-5 rounded-2xl bg-white border border-teal-200 hover:border-teal-500 hover:shadow-md transition-all text-left space-y-2 group dark:bg-slate-900 dark:border-teal-900"
          >
            <div className="h-10 w-10 rounded-xl bg-teal-100 text-teal-700 flex items-center justify-center font-bold group-hover:scale-105 transition-transform">
              👨‍👩‍👦
            </div>
            <h3 className="font-bold text-sm text-slate-900 dark:text-white">
              Parent Guardian Portal
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Ward live location, grant leave consent, call warden, gate movement timeline.
            </p>
          </button>

          <button
            onClick={() => {
              onSelectRole("tutor");
              onGoToDashboard();
            }}
            className="p-5 rounded-2xl bg-white border border-indigo-200 hover:border-indigo-500 hover:shadow-md transition-all text-left space-y-2 group dark:bg-slate-900 dark:border-indigo-900"
          >
            <div className="h-10 w-10 rounded-xl bg-indigo-100 text-indigo-700 flex items-center justify-center font-bold group-hover:scale-105 transition-transform">
              👨‍🏫
            </div>
            <h3 className="font-bold text-sm text-slate-900 dark:text-white">
              Class Tutor Desk
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Academic attendance review, parent telephonic verification call logger.
            </p>
          </button>

          <button
            onClick={() => {
              onSelectRole("warden");
              onGoToDashboard();
            }}
            className="p-5 rounded-2xl bg-white border border-amber-200 hover:border-amber-500 hover:shadow-md transition-all text-left space-y-2 group dark:bg-slate-900 dark:border-amber-900"
          >
            <div className="h-10 w-10 rounded-xl bg-amber-100 text-amber-700 flex items-center justify-center font-bold group-hover:scale-105 transition-transform">
              🔑
            </div>
            <h3 className="font-bold text-sm text-slate-900 dark:text-white">
              Hostel Chief Warden
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Hostel occupancy counters, generate cryptographic dynamic QR tokens.
            </p>
          </button>

          <button
            onClick={() => {
              onSelectRole("hod");
              onGoToDashboard();
            }}
            className="p-5 rounded-2xl bg-white border border-purple-200 hover:border-purple-500 hover:shadow-md transition-all text-left space-y-2 group dark:bg-slate-900 dark:border-purple-900"
          >
            <div className="h-10 w-10 rounded-xl bg-purple-100 text-purple-700 flex items-center justify-center font-bold group-hover:scale-105 transition-transform">
              🏛️
            </div>
            <h3 className="font-bold text-sm text-slate-900 dark:text-white">
              Department HOD
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Department-wide leave queue, lab schedule check, batch approvals.
            </p>
          </button>

          <button
            onClick={() => {
              onSelectRole("principal");
              onGoToDashboard();
            }}
            className="p-5 rounded-2xl bg-white border border-rose-200 hover:border-rose-500 hover:shadow-md transition-all text-left space-y-2 group dark:bg-slate-900 dark:border-rose-900"
          >
            <div className="h-10 w-10 rounded-xl bg-rose-100 text-rose-700 flex items-center justify-center font-bold group-hover:scale-105 transition-transform">
              👑
            </div>
            <h3 className="font-bold text-sm text-slate-900 dark:text-white">
              Principal Executive Center
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Institutional metrics, emergency bypass approvals, Gemini AI operational brief.
            </p>
          </button>

          <button
            onClick={() => {
              onSelectRole("guard");
              onGoToDashboard();
            }}
            className="p-5 rounded-2xl bg-white border border-emerald-200 hover:border-emerald-500 hover:shadow-md transition-all text-left space-y-2 group dark:bg-slate-900 dark:border-emerald-900 sm:col-span-2"
          >
            <div className="h-10 w-10 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold group-hover:scale-105 transition-transform">
              🛡️
            </div>
            <h3 className="font-bold text-sm text-slate-900 dark:text-white">
              Smart Gate Security Station
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Simulated optical camera QR scan, two-phase departure & return logging, instant parent WhatsApp dispatch.
            </p>
          </button>
        </div>
      </section>

      {/* Safety & Institutional Architecture Highlights */}
      <section className="bg-slate-100 rounded-3xl p-8 sm:p-10 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="space-y-2">
            <div className="h-10 w-10 rounded-xl bg-blue-600 text-white flex items-center justify-center font-bold shadow">
              <Lock className="h-5 w-5" />
            </div>
            <h3 className="font-bold text-base text-slate-900 dark:text-white">
              Zero-Trust Gate Security
            </h3>
            <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
              Anti-screenshot dynamic watermarks with ticking millisecond ribbons prevent fraudulent static screenshots. Tokens expire automatically upon verified return.
            </p>
          </div>

          <div className="space-y-2">
            <div className="h-10 w-10 rounded-xl bg-teal-600 text-white flex items-center justify-center font-bold shadow">
              <HeartHandshake className="h-5 w-5" />
            </div>
            <h3 className="font-bold text-base text-slate-900 dark:text-white">
              Verified Parent Integration
            </h3>
            <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
              Parents receive real-time WhatsApp Cloud API notifications the exact moment their ward leaves or re-enters campus gates. Full direct access to hostel warden contacts.
            </p>
          </div>

          <div className="space-y-2">
            <div className="h-10 w-10 rounded-xl bg-indigo-600 text-white flex items-center justify-center font-bold shadow">
              <Sparkles className="h-5 w-5" />
            </div>
            <h3 className="font-bold text-base text-slate-900 dark:text-white">
              Gemini 3.8 AI Policy Auditor
            </h3>
            <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
              AI pre-checks leave applications for vague reasons, attendance risks, and curfew compliance before routing, giving authorities clear explainable recommendations.
            </p>
          </div>
        </div>
      </section>

    </div>
  );
};
