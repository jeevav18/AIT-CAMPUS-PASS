import React, { useState } from "react";
import { StudentProfile, PassRequest, CreatePassInput } from "@/types/campuspass";
import { 
  PlusCircle, 
  QrCode, 
  Clock, 
  MapPin, 
  CheckCircle2, 
  AlertCircle, 
  Phone, 
  Building, 
  ArrowRight,
  ShieldCheck,
  Calendar,
  AlertTriangle,
  History,
  Send,
  HeartHandshake,
  FileText
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { DigitalQRPass } from "./DigitalQRPass";
import { PassApplicationModal } from "./PassApplicationModal";
import { PaperPassSlipModal } from "./PaperPassSlipModal";
import { toast } from "sonner";

interface StudentDashboardProps {
  student: StudentProfile;
  passes: PassRequest[];
  onApplyPass: (passData: CreatePassInput) => void;
  onRequestExtension: (passId: string, newTime: string, reason: string) => void;
  onNavigateToScanner?: (token: string) => void;
}

export const StudentDashboard: React.FC<StudentDashboardProps> = ({
  student,
  passes,
  onApplyPass,
  onRequestExtension,
  onNavigateToScanner,
}) => {
  const [isApplyModalOpen, setIsApplyModalOpen] = useState(false);
  const [selectedPassForQR, setSelectedPassForQR] = useState<PassRequest | null>(null);
  const [selectedPassForPaperSlip, setSelectedPassForPaperSlip] = useState<PassRequest | null>(null);
  
  // Extension Modal state
  const [isExtModalOpen, setIsExtModalOpen] = useState(false);
  const [extPassId, setExtPassId] = useState<string>("");
  const [extNewTime, setExtNewTime] = useState<string>("");
  const [extReason, setExtReason] = useState<string>("");

  // Student's passes
  const studentPasses = passes.filter((p) => p.studentId === student.id);
  const activePass = studentPasses.find(
    (p) => p.status === "approved" || p.status === "active_out" || p.status === "overdue" || p.status.startsWith("pending")
  );

  const handleOpenExtension = (pass: PassRequest) => {
    setExtPassId(pass.id);
    const currExpected = new Date(pass.expectedReturnDateTime);
    const plusTwoHours = new Date(currExpected.getTime() + 2 * 60 * 60 * 1000);
    const formatted = new Date(plusTwoHours.getTime() - plusTwoHours.getTimezoneOffset() * 60000)
      .toISOString()
      .slice(0, 16);
    setExtNewTime(formatted);
    setExtReason("");
    setIsExtModalOpen(true);
  };

  const handleConfirmExtension = (e: React.FormEvent) => {
    e.preventDefault();
    if (!extReason.trim()) {
      toast.error("Please provide a legitimate reason for extension.");
      return;
    }
    onRequestExtension(extPassId, new Date(extNewTime).toISOString(), extReason);
    setIsExtModalOpen(false);
    toast.success("Deadline extension request submitted to Chief Warden.");
  };

  return (
    <div className="space-y-6">
      
      {/* Student Profile Banner */}
      <div className="bg-gradient-to-r from-blue-700 via-indigo-700 to-slate-900 rounded-2xl p-6 text-white shadow-lg relative overflow-hidden">
        <div className="absolute right-0 top-0 bottom-0 w-1/3 opacity-10 bg-[radial-gradient(#fff_2px,transparent_2px)] [background-size:16px_16px]" />
        
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <img
              src={student.avatarUrl}
              alt={student.name}
              className="h-20 w-20 rounded-2xl object-cover border-2 border-white/50 shadow-md"
            />
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-extrabold tracking-tight">{student.name}</h2>
                <Badge className="bg-blue-500/30 text-blue-100 border-white/20 text-xs font-mono">
                  {student.rollNumber}
                </Badge>
              </div>
              <p className="text-xs text-blue-200 mt-0.5">
                {student.degree} • Year {student.year} (Section {student.section})
              </p>
              
              <div className="flex flex-wrap items-center gap-3 mt-2 text-xs text-blue-100/80">
                <div className="flex items-center gap-1">
                  <Building className="h-3.5 w-3.5 text-blue-300" />
                  <span>{student.hostelBlock} (Room {student.roomNumber})</span>
                </div>
                <span>•</span>
                <div className="flex items-center gap-1">
                  <span className="font-semibold text-emerald-300">Attendance: {student.attendancePercentage}%</span>
                </div>
              </div>
            </div>
          </div>

          {/* Quick Action Button */}
          <div className="flex items-center gap-2">
            <Button
              onClick={() => setIsApplyModalOpen(true)}
              className="bg-white text-blue-900 hover:bg-blue-50 font-semibold shadow-md gap-2"
            >
              <PlusCircle className="h-4 w-4 text-blue-600" />
              Apply for Pass
            </Button>
          </div>
        </div>
      </div>

      {/* Active Pass Spotlight Card */}
      {activePass ? (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-md overflow-hidden dark:bg-slate-900 dark:border-slate-800">
          <div className="bg-slate-50 border-b border-slate-200 px-6 py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-2 dark:bg-slate-800/60 dark:border-slate-800">
            <div>
              <div className="flex items-center gap-2.5">
                <span className="font-mono font-bold text-sm text-slate-800 dark:text-white">
                  Pass {activePass.passNumber}
                </span>
                <Badge className="capitalize text-xs">
                  {activePass.passType.replace("_", " ")}
                </Badge>
                {activePass.status === "approved" && (
                  <Badge className="bg-emerald-600 text-white text-xs">
                    Approved & Ready for Gate
                  </Badge>
                )}
                {activePass.status === "active_out" && (
                  <Badge className="bg-amber-600 text-white text-xs">
                    ● Currently Out on Pass
                  </Badge>
                )}
                {activePass.status === "overdue" && (
                  <Badge className="bg-red-600 text-white text-xs animate-pulse">
                    ⚠️ Curfew Overdue Alert
                  </Badge>
                )}
                {activePass.status.startsWith("pending") && (
                  <Badge className="bg-blue-600 text-white text-xs">
                    Pending Clearance ({activePass.currentStage.toUpperCase()})
                  </Badge>
                )}
              </div>
              <p className="text-xs text-slate-500 mt-1 dark:text-slate-400">
                Applied on {new Date(activePass.createdAt).toLocaleDateString([], { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" })}
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <Button
                size="sm"
                variant="outline"
                onClick={() => setSelectedPassForPaperSlip(activePass)}
                className="border-orange-300 text-orange-700 bg-orange-50 hover:bg-orange-100 gap-1.5 text-xs font-semibold dark:bg-orange-950/30 dark:border-orange-800 dark:text-orange-300"
              >
                <FileText className="h-3.5 w-3.5 text-orange-600" />
                Paper Pass Slip
              </Button>
              {(activePass.status === "approved" || activePass.status === "active_out") && (
                <Button
                  size="sm"
                  onClick={() => setSelectedPassForQR(activePass)}
                  className="bg-orange-600 hover:bg-orange-700 text-white gap-1.5 text-xs font-semibold shadow"
                >
                  <QrCode className="h-4 w-4" />
                  View Digital QR Pass
                </Button>
              )}
              {activePass.status === "active_out" && (
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => handleOpenExtension(activePass)}
                  className="text-xs font-semibold text-slate-700 border-slate-300 dark:text-slate-300"
                >
                  Request Return Extension
                </Button>
              )}
            </div>
          </div>

          <div className="p-6 space-y-6">
            
            {/* Multi-Stage Workflow Progress Stepper */}
            <div>
              <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-4">
                Multi-Tier Approval Verification Flow
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 relative">
                
                {/* Step 1: Tutor */}
                <div className={`p-3 rounded-xl border transition-all ${
                  activePass.approvalWorkflow.tutor.status === "approved"
                    ? "bg-emerald-50 border-emerald-300 text-emerald-900 dark:bg-emerald-950/20 dark:border-emerald-800 dark:text-emerald-300"
                    : activePass.currentStage === "tutor"
                    ? "bg-blue-50 border-blue-400 text-blue-900 ring-2 ring-blue-300 dark:bg-blue-950/20 dark:border-blue-700 dark:text-blue-200"
                    : "bg-slate-50 border-slate-200 text-slate-500 dark:bg-slate-800/40 dark:border-slate-800"
                }`}>
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-bold">1. Class Tutor</span>
                    {activePass.approvalWorkflow.tutor.status === "approved" ? (
                      <CheckCircle2 className="h-4 w-4 text-emerald-600" />
                    ) : (
                      <Clock className="h-4 w-4 text-slate-400" />
                    )}
                  </div>
                  <div className="text-xs font-semibold mt-1">
                    {student.tutorName.split("(")[0]}
                  </div>
                  <div className="text-[10px] text-slate-500 mt-0.5 dark:text-slate-400">
                    {activePass.approvalWorkflow.tutor.status === "approved"
                      ? "Attendance & Parent call verified"
                      : "Verifying attendance record"}
                  </div>
                </div>

                {/* Step 2: HOD */}
                <div className={`p-3 rounded-xl border transition-all ${
                  activePass.approvalWorkflow.hod.status === "approved"
                    ? "bg-emerald-50 border-emerald-300 text-emerald-900 dark:bg-emerald-950/20 dark:border-emerald-800 dark:text-emerald-300"
                    : activePass.currentStage === "hod"
                    ? "bg-blue-50 border-blue-400 text-blue-900 ring-2 ring-blue-300 dark:bg-blue-950/20 dark:border-blue-700 dark:text-blue-200"
                    : "bg-slate-50 border-slate-200 text-slate-500 dark:bg-slate-800/40 dark:border-slate-800"
                }`}>
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-bold">2. Dept HOD</span>
                    {activePass.approvalWorkflow.hod.status === "approved" ? (
                      <CheckCircle2 className="h-4 w-4 text-emerald-600" />
                    ) : (
                      <Clock className="h-4 w-4 text-slate-400" />
                    )}
                  </div>
                  <div className="text-xs font-semibold mt-1">
                    {student.hodName.split("(")[0]}
                  </div>
                  <div className="text-[10px] text-slate-500 mt-0.5 dark:text-slate-400">
                    {activePass.approvalWorkflow.hod.status === "approved"
                      ? "Lab & academic clearance granted"
                      : "Awaiting departmental check"}
                  </div>
                </div>

                {/* Step 3: Warden */}
                <div className={`p-3 rounded-xl border transition-all ${
                  activePass.approvalWorkflow.warden.status === "approved"
                    ? "bg-emerald-50 border-emerald-300 text-emerald-900 dark:bg-emerald-950/20 dark:border-emerald-800 dark:text-emerald-300"
                    : activePass.currentStage === "warden"
                    ? "bg-blue-50 border-blue-400 text-blue-900 ring-2 ring-blue-300 dark:bg-blue-950/20 dark:border-blue-700 dark:text-blue-200"
                    : "bg-slate-50 border-slate-200 text-slate-500 dark:bg-slate-800/40 dark:border-slate-800"
                }`}>
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-bold">3. Chief Warden</span>
                    {activePass.approvalWorkflow.warden.status === "approved" ? (
                      <CheckCircle2 className="h-4 w-4 text-emerald-600" />
                    ) : (
                      <Clock className="h-4 w-4 text-slate-400" />
                    )}
                  </div>
                  <div className="text-xs font-semibold mt-1">
                    {student.wardenName}
                  </div>
                  <div className="text-[10px] text-slate-500 mt-0.5 dark:text-slate-400">
                    {activePass.approvalWorkflow.warden.status === "approved"
                      ? "Hostel registry signed & QR generated"
                      : "Curfew & hostel clearance"}
                  </div>
                </div>

                {/* Step 4: Gate Security */}
                <div className={`p-3 rounded-xl border transition-all ${
                  activePass.actualExitDateTime
                    ? "bg-emerald-50 border-emerald-300 text-emerald-900 dark:bg-emerald-950/20 dark:border-emerald-800 dark:text-emerald-300"
                    : activePass.status === "approved"
                    ? "bg-blue-50 border-blue-400 text-blue-900 ring-2 ring-blue-300 dark:bg-blue-950/20 dark:border-blue-700 dark:text-blue-200"
                    : "bg-slate-50 border-slate-200 text-slate-500 dark:bg-slate-800/40 dark:border-slate-800"
                }`}>
                  <div className="flex items-center justify-between">
                    <span className="text-[11px] font-bold">4. Gate Security</span>
                    {activePass.actualExitDateTime ? (
                      <CheckCircle2 className="h-4 w-4 text-emerald-600" />
                    ) : (
                      <Clock className="h-4 w-4 text-slate-400" />
                    )}
                  </div>
                  <div className="text-xs font-semibold mt-1">
                    Main Campus Gate
                  </div>
                  <div className="text-[10px] text-slate-500 mt-0.5 dark:text-slate-400">
                    {activePass.actualExitDateTime
                      ? `Exited at ${new Date(activePass.actualExitDateTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`
                      : "Scan QR upon departure"}
                  </div>
                </div>

              </div>
            </div>

            {/* Pass Metadata Grid */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs pt-2 border-t border-slate-100 dark:border-slate-800">
              <div className="space-y-1">
                <span className="text-slate-400 font-medium">DESTINATION & PURPOSE</span>
                <p className="font-semibold text-slate-800 dark:text-slate-200">{activePass.destination}</p>
                <p className="text-slate-500 dark:text-slate-400">{activePass.reason}</p>
              </div>

              <div className="space-y-1">
                <span className="text-slate-400 font-medium">TIMINGS & CURFEW</span>
                <p className="text-slate-700 dark:text-slate-300">
                  Departure: <span className="font-semibold font-mono text-blue-600">{new Date(activePass.departureDateTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                </p>
                <p className="text-slate-700 dark:text-slate-300">
                  Return Curfew: <span className="font-semibold font-mono text-red-600">{new Date(activePass.expectedReturnDateTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                </p>
              </div>

              <div className="space-y-1 bg-slate-50 p-3 rounded-xl border border-slate-200 dark:bg-slate-800/50 dark:border-slate-700">
                <span className="text-slate-400 font-medium flex items-center gap-1">
                  <HeartHandshake className="h-3.5 w-3.5 text-teal-600" />
                  PARENT GUARDIAN STATUS
                </span>
                <p className="font-semibold text-slate-800 dark:text-slate-200">
                  {activePass.guardian.name} ({activePass.guardian.relation})
                </p>
                <p className="text-slate-500 font-mono text-[11px] dark:text-slate-400">
                  {activePass.guardian.phone} • WhatsApp Live
                </p>
              </div>
            </div>

          </div>
        </div>
      ) : (
        <div className="bg-white rounded-2xl border border-dashed border-slate-300 p-8 text-center space-y-3 dark:bg-slate-900 dark:border-slate-700">
          <div className="h-12 w-12 rounded-full bg-blue-50 text-blue-600 mx-auto flex items-center justify-center dark:bg-blue-950/40 dark:text-blue-400">
            <QrCode className="h-6 w-6" />
          </div>
          <h3 className="font-bold text-slate-800 text-base dark:text-white">
            No Active Pass Currently Open
          </h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto dark:text-slate-400">
            Planning to leave campus for books, project work, medical checkup or weekend home visit?
          </p>
          <Button
            onClick={() => setIsApplyModalOpen(true)}
            className="text-xs font-semibold bg-blue-600 hover:bg-blue-700 text-white"
          >
            Apply for Outing / Home Pass
          </Button>
        </div>
      )}

      {/* Pass History Table */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm dark:bg-slate-900 dark:border-slate-800">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <History className="h-4 w-4 text-slate-500" />
            <h3 className="font-bold text-sm text-slate-900 dark:text-white">
              Pass Records & Movement History
            </h3>
          </div>
          <span className="text-xs text-slate-500">
            {studentPasses.length} total entries recorded
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-100 text-slate-400 uppercase text-[10px] tracking-wider dark:border-slate-800">
                <th className="pb-3 font-semibold">Pass Number</th>
                <th className="pb-3 font-semibold">Category</th>
                <th className="pb-3 font-semibold">Destination</th>
                <th className="pb-3 font-semibold">Departure</th>
                <th className="pb-3 font-semibold">Return</th>
                <th className="pb-3 font-semibold">Status</th>
                <th className="pb-3 font-semibold text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {studentPasses.map((p) => (
                <tr key={p.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/40">
                  <td className="py-3 font-mono font-bold text-blue-600 dark:text-blue-400">
                    {p.passNumber}
                  </td>
                  <td className="py-3 capitalize text-slate-700 dark:text-slate-300">
                    {p.passType.replace("_", " ")}
                  </td>
                  <td className="py-3 text-slate-700 max-w-[180px] truncate dark:text-slate-300">
                    {p.destination}
                  </td>
                  <td className="py-3 text-slate-600 font-mono text-[11px] dark:text-slate-400">
                    {new Date(p.departureDateTime).toLocaleDateString([], { month: "short", day: "numeric" })}{" "}
                    {new Date(p.departureDateTime).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                  </td>
                  <td className="py-3 text-slate-600 font-mono text-[11px] dark:text-slate-400">
                    {new Date(p.expectedReturnDateTime).toLocaleDateString([], { month: "short", day: "numeric" })}{" "}
                    {new Date(p.expectedReturnDateTime).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                  </td>
                  <td className="py-3">
                    <Badge
                      className={
                        p.status === "completed"
                          ? "bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300 text-[10px]"
                          : p.status === "approved"
                          ? "bg-emerald-600 text-white text-[10px]"
                          : p.status === "active_out"
                          ? "bg-amber-600 text-white text-[10px]"
                          : p.status === "overdue"
                          ? "bg-red-600 text-white text-[10px]"
                          : "bg-blue-600 text-white text-[10px]"
                      }
                    >
                      {p.status.toUpperCase()}
                    </Badge>
                  </td>
                  <td className="py-3 text-right">
                    <div className="flex items-center justify-end gap-1">
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => setSelectedPassForPaperSlip(p)}
                        className="text-xs text-orange-600 hover:text-orange-700 hover:bg-orange-50 h-7 px-2"
                        title="View Official Paper Outing Pass Slip"
                      >
                        <FileText className="h-3.5 w-3.5 mr-1" />
                        Slip
                      </Button>
                      {p.qrToken && (
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => setSelectedPassForQR(p)}
                          className="text-xs text-blue-600 hover:text-blue-700 h-7 px-2"
                        >
                          <QrCode className="h-3.5 w-3.5 mr-1" />
                          Pass
                        </Button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Digital QR Modal */}
      {selectedPassForQR && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="relative max-w-md w-full">
            <button
              onClick={() => setSelectedPassForQR(null)}
              className="absolute -top-3 -right-3 z-10 bg-slate-800 text-white rounded-full p-1.5 hover:bg-slate-700 shadow"
            >
              ✕
            </button>
            <DigitalQRPass
              pass={selectedPassForQR}
              onNavigateToScanner={(token) => {
                setSelectedPassForQR(null);
                if (onNavigateToScanner) onNavigateToScanner(token);
              }}
            />
          </div>
        </div>
      )}

      {/* Pass Application Modal */}
      <PassApplicationModal
        student={student}
        isOpen={isApplyModalOpen}
        onClose={() => setIsApplyModalOpen(false)}
        onSubmit={onApplyPass}
      />

      {/* Deadline Extension Modal */}
      {isExtModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div className="bg-white rounded-2xl max-w-md w-full p-5 shadow-2xl border border-slate-200 space-y-4 dark:bg-slate-900 dark:border-slate-800">
            <h3 className="font-bold text-base text-slate-900 dark:text-white">
              Request Return Deadline Extension
            </h3>
            <p className="text-xs text-slate-500">
              Submit extension request to Chief Warden if delayed due to genuine transportation or study reasons.
            </p>
            <form onSubmit={handleConfirmExtension} className="space-y-3">
              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1 dark:text-slate-300">
                  Requested New Return Time
                </label>
                <input
                  type="datetime-local"
                  value={extNewTime}
                  onChange={(e) => setExtNewTime(e.target.value)}
                  required
                  className="w-full text-xs px-3 py-2 rounded-lg border border-slate-200 bg-white dark:bg-slate-800 dark:border-slate-700 dark:text-white"
                />
              </div>
              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1 dark:text-slate-300">
                  Reason for Delay
                </label>
                <textarea
                  rows={3}
                  placeholder="e.g. Traffic bottleneck on Avinashi Road / Delay in project viva"
                  value={extReason}
                  onChange={(e) => setExtReason(e.target.value)}
                  required
                  className="w-full text-xs px-3 py-2 rounded-lg border border-slate-200 bg-white dark:bg-slate-800 dark:border-slate-700 dark:text-white"
                />
              </div>
              <div className="flex items-center justify-end gap-2 pt-2">
                <Button
                  type="button"
                  variant="ghost"
                  onClick={() => setIsExtModalOpen(false)}
                  className="text-xs"
                >
                  Cancel
                </Button>
                <Button type="submit" className="text-xs bg-blue-600 hover:bg-blue-700 text-white">
                  Submit Extension Request
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Official Paper Pass Slip Modal */}
      <PaperPassSlipModal
        pass={selectedPassForPaperSlip}
        isOpen={!!selectedPassForPaperSlip}
        onClose={() => setSelectedPassForPaperSlip(null)}
      />

    </div>
  );
};
