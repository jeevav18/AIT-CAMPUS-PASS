import { useState } from "react";
import { Folder, File, ArrowLeft, Terminal, LayoutGrid } from "lucide-react";
import { playTick, playHover } from "@/lib/cyberAudio";

interface OSFileExplorerProps {
  onOpenFile: (appId: string) => void;
}

interface FileSystemItem {
  name: string;
  type: "folder" | "file";
  content?: string;
  targetApp?: string; // App ID to open when clicked
}

const OSFileExplorer = ({ onOpenFile }: OSFileExplorerProps) => {
  const [currentPath, setCurrentPath] = useState<string[]>([]);
  const [selectedItem, setSelectedItem] = useState<FileSystemItem | null>(null);

  // Deep Virtual File Tree Map representing actual portfolio data
  const fileTree: Record<string, FileSystemItem[]> = {
    root: [
      { name: "Resume", type: "folder" },
      { name: "Projects", type: "folder" },
      { name: "Certificates", type: "folder" },
      { name: "Skills", type: "folder" },
      { name: "SystemDocs", type: "folder" },
    ],
    "root/Resume": [
      { name: "jeeva_resume_decryptor.exe", type: "file", targetApp: "resume" },
      { name: "signature_status.txt", type: "file", content: "STATUS: SECURE_VERIFIED_RSA_SHA256\nLOCATION: COIMBATORE, INDIA\nDECLARATION: All statements in the profile are authentic and verified by Jeeva V." },
    ],
    "root/Projects": [
      { name: "salesforce_crm_system.app", type: "file", targetApp: "projects" },
      { name: "freelance_solutions.app", type: "file", targetApp: "projects" },
    ],
    "root/Certificates": [
      { name: "eclearnix_hackathon_360.cert", type: "file", targetApp: "certificates" },
    ],
    "root/Skills": [
      { name: "apex_programming_core.dat", type: "file", targetApp: "skills" },
      { name: "lightning_web_components.dat", type: "file", targetApp: "skills" },
      { name: "declarative_flow_builder.dat", type: "file", targetApp: "skills" },
    ],
    "root/SystemDocs": [
      { name: "career_objective.txt", type: "file", content: "To collaborate with global clients as a Salesforce Developer, engineering reliable, high-performance CRM solutions, customized triggers, Apex controller modules, and React components." },
      { name: "contact_protocols.txt", type: "file", content: "EMAIL: gopiiniyavan@gmail.com\nPHONE: +91 9442050959\nSTATUS: Open for collaborations and full-time employment roles." },
    ],
  };

  const getPathString = () => `root${currentPath.length ? "/" + currentPath.join("/") : ""}`;
  const currentItems = fileTree[getPathString()] || [];

  const handleItemClick = (item: FileSystemItem) => {
    playTick();
    if (item.type === "folder") {
      setCurrentPath((prev) => [...prev, item.name]);
      setSelectedItem(null);
    } else {
      setSelectedItem(item);
    }
  };

  const handleDoubleClick = (item: FileSystemItem) => {
    if (item.type === "file" && item.targetApp) {
      onOpenFile(item.targetApp);
    }
  };

  const handleBack = () => {
    playTick();
    setCurrentPath((prev) => prev.slice(0, -1));
    setSelectedItem(null);
  };

  return (
    <div className="flex flex-col h-full font-mono text-xs text-white">
      {/* Path Breadcrumbs Control bar */}
      <div className="flex items-center space-y-2 md:space-y-0 justify-between bg-[#050505] border border-[#00FF66]/15 rounded-md px-3 py-2 mb-4">
        <div className="flex items-center space-x-2">
          {currentPath.length > 0 && (
            <button
              onMouseEnter={playHover}
              onClick={handleBack}
              className="p-1 rounded bg-zinc-900 border border-[#00FF66]/20 hover:bg-[#00FF66]/15 text-[#00FF66] transition cursor-pointer"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
            </button>
          )}
          <span className="text-gray-500 font-bold uppercase text-[9px]">PATH:</span>
          <span className="text-[#00FF66] font-semibold">C: / {currentPath.join(" / ")}</span>
        </div>
        <span className="text-[9px] text-gray-500 font-bold uppercase">{currentItems.length} items detected</span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 flex-1 min-h-0">
        {/* Left Side: Directory Grid */}
        <div className="md:col-span-2 border border-[#00FF66]/15 bg-black/45 rounded-lg p-3 overflow-y-auto scrollbar-thin">
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {currentItems.map((item, idx) => (
              <div
                key={idx}
                onMouseEnter={playHover}
                onClick={() => handleItemClick(item)}
                onDoubleClick={() => handleDoubleClick(item)}
                className={`p-3 border rounded-lg flex flex-col items-center justify-center text-center cursor-pointer transition duration-200 select-none ${
                  selectedItem?.name === item.name
                    ? "bg-[#00FF66]/10 border-[#00FF66]"
                    : "bg-[#050505]/40 border-[#00FF66]/10 hover:border-[#00FF66]/30 hover:bg-[#00FF66]/5"
                }`}
              >
                {item.type === "folder" ? (
                  <Folder className="w-8 h-8 text-[#00E5FF] mb-2 filter drop-shadow-[0_2px_8px_rgba(0,229,255,0.2)]" />
                ) : (
                  <File className="w-8 h-8 text-[#FFC107] mb-2 filter drop-shadow-[0_2px_8px_rgba(255,193,7,0.2)]" />
                )}
                <span className="text-[10px] font-bold truncate w-full px-1">{item.name}</span>
                {item.targetApp && (
                  <span className="text-[8px] bg-[#00FF66]/10 text-[#00FF66] px-1 rounded-sm mt-1 uppercase font-extrabold tracking-wider">
                    LAUNCHABLE
                  </span>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Right Side: Preview Console */}
        <div className="border border-[#00FF66]/15 bg-black/60 rounded-lg p-4 flex flex-col justify-between overflow-hidden">
          <div className="space-y-4 h-full flex flex-col">
            <div className="flex items-center space-x-1.5 border-b border-[#00FF66]/10 pb-2 shrink-0">
              <Terminal className="w-4 h-4 text-[#00FF66]" />
              <span className="font-bold text-gray-400 uppercase text-[9px]">PREVIEW_COUPLE</span>
            </div>

            {selectedItem ? (
              <div className="flex-1 overflow-y-auto scrollbar-thin space-y-3 pr-1">
                <div className="text-[11px] font-bold text-[#00FF66] font-oxanium text-glow-green leading-tight break-all">
                  {selectedItem.name.toUpperCase()}
                </div>
                <div className="text-[9px] text-gray-500 font-bold uppercase">
                  TYPE: {selectedItem.type === "folder" ? "SYS_DIRECTORY" : "HEX_DATA_STREAM"}
                </div>
                
                {selectedItem.content ? (
                  <pre className="bg-[#040404] p-2.5 rounded border border-[#00FF66]/10 text-[10px] text-gray-300 whitespace-pre-wrap leading-relaxed">
                    {selectedItem.content}
                  </pre>
                ) : selectedItem.targetApp ? (
                  <div className="space-y-3">
                    <p className="text-[10px] text-gray-400 leading-relaxed bg-[#00FF66]/5 p-2 rounded border border-[#00FF66]/10">
                      This is an executable operating system script. Double-click the file, or use the action trigger below, to load the visual interface.
                    </p>
                    <button
                      onMouseEnter={playHover}
                      onClick={() => handleDoubleClick(selectedItem)}
                      className="w-full py-1.5 bg-[#00FF66]/15 hover:bg-[#00FF66]/25 border border-[#00FF66]/30 text-[#00FF66] font-bold text-[9px] uppercase tracking-widest rounded transition cursor-pointer"
                    >
                      EXECUTE APPLICATION
                    </button>
                  </div>
                ) : (
                  <p className="text-[10px] text-gray-500 italic">No additional content buffer mapped inside file sector.</p>
                )}
              </div>
            ) : (
              <div className="flex-1 flex flex-col items-center justify-center text-center text-gray-600">
                <LayoutGrid className="w-10 h-10 mb-2.5 opacity-30 animate-pulse" />
                <p className="text-[10px] max-w-[150px] leading-normal uppercase font-bold">Select any item to parse structural data</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default OSFileExplorer;
