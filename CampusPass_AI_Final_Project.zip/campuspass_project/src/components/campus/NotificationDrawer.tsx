import React, { useState } from "react";
import { NotificationPayload } from "@/types/campuspass";
import { 
  X, 
  Bell, 
  MessageSquare, 
  Phone, 
  CheckCheck, 
  Clock, 
  Check, 
  Send,
  ShieldCheck
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

interface NotificationDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  notifications: NotificationPayload[];
  onMarkAllRead: () => void;
}

export const NotificationDrawer: React.FC<NotificationDrawerProps> = ({
  isOpen,
  onClose,
  notifications,
  onMarkAllRead,
}) => {
  const [filterChannel, setFilterChannel] = useState<"ALL" | "WHATSAPP" | "SMS" | "IN_APP">("ALL");

  if (!isOpen) return null;

  const filtered = notifications.filter((n) => {
    if (filterChannel === "ALL") return true;
    return n.channel === filterChannel;
  });

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-white w-full max-w-md h-full shadow-2xl flex flex-col border-l border-slate-200 dark:bg-slate-900 dark:border-slate-800">
        
        {/* Header */}
        <div className="p-4 border-b border-slate-100 flex items-center justify-between dark:border-slate-800">
          <div className="flex items-center gap-2">
            <Bell className="h-5 w-5 text-blue-600" />
            <div>
              <h3 className="font-bold text-base text-slate-900 dark:text-white">
                Dispatch & Notification Log
              </h3>
              <p className="text-[11px] text-slate-500">
                SMS, WhatsApp Business & In-App Alerts
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Channel Filters */}
        <div className="p-3 bg-slate-50 border-b border-slate-100 flex items-center justify-between dark:bg-slate-800/40 dark:border-slate-800">
          <div className="flex gap-1.5 text-xs">
            <button
              onClick={() => setFilterChannel("ALL")}
              className={`px-2.5 py-1 rounded-lg font-semibold transition-colors ${
                filterChannel === "ALL"
                  ? "bg-slate-900 text-white dark:bg-white dark:text-slate-900"
                  : "bg-white text-slate-600 border border-slate-200 dark:bg-slate-800 dark:text-slate-300"
              }`}
            >
              All ({notifications.length})
            </button>
            <button
              onClick={() => setFilterChannel("WHATSAPP")}
              className={`px-2.5 py-1 rounded-lg font-semibold transition-colors ${
                filterChannel === "WHATSAPP"
                  ? "bg-emerald-600 text-white"
                  : "bg-white text-slate-600 border border-slate-200 dark:bg-slate-800 dark:text-slate-300"
              }`}
            >
              WhatsApp
            </button>
            <button
              onClick={() => setFilterChannel("SMS")}
              className={`px-2.5 py-1 rounded-lg font-semibold transition-colors ${
                filterChannel === "SMS"
                  ? "bg-blue-600 text-white"
                  : "bg-white text-slate-600 border border-slate-200 dark:bg-slate-800 dark:text-slate-300"
              }`}
            >
              SMS
            </button>
          </div>

          <Button
            variant="ghost"
            size="sm"
            onClick={onMarkAllRead}
            className="text-[11px] h-7 text-slate-500 hover:text-slate-700"
          >
            Mark all read
          </Button>
        </div>

        {/* Message Feed */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {filtered.length > 0 ? (
            filtered.map((n) => {
              const isWhatsApp = n.channel === "WHATSAPP";
              const isSms = n.channel === "SMS";

              return (
                <div
                  key={n.id}
                  className={`p-3.5 rounded-2xl border text-xs space-y-2 transition-all ${
                    isWhatsApp
                      ? "bg-emerald-50/70 border-emerald-200 dark:bg-emerald-950/20 dark:border-emerald-800"
                      : isSms
                      ? "bg-blue-50/70 border-blue-200 dark:bg-blue-950/20 dark:border-blue-800"
                      : "bg-slate-50 border-slate-200 dark:bg-slate-800/50 dark:border-slate-700"
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1.5">
                      {isWhatsApp ? (
                        <Badge className="bg-emerald-600 text-white text-[9px] font-mono">
                          WHATSAPP CLOUD API
                        </Badge>
                      ) : isSms ? (
                        <Badge className="bg-blue-600 text-white text-[9px] font-mono">
                          SMS GATEWAY
                        </Badge>
                      ) : (
                        <Badge variant="outline" className="text-[9px]">
                          IN-APP
                        </Badge>
                      )}
                      <span className="font-bold text-slate-800 text-[11px] dark:text-slate-200">
                        {n.recipientName}
                      </span>
                    </div>

                    <div className="flex items-center gap-1 text-[10px] text-slate-400 font-mono">
                      <span>{new Date(n.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                      <CheckCheck className="h-3 w-3 text-blue-500" />
                    </div>
                  </div>

                  {/* Body text preview */}
                  <div className="text-slate-700 text-xs leading-relaxed dark:text-slate-300 font-medium">
                    {n.message}
                  </div>

                  {n.recipientPhone && (
                    <div className="text-[10px] text-slate-400 font-mono pt-1 border-t border-slate-200/60 dark:border-slate-800 flex items-center justify-between">
                      <span>Sent to: {n.recipientPhone}</span>
                      <span className="text-emerald-600 font-semibold">Delivered (Status 200 OK)</span>
                    </div>
                  )}
                </div>
              );
            })
          ) : (
            <p className="text-xs text-slate-400 text-center py-12">
              No notifications in this channel.
            </p>
          )}
        </div>

        {/* Footer info */}
        <div className="p-3 bg-slate-50 border-t border-slate-200 text-[11px] text-slate-400 text-center dark:bg-slate-800/40 dark:border-slate-800">
          Connected to Institutional Webhook Engine • 99.98% Gateway SLA
        </div>

      </div>
    </div>
  );
};
