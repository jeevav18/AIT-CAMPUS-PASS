export type UserRole = 
  | 'student' 
  | 'tutor' 
  | 'hod' 
  | 'warden' 
  | 'principal' 
  | 'guard' 
  | 'parent';

export type PassType = 'outing' | 'home_pass' | 'emergency_medical' | 'event_pass';

export type PassStatus = 
  | 'draft' 
  | 'pending_tutor' 
  | 'pending_hod' 
  | 'pending_warden' 
  | 'approved' 
  | 'active_out' 
  | 'completed' 
  | 'rejected' 
  | 'overdue' 
  | 'cancelled';

export type ParentConsentStatus = 
  | 'not_requested'
  | 'pending'
  | 'verified_by_call'
  | 'consented_sms'
  | 'consented_portal'
  | 'rejected_by_parent';

export interface GuardianContact {
  id: string;
  name: string;
  relation: 'Father' | 'Mother' | 'Guardian';
  phone: string;
  alternatePhone?: string;
  email: string;
  whatsappEnabled: boolean;
  address: string;
  isPrimary: boolean;
}

export interface StudentProfile {
  id: string;
  rollNumber: string;
  name: string;
  email: string;
  phone: string;
  avatarUrl: string;
  department: string;
  degree: string;
  year: number;
  section: string;
  tutorId: string;
  tutorName: string;
  hodId: string;
  hodName: string;
  hostelBlock: string;
  roomNumber: string;
  wardenName: string;
  guardian: GuardianContact;
  localGuardian?: GuardianContact;
  attendancePercentage: number;
  disciplinaryRemarks: string[];
  currentStatus: 'IN_HOSTEL' | 'ON_OUTING' | 'ON_HOME_PASS' | 'OVERDUE';
}

export interface ApprovalStepRecord {
  role: 'tutor' | 'hod' | 'warden' | 'principal';
  status: 'pending' | 'approved' | 'rejected' | 'skipped';
  officerName?: string;
  officerId?: string;
  timestamp?: string;
  remarks?: string;
  parentContacted?: boolean;
  parentContactDetails?: string;
}

export interface GateMovementRecord {
  id: string;
  passId: string;
  passNumber: string;
  studentId: string;
  studentName: string;
  rollNumber: string;
  movementType: 'EXIT' | 'ENTRY';
  gateId: string;
  gateName: string;
  securityOfficerId: string;
  securityOfficerName: string;
  timestamp: string;
  status: 'VERIFIED' | 'FLAGGED_LATE' | 'IRREGULAR';
  notes?: string;
}

export interface ExtensionRequest {
  id: string;
  passId: string;
  previousExpectedReturn: string;
  requestedReturn: string;
  reason: string;
  requestedAt: string;
  status: 'pending' | 'approved' | 'rejected';
  reviewedBy?: string;
  reviewedAt?: string;
  reviewerRemarks?: string;
}

export interface PassRequest {
  id: string;
  passNumber: string; // e.g. CP-2025-0812
  passType: PassType;
  studentId: string;
  studentName: string;
  rollNumber: string;
  department: string;
  year: number;
  hostelBlock: string;
  roomNumber: string;
  avatarUrl: string;
  studentPhone: string;
  
  departureDateTime: string;
  expectedReturnDateTime: string;
  actualExitDateTime?: string;
  actualEntryDateTime?: string;
  
  destination: string;
  reason: string;
  destinationContact?: string;
  transportMode?: string;
  
  // Parent integration
  guardian: GuardianContact;
  parentConsentStatus: ParentConsentStatus;
  parentConsentNotes?: string;
  parentConsentTimestamp?: string;
  
  // Multi-tier Workflow
  currentStage: 'tutor' | 'hod' | 'warden' | 'principal' | 'gate' | 'completed';
  approvalWorkflow: {
    tutor: ApprovalStepRecord;
    hod: ApprovalStepRecord;
    warden: ApprovalStepRecord;
    principal?: ApprovalStepRecord;
  };
  
  status: PassStatus;
  rejectionReason?: string;
  rejectedBy?: string;
  
  // Security QR & Gate
  qrToken?: string;
  qrGeneratedAt?: string;
  qrExpiresAt?: string;
  isExceptionalCase?: boolean;
  
  // Movements & Extensions
  movements: GateMovementRecord[];
  extensions: ExtensionRequest[];
  
  // AI Risk Assessment
  aiAnalysis?: {
    riskScore: 'LOW' | 'MEDIUM' | 'HIGH';
    riskSummary: string;
    missingInfoAlerts: string[];
    policyCompliance: boolean;
    recommendation: 'APPROVE' | 'FLAG_FOR_CALL' | 'FURTHER_VERIFICATION';
  };
  
  createdAt: string;
  updatedAt: string;
}

export type CreatePassInput = Omit<
  PassRequest,
  | "id"
  | "passNumber"
  | "createdAt"
  | "updatedAt"
  | "movements"
  | "extensions"
  | "status"
  | "currentStage"
  | "approvalWorkflow"
>;

export interface NotificationPayload {
  id: string;
  recipientRole: UserRole;
  recipientName: string;
  recipientPhone?: string;
  channel: 'IN_APP' | 'SMS' | 'WHATSAPP';
  title: string;
  message: string;
  timestamp: string;
  read: boolean;
  passId?: string;
  passNumber?: string;
  type: 'PASS_SUBMITTED' | 'STAGE_APPROVED' | 'FINAL_APPROVED' | 'EXIT_RECORDED' | 'ENTRY_RECORDED' | 'OVERDUE_ALERT' | 'PARENT_CONSENT_REQ';
}

export interface LateReturnIncident {
  id: string;
  passId: string;
  passNumber: string;
  studentId: string;
  studentName: string;
  rollNumber: string;
  hostelBlock: string;
  roomNumber: string;
  studentPhone: string;
  guardianPhone: string;
  guardianName: string;
  expectedReturnTime: string;
  actualExitTime: string;
  overdueMinutes: number;
  status: 'ACTIVE_ALERT' | 'WARDEN_CONTACTED' | 'PARENT_ALERTED' | 'RESOLVED';
  actionsTaken: {
    timestamp: string;
    action: string;
    officer: string;
  }[];
  severity: 'MEDIUM' | 'HIGH' | 'CRITICAL';
}

export interface AuditLogItem {
  id: string;
  timestamp: string;
  actorName: string;
  actorRole: UserRole;
  action: string;
  entityType: 'PASS' | 'GATE' | 'POLICY' | 'USER' | 'NOTIFICATION';
  entityId: string;
  details: string;
  ipAddress: string;
}

export interface HostelSummary {
  blockId: string;
  blockName: string;
  gender: 'BOYS' | 'GIRLS';
  chiefWarden: string;
  totalRooms: number;
  capacity: number;
  currentResidents: number;
  currentlyOut: number;
  overdueCount: number;
}
