import React from "react";
import {
  Github,
  GitBranch,
  Star,
  ExternalLink,
  BookOpen,
  CheckCircle2,
  Sparkles,
  GitFork,
  Code2,
} from "lucide-react";
import { PORTFOLIO_DATA } from "@/data/portfolioData";

export const GithubSection: React.FC = () => {
  const { github } = PORTFOLIO_DATA;

  // Generate an authentic-looking subtle 52-week activity grid
  const activityDays = Array.from({ length: 52 * 7 }, (_, i) => {
    // Generate realistic distribution
    const rand = (Math.sin(i * 997 + 13) + 1) / 2;
    if (rand > 0.85) return 3;
    if (rand > 0.6) return 2;
    if (rand > 0.35) return 1;
    return 0;
  });

  const getHeatmapColor = (level: number) => {
    switch (level) {
      case 3:
        return "bg-blue-600 dark:bg-blue-500";
      case 2:
        return "bg-blue-400 dark:bg-blue-700";
      case 1:
        return "bg-blue-200 dark:bg-blue-900/60";
      default:
        return "bg-slate-100 dark:bg-slate-800/60";
    }
  };

  return (
    <section id="github" className="py-20 sm:py-28 bg-white dark:bg-slate-900 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-50 dark:bg-blue-950/60 border border-blue-200 dark:border-blue-800 text-blue-700 dark:text-blue-300 text-xs font-semibold uppercase tracking-wider mb-3">
            <Github className="w-3.5 h-3.5" />
            <span>Open Source & Code Quality</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            GitHub Activity & Public Repositories
          </h2>
          <p className="mt-3 text-base sm:text-lg text-slate-600 dark:text-slate-300">
            Transparent, well-documented engineering repositories, commit discipline, and open-source contributions.
          </p>
        </div>

        {/* 2-Column Overview */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start mb-12">
          {/* Left: GitHub Profile Card */}
          <div className="lg:col-span-4 p-6 sm:p-7 rounded-3xl bg-slate-50/70 dark:bg-slate-800/40 border border-slate-200/80 dark:border-slate-800 shadow-2xs space-y-6">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 flex items-center justify-center text-slate-900 dark:text-white shrink-0 shadow-2xs">
                <Github className="w-8 h-8" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-slate-900 dark:text-white">
                  @{github.username}
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  {github.bio}
                </p>
              </div>
            </div>

            {/* Language Breakdown */}
            <div className="space-y-3">
              <p className="text-xs font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500">
                Most Used Languages
              </p>
              <div className="space-y-2">
                {github.languages.map((lang) => (
                  <div key={lang.name} className="space-y-1">
                    <div className="flex justify-between text-xs font-semibold text-slate-700 dark:text-slate-300">
                      <span className="flex items-center gap-1.5">
                        <span
                          className="w-2.5 h-2.5 rounded-full"
                          style={{ backgroundColor: lang.color }}
                        />
                        {lang.name}
                      </span>
                      <span>{lang.percentage}%</span>
                    </div>
                    <div className="w-full h-1.5 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
                      <div
                        className="h-full rounded-full"
                        style={{
                          width: `${lang.percentage}%`,
                          backgroundColor: lang.color,
                        }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <a
              href={github.profileUrl}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center justify-center gap-2 w-full px-4 py-3 rounded-xl text-xs font-bold text-slate-800 dark:text-slate-200 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            >
              <Github className="w-4 h-4" />
              <span>Visit GitHub Profile</span>
              <ExternalLink className="w-3.5 h-3.5 ml-auto" />
            </a>
          </div>

          {/* Right: Featured Repositories Grid */}
          <div className="lg:col-span-8 grid grid-cols-1 sm:grid-cols-2 gap-4">
            {github.featuredRepos.map((repo) => (
              <div
                key={repo.name}
                className="p-5 rounded-2xl bg-slate-50/70 dark:bg-slate-800/40 border border-slate-200/80 dark:border-slate-800 shadow-2xs hover:shadow-md hover:border-blue-500/40 dark:hover:border-blue-500/40 transition-all flex flex-col justify-between"
              >
                <div className="space-y-2.5">
                  <div className="flex items-start justify-between gap-2">
                    <h4 className="text-sm font-bold text-slate-900 dark:text-white hover:text-blue-600 dark:hover:text-blue-400 transition-colors">
                      <a href={repo.url} target="_blank" rel="noreferrer">
                        {repo.name}
                      </a>
                    </h4>
                    <span className="text-[10px] font-semibold px-2 py-0.5 rounded-md bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-blue-600 dark:text-blue-400 shrink-0">
                      {repo.language}
                    </span>
                  </div>
                  <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed line-clamp-3">
                    {repo.description}
                  </p>
                </div>

                <div className="pt-3 mt-4 border-t border-slate-200/60 dark:border-slate-700/60 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
                  <div className="flex items-center gap-3">
                    <span className="flex items-center gap-1">
                      <Star className="w-3.5 h-3.5 text-amber-500" />
                      {repo.stars}
                    </span>
                    <span className="flex items-center gap-1">
                      <GitFork className="w-3.5 h-3.5 text-slate-400" />
                      {repo.forks}
                    </span>
                  </div>

                  <a
                    href={repo.url}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-1 text-[11px] font-bold text-blue-600 dark:text-blue-400 hover:underline"
                  >
                    <span>Inspect</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* GitHub Contribution Heatmap Simulation Banner */}
        <div className="p-6 sm:p-7 rounded-3xl bg-slate-50/70 dark:bg-slate-800/40 border border-slate-200/80 dark:border-slate-800 shadow-2xs">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4">
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                Yearly Coding Frequency & Contribution Cadence
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Continuous commit velocity across academic terms, hackathons, and independent platforms.
              </p>
            </div>
            <div className="flex items-center gap-1.5 text-[11px] text-slate-500 dark:text-slate-400 font-medium">
              <span>Less</span>
              <span className="w-2.5 h-2.5 rounded-xs bg-slate-100 dark:bg-slate-800" />
              <span className="w-2.5 h-2.5 rounded-xs bg-blue-200 dark:bg-blue-900/60" />
              <span className="w-2.5 h-2.5 rounded-xs bg-blue-400 dark:bg-blue-700" />
              <span className="w-2.5 h-2.5 rounded-xs bg-blue-600 dark:bg-blue-500" />
              <span>More</span>
            </div>
          </div>

          {/* Grid View */}
          <div className="overflow-x-auto pb-2">
            <div className="grid grid-rows-7 grid-flow-col gap-1 min-w-[700px]">
              {activityDays.map((lvl, idx) => (
                <div
                  key={idx}
                  className={`w-2.5 h-2.5 rounded-xs transition-colors ${getHeatmapColor(
                    lvl
                  )}`}
                  title={`Activity Level ${lvl}`}
                />
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default GithubSection;
