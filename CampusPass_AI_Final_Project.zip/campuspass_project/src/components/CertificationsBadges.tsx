import { useState } from "react";
import { motion } from "framer-motion";
import { Award, CheckCircle2, ExternalLink, Shield, Lock, ShieldCheck } from "lucide-react";
import { PORTFOLIO_DATA, CertificationItem } from "@/data/portfolioData";
import { playHover, playTick } from "@/lib/cyberAudio";

export const CertificationsBadges = () => {
  const [hoveredCertId, setHoveredCertId] = useState<string | null>(null);

  const getBadgeColor = (type: CertificationItem["badgeType"]) => {
    switch (type) {
      case "salesforce":
        return "text-[#00E5FF] border-[#00E5FF]/40 bg-[#00E5FF]/10 shadow-[0_0_20px_rgba(0,229,255,0.2)]";
      case "security":
        return "text-[#00FF66] border-[#00FF66]/40 bg-[#00FF66]/10 shadow-[0_0_20px_rgba(0,255,102,0.2)]";
      case "cloud":
        return "text-amber-400 border-amber-400/40 bg-amber-500/10 shadow-[0_0_20px_rgba(255,193,7,0.2)]";
      default:
        return "text-[#BF5AF2] border-[#BF5AF2]/40 bg-[#BF5AF2]/10 shadow-[0_0_20px_rgba(191,90,242,0.2)]";
    }
  };

  return (
    <section id="certifications" className="relative py-20 px-4 max-w-7xl mx-auto scroll-mt-20">
      {/* Section Header */}
      <div className="flex flex-col items-center text-center mb-12 space-y-3">
        <div className="flex items-center space-x-2 px-3 py-1 bg-[#00FF66]/10 border border-[#00FF66]/30 rounded-full text-xs font-mono text-[#00FF66]">
          <Award className="w-3.5 h-3.5" />
          <span className="tracking-widest uppercase">MODULE: SEC_CREDENTIALS_VAULT</span>
        </div>
        <h2 className="text-3xl sm:text-5xl font-bebas tracking-wider text-white">
          VERIFIED <span className="text-[#00FF66] text-glow-green">DIGITAL CREDENTIALS</span>
        </h2>
        <p className="text-sm text-gray-400 max-w-2xl font-mono">
          Cryptographically stamped badges and enterprise cloud credentials verified by authorized issuing certification authorities.
        </p>
      </div>

      {/* Badges Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {PORTFOLIO_DATA.certifications.map((cert) => {
          const badgeClass = getBadgeColor(cert.badgeType);
          const isHovered = hoveredCertId === cert.id;

          return (
            <motion.div
              key={cert.id}
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              whileHover={{ y: -5 }}
              onMouseEnter={() => {
                playHover();
                setHoveredCertId(cert.id);
              }}
              onMouseLeave={() => setHoveredCertId(null)}
              className="relative group bg-black/80 border border-zinc-800/80 hover:border-[#00FF66]/60 rounded-xl p-6 flex flex-col justify-between overflow-hidden transition-all duration-300 shadow-[0_10px_30px_rgba(0,0,0,0.7)] hover:shadow-[0_0_30px_rgba(0,255,102,0.15)]"
            >
              {/* Corner HUD accents */}
              <div className="absolute top-2 left-2 w-2 h-2 border-t border-l border-[#00FF66]/40 group-hover:border-[#00FF66]" />
              <div className="absolute top-2 right-2 w-2 h-2 border-t border-r border-[#00FF66]/40 group-hover:border-[#00FF66]" />
              <div className="absolute bottom-2 left-2 w-2 h-2 border-b border-l border-[#00FF66]/40 group-hover:border-[#00FF66]" />
              <div className="absolute bottom-2 right-2 w-2 h-2 border-b border-r border-[#00FF66]/40 group-hover:border-[#00FF66]" />

              {/* Digital Badge Hologram Seal */}
              <div className="flex items-center justify-between mb-6">
                <div
                  className={`w-14 h-14 rounded-xl border flex items-center justify-center relative overflow-hidden ${badgeClass}`}
                >
                  <ShieldCheck className="w-8 h-8" />
                  <span className="absolute inset-0 bg-scanlines opacity-20 pointer-events-none" />
                </div>

                <div className="text-right font-mono">
                  <span className="inline-flex items-center space-x-1 text-[9px] font-bold px-2 py-0.5 rounded border border-[#00FF66]/40 text-[#00FF66] bg-[#00FF66]/10 uppercase">
                    <CheckCircle2 className="w-2.5 h-2.5" />
                    <span>{cert.status}</span>
                  </span>
                  <div className="text-[11px] text-gray-500 mt-1">ISSUED: {cert.issueDate}</div>
                </div>
              </div>

              {/* Badge Details */}
              <div className="space-y-2 mb-6">
                <h3 className="text-lg font-bold font-oxanium text-white group-hover:text-[#00FF66] transition">
                  {cert.title}
                </h3>
                <div className="text-xs font-mono text-[#00E5FF] font-bold">
                  ISSUER: {cert.issuer}
                </div>
                <div className="text-[11px] font-mono text-gray-400 flex items-center space-x-1.5 pt-1">
                  <Lock className="w-3 h-3 text-[#00FF66]" />
                  <span>ID: {cert.credentialId}</span>
                </div>
              </div>

              {/* Covered Competencies */}
              <div className="space-y-2 mb-6">
                <div className="text-[10px] font-mono text-gray-500 uppercase tracking-wider">
                  Verified Skills:
                </div>
                <div className="flex flex-wrap gap-1">
                  {cert.skillsCovered.map((s) => (
                    <span
                      key={s}
                      className="px-2 py-0.5 bg-zinc-900 border border-zinc-800 text-[10px] font-mono text-gray-300 rounded"
                    >
                      {s}
                    </span>
                  ))}
                </div>
              </div>

              {/* Verification Link Button */}
              <div className="pt-4 border-t border-zinc-900">
                <a
                  href={cert.verificationUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  onClick={() => playTick()}
                  className="w-full py-2 bg-black hover:bg-[#00FF66]/10 border border-zinc-800 hover:border-[#00FF66] text-gray-300 hover:text-[#00FF66] rounded-lg font-mono text-xs font-bold uppercase tracking-wider flex items-center justify-center space-x-1.5 transition cursor-pointer"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>Verify Authenticity</span>
                </a>
              </div>
            </motion.div>
          );
        })}
      </div>
    </section>
  );
};
export default CertificationsBadges;
