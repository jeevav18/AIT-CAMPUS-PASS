import React, { useState } from "react";
import { PassRequest, HostelSummary } from "@/types/campuspass";
import { 
  KeyRound, 
  QrCode, 
  Building, 
  CheckCircle2, 
  XCircle, 
  Clock, 
  AlertTriangle, 
  Sparkles, 
  PhoneCall, 
  Users, 
  ArrowRight,
  ShieldCheck,
  FileText
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { PaperPassSlipModal } from "./PaperPassSlipModal";
import { toast } from "sonner";

interface WardenDashboardProps {
  wardenName: string;
  passes: PassRequest[];
  hostels: HostelSummary[];
  onApprove: (passId: string, remarks: string) => void;
  onReject: (passId: string, reason: string) => void;
  onApproveExtension: (passId: string, extId: string) => void;
  onNavigateToScanner?: (token: string) => void;
}

export const WardenDashboard: React.FC<WardenDashboardProps> = ({
  wardenName,
  passes,
  hostels,
  onApprove,
  onReject,
  onApproveExtension,
  onNavigateToScanner,
}) => {
  const [selectedBlock, setSelectedBlock] = useState<string>("All Hostels");
  const [wardenRemark, setWardenRemark] = useState("Hostel register cleared. QR token issued.");
  const [previewSlipPass, setPreviewSlipPass] = useState<PassRequest | null>(null);

  const pendingPasses = passes.filter((p) => p.status === "pending_warden");
  const activeOutPasses = passes.filter((p) => p.status === "active_out");
  const overduePasses = passes.filter((p) => p.status === "overdue");
  
  // Extension requests pending
  const pendingExtensions = passes.flatMap((p) =>
    (p.extensions || [])
      .filter((e) => e.status === "pending")
      .map((e) => ({ ...e, pass: p }))
  );

  const handleIssueQR = (pass: PassRequest) => {
    onApprove(pass.id, wardenRemark);
    toast.success(`Cryptographic QR Pass generated for ${pass.studentName}! Parent WhatsApp dispatched.`);
  };

  return (
    <div className="space-y-6">
      
      {/* Banner */}
      <div className="bg-gradient-to-r from-amber-700 via-orange-800 to-slate-900 rounded-2xl p-6 text-white shadow-lg flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="h-14 w-14 rounded-2xl bg-white/10 backdrop-blur flex items-center justify-center text-white border border-white/20">
            <KeyRound className="h-7 w-7 text-amber-200" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-bold tracking-tight">
                Hostel Chief Warden Command Center
              </h2>
              <Badge className="bg-amber-500/30 text-amber-100 border-white/20 text-xs">
                Final Issuing Authority
              </Badge>
            </div>
            <p className="text-xs text-amber-100/90 mt-0.5">
              Officer: {wardenName} • Boys & Girls Campus Hostel Security
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <div className="bg-black/25 backdrop-blur px-3 py-2 rounded-xl border border-white/10 text-center">
            <span className="text-[10px] text-amber-200 uppercase font-bold block">Awaiting QR</span>
            <span className="text-lg font-extrabold text-white">{pendingPasses.length}</span>
          </div>
          <div className="bg-black/25 backdrop-blur px-3 py-2 rounded-xl border border-white/10 text-center">
            <span className="text-[10px] text-amber-200 uppercase font-bold block">Currently Out</span>
            <span className="text-lg font-extrabold text-white">{activeOutPasses.length}</span>
          </div>
          <div className="bg-red-500/30 backdrop-blur px-3 py-2 rounded-xl border border-red-400/30 text-center">
            <span className="text-[10px] text-red-200 uppercase font-bold block">Overdue</span>
            <span className="text-lg font-extrabold text-red-300">{overduePasses.length}</span>
          </div>
        </div>
      </div>

      {/* Hostel Blocks Overview Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {hostels.map((h) => (
          <div
            key={h.blockId}
            className="p-4 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-2 dark:bg-slate-900 dark:border-slate-800"
          >
            <div className="flex items-center justify-between">
              <span className="font-bold text-xs text-slate-800 truncate dark:text-slate-200">
                {h.blockName.split("(")[0]}
              </span>
              <Badge variant="outline" className="text-[9px] font-mono">
                {h.gender}
              </Badge>
            </div>

            <div className="grid grid-cols-2 gap-2 text-[11px] pt-1">
              <div>
                <span className="text-slate-400 block text-[10px]">IN HOSTEL</span>
                <span className="font-bold text-slate-800 text-sm dark:text-slate-200">
                  {h.currentResidents - h.currentlyOut} / {h.capacity}
                </span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px]">ON PASS</span>
                <span className="font-bold text-blue-600 text-sm dark:text-blue-400">
                  {h.currentlyOut}
                </span>
              </div>
            </div>

            {h.overdueCount > 0 && (
              <div className="text-[10px] font-bold text-red-600 bg-red-50 p-1 rounded text-center dark:bg-red-950/30">
                ⚠️ {h.overdueCount} Overdue Alert
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Pending Return Extension Requests (if any) */}
      {pendingExtensions.length > 0 && (
        <div className="bg-amber-50 rounded-2xl border border-amber-300 p-5 dark:bg-amber-950/20 dark:border-amber-800">
          <h3 className="font-bold text-sm text-amber-900 mb-2 flex items-center gap-1.5 dark:text-amber-200">
            <Clock className="h-4 w-4 text-amber-700" />
            Curfew Extension Requests Awaiting Warden Decision
          </h3>
          <div className="space-y-2">
            {pendingExtensions.map((ext) => (
              <div
                key={ext.id}
                className="p-3 bg-white rounded-xl border border-amber-200 flex items-center justify-between text-xs dark:bg-slate-900 dark:border-amber-900"
              >
                <div>
                  <span className="font-bold text-slate-900 dark:text-white">
                    {ext.pass.studentName} ({ext.pass.rollNumber})
                  </span>
                  <p className="text-slate-600 dark:text-slate-400">
                    Reason: {ext.reason} • Requested return:{" "}
                    <strong className="text-red-600">{new Date(ext.requestedReturn).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</strong>
                  </p>
                </div>
                <Button
                  size="sm"
                  onClick={() => onApproveExtension(ext.pass.id, ext.id)}
                  className="text-xs bg-amber-600 hover:bg-amber-700 text-white"
                >
                  Approve Extension
                </Button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Main Final Approval Queue: Issuing Digital QR Passes */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm dark:bg-slate-900 dark:border-slate-800">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-bold text-sm text-slate-900 flex items-center gap-2 dark:text-white">
            <QrCode className="h-4 w-4 text-amber-600" />
            Applications Ready for Final Warden Approval & Digital QR Generation
          </h3>
          <span className="text-xs text-slate-500">
            {pendingPasses.length} ready to issue
          </span>
        </div>

        {pendingPasses.length > 0 ? (
          <div className="divide-y divide-slate-100 dark:divide-slate-800">
            {pendingPasses.map((p) => (
              <div key={p.id} className="py-4 first:pt-0 last:pb-0 flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="flex items-start gap-3.5">
                  <img
                    src={p.avatarUrl}
                    alt={p.studentName}
                    className="h-14 w-14 rounded-xl object-cover border border-slate-200"
                  />
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-base text-slate-900 dark:text-white">
                        {p.studentName}
                      </span>
                      <span className="font-mono text-xs font-bold text-blue-600">
                        {p.rollNumber}
                      </span>
                      <Badge className="capitalize text-[10px]">
                        {p.passType.replace("_", " ")}
                      </Badge>
                      <Badge className="bg-slate-100 text-slate-700 text-[10px] dark:bg-slate-800 dark:text-slate-300">
                        Room {p.roomNumber} ({p.hostelBlock.split("(")[0]})
                      </Badge>
                    </div>

                    <p className="text-xs text-slate-600 mt-1 dark:text-slate-400">
                      <strong>Destination:</strong> {p.destination} • <strong>Reason:</strong> {p.reason}
                    </p>

                    <div className="flex flex-wrap items-center gap-3 mt-1.5 text-[11px] text-slate-500">
                      <span>Cleared by Tutor: {p.approvalWorkflow.tutor.officerName?.split(" ")[1]} ✓</span>
                      <span>•</span>
                      <span>Cleared by HOD: {p.approvalWorkflow.hod.officerName?.split(" ")[1]} ✓</span>
                      <span>•</span>
                      <span className="text-teal-700 font-semibold dark:text-teal-400">
                        Parent WhatsApp Ready: {p.guardian.name} ({p.guardian.phone})
                      </span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => setPreviewSlipPass(p)}
                    className="border-orange-300 text-orange-700 bg-orange-50 hover:bg-orange-100 text-xs font-semibold gap-1 dark:bg-orange-950/30 dark:border-orange-800 dark:text-orange-300"
                    title="View Official Paper Outing Pass Slip"
                  >
                    <FileText className="h-3.5 w-3.5 text-orange-600" />
                    Paper Slip
                  </Button>
                  <Button
                    size="sm"
                    onClick={() => handleIssueQR(p)}
                    className="bg-amber-600 hover:bg-amber-700 text-white text-xs font-semibold gap-1.5 shadow"
                  >
                    <QrCode className="h-4 w-4" />
                    Approve & Issue Cryptographic QR
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => onReject(p.id, "Hostel leave declined by Chief Warden.")}
                    className="border-red-300 text-red-600 hover:bg-red-50 text-xs"
                  >
                    Decline
                  </Button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="p-8 text-center text-slate-500">
            <CheckCircle2 className="h-10 w-10 text-emerald-500 mx-auto mb-2" />
            <h4 className="font-bold text-sm text-slate-800 dark:text-slate-200">
              No Pending Passes in Warden Queue
            </h4>
            <p className="text-xs text-slate-400 mt-1">
              All approved passes have had valid QR tokens issued for gate security.
            </p>
          </div>
        )}
      </div>

      {/* Official Paper Pass Slip Modal */}
      <PaperPassSlipModal
        pass={previewSlipPass}
        isOpen={!!previewSlipPass}
        onClose={() => setPreviewSlipPass(null)}
      />

    </div>
  );
};
