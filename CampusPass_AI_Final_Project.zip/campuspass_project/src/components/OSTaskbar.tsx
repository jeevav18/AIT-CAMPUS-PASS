import { useState, useEffect } from "react";
import { Play, Activity, Cpu, Wifi, Battery, Bell, Search } from "lucide-react";
import { playTick, playHover } from "@/lib/cyberAudio";

interface OSTaskbarProps {
  onToggleStart: () => void;
  activeApps: { id: string; title: string; icon: React.ComponentType<{ className?: string }>; isMinimized: boolean }[];
  onToggleMinimize: (appId: string) => void;
  onOpenNotifications: () => void;
  openSearch: () => void;
  cpuUsage: number;
  ramUsage: number;
}

const OSTaskbar = ({
  onToggleStart,
  activeApps,
  onToggleMinimize,
  onOpenNotifications,
  openSearch,
  cpuUsage,
  ramUsage,
}: OSTaskbarProps) => {
  const [timeStr, setTimeStr] = useState("");
  const [dateStr, setDateStr] = useState("");

  // Update clock
  useEffect(() => {
    const updateTime = () => {
      const d = new Date();
      setTimeStr(d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }));
      setDateStr(d.toLocaleDateString([], { month: "short", day: "2-digit" }));
    };
    updateTime();
    const timer = setInterval(updateTime, 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="fixed bottom-0 left-0 right-0 h-12 bg-black/90 border-t border-[#00FF66]/20 flex items-center justify-between px-3 md:px-4 z-[9999] font-mono text-[10px] text-white select-none">
      {/* Background ambient sweep */}
      <div className="absolute inset-0 bg-gradient-to-r from-[#00FF66]/5 via-transparent to-[#00E5FF]/5 pointer-events-none" />

      {/* Start Button & Search block */}
      <div className="flex items-center space-x-2">
        <button
          onMouseEnter={playHover}
          onClick={() => {
            playTick();
            onToggleStart();
          }}
          className="h-8 px-3 bg-[#00FF66]/15 border border-[#00FF66]/35 hover:bg-[#00FF66]/30 text-[#00FF66] font-extrabold rounded-md flex items-center space-x-1 cursor-pointer transition shadow-[0_0_8px_rgba(0,255,102,0.15)] hover:shadow-[0_0_12px_rgba(0,255,102,0.3)] uppercase font-oxanium text-glow-green"
        >
          <Play className="w-3.5 h-3.5 fill-[#00FF66] rotate-90" />
          <span>START</span>
        </button>

        {/* Desktop Application Search Shortcut */}
        <button
          onMouseEnter={playHover}
          onClick={() => {
            playTick();
            openSearch();
          }}
          className="p-2 border border-zinc-800 bg-zinc-950/40 text-gray-400 hover:text-[#00E5FF] hover:border-[#00E5FF]/30 rounded-md transition cursor-pointer md:flex items-center space-x-1.5 hidden"
          title="Search AI OS Applications"
        >
          <Search className="w-3.5 h-3.5" />
          <span className="text-[9px] uppercase font-bold tracking-wider">Search Node...</span>
        </button>
      </div>

      {/* Center Grid: Dynamic Active Running Windows tabs */}
      <div className="flex-1 flex justify-center items-center overflow-x-auto px-4 max-w-[50%] md:max-w-[60%] space-x-1.5 scrollbar-none scrollbar-thin">
        {activeApps.map((app) => (
          <button
            key={app.id}
            onMouseEnter={playHover}
            onClick={() => onToggleMinimize(app.id)}
            className={`h-8 px-2.5 rounded-md border flex items-center space-x-2 transition-all cursor-pointer truncate max-w-[140px] ${
              app.isMinimized
                ? "bg-black/30 border-zinc-800 text-gray-500 hover:text-gray-300"
                : "bg-gradient-to-b from-zinc-900 to-black border-[#00FF66]/30 text-[#00FF66] shadow-[0_0_8px_rgba(0,255,102,0.05)]"
            }`}
          >
            <app.icon className="w-3.5 h-3.5 shrink-0" />
            <span className="text-[9px] uppercase font-bold tracking-wider truncate hidden sm:inline">{app.title}</span>
            <span className={`w-1 h-1 rounded-full shrink-0 ${app.isMinimized ? "bg-gray-700" : "bg-[#00FF66] animate-pulse"}`} />
          </button>
        ))}
      </div>

      {/* Right Grid: Network, Telemetry meters, Live Clock */}
      <div className="flex items-center space-x-3">
        {/* Live system telemetry */}
        <div className="hidden lg:flex items-center space-x-3.5 border-r border-zinc-800 pr-3 text-[9px] text-gray-400 font-bold">
          <div className="flex items-center space-x-1.5">
            <Cpu className="w-3 h-3 text-[#00FF66]" />
            <span>CPU: <span className="text-white font-mono">{cpuUsage}%</span></span>
          </div>
          <div className="flex items-center space-x-1.5">
            <Activity className="w-3 h-3 text-[#00E5FF]" />
            <span>RAM: <span className="text-white font-mono">{ramUsage}%</span></span>
          </div>
        </div>

        {/* Mock Network / Battery */}
        <div className="flex items-center space-x-2 text-gray-500">
          <Wifi className="w-3.5 h-3.5 text-[#00FF66]" title="Network Coupling: Stable 4.8 THz" />
          <Battery className="w-3.5 h-3.5 text-[#00E5FF] rotate-90" title="Bypass Cell Capacity: 100%" />
        </div>

        {/* Alerts / Notifications Drawer Trigger */}
        <button
          onMouseEnter={playHover}
          onClick={() => {
            playTick();
            onOpenNotifications();
          }}
          className="p-1.5 border border-zinc-800 hover:border-[#00FF66]/30 hover:bg-[#00FF66]/5 rounded text-gray-400 hover:text-[#00FF66] transition cursor-pointer relative"
        >
          <Bell className="w-3.5 h-3.5" />
          <span className="absolute top-0.5 right-0.5 w-1.5 h-1.5 bg-[#FFC107] rounded-full animate-ping" />
        </button>

        {/* Live Date-Time Module */}
        <div className="border-l border-zinc-800 pl-3 flex flex-col items-end leading-tight text-[9px] text-gray-400 font-bold text-glow-green">
          <span className="text-white font-mono">{timeStr}</span>
          <span className="text-gray-500 mt-0.5">{dateStr}</span>
        </div>
      </div>
    </div>
  );
};

export default OSTaskbar;
