import React from "react";
import {
  Cloud,
  Sparkles,
  Code2,
  Bot,
  ArrowRightLeft,
  Zap,
  Cpu,
  GraduationCap,
  ArrowUpRight,
} from "lucide-react";
import { PORTFOLIO_DATA, ServiceItem } from "@/data/portfolioData";

export const ServicesSection: React.FC = () => {
  const getIcon = (iconName: string) => {
    switch (iconName) {
      case "Cloud":
        return <Cloud className="w-5 h-5 text-sky-500" />;
      case "Sparkles":
        return <Sparkles className="w-5 h-5 text-blue-500" />;
      case "Code2":
        return <Code2 className="w-5 h-5 text-indigo-500" />;
      case "Bot":
        return <Bot className="w-5 h-5 text-purple-500" />;
      case "ArrowRightLeft":
        return <ArrowRightLeft className="w-5 h-5 text-pink-500" />;
      case "Zap":
        return <Zap className="w-5 h-5 text-amber-500" />;
      case "Cpu":
        return <Cpu className="w-5 h-5 text-emerald-500" />;
      case "GraduationCap":
        return <GraduationCap className="w-5 h-5 text-blue-600" />;
      default:
        return <Code2 className="w-5 h-5 text-blue-500" />;
    }
  };

  return (
    <section id="capabilities" className="py-20 sm:py-28 bg-slate-50/60 dark:bg-[#0B1120] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-50 dark:bg-blue-950/60 border border-blue-200 dark:border-blue-800 text-blue-700 dark:text-blue-300 text-xs font-semibold uppercase tracking-wider mb-3">
            <span>Engineering Scope</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            What I Can Build & Deliver
          </h2>
          <p className="mt-3 text-base sm:text-lg text-slate-600 dark:text-slate-300">
            End-to-end technical deliverables ready for enterprise deployment, startup scalability, and institutional automation.
          </p>
        </div>

        {/* 8 Capability Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {PORTFOLIO_DATA.services.map((srv) => (
            <div
              key={srv.id}
              className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-2xs hover:shadow-xl hover:border-blue-500/50 dark:hover:border-blue-500/50 transition-all duration-300 flex flex-col justify-between group"
            >
              <div>
                <div className="w-12 h-12 rounded-2xl bg-slate-50 dark:bg-slate-800 border border-slate-200/60 dark:border-slate-700/60 flex items-center justify-center mb-4 group-hover:scale-105 transition-transform shadow-2xs">
                  {getIcon(srv.icon)}
                </div>

                <h3 className="text-base font-bold text-slate-900 dark:text-white tracking-tight mb-2 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
                  {srv.title}
                </h3>

                <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 leading-relaxed mb-4">
                  {srv.description}
                </p>
              </div>

              <div className="pt-3 border-t border-slate-100 dark:border-slate-800/80 flex flex-wrap gap-1.5">
                {srv.tags.map((tag, idx) => (
                  <span
                    key={idx}
                    className="px-2 py-0.5 rounded-md text-[10px] font-semibold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ServicesSection;
