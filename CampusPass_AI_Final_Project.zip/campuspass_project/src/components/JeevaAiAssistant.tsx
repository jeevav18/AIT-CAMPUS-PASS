import React, { useState } from "react";
import {
  MessageSquare,
  X,
  Send,
  Sparkles,
  Bot,
  User,
  CheckCircle2,
  FileText,
  Briefcase,
  ExternalLink,
} from "lucide-react";
import { PORTFOLIO_DATA } from "@/data/portfolioData";

interface Message {
  id: string;
  sender: "user" | "assistant";
  text: string;
  timestamp: string;
  actionButton?: {
    label: string;
    targetId: string;
  };
}

export const JeevaAiAssistant: React.FC<{ onOpenResume: () => void }> = ({
  onOpenResume,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      sender: "assistant",
      text: "Hello! I am Jeeva's Portfolio Assistant. How can I help you learn about his engineering skills, Salesforce expertise, project case studies, or full-time availability?",
      timestamp: "Just now",
    },
  ]);

  const quickQuestions = [
    "What is Jeeva's Salesforce background?",
    "Show me his top project case study",
    "What is his educational background & CGPA?",
    "Is he available for immediate hiring?",
  ];

  const handleSend = (textToSend?: string) => {
    const query = textToSend || input;
    if (!query.trim()) return;

    const userMsg: Message = {
      id: Date.now().toString(),
      sender: "user",
      text: query,
      timestamp: "Just now",
    };

    setMessages((prev) => [...prev, userMsg]);
    if (!textToSend) setInput("");

    // Simulate smart AI response grounded in PORTFOLIO_DATA
    setTimeout(() => {
      let reply = "";
      let action: { label: string; targetId: string } | undefined = undefined;
      const lower = query.toLowerCase();

      if (lower.includes("salesforce") || lower.includes("apex") || lower.includes("lwc")) {
        reply =
          "Jeeva is a certified Salesforce specialist with deep hands-on expertise in Lightning Web Components (LWC), Apex development, SOQL/SOSL queries, Flows, Process Automation, and REST API integrations with external cloud systems.";
        action = { label: "View Salesforce Skills", targetId: "skills" };
      } else if (lower.includes("project") || lower.includes("case study") || lower.includes("work")) {
        reply =
          "Jeeva has engineered high-impact systems including: 1) Enterprise Salesforce CRM Service Portal (with Apex & LWC), 2) MedPulse AI Telemedicine Hub, 3) SecureCloud Microservices Engine, and 4) Smart Campus IoT Energy Guardian.";
        action = { label: "Explore Projects", targetId: "projects" };
      } else if (lower.includes("education") || lower.includes("college") || lower.includes("cgpa") || lower.includes("degree")) {
        reply =
          "Jeeva is pursuing his Bachelor of Engineering in Electronics & Communication Engineering at Adithya Institute of Technology, Coimbatore (Class of 2027) with an impressive 8.10 CGPA.";
        action = { label: "View Education Details", targetId: "education" };
      } else if (lower.includes("hire") || lower.includes("available") || lower.includes("internship") || lower.includes("job") || lower.includes("notice")) {
        reply =
          "Yes! Jeeva is actively seeking full-time Software Engineer, Salesforce Developer, and Full-Stack Engineering roles. He is available with 0 days notice.";
        action = { label: "Contact Jeeva Directly", targetId: "contact" };
      } else if (lower.includes("resume") || lower.includes("cv")) {
        reply =
          "You can preview and download Jeeva's official ATS-optimized Resume directly via the top navigation bar or the button below.";
        onOpenResume();
      } else {
        reply =
          "Jeeva V is an engineer specializing in Salesforce Development (Apex, LWC), Modern Full-Stack Systems (React, TypeScript, Node.js), and Cloud Engineering. Feel free to explore the interactive sections or download his resume!";
        action = { label: "Explore Experience", targetId: "experience" };
      }

      const assistantMsg: Message = {
        id: (Date.now() + 1).toString(),
        sender: "assistant",
        text: reply,
        timestamp: "Just now",
        actionButton: action,
      };

      setMessages((prev) => [...prev, assistantMsg]);
    }, 450);
  };

  const scrollToSection = (id: string) => {
    const elem = document.getElementById(id);
    if (elem) {
      const offset = 76;
      const elementPosition = elem.getBoundingClientRect().top + window.pageYOffset - offset;
      window.scrollTo({
        top: elementPosition,
        behavior: "smooth",
      });
    }
  };

  return (
    <>
      {/* Floating Launcher Trigger */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="fixed bottom-6 right-6 z-40 p-3.5 sm:p-4 rounded-2xl bg-blue-600 hover:bg-blue-700 text-white shadow-xl shadow-blue-600/30 hover:scale-105 active:scale-95 transition-all cursor-pointer flex items-center gap-2 group"
        aria-label="Open AI Recruiter Assistant"
      >
        <Sparkles className="w-5 h-5 animate-pulse" />
        <span className="hidden sm:inline font-bold text-xs">AI Recruiter Assistant</span>
      </button>

      {/* Chat Window */}
      {isOpen && (
        <div className="fixed bottom-20 right-4 sm:right-6 z-50 w-[calc(100vw-32px)] sm:w-[390px] h-[520px] bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl flex flex-col overflow-hidden animate-in slide-in-from-bottom-5 duration-200">
          {/* Header */}
          <div className="px-5 py-3.5 bg-gradient-to-r from-blue-600 to-indigo-600 text-white flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-white/20 backdrop-blur-sm flex items-center justify-center">
                <Bot className="w-4 h-4" />
              </div>
              <div>
                <h3 className="font-bold text-xs sm:text-sm">Jeeva AI Assistant</h3>
                <p className="text-[10px] text-blue-100/90 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                  Instant Recruiter Helper
                </p>
              </div>
            </div>

            <button
              onClick={() => setIsOpen(false)}
              className="p-1 rounded-lg text-white/80 hover:text-white hover:bg-white/10 transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Chat Messages */}
          <div className="flex-1 p-4 overflow-y-auto space-y-3 bg-slate-50/50 dark:bg-slate-950/40 text-xs">
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex gap-2 ${
                  msg.sender === "user" ? "justify-end" : "justify-start"
                }`}
              >
                {msg.sender === "assistant" && (
                  <div className="w-6 h-6 rounded-full bg-blue-600 text-white flex items-center justify-center shrink-0 mt-0.5">
                    <Sparkles className="w-3 h-3" />
                  </div>
                )}

                <div
                  className={`max-w-[82%] p-3 rounded-2xl ${
                    msg.sender === "user"
                      ? "bg-blue-600 text-white rounded-tr-xs"
                      : "bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 border border-slate-200 dark:border-slate-700 rounded-tl-xs shadow-2xs"
                  }`}
                >
                  <p className="leading-relaxed">{msg.text}</p>
                  {msg.actionButton && (
                    <button
                      onClick={() => {
                        scrollToSection(msg.actionButton!.targetId);
                      }}
                      className="mt-2 inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-[11px] font-bold bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 border border-blue-200 dark:border-blue-800 hover:bg-blue-100 cursor-pointer"
                    >
                      <span>{msg.actionButton.label}</span>
                      <ExternalLink className="w-3 h-3" />
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>

          {/* Suggested Prompts */}
          <div className="p-2.5 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 flex gap-1.5 overflow-x-auto text-[11px]">
            {quickQuestions.map((q, idx) => (
              <button
                key={idx}
                onClick={() => handleSend(q)}
                className="px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-blue-50 dark:hover:bg-blue-950/40 hover:text-blue-600 dark:hover:text-blue-400 whitespace-nowrap transition-colors border border-slate-200 dark:border-slate-700 cursor-pointer"
              >
                {q}
              </button>
            ))}
          </div>

          {/* Input Bar */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSend();
            }}
            className="p-2.5 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 flex items-center gap-2"
          >
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask anything about Jeeva's experience..."
              className="flex-1 px-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 text-xs text-slate-900 dark:text-white placeholder-slate-400 border border-slate-200 dark:border-slate-700 focus:outline-none focus:ring-1 focus:ring-blue-500"
            />
            <button
              type="submit"
              className="p-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white shrink-0 transition-colors"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      )}
    </>
  );
};

export default JeevaAiAssistant;
