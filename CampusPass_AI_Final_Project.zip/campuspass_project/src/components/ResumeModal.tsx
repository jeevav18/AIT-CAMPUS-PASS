import React, { useState } from "react";
import {
  X,
  Download,
  Printer,
  Mail,
  Phone,
  MapPin,
  Linkedin,
  Github,
  CheckCircle2,
  Copy,
  Check,
  FileText,
  Sparkles,
} from "lucide-react";
import { PORTFOLIO_DATA } from "@/data/portfolioData";

interface ResumeModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ResumeModal: React.FC<ResumeModalProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<"formatted" | "plainText">("formatted");
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const handlePrint = () => {
    window.print();
  };

  const getPlainTextResume = () => {
    return `
================================================================================
JEEVA V — SOFTWARE DEVELOPER & SALESFORCE ENGINEER
Email: ${PORTFOLIO_DATA.personal.email} | Phone: ${PORTFOLIO_DATA.personal.phone} | Location: ${PORTFOLIO_DATA.personal.location}
LinkedIn: ${PORTFOLIO_DATA.personal.linkedinUrl} | GitHub: ${PORTFOLIO_DATA.personal.githubUrl}
Portfolio: https://jeeva-portfolio.web.app
================================================================================

PROFESSIONAL SUMMARY
--------------------------------------------------------------------------------
${PORTFOLIO_DATA.personal.statement}

EDUCATION
--------------------------------------------------------------------------------
${PORTFOLIO_DATA.education[0].degree}
${PORTFOLIO_DATA.education[0].institution} (${PORTFOLIO_DATA.education[0].period})
Cumulative Grade: ${PORTFOLIO_DATA.education[0].grade}
Key Coursework: ${PORTFOLIO_DATA.education[0].coursework.join(", ")}

TECHNICAL SKILLS MATRIX
--------------------------------------------------------------------------------
* Salesforce: Apex, Lightning Web Components (LWC), SOQL/SOSL, Flows, Process Builder, REST Integrations
* Languages: TypeScript, JavaScript, Python, Apex, SQL, C/C++, HTML5, CSS3
* Frontend: React.js, Next.js, Tailwind CSS, Vite, Redux Toolkit, State Management
* Backend: Node.js, Express, FastAPI, Django REST Framework, RESTful APIs, WebSockets
* Databases & Cloud: PostgreSQL, MongoDB, Redis, AWS (S3, Lambda, EC2), Firebase, Docker
* Systems & Security: Git, GitHub Actions (CI/CD), OWASP Top 10, JWT/OAuth2, Linux

WORK & INTERNSHIP EXPERIENCE
--------------------------------------------------------------------------------
${PORTFOLIO_DATA.experience
  .map(
    (e) => `
${e.role.toUpperCase()} | ${e.company} (${e.period} | ${e.location})
What I Worked On: ${e.whatIWorkedOn}
Key Responsibilities:
${e.responsibilities.map((r) => `  * ${r}`).join("\n")}
Impact & Achievements:
${e.achievements.map((a) => `  * ${a}`).join("\n")}
Technologies: ${e.technologies.join(", ")}
`
  )
  .join("\n")}

FEATURED ENGINEERING PROJECTS
--------------------------------------------------------------------------------
${PORTFOLIO_DATA.projects
  .map(
    (p) => `
* ${p.title} (${p.categoryLabel})
  Description: ${p.shortDesc}
  Architecture: ${p.caseStudy.architecture}
  Technologies: ${p.technologies.join(", ")}
  Key Impact: ${p.metrics}
  GitHub: ${p.githubUrl}
`
  )
  .join("\n")}

VERIFIED INDUSTRY CERTIFICATIONS
--------------------------------------------------------------------------------
${PORTFOLIO_DATA.certifications
  .map((c) => `* ${c.title} — Issued by ${c.issuer} (${c.issueDate}) | Credential ID: ${c.credentialId}`)
  .join("\n")}

AWARDS & RECOGNITION
--------------------------------------------------------------------------------
${PORTFOLIO_DATA.achievements
  .map((a) => `* ${a.title} (${a.year}) — ${a.organization}: ${a.description} [${a.metrics}]`)
  .join("\n")}
================================================================================
`;
  };

  const handleCopyPlainText = () => {
    navigator.clipboard.writeText(getPlainTextResume());
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleDownload = () => {
    const element = document.createElement("a");
    const resumeText = getPlainTextResume();
    const file = new Blob([resumeText], { type: "text/plain" });
    element.href = URL.createObjectURL(file);
    element.download = "Jeeva_V_Resume_ATS.txt";
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 overflow-y-auto bg-slate-950/75 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className="relative w-full max-w-4xl bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 max-h-[92vh] overflow-y-auto flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Sticky Control Bar */}
        <div className="sticky top-0 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md px-6 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between z-10">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-blue-600 text-white flex items-center justify-center font-bold text-xs">
              JV
            </div>
            <div>
              <h3 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white">
                Resume Preview — Jeeva V
              </h3>
              <p className="text-xs text-slate-500">ATS-Optimized & Executive Document</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* View Switcher */}
            <div className="hidden sm:flex items-center bg-slate-100 dark:bg-slate-800 p-1 rounded-xl text-xs font-semibold">
              <button
                onClick={() => setActiveTab("formatted")}
                className={`px-3 py-1 rounded-lg transition-colors cursor-pointer ${
                  activeTab === "formatted"
                    ? "bg-white dark:bg-slate-900 text-blue-600 dark:text-blue-400 shadow-2xs"
                    : "text-slate-600 dark:text-slate-400"
                }`}
              >
                Executive Layout
              </button>
              <button
                onClick={() => setActiveTab("plainText")}
                className={`px-3 py-1 rounded-lg transition-colors cursor-pointer ${
                  activeTab === "plainText"
                    ? "bg-white dark:bg-slate-900 text-blue-600 dark:text-blue-400 shadow-2xs"
                    : "text-slate-600 dark:text-slate-400"
                }`}
              >
                ATS Plain Text
              </button>
            </div>

            <button
              onClick={handleDownload}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold text-white bg-blue-600 hover:bg-blue-700 transition-colors cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download</span>
            </button>

            <button
              onClick={handlePrint}
              className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 transition-colors cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print</span>
            </button>

            <button
              onClick={onClose}
              className="p-1.5 rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors cursor-pointer"
              aria-label="Close"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content Area */}
        {activeTab === "formatted" ? (
          <div className="p-6 sm:p-10 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 space-y-6">
            <div className="bg-white dark:bg-slate-900 p-6 sm:p-10 rounded-2xl shadow-2xs border border-slate-200/80 dark:border-slate-800 space-y-6">
              {/* Header */}
              <div className="border-b border-slate-200 dark:border-slate-800 pb-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-2xl bg-gradient-to-tr from-blue-600 to-indigo-600 text-white flex items-center justify-center font-extrabold text-xl shadow-sm border border-blue-400/30 shrink-0">
                    JV
                  </div>
                  <div>
                    <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white tracking-tight">
                      {PORTFOLIO_DATA.personal.name}
                    </h1>
                    <p className="text-sm font-semibold text-blue-600 dark:text-blue-400 mt-0.5">
                      {PORTFOLIO_DATA.personal.title}
                    </p>
                  </div>
                </div>

                <div className="text-xs text-slate-600 dark:text-slate-400 space-y-1 sm:text-right">
                  <p className="flex items-center sm:justify-end gap-1.5">
                    <Mail className="w-3.5 h-3.5 text-blue-600" />
                    <span>{PORTFOLIO_DATA.personal.email}</span>
                  </p>
                  <p className="flex items-center sm:justify-end gap-1.5">
                    <Phone className="w-3.5 h-3.5 text-blue-600" />
                    <span>{PORTFOLIO_DATA.personal.phone}</span>
                  </p>
                  <p className="flex items-center sm:justify-end gap-1.5">
                    <MapPin className="w-3.5 h-3.5 text-blue-600" />
                    <span>{PORTFOLIO_DATA.personal.location}</span>
                  </p>
                </div>
              </div>

              {/* Summary */}
              <div className="space-y-1.5">
                <h2 className="text-xs font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400">
                  Professional Profile
                </h2>
                <p className="text-xs sm:text-sm text-slate-700 dark:text-slate-300 leading-relaxed">
                  {PORTFOLIO_DATA.personal.statement}
                </p>
              </div>

              {/* Education */}
              <div className="space-y-2">
                <h2 className="text-xs font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400">
                  Education & Honors
                </h2>
                <div className="flex justify-between items-baseline text-xs sm:text-sm">
                  <div>
                    <p className="font-bold text-slate-900 dark:text-white">
                      {PORTFOLIO_DATA.education[0].degree}
                    </p>
                    <p className="text-xs text-slate-600 dark:text-slate-400">
                      {PORTFOLIO_DATA.education[0].institution} —{" "}
                      <span className="text-emerald-600 dark:text-emerald-400 font-bold">
                        CGPA {PORTFOLIO_DATA.education[0].grade}
                      </span>
                    </p>
                  </div>
                  <span className="text-xs text-slate-500 font-medium">
                    {PORTFOLIO_DATA.education[0].period}
                  </span>
                </div>
              </div>

              {/* Skills Matrix */}
              <div className="space-y-2">
                <h2 className="text-xs font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400">
                  Core Skills Matrix
                </h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                  <div>
                    <span className="font-bold text-slate-900 dark:text-white">Salesforce & Cloud: </span>
                    <span className="text-slate-600 dark:text-slate-300">
                      Apex, LWC, SOQL/SOSL, Flows, REST APIs, AWS (S3, Lambda)
                    </span>
                  </div>
                  <div>
                    <span className="font-bold text-slate-900 dark:text-white">Full-Stack & Languages: </span>
                    <span className="text-slate-600 dark:text-slate-300">
                      TypeScript, React, Node.js, Python, PostgreSQL, MongoDB, Redis
                    </span>
                  </div>
                </div>
              </div>

              {/* Work Experience */}
              <div className="space-y-4">
                <h2 className="text-xs font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400">
                  Work Experience
                </h2>
                {PORTFOLIO_DATA.experience.map((exp) => (
                  <div key={exp.id} className="space-y-1.5">
                    <div className="flex justify-between items-baseline text-xs sm:text-sm">
                      <span className="font-bold text-slate-900 dark:text-white">
                        {exp.role} — <span className="font-semibold text-blue-600 dark:text-blue-400">{exp.company}</span>
                      </span>
                      <span className="text-xs text-slate-500 font-medium">{exp.period}</span>
                    </div>
                    <p className="text-xs text-slate-600 dark:text-slate-400">{exp.description}</p>
                    <ul className="list-disc list-inside space-y-0.5 text-xs text-slate-700 dark:text-slate-300">
                      {exp.responsibilities.map((r, i) => (
                        <li key={i}>{r}</li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>

              {/* Projects */}
              <div className="space-y-3">
                <h2 className="text-xs font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400">
                  Featured Engineering Systems
                </h2>
                {PORTFOLIO_DATA.projects.map((p) => (
                  <div key={p.id} className="space-y-1 text-xs">
                    <div className="flex justify-between font-bold text-slate-900 dark:text-white">
                      <span>{p.title}</span>
                      <span className="text-blue-600 dark:text-blue-400 font-normal">{p.categoryLabel}</span>
                    </div>
                    <p className="text-slate-600 dark:text-slate-400">{p.shortDesc}</p>
                    <p className="text-[11px] text-slate-500 font-mono">
                      Tech: {p.technologies.join(", ")} | Impact: {p.metrics}
                    </p>
                  </div>
                ))}
              </div>

              {/* Certifications & Honors */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
                <div>
                  <h2 className="text-xs font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400 mb-1.5">
                    Certifications
                  </h2>
                  <ul className="space-y-1 text-xs text-slate-700 dark:text-slate-300">
                    {PORTFOLIO_DATA.certifications.map((c) => (
                      <li key={c.id} className="flex items-center gap-1.5">
                        <CheckCircle2 className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                        <span>{c.title} ({c.issueDate})</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div>
                  <h2 className="text-xs font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400 mb-1.5">
                    Hackathons & Honors
                  </h2>
                  <ul className="space-y-1 text-xs text-slate-700 dark:text-slate-300">
                    {PORTFOLIO_DATA.achievements.map((a) => (
                      <li key={a.id} className="flex items-center gap-1.5">
                        <Sparkles className="w-3.5 h-3.5 text-amber-500 shrink-0" />
                        <span>{a.title}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="p-6 bg-slate-900 text-slate-200 font-mono text-xs overflow-x-auto space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-slate-400">Plain text format for direct ATS forms copy-paste</span>
              <button
                onClick={handleCopyPlainText}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-sans text-xs font-semibold transition-colors"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-300" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? "Copied to Clipboard!" : "Copy Full Text"}</span>
              </button>
            </div>
            <pre className="whitespace-pre-wrap leading-relaxed">{getPlainTextResume()}</pre>
          </div>
        )}
      </div>
    </div>
  );
};

export default ResumeModal;
