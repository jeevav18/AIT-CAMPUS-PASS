import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Power, RefreshCw, Terminal } from "lucide-react";
import { playTick, playHover, playGlitchSweep, playSuccessChime } from "@/lib/cyberAudio";

interface OSShutdownProps {
  onReboot: () => void;
}

const shutdownSteps = [
  "HALTING DAEMON THREADS...",
  "DISCONNECTING GITHUB SYNAPSE TUNNELS...",
  "UNMOUNTING VIRTUAL SFDX FILESYSTEMS...",
  "TERMINATING COGNITIVE AI_COPILOT INSTANCE...",
  "PURGING TEMPORARY MEMORY BLOCKS...",
  "CLEARING SHADOW DOM BUFFER CACHES...",
  "POWER DOWN STAGE 1: SYSTEM CLUSTERS OFFLINE",
  "POWER DOWN STAGE 2: GRAVITY MATRIX HALTED",
  "JEEVA OS SHUTDOWN COMPLETED. SYSTEM DISENGAGED."
];

const OSShutdown = ({ onReboot }: OSShutdownProps) => {
  const [logs, setLogs] = useState<string[]>([]);
  const [isFullyOff, setIsFullyOff] = useState(false);

  useEffect(() => {
    let currentStep = 0;
    const interval = setInterval(() => {
      if (currentStep < shutdownSteps.length) {
        setLogs((prev) => [...prev, shutdownSteps[currentStep]]);
        playTick();
        currentStep++;
      } else {
        clearInterval(interval);
        setTimeout(() => {
          setIsFullyOff(true);
        }, 1000);
      }
    }, 450);

    return () => clearInterval(interval);
  }, []);

  const handleReboot = () => {
    playGlitchSweep();
    setIsFullyOff(false);
    setLogs([]);
    setTimeout(() => {
      onReboot();
    }, 300);
  };

  return (
    <div className="fixed inset-0 z-[100000] bg-black flex flex-col items-center justify-center font-mono text-xs text-white overflow-hidden p-4">
      {/* Grid scanning effects */}
      <div className="absolute inset-0 bg-scanlines opacity-[0.06] pointer-events-none" />

      {!isFullyOff ? (
        /* Sequential log shutdown */
        <div className="w-full max-w-md bg-[#050505] border border-red-500/20 p-6 rounded-lg space-y-4 shadow-[0_0_40px_rgba(239,68,68,0.1)]">
          <div className="flex items-center space-x-2 border-b border-red-500/15 pb-2 text-red-500">
            <Terminal className="w-4 h-4 animate-pulse" />
            <span className="font-bold uppercase tracking-widest text-[10px]">OS_CORE_TERMINATION</span>
          </div>

          <div className="space-y-1.5 min-h-[160px] text-red-400 font-bold font-mono text-[10px] uppercase">
            {logs.map((log, idx) => (
              <div key={idx} className="flex justify-between">
                <span>{`> ${log}`}</span>
                <span>[OK]</span>
              </div>
            ))}
          </div>

          <div className="flex justify-between items-center text-[8px] text-gray-500 uppercase font-bold border-t border-zinc-900 pt-3">
            <span>ADDR: 0x00000</span>
            <span className="animate-pulse text-red-500">GRACEFUL_HALT_ENGAGED</span>
          </div>
        </div>
      ) : (
        /* Fully powered down screen */
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1 }}
          className="flex flex-col items-center space-y-6 text-center z-10"
        >
          <div className="space-y-2">
            <h3 className="text-sm font-bold text-gray-600 uppercase tracking-widest font-oxanium">System offline</h3>
            <p className="text-[10px] text-zinc-700 max-w-xs leading-normal">
              Thank you for evaluating JEEVA OS X. Feel free to re-engage the power core.
            </p>
          </div>

          <button
            onMouseEnter={playHover}
            onClick={handleReboot}
            className="w-16 h-16 rounded-full border-2 border-red-500/40 hover:border-red-500 bg-red-500/10 hover:bg-red-500 text-red-500 hover:text-white flex items-center justify-center transition-all duration-300 cursor-pointer shadow-[0_0_15px_rgba(239,68,68,0.1)] hover:shadow-[0_0_25px_rgba(239,68,68,0.4)] animate-pulse"
            title="Reboot System Core"
          >
            <Power className="w-8 h-8" />
          </button>

          <span className="text-[8px] text-zinc-800 font-extrabold uppercase tracking-widest">
            TAP SECURE SWITCH TO RE-INITIALIZE
          </span>
        </motion.div>
      )}
    </div>
  );
};

export default OSShutdown;
