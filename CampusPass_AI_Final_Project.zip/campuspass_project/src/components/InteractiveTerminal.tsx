import { useState, useRef, useEffect } from "react";
import { motion } from "framer-motion";
import { Terminal as TermIcon, CornerDownLeft, Maximize2, Minimize2, Trash2, Volume2, Shield } from "lucide-react";
import { PORTFOLIO_DATA } from "@/data/portfolioData";
import { playKeyStroke, playTick, playSuccessChime, playGlitchSweep } from "@/lib/cyberAudio";

interface CommandOutput {
  id: string;
  command: string;
  response: string | React.ReactNode;
  time: string;
  isError?: boolean;
}

export const InteractiveTerminal = () => {
  const [inputVal, setInputVal] = useState("");
  const [history, setHistory] = useState<CommandOutput[]>([
    {
      id: "init-1",
      command: "sysinfo --status",
      response: `SYSTEM: ${PORTFOLIO_DATA.personal.codename} v3.4.0 (x86_64-hardened)\nSTATUS: ${PORTFOLIO_DATA.personal.systemStatus}\nCLEARANCE: ${PORTFOLIO_DATA.personal.clearanceLevel}\nType 'help' to view available commands.`,
      time: new Date().toLocaleTimeString(),
    },
  ]);
  const [commandHistory, setCommandHistory] = useState<string[]>([]);
  const [historyIndex, setHistoryIndex] = useState<number>(-1);
  const [isFullScreen, setIsFullScreen] = useState(false);

  const inputRef = useRef<HTMLInputElement>(null);
  const terminalEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    terminalEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [history]);

  const handleCommandExecution = (cmdRaw: string) => {
    const cmd = cmdRaw.trim().toLowerCase();
    if (!cmd) return;

    playKeyStroke();
    setCommandHistory((prev) => [cmdRaw, ...prev]);
    setHistoryIndex(-1);

    const time = new Date().toLocaleTimeString();
    const [baseCmd, ...args] = cmd.split(" ");

    let responseContent: string | React.ReactNode = "";
    let isError = false;

    switch (baseCmd) {
      case "help":
        responseContent = (
          <div className="space-y-1.5 text-xs">
            <div className="text-[#00FF66] font-bold">AVAILABLE COMMANDS:</div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-1">
              <div><span className="text-[#00E5FF] font-bold">whoami</span> - Display candidate identity</div>
              <div><span className="text-[#00E5FF] font-bold">about</span> - Read executive profile summary</div>
              <div><span className="text-[#00E5FF] font-bold">skills</span> - List 3D technical proficiencies</div>
              <div><span className="text-[#00E5FF] font-bold">projects</span> - Show major software repositories</div>
              <div><span className="text-[#00E5FF] font-bold">experience</span> - Trace career history</div>
              <div><span className="text-[#00E5FF] font-bold">certifications</span> - Display verified credentials</div>
              <div><span className="text-[#00E5FF] font-bold">contact</span> - Jump to secure transmission channel</div>
              <div><span className="text-[#00E5FF] font-bold">socials</span> - Display verified uplink links</div>
              <div><span className="text-[#00E5FF] font-bold">scan</span> - Run live system threat audit</div>
              <div><span className="text-[#00E5FF] font-bold">clear</span> - Purge terminal console buffer</div>
            </div>
          </div>
        );
        break;

      case "whoami":
        responseContent = `CANDIDATE: ${PORTFOLIO_DATA.personal.name}\nCODENAME: ${PORTFOLIO_DATA.personal.codename}\nPRIMARY ROLE: ${PORTFOLIO_DATA.personal.title}\nLOCATION: ${PORTFOLIO_DATA.personal.location}\nCLEARANCE: ${PORTFOLIO_DATA.personal.clearanceLevel}`;
        break;

      case "about":
        responseContent = `${PORTFOLIO_DATA.about.summary}\n\nCAREER GOAL: ${PORTFOLIO_DATA.about.careerGoal}`;
        break;

      case "skills":
        responseContent = (
          <div className="space-y-1">
            <div className="text-[#00FF66] font-bold">PRIMARY TECHNICAL CORES:</div>
            {PORTFOLIO_DATA.skills.map((s) => (
              <div key={s.id} className="flex justify-between text-xs max-w-sm">
                <span className="text-gray-300">› {s.name}</span>
                <span className="text-[#00E5FF] font-bold">{s.level} ({s.score}%)</span>
              </div>
            ))}
          </div>
        );
        break;

      case "projects":
        responseContent = (
          <div className="space-y-1.5">
            <div className="text-[#00E5FF] font-bold">ACTIVE ENTERPRISE REPOSITORIES:</div>
            {PORTFOLIO_DATA.projects.map((p) => (
              <div key={p.id} className="text-xs">
                <span className="text-[#00FF66] font-bold">[{p.badge}]</span> {p.title} - <span className="text-gray-400">{p.category}</span>
              </div>
            ))}
          </div>
        );
        break;

      case "experience":
        responseContent = (
          <div className="space-y-1">
            <div className="text-[#BF5AF2] font-bold">CAREER SYSTEM TRACE:</div>
            {PORTFOLIO_DATA.experience.map((e) => (
              <div key={e.id} className="text-xs">
                <span className="text-white font-bold">{e.role}</span> @ {e.organization} ({e.period})
              </div>
            ))}
          </div>
        );
        break;

      case "certifications":
        responseContent = (
          <div className="space-y-1">
            <div className="text-[#00FF66] font-bold">VERIFIED BADGES:</div>
            {PORTFOLIO_DATA.certifications.map((c) => (
              <div key={c.id} className="text-xs text-gray-300">
                › {c.title} [{c.issuer}] - ID: {c.credentialId}
              </div>
            ))}
          </div>
        );
        break;

      case "contact": {
        responseContent = `Navigating to secure communication channel...\nEMAIL: ${PORTFOLIO_DATA.personal.email}\nPHONE: ${PORTFOLIO_DATA.personal.phone}`;
        const contactElem = document.getElementById("contact");
        if (contactElem) {
          contactElem.scrollIntoView({ behavior: "smooth" });
        }
        break;
      }

      case "socials":
        responseContent = `GITHUB: ${PORTFOLIO_DATA.personal.githubUrl}\nLINKEDIN: ${PORTFOLIO_DATA.personal.linkedinUrl}\nTRAILHEAD: ${PORTFOLIO_DATA.personal.trailheadUrl || "N/A"}\nLEETCODE: ${PORTFOLIO_DATA.personal.leetcodeUrl || "N/A"}`;
        break;

      case "scan":
        playGlitchSweep();
        responseContent = `[AUDIT STARTED] Probing port range 1-65535...\n[OK] Zero unauthenticated listeners discovered.\n[OK] TLS 1.3 cryptographic cipher integrity: 100%\n[OK] Threat radar status: SECURE`;
        break;

      case "clear":
        setHistory([]);
        setInputVal("");
        return;

      case "sudo":
        responseContent = `Permission denied: ${PORTFOLIO_DATA.personal.codename} is logged in as root. No privilege escalation needed.`;
        break;

      case "date":
        responseContent = new Date().toUTCString();
        break;

      case "echo":
        responseContent = args.join(" ") || "";
        break;

      default:
        isError = true;
        responseContent = `Command not recognized: '${cmdRaw}'. Type 'help' for a list of valid commands.`;
        break;
    }

    setHistory((prev) => [
      ...prev,
      {
        id: Math.random().toString(),
        command: cmdRaw,
        response: responseContent,
        time,
        isError,
      },
    ]);

    setInputVal("");
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    playKeyStroke();

    if (e.key === "Enter") {
      handleCommandExecution(inputVal);
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      if (commandHistory.length > 0) {
        const nextIndex = Math.min(historyIndex + 1, commandHistory.length - 1);
        setHistoryIndex(nextIndex);
        setInputVal(commandHistory[nextIndex]);
      }
    } else if (e.key === "ArrowDown") {
      e.preventDefault();
      if (historyIndex > 0) {
        const prevIndex = historyIndex - 1;
        setHistoryIndex(prevIndex);
        setInputVal(commandHistory[prevIndex]);
      } else if (historyIndex === 0) {
        setHistoryIndex(-1);
        setInputVal("");
      }
    } else if (e.key === "Tab") {
      e.preventDefault();
      // Simple tab autocompletion
      const commands = ["help", "whoami", "about", "skills", "projects", "experience", "certifications", "contact", "socials", "scan", "clear"];
      const match = commands.find((c) => c.startsWith(inputVal.toLowerCase().trim()));
      if (match) {
        setInputVal(match);
      }
    }
  };

  return (
    <section id="terminal" className="relative py-20 px-4 max-w-5xl mx-auto scroll-mt-20">
      {/* Section Header */}
      <div className="flex flex-col items-center text-center mb-12 space-y-3">
        <div className="flex items-center space-x-2 px-3 py-1 bg-[#00FF66]/10 border border-[#00FF66]/30 rounded-full text-xs font-mono text-[#00FF66]">
          <TermIcon className="w-3.5 h-3.5" />
          <span className="tracking-widest uppercase">MODULE: INTERACTIVE_SHELL_v3</span>
        </div>
        <h2 className="text-3xl sm:text-5xl font-bebas tracking-wider text-white">
          HACKER <span className="text-[#00FF66] text-glow-green">COMMAND TERMINAL</span>
        </h2>
        <p className="text-sm text-gray-400 max-w-2xl font-mono">
          Execute direct CLI commands into candidate memory. Type <span className="text-[#00FF66] font-bold">help</span>, <span className="text-[#00E5FF] font-bold">whoami</span>, <span className="text-amber-400 font-bold">skills</span>, or <span className="text-[#BF5AF2] font-bold">projects</span>.
        </p>
      </div>

      {/* Terminal Window Container */}
      <div
        className={`bg-[#050505] border-2 border-[#00FF66]/40 rounded-xl overflow-hidden shadow-[0_0_40px_rgba(0,255,102,0.15)] font-mono transition-all ${
          isFullScreen ? "fixed inset-4 z-[99999] flex flex-col" : "relative min-h-[420px]"
        }`}
      >
        {/* Terminal Header Bar */}
        <div className="bg-black border-b border-[#00FF66]/20 px-4 py-2.5 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <span className="w-3 h-3 rounded-full bg-red-500/80 cursor-pointer" onClick={() => setHistory([])} />
            <span className="w-3 h-3 rounded-full bg-yellow-500/80" />
            <span className="w-3 h-3 rounded-full bg-[#00FF66]/80" />
            <span className="text-xs text-gray-400 ml-2 font-bold">
              visitor@{PORTFOLIO_DATA.terminalWelcome.hostName}:~
            </span>
          </div>

          <div className="flex items-center space-x-3 text-xs text-gray-400">
            <button
              onClick={() => {
                playTick();
                setHistory([]);
              }}
              className="hover:text-red-400 transition cursor-pointer flex items-center space-x-1"
              title="Clear Buffer"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Clear</span>
            </button>

            <button
              onClick={() => {
                playTick();
                setIsFullScreen(!isFullScreen);
              }}
              className="hover:text-[#00FF66] transition cursor-pointer"
              title="Toggle Fullscreen"
            >
              {isFullScreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
            </button>
          </div>
        </div>

        {/* Terminal Body Screen */}
        <div
          onClick={() => inputRef.current?.focus()}
          className="p-4 sm:p-6 bg-black/95 flex-1 overflow-y-auto space-y-4 text-xs sm:text-sm text-gray-300 max-h-[380px] sm:max-h-[440px] scrollbar-thin cursor-text"
        >
          {/* ASCII Banner */}
          <div className="text-[9px] sm:text-[10px] text-[#00FF66] font-mono leading-none select-none opacity-80 overflow-x-auto">
            {PORTFOLIO_DATA.terminalWelcome.bannerArt.map((line, i) => (
              <pre key={i} className="font-mono">{line}</pre>
            ))}
          </div>

          {/* Quick Suggestion Chips */}
          <div className="flex flex-wrap gap-1.5 pt-2">
            <span className="text-gray-500 text-xs mr-1">Try clicking:</span>
            {["whoami", "skills", "projects", "experience", "scan", "contact", "help"].map((cmd) => (
              <button
                key={cmd}
                onClick={(e) => {
                  e.stopPropagation();
                  handleCommandExecution(cmd);
                }}
                className="px-2 py-0.5 rounded bg-[#00FF66]/10 hover:bg-[#00FF66]/20 border border-[#00FF66]/30 text-[#00FF66] text-xs transition cursor-pointer font-bold"
              >
                {cmd}
              </button>
            ))}
          </div>

          {/* History Output Stream */}
          <div className="space-y-4 pt-2">
            {history.map((item) => (
              <div key={item.id} className="space-y-1">
                <div className="flex items-center space-x-2 text-[#00E5FF]">
                  <span className="text-[#00FF66]">visitor@portfolio:~$</span>
                  <span className="font-bold text-white">{item.command}</span>
                  <span className="text-[10px] text-gray-600 ml-auto">{item.time}</span>
                </div>
                <div
                  className={`pl-4 whitespace-pre-wrap ${
                    item.isError ? "text-red-400" : "text-gray-300"
                  }`}
                >
                  {item.response}
                </div>
              </div>
            ))}
          </div>

          {/* Active Input Line */}
          <div className="flex items-center space-x-2 text-[#00FF66] pt-2">
            <span className="shrink-0 font-bold">visitor@portfolio:~$</span>
            <input
              ref={inputRef}
              type="text"
              value={inputVal}
              onChange={(e) => setInputVal(e.target.value)}
              onKeyDown={handleKeyDown}
              className="w-full bg-transparent text-white focus:outline-none font-mono text-xs sm:text-sm"
              autoFocus
              placeholder="Type command here..."
              spellCheck={false}
              autoComplete="off"
            />
          </div>

          <div ref={terminalEndRef} />
        </div>
      </div>
    </section>
  );
};
export default InteractiveTerminal;
