import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { toast } from "sonner";
import { Trash2, Mail } from "lucide-react";
import { format } from "date-fns";

const MessagesTab = () => {
  const queryClient = useQueryClient();

  const { data: messages } = useQuery({
    queryKey: ["messages"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("messages")
        .select("*")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("messages").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["messages"] });
      toast.success("Message deleted successfully");
    },
  });

  return (
    <div className="space-y-4">
      {messages && messages.length === 0 && (
        <Card>
          <CardContent className="p-12 text-center text-muted-foreground">
            <Mail className="w-12 h-12 mx-auto mb-4 opacity-50" />
            <p>No messages yet</p>
          </CardContent>
        </Card>
      )}
      {messages?.map((message) => (
        <Card key={message.id}>
          <CardContent className="p-6">
            <div className="flex justify-between items-start mb-4">
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-2">
                  <h3 className="font-bold text-lg">{message.name}</h3>
                  <span className="text-sm text-muted-foreground">
                    ({message.email})
                  </span>
                </div>
                <p className="text-sm text-muted-foreground mb-3">
                  {format(new Date(message.created_at), "PPpp")}
                </p>
                <p className="text-foreground">{message.message}</p>
              </div>
              <Button
                size="sm"
                variant="destructive"
                onClick={() => deleteMutation.mutate(message.id)}
              >
                <Trash2 className="w-4 h-4" />
              </Button>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
};

export default MessagesTab;
