import React, { useState } from "react";
import { 
  X, 
  Building2, 
  GraduationCap, 
  MapPin, 
  Phone, 
  Mail, 
  Globe, 
  Award, 
  BookOpen, 
  ShieldCheck, 
  HeartHandshake, 
  Sparkles,
  ExternalLink
} from "lucide-react";
import { AdithyaLogo } from "./AdithyaLogo";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

interface InstitutionalDirectoryModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const InstitutionalDirectoryModal: React.FC<InstitutionalDirectoryModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [activeTab, setActiveTab] = useState<"overview" | "departments" | "courses" | "contacts" | "scholarships">("overview");

  if (!isOpen) return null;

  const departments = [
    {
      name: "Department of Artificial Intelligence & Data Science",
      code: "AI & DS",
      degrees: ["B.Tech Artificial Intelligence and Data Science"],
      labs: "NVIDIA Deep Learning Lab, Big Data Analytics Centre",
      head: "Dr. K. Senthil Kumar, Ph.D.",
    },
    {
      name: "Department of Computer Science and Engineering",
      code: "CSE",
      degrees: ["B.E. Computer Science and Engineering", "M.E. Computer Science and Engineering"],
      labs: "Cloud Computing Centre of Excellence, Cybersecurity Lab",
      head: "Dr. M. Radhika, Ph.D.",
    },
    {
      name: "Department of Information Technology",
      code: "IT",
      degrees: ["B.Tech Information Technology"],
      labs: "Full-Stack Development Lab, IoT Systems Studio",
      head: "Dr. P. Suresh, Ph.D.",
    },
    {
      name: "Department of Electronics and Communication Engineering",
      code: "ECE",
      degrees: ["B.E. Electronics and Communication Engineering", "M.E. Applied Electronics"],
      labs: "VLSI Design & Embedded Systems Centre, RF & Wireless Lab",
      head: "Dr. P. Balasubramanian, Ph.D.",
    },
    {
      name: "Department of Electrical and Electronics Engineering",
      code: "EEE",
      degrees: ["B.E. Electrical and Electronics Engineering"],
      labs: "Smart Grid & Renewable Energy Lab, Power Electronics Simulation",
      head: "Dr. V. Karthikeyan, Ph.D.",
    },
    {
      name: "Department of Mechanical Engineering",
      code: "MECH",
      degrees: ["B.E. Mechanical Engineering", "M.E. Engineering Design"],
      labs: "CNC & Robotics Automation Lab, SAE Baja Vehicle Workshop",
      head: "Dr. S. Shanmugam, Ph.D.",
    },
    {
      name: "Department of Civil Engineering",
      code: "CIVIL",
      degrees: ["B.E. Civil Engineering", "M.E. Structural Engineering"],
      labs: "Advanced Structural Testing Facility, Geo-technical & CAD Centre",
      head: "Dr. R. Natarajan, Ph.D.",
    },
    {
      name: "Department of Management Studies",
      code: "MBA",
      degrees: ["MBA (Finance, HR, Marketing, Systems, Production)"],
      labs: "Business Analytics Simulation Lab, Case Study Forum",
      head: "Dr. K. Ramanathan, Ph.D.",
    },
    {
      name: "Department of Science and Humanities",
      code: "S&H",
      degrees: ["Supporting First-Year Engineering Foundations & Research"],
      labs: "Physics, Chemistry, English Communication & Language Lab",
      head: "Prof. S. Ranganathan, M.Sc., M.Phil.",
    },
  ];

  const artsScienceCourses = [
    { faculty: "Computer Science & Technology", programs: ["B.Sc. Computer Science", "B.Sc. Artificial Intelligence & Machine Learning (AI & ML)"] },
    { faculty: "Sciences & Humanities", programs: ["B.Sc. Psychology", "B.Sc. Mathematics", "B.A. English Literature", "B.A. Political Science"] },
    { faculty: "Commerce & Finance", programs: ["B.Com. Computer Applications", "B.Com. Professional Accounting"] },
    { faculty: "Business Management", programs: ["BBA (Bachelor of Business Administration - General)"] },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl max-w-4xl w-full max-h-[90vh] flex flex-col shadow-2xl border border-slate-200 overflow-hidden dark:bg-slate-900 dark:border-slate-800">
        
        {/* Header with Adithya Logo */}
        <div className="p-6 bg-gradient-to-r from-orange-50 via-slate-50 to-blue-50 border-b border-slate-200 flex items-center justify-between dark:from-slate-950 dark:via-slate-900 dark:to-slate-950 dark:border-slate-800">
          <div className="flex items-center gap-3">
            <AdithyaLogo size="lg" />
            <div className="pl-2 border-l border-slate-300 dark:border-slate-700">
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-slate-900 text-lg dark:text-white">
                  Adithya Institute of Technology (AIT)
                </span>
                <Badge className="bg-orange-600 text-white font-mono text-[10px]">
                  TNEA Code: 2744
                </Badge>
              </div>
              <p className="text-xs text-slate-600 dark:text-slate-400">
                Autonomous • Approved by AICTE, New Delhi • Affiliated to Anna University, Chennai • NAAC Accredited
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-2 rounded-xl hover:bg-white/80 dark:hover:bg-slate-800"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="flex border-b border-slate-200 bg-white px-6 gap-2 text-xs font-semibold dark:bg-slate-900 dark:border-slate-800 overflow-x-auto">
          <button
            onClick={() => setActiveTab("overview")}
            className={`py-3 px-3 border-b-2 transition-colors whitespace-nowrap ${
              activeTab === "overview"
                ? "border-orange-600 text-orange-600"
                : "border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200"
            }`}
          >
            Campus Overview & Key Facts
          </button>
          <button
            onClick={() => setActiveTab("departments")}
            className={`py-3 px-3 border-b-2 transition-colors whitespace-nowrap ${
              activeTab === "departments"
                ? "border-orange-600 text-orange-600"
                : "border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200"
            }`}
          >
            9 Academic Departments
          </button>
          <button
            onClick={() => setActiveTab("courses")}
            className={`py-3 px-3 border-b-2 transition-colors whitespace-nowrap ${
              activeTab === "courses"
                ? "border-orange-600 text-orange-600"
                : "border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200"
            }`}
          >
            Programs & Sibling Colleges
          </button>
          <button
            onClick={() => setActiveTab("scholarships")}
            className={`py-3 px-3 border-b-2 transition-colors whitespace-nowrap ${
              activeTab === "scholarships"
                ? "border-orange-600 text-orange-600"
                : "border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200"
            }`}
          >
            Fees & Merit Scholarships
          </button>
          <button
            onClick={() => setActiveTab("contacts")}
            className={`py-3 px-3 border-b-2 transition-colors whitespace-nowrap ${
              activeTab === "contacts"
                ? "border-orange-600 text-orange-600"
                : "border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200"
            }`}
          >
            Official Contacts & Helplines
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6 text-slate-700 text-xs dark:text-slate-300">
          
          {/* TAB 1: OVERVIEW */}
          {activeTab === "overview" && (
            <div className="space-y-5">
              <div className="bg-gradient-to-r from-orange-50 to-amber-50 p-5 rounded-2xl border border-orange-200 dark:bg-orange-950/20 dark:border-orange-800">
                <h4 className="font-bold text-sm text-orange-900 mb-1 flex items-center gap-1.5 dark:text-orange-200">
                  <Award className="h-4 w-4 text-orange-600" />
                  Institutional Accreditation & Standing
                </h4>
                <p className="text-slate-600 leading-relaxed dark:text-slate-300">
                  <strong>Adithya Institute of Technology (AIT)</strong> is an autonomous, self-financing engineering institution approved by AICTE (New Delhi), accredited by NAAC, and permanently affiliated to Anna University, Chennai (Counselling TNEA Code: <strong>2744</strong>). Situated on a lush, state-of-the-art campus on Sathy Main Road, Kurumbapalayam, Coimbatore, AIT fosters world-class technical education, industry-readiness, and entrepreneurship.
                </p>
              </div>

              {/* Campus Address & Geography */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2 dark:bg-slate-800/50 dark:border-slate-700">
                  <span className="font-bold text-[10px] text-slate-400 uppercase tracking-wider block">
                    CENTRAL EDUCATION ZONE ADDRESS
                  </span>
                  <div className="flex items-start gap-2">
                    <MapPin className="h-4 w-4 text-orange-600 shrink-0 mt-0.5" />
                    <div>
                      <p className="font-semibold text-slate-900 dark:text-white">
                        SF No. 344, 349, Sathy Main Road
                      </p>
                      <p className="text-slate-600 dark:text-slate-400">
                        Kurumbapalayam Post, S S Kulam, Coimbatore - 641107, Tamil Nadu, India.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-2 dark:bg-slate-800/50 dark:border-slate-700">
                  <span className="font-bold text-[10px] text-slate-400 uppercase tracking-wider block">
                    CAMPUSPASS SMART HOSTEL INTEGRATION
                  </span>
                  <div className="flex items-start gap-2">
                    <ShieldCheck className="h-4 w-4 text-emerald-600 shrink-0 mt-0.5" />
                    <div>
                      <p className="font-semibold text-slate-900 dark:text-white">
                        4 On-Campus Hostel Blocks
                      </p>
                      <p className="text-slate-600 dark:text-slate-400">
                        Kaveri Boys Hostel (Block A), Vaigai Boys Hostel (Block B), Nila Girls Hostel (Block C) & PG Scholars Wing. 24/7 Gate Guard Optical Scanner & Parent WhatsApp Alerts.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: 9 ACADEMIC DEPARTMENTS */}
          {activeTab === "departments" && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h4 className="font-bold text-sm text-slate-900 dark:text-white">
                  9 Core Academic Departments at AIT
                </h4>
                <Badge variant="outline" className="font-mono text-[10px]">
                  Anna University Affiliated
                </Badge>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {departments.map((d, idx) => (
                  <div
                    key={idx}
                    className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-1.5 hover:border-orange-300 transition-colors dark:bg-slate-800/50 dark:border-slate-700"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-mono text-[10px] font-bold text-orange-600 bg-orange-100 px-1.5 py-0.5 rounded dark:bg-orange-950/40 dark:text-orange-400">
                        {d.code}
                      </span>
                      <span className="text-[10px] text-slate-400">{d.head}</span>
                    </div>
                    <h5 className="font-bold text-slate-900 dark:text-white leading-tight">
                      {d.name}
                    </h5>
                    <div className="text-[11px] text-slate-600 space-y-0.5 dark:text-slate-400">
                      <div>
                        <strong>Degree:</strong> {d.degrees.join(", ")}
                      </div>
                      <div className="text-slate-500">
                        <strong>Labs:</strong> {d.labs}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 3: DEGREE COURSES & SIBLING COLLEGES */}
          {activeTab === "courses" && (
            <div className="space-y-5">
              {/* Engineering UG & PG */}
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 dark:bg-slate-800/40 dark:border-slate-700 space-y-3">
                <span className="font-bold text-sm text-slate-900 block dark:text-white">
                  1. Adithya Institute of Technology (AIT) — 13 to 14 Core Engineering & PG Degrees
                </span>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <span className="text-[10px] font-bold uppercase text-orange-600 block">
                      Undergraduate (UG) – B.E. / B.Tech (4 Years)
                    </span>
                    <ul className="list-disc pl-4 space-y-0.5 text-[11px] text-slate-600 dark:text-slate-400">
                      <li>B.Tech – Artificial Intelligence and Data Science</li>
                      <li>B.Tech – Information Technology</li>
                      <li>B.E. – Computer Science and Engineering</li>
                      <li>B.E. – Electronics and Communication Engineering</li>
                      <li>B.E. – Electrical and Electronics Engineering</li>
                      <li>B.E. – Mechanical Engineering</li>
                      <li>B.E. – Civil Engineering</li>
                    </ul>
                  </div>

                  <div className="space-y-1">
                    <span className="text-[10px] font-bold uppercase text-blue-600 block">
                      Postgraduate (PG) – M.E. / MBA (2 Years)
                    </span>
                    <ul className="list-disc pl-4 space-y-0.5 text-[11px] text-slate-600 dark:text-slate-400">
                      <li>M.E. – Computer Science and Engineering</li>
                      <li>M.E. – Applied Electronics</li>
                      <li>M.E. – Engineering Design</li>
                      <li>M.E. – Structural Engineering</li>
                      <li>MBA – Master of Business Administration (Finance, HR, Marketing, Systems, Production)</li>
                    </ul>
                  </div>
                </div>
              </div>

              {/* Sibling College: ACAS */}
              <div className="p-4 rounded-2xl bg-teal-50 border border-teal-200 dark:bg-teal-950/20 dark:border-teal-800 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-sm text-teal-950 dark:text-teal-200">
                    2. Adithya College of Arts & Science (ACAS)
                  </span>
                  <span className="text-[10px] text-teal-700 font-mono dark:text-teal-400">
                    Kurumbapalayam Campus
                  </span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                  {artsScienceCourses.map((c, i) => (
                    <div key={i} className="text-[11px] space-y-0.5">
                      <span className="font-bold text-teal-900 block dark:text-teal-300">
                        {c.faculty}:
                      </span>
                      <p className="text-teal-800 dark:text-teal-300/80">
                        {c.programs.join(" • ")}
                      </p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Sibling College: AIHS */}
              <div className="p-4 rounded-2xl bg-rose-50 border border-rose-200 dark:bg-rose-950/20 dark:border-rose-800">
                <span className="font-bold text-sm text-rose-950 block dark:text-rose-200">
                  3. Adithya Institute of Health Science (AIHS)
                </span>
                <p className="text-[11px] text-rose-800 mt-1 dark:text-rose-300">
                  Offering specialized Allied Health and Healthcare professional diploma and degree curricula in the unified central education zone.
                </p>
              </div>
            </div>
          )}

          {/* TAB 4: FEES & SCHOLARSHIPS */}
          {activeTab === "scholarships" && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 dark:bg-amber-950/20 dark:border-amber-800 space-y-2">
                <span className="font-bold text-sm text-amber-950 block dark:text-amber-200">
                  Fee Range & Financial Aid
                </span>
                <p className="text-slate-600 leading-relaxed dark:text-slate-300">
                  The tuition fee structure at Adithya Institute of Technology ranges approximately from <strong>₹40,000 to ₹1,50,000 per academic year</strong> depending on the course, branch specialization, and government quota (TNEA) vs management quota allocations.
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2 dark:bg-slate-800/40 dark:border-slate-700">
                <span className="font-bold text-sm text-slate-900 block dark:text-white">
                  Adithya Merit Scholarships
                </span>
                <ul className="list-disc pl-4 space-y-1 text-slate-600 dark:text-slate-400">
                  <li><strong>Merit Cutoff Waiver:</strong> Students scoring above 185/200 in higher secondary TNEA cutoff are eligible for substantial tuition fee concessions.</li>
                  <li><strong>Sports Quota Excellence:</strong> National and State level sports achievers receive hostel accommodation and sports scholarship waivers.</li>
                  <li><strong>First Generation Graduate:</strong> Full compliance with Tamil Nadu state government first graduate subsidy grants.</li>
                </ul>
              </div>
            </div>
          )}

          {/* TAB 5: OFFICIAL HELPLINES & CONTACTS */}
          {activeTab === "contacts" && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                
                {/* AIT */}
                <div className="p-4 rounded-xl bg-orange-50 border border-orange-200 space-y-2 dark:bg-orange-950/20 dark:border-orange-800">
                  <span className="font-bold text-xs text-orange-900 block uppercase dark:text-orange-200">
                    ADITHYA INSTITUTE OF TECHNOLOGY (AIT)
                  </span>
                  <div className="space-y-1 text-slate-600 dark:text-slate-400">
                    <p><strong>Primary Helplines:</strong></p>
                    <p className="font-mono">+91 73737 00933</p>
                    <p className="font-mono">+91 97889 33311</p>
                    <p><strong>Office:</strong> 0422-2654504</p>
                    <p><strong>Placement:</strong> +91 94435 50569</p>
                    <p><strong>Email:</strong> info@adithyatech.edu.in</p>
                  </div>
                </div>

                {/* ACAS */}
                <div className="p-4 rounded-xl bg-teal-50 border border-teal-200 space-y-2 dark:bg-teal-950/20 dark:border-teal-800">
                  <span className="font-bold text-xs text-teal-900 block uppercase dark:text-teal-200">
                    ADITHYA COLLEGE OF ARTS & SCIENCE (ACAS)
                  </span>
                  <div className="space-y-1 text-slate-600 dark:text-slate-400">
                    <p><strong>Admissions:</strong></p>
                    <p className="font-mono">+91 63843 63843</p>
                    <p className="font-mono">+91 96885 22211</p>
                    <p><strong>Campus Desk:</strong> +91 97889 33311</p>
                    <p><strong>Email:</strong> principal@adithyacas.edu.in</p>
                  </div>
                </div>

                {/* AIHS */}
                <div className="p-4 rounded-xl bg-rose-50 border border-rose-200 space-y-2 dark:bg-rose-950/20 dark:border-rose-800">
                  <span className="font-bold text-xs text-rose-900 block uppercase dark:text-rose-200">
                    ADITHYA INSTITUTE OF HEALTH SCIENCE (AIHS)
                  </span>
                  <div className="space-y-1 text-slate-600 dark:text-slate-400">
                    <p><strong>Primary Helpline:</strong></p>
                    <p className="font-mono">+91 94424 81555</p>
                    <p><strong>Counselling Desk:</strong></p>
                    <p className="font-mono">+91 97512 15444</p>
                    <p><strong>Email:</strong> info@adithyainstituteofhealthscience.com</p>
                  </div>
                </div>

              </div>
            </div>
          )}

        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between dark:bg-slate-900 dark:border-slate-800">
          <div className="flex items-center gap-2 text-xs text-slate-500">
            <Building2 className="h-4 w-4 text-orange-600" />
            <span>Adithya Institutions, Kurumbapalayam, Coimbatore (TNEA: 2744)</span>
          </div>
          <Button
            size="sm"
            onClick={onClose}
            className="bg-orange-600 hover:bg-orange-700 text-white text-xs font-semibold"
          >
            Close Directory
          </Button>
        </div>

      </div>
    </div>
  );
};
