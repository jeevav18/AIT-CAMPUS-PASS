import { useState, useRef, useEffect } from "react";
import { Send, Bot, User, Terminal, Sparkles } from "lucide-react";
import { playTick, playHover, playSuccessChime } from "@/lib/cyberAudio";

interface OSAiAssistantProps {
  onExecuteCommand: (action: string) => void;
}

interface Message {
  sender: "bot" | "user";
  text: string;
}

const OSAiAssistant = ({ onExecuteCommand }: OSAiAssistantProps) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      sender: "bot",
      text: "HELLO GUEST RECRUITER. I am JEEVA_18_COPILOT v4.0. How can I assist you with analyzing Jeeva's capabilities today? You can type a question, or trigger a command using the hotkeys below.",
    },
  ]);
  const [inputValue, setInputValue] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const predefinedPrompts = [
    { label: "Tell me about Jeeva", query: "Tell me about Jeeva" },
    { label: "Show Skills Matrix", query: "Open Skills App", action: "skills" },
    { label: "Decrypt Resume PDF", query: "Open Resume App", action: "resume" },
    { label: "Open Code Projects", query: "Open Projects App", action: "projects" },
    { label: "Contact Jeeva", query: "Open Contact Console", action: "contact" },
  ];

  const handleSend = (text: string, action?: string) => {
    if (!text.trim()) return;
    playTick();
    
    // Add user message
    const newMessages = [...messages, { sender: "user" as const, text }];
    setMessages(newMessages);
    setInputValue("");

    // Trigger action if mapped
    if (action) {
      onExecuteCommand(action);
    }

    // Processing response
    setTimeout(() => {
      let botResponse = "";
      const query = text.toLowerCase();

      if (query.includes("about") || query.includes("who is") || query.includes("jeeva")) {
        botResponse = "Jeeva V is an expert Salesforce Developer & Electronics student from Coimbatore, India. He delivers optimized, high-performance Apex controllers, LWC microfrontends, and workflow automations, bypassing governor limits with custom indexes.";
      } else if (query.includes("skill") || query.includes("matrix") || query.includes("apex")) {
        botResponse = "Opening the custom 3D Orbital Skills Matrix... Jeeva's primary expertise includes Apex programming (90%), LWC components (85%), flow orchestrations (95%), and React/TS stacks (80%).";
        onExecuteCommand("skills");
      } else if (query.includes("resume") || query.includes("download") || query.includes("pdf")) {
        botResponse = "Accessing the Secure Decryptor... Decrypting Jeeva's professional credentials now.";
        onExecuteCommand("resume");
      } else if (query.includes("project") || query.includes("portfolio") || query.includes("code")) {
        botResponse = "Launching Project Explorer... Jeeva has delivered massive custom Salesforce CRM platforms and handles freelance global developer integrations.";
        onExecuteCommand("projects");
      } else if (query.includes("contact") || query.includes("email") || query.includes("phone")) {
        botResponse = "Opening Secure Message Transmission console... Feel free to dispatch a message directly to Jeeva's terminal queue! Alternatively, email: gopiiniyavan@gmail.com.";
        onExecuteCommand("contact");
      } else if (query.includes("experience") || query.includes("work")) {
        botResponse = "Launching Experience Timeline... Jeeva is currently active as a Freelance Salesforce Developer, designing robust CRM customization loops and index triggers.";
        onExecuteCommand("experience");
      } else if (query.includes("education") || query.includes("college") || query.includes("university")) {
        botResponse = "Jeeva is completing his Bachelor of Engineering in Electronics and Communication at Adithya Institute of Technology, Anna University, with an active CGPA of 7.68.";
        onExecuteCommand("experience");
      } else {
        botResponse = "Command processed. Mapped database indicates Jeeva is highly proficient in Apex, Salesforce customization, React, and automated GitHub integrations. Try using our quick-launch widgets below.";
      }

      setMessages((prev) => [...prev, { sender: "bot" as const, text: botResponse }]);
      playSuccessChime();
    }, 800);
  };

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  return (
    <div className="flex flex-col h-full font-mono text-xs text-white">
      {/* Bot Header bar */}
      <div className="flex items-center justify-between border-b border-[#00FF66]/10 pb-3 mb-3 shrink-0">
        <div className="flex items-center space-x-2">
          <Bot className="w-5 h-5 text-[#00FF66] animate-pulse" />
          <div>
            <h4 className="font-bold text-white uppercase font-oxanium text-glow-green">JEEVA_18_COPILOT</h4>
            <span className="text-[8px] text-gray-500 uppercase tracking-widest font-extrabold">Active AI Query Core</span>
          </div>
        </div>
        <div className="flex items-center space-x-1 text-[8px] text-[#00E5FF] font-bold">
          <Sparkles className="w-3 h-3 text-[#00E5FF] animate-spin-slow" />
          <span>QUANTUM_ONLINE</span>
        </div>
      </div>

      {/* Messages Grid box */}
      <div className="flex-1 overflow-y-auto scrollbar-thin space-y-3.5 pr-1.5 mb-4 p-2 bg-[#040404]/80 rounded border border-[#00FF66]/10">
        {messages.map((msg, index) => (
          <div
            key={index}
            className={`flex items-start space-x-2.5 ${msg.sender === "user" ? "justify-end" : "justify-start"}`}
          >
            {msg.sender === "bot" && (
              <div className="p-1.5 bg-[#00FF66]/10 text-[#00FF66] rounded border border-[#00FF66]/20">
                <Bot className="w-3.5 h-3.5" />
              </div>
            )}
            <div
              className={`max-w-[85%] rounded-lg p-2.5 leading-relaxed ${
                msg.sender === "user"
                  ? "bg-[#00E5FF]/10 text-[#00E5FF] border border-[#00E5FF]/20 text-right"
                  : "bg-zinc-900/60 text-gray-300 border border-zinc-800"
              }`}
            >
              {msg.text}
            </div>
            {msg.sender === "user" && (
              <div className="p-1.5 bg-[#00E5FF]/10 text-[#00E5FF] rounded border border-[#00E5FF]/20">
                <User className="w-3.5 h-3.5" />
              </div>
            )}
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>

      {/* Quick helper command keys */}
      <div className="flex flex-wrap gap-1.5 mb-3 shrink-0">
        {predefinedPrompts.map((p, idx) => (
          <button
            key={idx}
            onMouseEnter={playHover}
            onClick={() => handleSend(p.query, p.action)}
            className="px-2 py-1 border border-[#00FF66]/20 hover:border-[#00FF66] bg-[#00FF66]/5 hover:bg-[#00FF66]/10 rounded text-[9px] text-[#00FF66] transition cursor-pointer uppercase font-bold"
          >
            {p.label}
          </button>
        ))}
      </div>

      {/* Inputs prompt form */}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          handleSend(inputValue);
        }}
        className="flex items-center space-x-2 border-t border-[#00FF66]/10 pt-3 shrink-0"
      >
        <div className="relative flex-1 flex items-center">
          <Terminal className="absolute left-3 w-4 h-4 text-gray-500" />
          <input
            type="text"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            placeholder="Query credentials database... e.g. 'skills', 'projects'"
            className="w-full bg-black/60 border border-[#00FF66]/20 focus:border-[#00FF66]/50 rounded-md py-2 pl-9 pr-4 text-xs text-white focus:outline-none transition font-mono"
          />
        </div>
        <button
          type="submit"
          onMouseEnter={playHover}
          className="p-2 border border-[#00FF66]/30 bg-[#00FF66]/10 hover:bg-[#00FF66]/20 text-[#00FF66] rounded-md transition cursor-pointer"
        >
          <Send className="w-4 h-4" />
        </button>
      </form>
    </div>
  );
};

export default OSAiAssistant;
