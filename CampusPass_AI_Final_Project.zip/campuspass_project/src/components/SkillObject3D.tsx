import { useEffect, useRef } from "react";
import * as THREE from "three";
import { SkillItem } from "@/data/portfolioData";

interface SkillObject3DProps {
  skill: SkillItem;
  isHovered?: boolean;
  accentColor?: "green" | "cyan" | "purple";
}

export const SkillObject3D = ({
  skill,
  isHovered = false,
  accentColor = "green",
}: SkillObject3DProps) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const meshGroupRef = useRef<THREE.Group | null>(null);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const width = container.clientWidth || 180;
    const height = container.clientHeight || 180;

    const scene = new THREE.Scene();
    sceneRef.current = scene;

    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 100);
    camera.position.z = 16;

    const renderer = new THREE.WebGLRenderer({
      alpha: true,
      antialias: true,
      powerPreference: "low-power",
    });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setClearColor(0x000000, 0);

    container.appendChild(renderer.domElement);

    const group = new THREE.Group();
    meshGroupRef.current = group;
    scene.add(group);

    // Color conversion
    const hexColor = parseInt(skill.color.replace("#", "0x")) || 0x00ff66;
    const secColor = accentColor === "cyan" ? 0x00e5ff : accentColor === "purple" ? 0xbf5af2 : 0x00ff66;

    // Build specific 3D geometry based on skill.icon3dType
    switch (skill.icon3dType) {
      case "apex": {
        // 3D Apex Polyhedral Energy Core + High-Throughput Brackets
        const apexCoreGeo = new THREE.OctahedronGeometry(4.2, 0);
        const apexCoreMat = new THREE.MeshBasicMaterial({
          color: 0x00e5ff,
          wireframe: true,
          transparent: true,
          opacity: 0.85,
        });
        const apexCore = new THREE.Mesh(apexCoreGeo, apexCoreMat);
        group.add(apexCore);

        const innerGeo = new THREE.DodecahedronGeometry(2.4, 0);
        const innerMat = new THREE.MeshBasicMaterial({
          color: 0x00ff66,
          wireframe: true,
          transparent: true,
          opacity: 0.7,
        });
        const inner = new THREE.Mesh(innerGeo, innerMat);
        group.add(inner);

        const ringGeo = new THREE.TorusGeometry(5.4, 0.1, 8, 36);
        const ringMat = new THREE.MeshBasicMaterial({
          color: 0x00e5ff,
          transparent: true,
          opacity: 0.5,
        });
        const ring = new THREE.Mesh(ringGeo, ringMat);
        ring.rotation.x = Math.PI / 3;
        group.add(ring);
        break;
      }

      case "lwc": {
        // 3D Lightning Web Components Quantum Core with Dual Shadow DOM Rings
        const lwcCoreGeo = new THREE.IcosahedronGeometry(3.6, 0);
        const lwcCoreMat = new THREE.MeshBasicMaterial({
          color: 0x00ff66,
          wireframe: true,
          transparent: true,
          opacity: 0.9,
        });
        const lwcCore = new THREE.Mesh(lwcCoreGeo, lwcCoreMat);
        group.add(lwcCore);

        const createShadowRing = (rx: number, ry: number) => {
          const rGeo = new THREE.TorusGeometry(5.2, 0.12, 8, 36);
          const rMat = new THREE.MeshBasicMaterial({
            color: 0x00e5ff,
            transparent: true,
            opacity: 0.6,
          });
          const rMesh = new THREE.Mesh(rGeo, rMat);
          rMesh.rotation.x = rx;
          rMesh.rotation.y = ry;
          return rMesh;
        };

        group.add(createShadowRing(Math.PI / 4, 0));
        group.add(createShadowRing(-Math.PI / 4, Math.PI / 2));
        break;
      }

      case "soql": {
        // Stacked rotating database disc cylinders with index planes
        for (let i = 0; i < 3; i++) {
          const cylGeo = new THREE.CylinderGeometry(3.6, 3.6, 1.2, 24, 1, true);
          const cylMat = new THREE.MeshBasicMaterial({
            color: 0x00e5ff,
            wireframe: true,
            transparent: true,
            opacity: 0.8,
          });
          const cyl = new THREE.Mesh(cylGeo, cylMat);
          cyl.position.y = (i - 1) * 2.2;
          group.add(cyl);
        }

        const queryPlaneGeo = new THREE.PlaneGeometry(5, 5);
        const queryPlaneMat = new THREE.MeshBasicMaterial({
          color: 0x00ff66,
          wireframe: true,
          side: THREE.DoubleSide,
          transparent: true,
          opacity: 0.35,
        });
        const plane = new THREE.Mesh(queryPlaneGeo, queryPlaneMat);
        plane.rotation.x = Math.PI / 2;
        group.add(plane);
        break;
      }

      case "sosl": {
        // Multi-directional search radar sphere with scanning target reticle
        const sphereGeo = new THREE.SphereGeometry(4.2, 12, 12);
        const sphereMat = new THREE.MeshBasicMaterial({
          color: 0xbf5af2,
          wireframe: true,
          transparent: true,
          opacity: 0.7,
        });
        const sphere = new THREE.Mesh(sphereGeo, sphereMat);
        group.add(sphere);

        const reticleGeo = new THREE.RingGeometry(4.8, 5.2, 32);
        const reticleMat = new THREE.MeshBasicMaterial({
          color: 0x00ff66,
          side: THREE.DoubleSide,
          transparent: true,
          opacity: 0.6,
        });
        const reticle = new THREE.Mesh(reticleGeo, reticleMat);
        group.add(reticle);

        const beamGeo = new THREE.BoxGeometry(0.2, 5.5, 0.2);
        const beamMat = new THREE.MeshBasicMaterial({ color: 0xbf5af2 });
        const beam = new THREE.Mesh(beamGeo, beamMat);
        group.add(beam);
        break;
      }

      case "html": {
        // HTML Semantic Angular Polyhedron Architecture
        const boxGeo = new THREE.BoxGeometry(4.6, 4.6, 4.6);
        const boxMat = new THREE.MeshBasicMaterial({
          color: 0xff5722,
          wireframe: true,
          transparent: true,
          opacity: 0.8,
        });
        const box = new THREE.Mesh(boxGeo, boxMat);
        group.add(box);

        const innerPlane = new THREE.PlaneGeometry(3.6, 3.6);
        const innerMat = new THREE.MeshBasicMaterial({
          color: 0x00ff66,
          wireframe: true,
          side: THREE.DoubleSide,
          transparent: true,
          opacity: 0.4,
        });
        const p1 = new THREE.Mesh(innerPlane, innerMat);
        group.add(p1);
        break;
      }

      case "css": {
        // Cascading Isometric Multi-Layer Styling Planes
        for (let l = 0; l < 3; l++) {
          const layerGeo = new THREE.PlaneGeometry(5.2, 3.8);
          const layerMat = new THREE.MeshBasicMaterial({
            color: l === 0 ? 0x29b6f6 : l === 1 ? 0x00e5ff : 0x00ff66,
            wireframe: true,
            side: THREE.DoubleSide,
            transparent: true,
            opacity: 0.65 - l * 0.1,
          });
          const layer = new THREE.Mesh(layerGeo, layerMat);
          layer.position.set((l - 1) * 0.8, (l - 1) * 0.8, (l - 1) * 1.5);
          group.add(layer);
        }
        break;
      }

      case "javascript": {
        // Hexagonal JS Reactor Prism with Inner Energy Core
        const hexGeo = new THREE.CylinderGeometry(3.6, 3.6, 3, 6, 1);
        const hexMat = new THREE.MeshBasicMaterial({
          color: 0xffc107,
          wireframe: true,
          transparent: true,
          opacity: 0.85,
        });
        const hex = new THREE.Mesh(hexGeo, hexMat);
        group.add(hex);

        const innerOcta = new THREE.OctahedronGeometry(2.2, 0);
        const innerOctaMat = new THREE.MeshBasicMaterial({
          color: 0x00ff66,
          wireframe: true,
          transparent: true,
          opacity: 0.8,
        });
        const innerM = new THREE.Mesh(innerOcta, innerOctaMat);
        group.add(innerM);
        break;
      }

      case "flow": {
        // Decision Diamond Network & Branching Nodes
        const diamondGeo = new THREE.OctahedronGeometry(4.2, 0);
        const diamondMat = new THREE.MeshBasicMaterial({
          color: 0x00ff66,
          wireframe: true,
          transparent: true,
          opacity: 0.85,
        });
        const diamond = new THREE.Mesh(diamondGeo, diamondMat);
        diamond.scale.set(1.4, 0.8, 1);
        group.add(diamond);

        const branchPoints = [-3.2, 0, 3.2];
        branchPoints.forEach((xPos) => {
          const nodeGeo = new THREE.SphereGeometry(0.9, 8, 8);
          const nodeMat = new THREE.MeshBasicMaterial({
            color: 0x00e5ff,
            wireframe: true,
          });
          const node = new THREE.Mesh(nodeGeo, nodeMat);
          node.position.set(xPos, -3.5, 0);
          group.add(node);
        });
        break;
      }

      case "visualforce": {
        // Visualforce Vintage System Console Frame & Controller Grid
        const frameGeo = new THREE.BoxGeometry(5.4, 4.2, 1.2);
        const frameMat = new THREE.MeshBasicMaterial({
          color: 0xff9800,
          wireframe: true,
          transparent: true,
          opacity: 0.75,
        });
        const frame = new THREE.Mesh(frameGeo, frameMat);
        group.add(frame);

        const screenGeo = new THREE.PlaneGeometry(4.4, 3.2);
        const screenMat = new THREE.MeshBasicMaterial({
          color: 0x00ff66,
          wireframe: true,
          side: THREE.DoubleSide,
          transparent: true,
          opacity: 0.35,
        });
        const screen = new THREE.Mesh(screenGeo, screenMat);
        screen.position.z = 0.65;
        group.add(screen);
        break;
      }

      case "rest_api": {
        // Dual REST Gateway Endpoints with Bidirectional Packet Orbit
        const gw1Geo = new THREE.BoxGeometry(2.4, 2.4, 2.4);
        const gw1Mat = new THREE.MeshBasicMaterial({
          color: 0x00e5ff,
          wireframe: true,
        });
        const gw1 = new THREE.Mesh(gw1Geo, gw1Mat);
        gw1.position.x = -3;
        group.add(gw1);

        const gw2 = new THREE.Mesh(gw1Geo, gw1Mat);
        gw2.position.x = 3;
        group.add(gw2);

        const pipeGeo = new THREE.CylinderGeometry(0.3, 0.3, 6, 8);
        const pipeMat = new THREE.MeshBasicMaterial({
          color: 0x00ff66,
          wireframe: true,
          transparent: true,
          opacity: 0.6,
        });
        const pipe = new THREE.Mesh(pipeGeo, pipeMat);
        pipe.rotation.z = Math.PI / 2;
        group.add(pipe);
        break;
      }

      case "triggers": {
        // 3D Event Trigger Spark Mechanism with Instant Reaction Wave
        const sparkGeo = new THREE.IcosahedronGeometry(3.5, 0);
        const sparkMat = new THREE.MeshBasicMaterial({
          color: 0x00ff66,
          wireframe: true,
          transparent: true,
          opacity: 0.9,
        });
        const spark = new THREE.Mesh(sparkGeo, sparkMat);
        group.add(spark);

        const waveGeo = new THREE.RingGeometry(4.8, 5.4, 24);
        const waveMat = new THREE.MeshBasicMaterial({
          color: 0x00e5ff,
          side: THREE.DoubleSide,
          transparent: true,
          opacity: 0.5,
        });
        const wave = new THREE.Mesh(waveGeo, waveMat);
        wave.rotation.x = Math.PI / 3;
        group.add(wave);
        break;
      }

      case "ethical_hacker":
      default: {
        // 3D Cryptographic Cyber Defense Shield + Rotating Lock Core
        const shieldGeo = new THREE.OctahedronGeometry(4.5, 0);
        const shieldMat = new THREE.MeshBasicMaterial({
          color: 0x00ff66,
          wireframe: true,
          transparent: true,
          opacity: 0.85,
        });
        const shield = new THREE.Mesh(shieldGeo, shieldMat);
        group.add(shield);

        const lockCoreGeo = new THREE.BoxGeometry(2.5, 2.8, 1.2);
        const lockCoreMat = new THREE.MeshBasicMaterial({
          color: secColor,
          wireframe: true,
          transparent: true,
          opacity: 0.6,
        });
        const lockCore = new THREE.Mesh(lockCoreGeo, lockCoreMat);
        group.add(lockCore);

        const ringGeo = new THREE.RingGeometry(6, 6.3, 32);
        const ringMat = new THREE.MeshBasicMaterial({
          color: 0x00ff66,
          side: THREE.DoubleSide,
          transparent: true,
          opacity: 0.4,
        });
        const ring = new THREE.Mesh(ringGeo, ringMat);
        ring.rotation.x = Math.PI / 4;
        group.add(ring);
        break;
      }
    }

    let animationId: number;
    const animate = () => {
      animationId = requestAnimationFrame(animate);

      if (group) {
        const speedMultiplier = isHovered ? 2.5 : 1;
        group.rotation.x += 0.008 * speedMultiplier;
        group.rotation.y += 0.012 * speedMultiplier;
      }

      renderer.render(scene, camera);
    };

    animate();

    return () => {
      cancelAnimationFrame(animationId);
      if (container && renderer.domElement) {
        container.removeChild(renderer.domElement);
      }
      renderer.dispose();
    };
  }, [skill, isHovered, accentColor]);

  return (
    <div
      ref={containerRef}
      className="w-full h-full min-h-[140px] flex items-center justify-center pointer-events-none"
    />
  );
};
export default SkillObject3D;
