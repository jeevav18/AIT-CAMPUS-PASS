import React, { useState } from "react";
import {
  Award,
  ExternalLink,
  ShieldCheck,
  Cloud,
  CheckCircle2,
  Calendar,
  Sparkles,
  Code2,
  BrainCircuit,
  Globe,
} from "lucide-react";
import { PORTFOLIO_DATA, CertificationItem } from "@/data/portfolioData";

export const CertificationsSection: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<string>("All");

  const categories = [
    "All",
    "Salesforce",
    "Cloud",
    "Programming",
    "AI",
    "Web Development",
  ];

  const filteredCertifications =
    selectedCategory === "All"
      ? PORTFOLIO_DATA.certifications
      : PORTFOLIO_DATA.certifications.filter(
          (cert) => cert.category === selectedCategory
        );

  const getCategoryIcon = (category: CertificationItem["category"]) => {
    switch (category) {
      case "Salesforce":
        return <Cloud className="w-5 h-5 text-sky-500" />;
      case "Cloud":
        return <Cloud className="w-5 h-5 text-amber-500" />;
      case "Programming":
        return <Code2 className="w-5 h-5 text-blue-500" />;
      case "AI":
        return <BrainCircuit className="w-5 h-5 text-purple-500" />;
      case "Web Development":
        return <Globe className="w-5 h-5 text-emerald-500" />;
      default:
        return <Award className="w-5 h-5 text-blue-500" />;
    }
  };

  return (
    <section id="certifications" className="py-20 sm:py-28 bg-white dark:bg-slate-900 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-50 dark:bg-blue-950/60 border border-blue-200 dark:border-blue-800 text-blue-700 dark:text-blue-300 text-xs font-semibold uppercase tracking-wider mb-3">
            <span>Verified Credentials</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            Certifications & Technical Accreditations
          </h2>
          <p className="mt-3 text-base sm:text-lg text-slate-600 dark:text-slate-300">
            Industry credentials in Salesforce Development & Administration, Cloud Computing, AI Engineering, and Full-Stack Systems.
          </p>
        </div>

        {/* Category Filters */}
        <div className="flex flex-wrap items-center justify-center gap-2 mb-12">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all cursor-pointer ${
                selectedCategory === cat
                  ? "bg-blue-600 text-white shadow-md shadow-blue-600/20"
                  : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700"
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Certifications Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredCertifications.map((cert) => (
            <div
              key={cert.id}
              className="p-6 rounded-3xl bg-slate-50/70 dark:bg-slate-800/40 border border-slate-200/80 dark:border-slate-800 shadow-2xs hover:shadow-lg transition-all duration-300 flex flex-col justify-between group"
            >
              <div className="space-y-4">
                <div className="flex items-start justify-between gap-3">
                  <div className="w-10 h-10 rounded-xl bg-white dark:bg-slate-900 text-blue-600 dark:text-blue-400 flex items-center justify-center shrink-0 border border-slate-200/80 dark:border-slate-700/80 shadow-2xs group-hover:scale-105 transition-transform">
                    {getCategoryIcon(cert.category)}
                  </div>

                  <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-slate-500 dark:text-slate-400 bg-white dark:bg-slate-900 px-2.5 py-1 rounded-lg border border-slate-200 dark:border-slate-700">
                    <Calendar className="w-3 h-3" />
                    {cert.issueDate}
                  </span>
                </div>

                <div>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400">
                    {cert.category}
                  </span>
                  <h3 className="text-base font-bold text-slate-900 dark:text-white tracking-tight mt-0.5">
                    {cert.title}
                  </h3>
                  <p className="text-xs font-semibold text-slate-600 dark:text-slate-400 mt-0.5">
                    Issued by {cert.issuer}
                  </p>
                </div>

                <div className="p-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200/60 dark:border-slate-700/60 text-[11px] font-mono text-slate-600 dark:text-slate-400">
                  <span className="text-slate-400 font-sans">ID: </span>
                  {cert.credentialId}
                </div>

                <div>
                  <p className="text-[11px] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500 mb-1.5">
                    Skills & Competencies
                  </p>
                  <div className="flex flex-wrap gap-1">
                    {cert.skillsCovered.map((sk, sIdx) => (
                      <span
                        key={sIdx}
                        className="px-2 py-0.5 rounded-md text-[11px] font-medium bg-white dark:bg-slate-900 border border-slate-200/70 dark:border-slate-700 text-slate-700 dark:text-slate-300"
                      >
                        {sk}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              <div className="pt-4 mt-4 border-t border-slate-200/60 dark:border-slate-700/60 flex items-center justify-between">
                <a
                  href={cert.verificationUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-1.5 text-xs font-bold text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300 cursor-pointer"
                >
                  <span>Verify Credential</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>

                <span className="text-[11px] font-medium text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  Active
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default CertificationsSection;
