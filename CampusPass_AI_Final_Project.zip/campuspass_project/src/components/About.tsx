import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  User,
  GraduationCap,
  Briefcase,
  Target,
  Sparkles,
  Award,
  Shield,
  Activity,
  Cpu,
  Radio,
  FileText,
  Lock,
} from "lucide-react";
import { PORTFOLIO_DATA } from "@/data/portfolioData";
import { playHover, playTick } from "@/lib/cyberAudio";

interface AboutProps {
  onOpenResume?: () => void;
}

export const About = ({ onOpenResume }: AboutProps) => {
  const [activeTab, setActiveTab] = useState<
    "bio" | "goals" | "interests" | "metrics" | "values"
  >("bio");

  const tabs = [
    { id: "bio", label: "01. BIO TELEMETRY", icon: User },
    { id: "goals", label: "02. MISSION & GOALS", icon: Target },
    { id: "interests", label: "03. CYBER INTERESTS", icon: Cpu },
    { id: "metrics", label: "04. PERFORMANCE STATS", icon: Activity },
    { id: "values", label: "05. CORE PILLARS", icon: Shield },
  ] as const;

  return (
    <section id="about" className="relative py-20 px-4 max-w-7xl mx-auto scroll-mt-20">
      {/* Section Header */}
      <div className="flex flex-col items-center text-center mb-12 space-y-3">
        <div className="flex items-center space-x-2 px-3 py-1 bg-[#00FF66]/10 border border-[#00FF66]/30 rounded-full text-xs font-mono text-[#00FF66]">
          <User className="w-3.5 h-3.5" />
          <span className="tracking-widest uppercase">MODULE: SEC_PROFILE_CORE</span>
        </div>
        <h2 className="text-3xl sm:text-5xl font-bebas tracking-wider text-white">
          FUTURISTIC <span className="text-[#00FF66] text-glow-green">OS PROFILE</span> PANEL
        </h2>
        <p className="text-sm text-gray-400 max-w-2xl font-mono">
          Decrypted executive profile, security architecture mission, live telemetry metrics, and core engineering philosophy.
        </p>
      </div>

      {/* Main Futuristic OS Panel Window */}
      <div className="bg-[#050505] border-2 border-[#00FF66]/40 rounded-xl overflow-hidden shadow-[0_0_50px_rgba(0,255,102,0.15)] font-mono">
        {/* OS Panel Titlebar */}
        <div className="bg-black border-b border-[#00FF66]/20 px-4 py-3 flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center space-x-2">
            <span className="w-3 h-3 rounded-full bg-red-500/80" />
            <span className="w-3 h-3 rounded-full bg-yellow-500/80" />
            <span className="w-3 h-3 rounded-full bg-[#00FF66]/80 animate-pulse" />
            <span className="text-xs text-white font-bold ml-2 font-oxanium tracking-wider">
              {PORTFOLIO_DATA.personal.codename} // CANDIDATE_PROFILE.SYS
            </span>
          </div>

          <div className="flex items-center space-x-2 text-[10px] text-[#00FF66]">
            <span className="w-2 h-2 rounded-full bg-[#00FF66] animate-ping" />
            <span>CLEARANCE: {PORTFOLIO_DATA.personal.clearanceLevel}</span>
          </div>
        </div>

        {/* Tab Strip */}
        <div className="flex overflow-x-auto bg-black/60 border-b border-zinc-800 scrollbar-thin">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;

            return (
              <button
                key={tab.id}
                onMouseEnter={playHover}
                onClick={() => {
                  playTick();
                  setActiveTab(tab.id);
                }}
                className={`flex items-center space-x-2 px-5 py-3 text-xs font-bold uppercase transition whitespace-nowrap cursor-pointer border-b-2 ${
                  isActive
                    ? "border-[#00FF66] text-[#00FF66] bg-[#00FF66]/10"
                    : "border-transparent text-gray-400 hover:text-white hover:bg-white/5"
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Panel Content Body */}
        <div className="p-6 sm:p-8 min-h-[360px] bg-black/90 text-gray-300 text-xs sm:text-sm">
          <AnimatePresence mode="wait">
            {activeTab === "bio" && (
              <motion.div
                key="bio"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="space-y-6"
              >
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {/* Left Bio Text */}
                  <div className="md:col-span-2 space-y-4">
                    <h3 className="text-xl font-bold font-oxanium text-white text-glow-green">
                      &gt; SYSTEM ARCHITECT & SEC-OPS SPECIALIST
                    </h3>
                    <p className="text-gray-300 leading-relaxed text-xs sm:text-sm">
                      {PORTFOLIO_DATA.about.summary}
                    </p>
                    <div className="space-y-2 pt-2">
                      {PORTFOLIO_DATA.personal.bioFull.map((para, i) => (
                        <div key={i} className="flex items-start space-x-2 text-xs text-gray-400">
                          <span className="text-[#00FF66] font-bold">›</span>
                          <span>{para}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Right Telemetry Sidebar */}
                  <div className="bg-black/60 border border-zinc-800 rounded-xl p-4 space-y-4">
                    <div className="flex items-center justify-between border-b border-zinc-800 pb-2">
                      <div className="text-[10px] text-gray-500 uppercase tracking-widest font-bold">
                        IDENTITY MATRIX
                      </div>
                      <span className="text-[9px] font-mono text-[#00FF66] bg-[#00FF66]/10 px-1.5 py-0.5 rounded border border-[#00FF66]/30">
                        BIO_ID: #0x18
                      </span>
                    </div>

                    {/* Biometric Monogram Preview Card */}
                    <div className="flex items-center space-x-3 p-2 bg-zinc-950/80 border border-[#00FF66]/20 rounded-lg relative overflow-hidden">
                      <div className="relative w-14 h-14 rounded-md border border-[#00FF66]/50 flex-shrink-0 bg-black flex items-center justify-center font-mono font-bold text-lg text-[#00FF66]">
                        JV
                      </div>
                      <div className="text-xs space-y-0.5 overflow-hidden">
                        <div className="text-white font-bold truncate">{PORTFOLIO_DATA.personal.name}</div>
                        <div className="text-[#00FF66] text-[10px] truncate">{PORTFOLIO_DATA.personal.codename}</div>
                        <div className="text-gray-400 text-[10px] flex items-center space-x-1">
                          <span className="w-1.5 h-1.5 rounded-full bg-[#00FF66] inline-block animate-ping" />
                          <span>BIO_MATCH: 99.9%</span>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-2 text-xs">
                      <div>
                        <span className="text-gray-500 block text-[10px]">CANDIDATE NAME</span>
                        <span className="text-white font-bold">{PORTFOLIO_DATA.personal.name}</span>
                      </div>
                      <div>
                        <span className="text-gray-500 block text-[10px]">PRIMARY FOCUS</span>
                        <span className="text-[#00E5FF] font-bold">{PORTFOLIO_DATA.personal.title}</span>
                      </div>
                      <div>
                        <span className="text-gray-500 block text-[10px]">CURRENT LOCATION</span>
                        <span className="text-gray-300">{PORTFOLIO_DATA.personal.location}</span>
                      </div>
                      <div>
                        <span className="text-gray-500 block text-[10px]">AVAILABILITY</span>
                        <span className="text-[#00FF66] font-bold">FULL-TIME & CONSULTING</span>
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {activeTab === "goals" && (
              <motion.div
                key="goals"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="space-y-6"
              >
                <h3 className="text-xl font-bold font-oxanium text-[#00E5FF] text-glow-cyan">
                  &gt; STRATEGIC CAREER DIRECTIVE
                </h3>
                <div className="bg-black/60 border border-[#00E5FF]/30 p-5 rounded-xl text-gray-200 text-sm leading-relaxed shadow-[0_0_20px_rgba(0,229,255,0.1)]">
                  {PORTFOLIO_DATA.about.careerGoal}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-4">
                  <div className="p-4 bg-black/40 border border-zinc-800 rounded-lg space-y-1">
                    <div className="text-[#00FF66] font-bold text-xs">01. SCALABILITY</div>
                    <p className="text-gray-400 text-[11px]">Architecting zero-downtime multi-tenant enterprise cloud platforms.</p>
                  </div>
                  <div className="p-4 bg-black/40 border border-zinc-800 rounded-lg space-y-1">
                    <div className="text-[#00E5FF] font-bold text-xs">02. DEFENSE IN DEPTH</div>
                    <p className="text-gray-400 text-[11px]">Hardening every OSI layer with automated fuzzing and strict cryptographic verification.</p>
                  </div>
                  <div className="p-4 bg-black/40 border border-zinc-800 rounded-lg space-y-1">
                    <div className="text-[#BF5AF2] font-bold text-xs">03. AUTONOMOUS AI</div>
                    <p className="text-gray-400 text-[11px]">Embedding intelligent heuristic detection into production security pipelines.</p>
                  </div>
                </div>
              </motion.div>
            )}

            {activeTab === "interests" && (
              <motion.div
                key="interests"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="grid grid-cols-1 sm:grid-cols-2 gap-4"
              >
                {PORTFOLIO_DATA.about.interests.map((item, i) => (
                  <div
                    key={i}
                    className="bg-black/60 border border-zinc-800 hover:border-[#00FF66]/50 p-5 rounded-xl space-y-2 transition duration-200"
                  >
                    <div className="text-sm font-bold font-oxanium text-white flex items-center space-x-2">
                      <span className="w-2 h-2 rounded-full bg-[#00FF66]" />
                      <span>{item.title}</span>
                    </div>
                    <p className="text-xs text-gray-400 leading-relaxed">{item.desc}</p>
                  </div>
                ))}
              </motion.div>
            )}

            {activeTab === "metrics" && (
              <motion.div
                key="metrics"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4"
              >
                {PORTFOLIO_DATA.about.metrics.map((metric, i) => (
                  <div
                    key={i}
                    className="bg-black/60 border border-zinc-800 p-5 rounded-xl text-center space-y-2"
                  >
                    <div className="text-2xl sm:text-3xl font-bold font-oxanium text-[#00FF66] text-glow-green">
                      {metric.value}
                    </div>
                    <div className="text-xs font-bold text-white uppercase tracking-wider">
                      {metric.label}
                    </div>
                    <p className="text-[10px] text-gray-500">{metric.detail}</p>
                  </div>
                ))}
              </motion.div>
            )}

            {activeTab === "values" && (
              <motion.div
                key="values"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="grid grid-cols-1 md:grid-cols-3 gap-4"
              >
                {PORTFOLIO_DATA.about.coreValues.map((val, i) => (
                  <div
                    key={i}
                    className="bg-black/60 border border-zinc-800 p-5 rounded-xl space-y-2"
                  >
                    <div className="text-xs text-[#00FF66] font-bold uppercase">
                      PILLAR 0{i + 1}
                    </div>
                    <h4 className="text-sm font-bold font-oxanium text-white">{val.title}</h4>
                    <p className="text-xs text-gray-400 leading-relaxed">{val.desc}</p>
                  </div>
                ))}
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* OS Footer Status Bar */}
        <div className="bg-black border-t border-zinc-900 px-4 py-2 flex flex-wrap items-center justify-between text-[10px] text-gray-500 font-mono">
          <span>HOST: {PORTFOLIO_DATA.terminalWelcome.hostName}</span>
          <span className="text-[#00FF66]">ALL ENGINES NOMINAL</span>
        </div>
      </div>
    </section>
  );
};
export default About;
