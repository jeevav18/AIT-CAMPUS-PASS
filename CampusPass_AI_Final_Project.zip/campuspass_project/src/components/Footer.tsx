import React from "react";
import {
  ArrowUp,
  Github,
  Linkedin,
  Code2,
  Mail,
  Heart,
  Sparkles,
  Phone,
  MapPin,
} from "lucide-react";
import { PORTFOLIO_DATA } from "@/data/portfolioData";

export const Footer: React.FC = () => {
  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: "smooth",
    });
  };

  const scrollTo = (id: string) => {
    const elem = document.getElementById(id);
    if (elem) {
      const offset = 76;
      const elementPosition = elem.getBoundingClientRect().top + window.pageYOffset - offset;
      window.scrollTo({
        top: elementPosition,
        behavior: "smooth",
      });
    }
  };

  return (
    <footer className="bg-white dark:bg-[#0B1120] border-t border-slate-200/80 dark:border-slate-800 py-14">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
          {/* Col 1: Brand & Status */}
          <div className="md:col-span-2 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-600 text-white flex items-center justify-center font-extrabold text-sm shadow-md shadow-blue-500/20 border border-blue-400/30 shrink-0">
                JV
              </div>
              <div>
                <p className="font-bold text-slate-900 dark:text-white text-base">
                  {PORTFOLIO_DATA.personal.name}
                </p>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  {PORTFOLIO_DATA.personal.title}
                </p>
              </div>
            </div>

            <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 max-w-md leading-relaxed">
              {PORTFOLIO_DATA.personal.tagline}
            </p>

            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800 text-emerald-700 dark:text-emerald-300 text-xs font-semibold">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span>Available for Immediate Technical Hiring & Projects</span>
            </div>
          </div>

          {/* Col 2: Navigation Links */}
          <div className="space-y-3">
            <p className="text-xs font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500">
              Quick Navigation
            </p>
            <ul className="space-y-2 text-xs font-medium text-slate-600 dark:text-slate-400">
              <li>
                <button
                  onClick={() => scrollTo("about")}
                  className="hover:text-blue-600 dark:hover:text-blue-400 transition-colors"
                >
                  About Story
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollTo("skills")}
                  className="hover:text-blue-600 dark:hover:text-blue-400 transition-colors"
                >
                  Technical Matrix
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollTo("projects")}
                  className="hover:text-blue-600 dark:hover:text-blue-400 transition-colors"
                >
                  Featured Projects
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollTo("experience")}
                  className="hover:text-blue-600 dark:hover:text-blue-400 transition-colors"
                >
                  Career Experience
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollTo("certifications")}
                  className="hover:text-blue-600 dark:hover:text-blue-400 transition-colors"
                >
                  Certifications
                </button>
              </li>
            </ul>
          </div>

          {/* Col 3: Direct Connect */}
          <div className="space-y-3">
            <p className="text-xs font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500">
              Direct Contact
            </p>
            <div className="space-y-2 text-xs text-slate-600 dark:text-slate-400">
              <p>
                <a
                  href={`mailto:${PORTFOLIO_DATA.personal.email}`}
                  className="hover:text-blue-600 dark:hover:text-blue-400 font-semibold"
                >
                  {PORTFOLIO_DATA.personal.email}
                </a>
              </p>
              <p>{PORTFOLIO_DATA.personal.phone}</p>
              <p>{PORTFOLIO_DATA.personal.location}</p>
            </div>

            <div className="flex items-center gap-2 pt-2">
              <a
                href={PORTFOLIO_DATA.personal.githubUrl}
                target="_blank"
                rel="noreferrer"
                className="p-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:text-blue-600 dark:hover:text-blue-400 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
                aria-label="GitHub"
              >
                <Github className="w-4 h-4" />
              </a>
              <a
                href={PORTFOLIO_DATA.personal.linkedinUrl}
                target="_blank"
                rel="noreferrer"
                className="p-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:text-blue-600 dark:hover:text-blue-400 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
                aria-label="LinkedIn"
              >
                <Linkedin className="w-4 h-4" />
              </a>
              <a
                href={PORTFOLIO_DATA.personal.leetcodeUrl}
                target="_blank"
                rel="noreferrer"
                className="p-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:text-blue-600 dark:hover:text-blue-400 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
                aria-label="LeetCode"
              >
                <Code2 className="w-4 h-4" />
              </a>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-slate-100 dark:border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500 dark:text-slate-400">
          <p>© {new Date().getFullYear()} {PORTFOLIO_DATA.personal.name}. All rights reserved.</p>

          <button
            onClick={scrollToTop}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl font-semibold text-slate-700 dark:text-slate-300 hover:text-blue-600 dark:hover:text-blue-400 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors cursor-pointer"
          >
            <span>Back to Top</span>
            <ArrowUp className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
