import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Shield, Sparkles, X, Terminal, CheckCircle, ExternalLink, Cpu, Layers } from "lucide-react";
import { PORTFOLIO_DATA, SkillItem } from "@/data/portfolioData";
import SkillObject3D from "./SkillObject3D";
import { playHover, playTick } from "@/lib/cyberAudio";

interface SkillsSection3DProps {
  accentColor?: "green" | "cyan" | "purple";
}

export const SkillsSection3D = ({ accentColor = "green" }: SkillsSection3DProps) => {
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [activeSkill, setActiveSkill] = useState<SkillItem | null>(null);
  const [hoveredSkillId, setHoveredSkillId] = useState<string | null>(null);

  const categories = [
    { id: "all", label: "ALL SKILLS" },
    { id: "salesforce", label: "SALESFORCE" },
    { id: "cybersecurity", label: "ETHICAL HACKING" },
    { id: "frontend", label: "FRONTEND" },
    { id: "database", label: "DATABASE (SOQL/SOSL)" },
    { id: "integrations", label: "REST INTEGRATIONS" },
    { id: "automation", label: "FLOW AUTOMATION" },
    { id: "languages", label: "LANGUAGES" },
  ];

  const filteredSkills =
    selectedCategory === "all"
      ? PORTFOLIO_DATA.skills
      : PORTFOLIO_DATA.skills.filter((s) => s.category === selectedCategory);

  const levelColorMap = {
    BEGINNER: "text-blue-400 border-blue-400/40 bg-blue-500/10",
    INTERMEDIATE: "text-amber-400 border-amber-400/40 bg-amber-500/10",
    ADVANCED: "text-[#00E5FF] border-[#00E5FF]/40 bg-[#00E5FF]/10",
    EXPERT: "text-[#00FF66] border-[#00FF66]/40 bg-[#00FF66]/10",
  };

  return (
    <section id="skills" className="relative py-20 px-4 max-w-7xl mx-auto scroll-mt-20">
      {/* Section Header */}
      <div className="flex flex-col items-center text-center mb-12 space-y-3">
        <div className="flex items-center space-x-2 px-3 py-1 bg-[#00FF66]/10 border border-[#00FF66]/30 rounded-full text-xs font-mono text-[#00FF66]">
          <Shield className="w-3.5 h-3.5" />
          <span className="tracking-widest uppercase">MODULE: SEC_SKILLS_CORE_3D</span>
        </div>
        <h2 className="text-3xl sm:text-5xl font-bebas tracking-wider text-white">
          INTERACTIVE <span className="text-[#00FF66] text-glow-green">3D SKILLS</span> MATRIX
        </h2>
        <p className="text-sm text-gray-400 max-w-2xl font-mono">
          Each capability is mapped to an interactive 3D geometric core. Hover or click any module to inspect technical specifications and security telemetry.
        </p>

        {/* Visual Progression Tier Indicator */}
        <div className="pt-3 flex flex-wrap items-center justify-center gap-2 text-[10px] font-mono font-bold tracking-wider">
          <span className="text-gray-500 uppercase mr-1">Progression Tiers:</span>
          {(["BEGINNER", "INTERMEDIATE", "ADVANCED", "EXPERT"] as const).map((lvl, i) => (
            <div key={lvl} className="flex items-center space-x-1.5">
              <span className={`px-2 py-0.5 border rounded ${levelColorMap[lvl]}`}>{lvl}</span>
              {i < 3 && <span className="text-gray-600 font-normal">→</span>}
            </div>
          ))}
        </div>
      </div>

      {/* Category Filter Tabs */}
      <div className="flex flex-wrap items-center justify-center gap-2 mb-10">
        {categories.map((cat) => (
          <button
            key={cat.id}
            onMouseEnter={playHover}
            onClick={() => {
              playTick();
              setSelectedCategory(cat.id);
            }}
            className={`px-4 py-1.5 rounded-lg font-mono text-xs font-bold uppercase transition duration-200 cursor-pointer border ${
              selectedCategory === cat.id
                ? "bg-[#00FF66]/20 border-[#00FF66] text-[#00FF66] shadow-[0_0_12px_rgba(0,255,102,0.3)]"
                : "bg-black/60 border-zinc-800 text-gray-400 hover:text-white hover:border-zinc-700"
            }`}
          >
            {cat.label}
          </button>
        ))}
      </div>

      {/* 3D Skills Interactive Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {filteredSkills.map((skill) => {
          const isHovered = hoveredSkillId === skill.id;

          return (
            <motion.div
              key={skill.id}
              layout
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95 }}
              whileHover={{ y: -6 }}
              onMouseEnter={() => {
                playHover();
                setHoveredSkillId(skill.id);
              }}
              onMouseLeave={() => setHoveredSkillId(null)}
              onClick={() => {
                playTick();
                setActiveSkill(skill);
              }}
              className="relative group bg-black/70 border border-zinc-800/80 hover:border-[#00FF66]/60 rounded-xl p-4 flex flex-col justify-between overflow-hidden cursor-pointer transition-all duration-300 shadow-[0_4px_20px_rgba(0,0,0,0.6)] hover:shadow-[0_0_25px_rgba(0,255,102,0.15)]"
            >
              {/* Corner HUD reticle marks */}
              <div className="absolute top-2 left-2 w-2 h-2 border-t border-l border-[#00FF66]/30 group-hover:border-[#00FF66]" />
              <div className="absolute top-2 right-2 w-2 h-2 border-t border-r border-[#00FF66]/30 group-hover:border-[#00FF66]" />
              <div className="absolute bottom-2 left-2 w-2 h-2 border-b border-l border-[#00FF66]/30 group-hover:border-[#00FF66]" />
              <div className="absolute bottom-2 right-2 w-2 h-2 border-b border-r border-[#00FF66]/30 group-hover:border-[#00FF66]" />

              {/* Top Meta Bar */}
              <div className="flex items-center justify-between z-10">
                <span className="text-[10px] font-mono font-bold text-gray-500 uppercase tracking-wider">
                  0x{skill.score.toString(16).toUpperCase()} // {skill.category}
                </span>
                <span
                  className={`text-[9px] font-mono font-bold px-2 py-0.5 rounded border uppercase tracking-wider ${
                    levelColorMap[skill.level]
                  }`}
                >
                  {skill.level}
                </span>
              </div>

              {/* 3D Geometric Interactive Canvas Canvas Viewport */}
              <div className="my-2 h-36 relative flex items-center justify-center">
                <SkillObject3D skill={skill} isHovered={isHovered} accentColor={accentColor} />

                {/* Subtle Hover Hologram Overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition duration-300 pointer-events-none" />
              </div>

              {/* Bottom Skill Info */}
              <div className="z-10 space-y-2">
                <div className="flex items-center justify-between">
                  <h3 className="text-base font-bold font-oxanium text-white group-hover:text-[#00FF66] transition">
                    {skill.name}
                  </h3>
                  <span className="text-xs font-mono font-bold text-[#00E5FF]">
                    {skill.score}%
                  </span>
                </div>

                {/* Score Progress Bar */}
                <div className="w-full h-1.5 bg-zinc-900 border border-zinc-800 rounded-full overflow-hidden">
                  <motion.div
                    className="h-full bg-gradient-to-r from-[#00FF66] to-[#00E5FF] rounded-full"
                    initial={{ width: 0 }}
                    whileInView={{ width: `${skill.score}%` }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.8, ease: "easeOut" }}
                  />
                </div>

                <div className="flex items-center justify-between text-[11px] font-mono text-gray-400 pt-1">
                  <span>EXP: {skill.experience}</span>
                  <span className="text-[#00FF66] group-hover:underline flex items-center space-x-1">
                    <span>Inspect</span>
                    <span>›</span>
                  </span>
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>

      {/* Interactive Detail Modal Inspector */}
      <AnimatePresence>
        {activeSkill && (
          <div className="fixed inset-0 z-[10000] bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
            <motion.div
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="relative w-full max-w-xl bg-[#070707] border-2 border-[#00FF66]/60 rounded-xl p-6 sm:p-8 shadow-[0_0_50px_rgba(0,255,102,0.25)] font-mono text-white overflow-hidden"
            >
              {/* Scanline overlay */}
              <div className="absolute inset-0 bg-scanlines opacity-10 pointer-events-none" />

              {/* Modal Header */}
              <div className="flex items-start justify-between border-b border-[#00FF66]/20 pb-4 mb-6">
                <div>
                  <div className="flex items-center space-x-2">
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded border uppercase tracking-wider ${
                        levelColorMap[activeSkill.level]
                      }`}
                    >
                      {activeSkill.level} TIER
                    </span>
                    <span className="text-xs text-[#00E5FF] font-bold">
                      SCORE: {activeSkill.score}/100
                    </span>
                  </div>
                  <h3 className="text-2xl sm:text-3xl font-bebas tracking-wide text-white mt-1">
                    {activeSkill.name}
                  </h3>
                </div>

                <button
                  onClick={() => {
                    playTick();
                    setActiveSkill(null);
                  }}
                  className="p-1.5 rounded-lg border border-zinc-800 bg-black/60 hover:border-red-500 hover:text-red-400 text-gray-400 transition cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* 3D Visualizer & Details Split */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 mb-6">
                {/* 3D Model Display */}
                <div className="h-44 bg-black/80 border border-zinc-800 rounded-lg flex flex-col items-center justify-center p-2 relative overflow-hidden">
                  <SkillObject3D skill={activeSkill} isHovered={true} accentColor={accentColor} />
                  <span className="absolute bottom-2 text-[9px] text-gray-500 uppercase tracking-wider">
                    // 3D Wireframe Telemetry Active
                  </span>
                </div>

                {/* Telemetry Stats */}
                <div className="space-y-3 text-xs">
                  <div className="bg-black/40 border border-zinc-800/80 p-2.5 rounded-lg">
                    <div className="text-[10px] text-gray-500 uppercase font-bold">Experience Time</div>
                    <div className="text-[#00FF66] font-bold text-sm">{activeSkill.experience} in Production</div>
                  </div>

                  <div className="bg-black/40 border border-zinc-800/80 p-2.5 rounded-lg">
                    <div className="text-[10px] text-gray-500 uppercase font-bold">Live Repositories / Projects</div>
                    <div className="text-[#00E5FF] font-bold text-sm">{activeSkill.projectsCount}+ Enterprise Implementations</div>
                  </div>

                  <div className="bg-black/40 border border-zinc-800/80 p-2.5 rounded-lg">
                    <div className="text-[10px] text-gray-500 uppercase font-bold">Security Classification</div>
                    <div className="text-[#BF5AF2] font-bold text-xs">Zero-Trust Hardened</div>
                  </div>
                </div>
              </div>

              {/* Description */}
              <div className="space-y-2 mb-6">
                <h4 className="text-xs font-bold text-[#00FF66] uppercase tracking-wider flex items-center space-x-1.5">
                  <Terminal className="w-3.5 h-3.5" />
                  <span>Module Functional Description</span>
                </h4>
                <p className="text-xs text-gray-300 leading-relaxed bg-black/50 p-3 rounded-lg border border-zinc-800">
                  {activeSkill.description}
                </p>
              </div>

              {/* Tools & Frameworks Pills */}
              <div className="space-y-2 mb-6">
                <h4 className="text-xs font-bold text-gray-400 uppercase tracking-wider flex items-center space-x-1.5">
                  <Layers className="w-3.5 h-3.5 text-[#00E5FF]" />
                  <span>Integrated Tooling & Libraries</span>
                </h4>
                <div className="flex flex-wrap gap-1.5">
                  {activeSkill.tools.map((tool) => (
                    <span
                      key={tool}
                      className="px-2.5 py-1 bg-black border border-zinc-800 text-gray-300 text-[11px] rounded font-mono"
                    >
                      {tool}
                    </span>
                  ))}
                </div>
              </div>

              {/* Close Action Button */}
              <button
                onClick={() => {
                  playTick();
                  setActiveSkill(null);
                }}
                className="w-full py-2.5 bg-[#00FF66]/10 hover:bg-[#00FF66]/20 border border-[#00FF66]/50 text-[#00FF66] font-bold rounded-lg uppercase tracking-wider text-xs transition cursor-pointer shadow-[0_0_15px_rgba(0,255,102,0.2)]"
              >
                Close Diagnostic Inspector
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </section>
  );
};
export default SkillsSection3D;
