import React, { useState } from "react";
import { PassRequest, GateMovementRecord } from "@/types/campuspass";
import { 
  Scan, 
  Camera, 
  CheckCircle2, 
  XCircle, 
  AlertTriangle, 
  ShieldCheck, 
  User, 
  Clock, 
  Building, 
  Phone, 
  ArrowUpRight, 
  ArrowDownLeft, 
  History,
  QrCode,
  Radio,
  FileText
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { PaperPassSlipModal } from "./PaperPassSlipModal";
import { toast } from "sonner";

interface GateSecurityDashboardProps {
  guardName: string;
  passes: PassRequest[];
  onVerifyScan: (token: string, gateId: string, gateName: string) => {
    success: boolean;
    movementType: "EXIT" | "ENTRY";
    pass: PassRequest;
    message: string;
    isOverdue?: boolean;
    overdueMinutes?: number;
  };
  initialScannedToken?: string;
}

export const GateSecurityDashboard: React.FC<GateSecurityDashboardProps> = ({
  guardName,
  passes,
  onVerifyScan,
  initialScannedToken,
}) => {
  const [selectedGate, setSelectedGate] = useState<string>("Gate 1 (Main Entrance)");
  const [inputToken, setInputToken] = useState<string>(initialScannedToken || "");
  const [isScanningActive, setIsScanningActive] = useState<boolean>(true);
  const [lastScanResult, setLastScanResult] = useState<{
    success: boolean;
    movementType: "EXIT" | "ENTRY";
    pass: PassRequest;
    message: string;
    isOverdue?: boolean;
    overdueMinutes?: number;
  } | null>(null);
  const [selectedPassForPaperSlip, setSelectedPassForPaperSlip] = useState<PassRequest | null>(null);

  // Collect all gate movements across passes
  const allMovements = passes
    .flatMap((p) => p.movements || [])
    .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

  const handleExecuteScan = (tokenToScan?: string) => {
    const token = tokenToScan || inputToken;
    if (!token.trim()) {
      toast.error("Please enter or scan a valid QR token.");
      return;
    }

    try {
      const result = onVerifyScan(token, "GATE-01", selectedGate);
      setLastScanResult(result);
      if (result.movementType === "EXIT") {
        toast.success(`DEPARTURE RECORDED: ${result.pass.studentName} exited via ${selectedGate}. Parent WhatsApp alert sent.`);
      } else {
        if (result.isOverdue) {
          toast.warning(`ARRIVAL FLAGGED LATE: ${result.pass.studentName} returned ${result.overdueMinutes}m past curfew.`);
        } else {
          toast.success(`SAFE RETURN VERIFIED: ${result.pass.studentName} has entered campus.`);
        }
      }
      setInputToken("");
    } catch (err: unknown) {
      const errorMsg = err instanceof Error ? err.message : "Gate scan validation failed.";
      toast.error(errorMsg);
      setLastScanResult(null);
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-emerald-800 via-teal-900 to-slate-900 rounded-2xl p-6 text-white shadow-lg flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="h-14 w-14 rounded-2xl bg-white/10 backdrop-blur flex items-center justify-center text-white border border-white/20">
            <Scan className="h-7 w-7 text-emerald-200" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-bold tracking-tight">
                Gate Security QR Scanner Station
              </h2>
              <Badge className="bg-emerald-500/30 text-emerald-100 border-white/20 text-xs">
                Real-Time Verification
              </Badge>
            </div>
            <p className="text-xs text-emerald-100/90 mt-0.5">
              Officer On Duty: {guardName} • Adithya Institute Campus Main Security Post (Gate 1 Kurumbapalayam)
            </p>
          </div>
        </div>

        {/* Gate Selector */}
        <div className="flex items-center gap-2 bg-black/30 p-2 rounded-xl border border-white/10 text-xs">
          <Radio className="h-4 w-4 text-emerald-400 animate-pulse" />
          <span className="text-slate-300">Active Gate Post:</span>
          <select
            value={selectedGate}
            onChange={(e) => setSelectedGate(e.target.value)}
            className="bg-slate-800 text-white rounded px-2 py-1 font-semibold border-none focus:ring-1 focus:ring-emerald-400"
          >
            <option>Gate 1 (Main Entrance)</option>
            <option>Gate 2 (North Campus Gate)</option>
            <option>Gate 3 (Hostel South Gate)</option>
          </select>
        </div>
      </div>

      {/* Main Scanner Section */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column (5 cols): Camera Viewfinder Simulator & Scanner Inputs */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm dark:bg-slate-900 dark:border-slate-800">
            <div className="flex items-center justify-between mb-3">
              <span className="font-bold text-xs uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                <Camera className="h-4 w-4 text-emerald-600" />
                Optical QR Scanner Feed
              </span>
              <span className="text-[10px] font-mono bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full font-bold dark:bg-emerald-950/40 dark:text-emerald-300">
                1080p HD LIVE
              </span>
            </div>

            {/* Viewfinder Screen with Laser Animation */}
            <div className="relative aspect-video rounded-xl bg-slate-950 overflow-hidden flex items-center justify-center border-2 border-slate-800 group shadow-inner">
              {/* Corner crosshairs */}
              <div className="absolute top-3 left-3 w-6 h-6 border-t-2 border-l-2 border-emerald-400" />
              <div className="absolute top-3 right-3 w-6 h-6 border-t-2 border-r-2 border-emerald-400" />
              <div className="absolute bottom-3 left-3 w-6 h-6 border-b-2 border-l-2 border-emerald-400" />
              <div className="absolute bottom-3 right-3 w-6 h-6 border-b-2 border-r-2 border-emerald-400" />

              {/* Laser line moving vertically */}
              <div className="absolute left-4 right-4 h-0.5 bg-gradient-to-r from-transparent via-emerald-400 to-transparent shadow-[0_0_8px_#34d399] animate-bounce" />

              <div className="text-center space-y-2 p-4">
                <QrCode className="h-14 w-14 text-emerald-400/80 mx-auto animate-pulse" />
                <p className="text-xs text-emerald-200/90 font-mono">
                  Point barcode or student phone screen toward lens
                </p>
              </div>

              {/* Live timestamp */}
              <div className="absolute bottom-2 right-3 text-[10px] text-emerald-400/80 font-mono">
                {selectedGate}
              </div>
            </div>

            {/* Manual Token Entry / Barcode Scanner Emulation */}
            <div className="mt-4 space-y-2">
              <label className="text-xs font-semibold text-slate-700 block dark:text-slate-300">
                Token String / Pass ID Scan Input
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="Paste token e.g. CP-QR-SEC-TOKEN-... or CP-2025-0914"
                  value={inputToken}
                  onChange={(e) => setInputToken(e.target.value)}
                  className="flex-1 text-xs px-3 py-2 rounded-xl border border-slate-200 bg-slate-50 focus:bg-white font-mono dark:bg-slate-800 dark:border-slate-700 dark:text-white"
                />
                <Button
                  onClick={() => handleExecuteScan()}
                  className="bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold px-4"
                >
                  Verify
                </Button>
              </div>
            </div>

            {/* Quick Test Chips for Testing all conditions */}
            <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-2">
                Quick One-Click Test Cases:
              </span>
              <div className="space-y-1.5 text-xs">
                {passes.filter((p) => p.qrToken).map((p) => (
                  <button
                    key={p.id}
                    onClick={() => handleExecuteScan(p.qrToken!)}
                    className="w-full text-left p-2 rounded-lg bg-slate-50 hover:bg-emerald-50 border border-slate-200 hover:border-emerald-300 transition-colors flex items-center justify-between dark:bg-slate-800/60 dark:border-slate-700"
                  >
                    <div>
                      <span className="font-semibold text-slate-800 dark:text-slate-200">
                        {p.studentName} ({p.rollNumber})
                      </span>
                      <span className="text-[10px] text-slate-400 block font-mono">
                        {p.passNumber} • {p.status === 'approved' ? 'Exit Ready' : p.status === 'active_out' ? 'Return Ready' : p.status}
                      </span>
                    </div>
                    <Badge
                      className={
                        p.status === "approved"
                          ? "bg-blue-600 text-white text-[9px]"
                          : p.status === "active_out"
                          ? "bg-amber-600 text-white text-[9px]"
                          : p.status === "overdue"
                          ? "bg-red-600 text-white text-[9px]"
                          : "bg-slate-600 text-white text-[9px]"
                      }
                    >
                      {p.status === "approved" ? "Scan EXIT" : p.status === "active_out" ? "Scan ENTRY" : p.status}
                    </Badge>
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Right Column (7 cols): Last Scan Verification Result & Live Gate Movement Log */}
        <div className="lg:col-span-7 space-y-4">
          
          {/* Real-time Verification Output Card */}
          {lastScanResult ? (
            <div className={`p-6 rounded-2xl border-2 shadow-md transition-all ${
              lastScanResult.movementType === "EXIT"
                ? "bg-amber-50/80 border-amber-400 text-amber-950 dark:bg-amber-950/20 dark:border-amber-700 dark:text-amber-200"
                : lastScanResult.isOverdue
                ? "bg-red-50/80 border-red-400 text-red-950 dark:bg-red-950/20 dark:border-red-700 dark:text-red-200"
                : "bg-emerald-50/80 border-emerald-400 text-emerald-950 dark:bg-emerald-950/20 dark:border-emerald-700 dark:text-emerald-200"
            }`}>
              <div className="flex items-start justify-between gap-4">
                <div className="flex items-start gap-4">
                  <img
                    src={lastScanResult.pass.avatarUrl}
                    alt={lastScanResult.pass.studentName}
                    className="h-16 w-16 rounded-xl object-cover border-2 border-white shadow shrink-0"
                  />
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-extrabold text-lg text-slate-900 dark:text-white">
                        {lastScanResult.pass.studentName}
                      </span>
                      <Badge className="font-mono text-xs font-bold">
                        {lastScanResult.pass.rollNumber}
                      </Badge>
                    </div>

                    <p className="text-xs text-slate-700 mt-0.5 dark:text-slate-300">
                      {lastScanResult.pass.department} • Room {lastScanResult.pass.roomNumber} ({lastScanResult.pass.hostelBlock.split("(")[0]})
                    </p>

                    <div className="mt-2 text-xs font-semibold">
                      {lastScanResult.movementType === "EXIT" ? (
                        <span className="inline-flex items-center gap-1.5 text-amber-800 dark:text-amber-300">
                          <ArrowUpRight className="h-4 w-4" />
                          CAMPUS EXIT AUTHORIZED & RECORDED
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1.5 text-emerald-800 dark:text-emerald-300">
                          <ArrowDownLeft className="h-4 w-4" />
                          CAMPUS RETURN ENTRY VERIFIED
                        </span>
                      )}
                    </div>

                    <p className="text-[11px] mt-1 opacity-90">
                      {lastScanResult.message}
                    </p>
                  </div>
                </div>

                <div className="text-right shrink-0">
                  <span className="text-[10px] text-slate-500 font-bold uppercase block">PASS ID</span>
                  <span className="font-mono font-bold text-sm text-slate-900 dark:text-white">
                    {lastScanResult.pass.passNumber}
                  </span>
                </div>
              </div>

              {/* Parent SMS & WhatsApp Confirmation Dispatch Info */}
              <div className="mt-4 pt-3 border-t border-black/10 flex items-center justify-between text-xs dark:border-white/10">
                <span className="flex items-center gap-1.5 font-medium">
                  <Phone className="h-3.5 w-3.5" />
                  Parent WhatsApp Alert: <strong>{lastScanResult.pass.guardian.name} ({lastScanResult.pass.guardian.phone})</strong>
                </span>
                <Badge variant="outline" className="text-[10px] border-emerald-500 text-emerald-700 dark:text-emerald-300">
                  Delivered ✓
                </Badge>
              </div>
            </div>
          ) : (
            <div className="p-6 rounded-2xl bg-white border border-slate-200 shadow-sm text-center text-slate-400 dark:bg-slate-900 dark:border-slate-800">
              <ShieldCheck className="h-10 w-10 text-slate-300 mx-auto mb-2 dark:text-slate-600" />
              <h4 className="font-bold text-sm text-slate-700 dark:text-slate-300">
                Awaiting Gate QR Scan
              </h4>
              <p className="text-xs text-slate-400 mt-0.5">
                Scan or select any active pass token to record departure or return arrival.
              </p>
            </div>
          )}

          {/* Live Gate Movements Feed */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm dark:bg-slate-900 dark:border-slate-800">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <History className="h-4 w-4 text-emerald-600" />
                <h3 className="font-bold text-sm text-slate-900 dark:text-white">
                  Live Gate Transit Log (Today's Movements)
                </h3>
              </div>
              <span className="text-xs text-slate-500">
                {allMovements.length} scans registered
              </span>
            </div>

            <div className="space-y-2.5 max-h-[320px] overflow-y-auto pr-1">
              {allMovements.map((mov) => (
                <div
                  key={mov.id}
                  className="p-3 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between text-xs hover:bg-slate-100/80 transition-colors dark:bg-slate-800/40 dark:border-slate-800"
                >
                  <div className="flex items-center gap-3">
                    <div className={`h-8 w-8 rounded-lg flex items-center justify-center font-bold text-xs text-white ${
                      mov.movementType === "EXIT" ? "bg-amber-600" : "bg-emerald-600"
                    }`}>
                      {mov.movementType}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-slate-900 dark:text-white">
                          {mov.studentName}
                        </span>
                        <span className="font-mono text-[11px] text-slate-500">
                          ({mov.rollNumber})
                        </span>
                        <Badge variant="outline" className="text-[9px]">
                          {mov.passNumber}
                        </Badge>
                      </div>
                      <div className="text-[11px] text-slate-500 mt-0.5">
                        {mov.gateName} • Officer: {mov.securityOfficerName}
                      </div>
                    </div>
                  </div>

                  <div className="text-right">
                    <span className="font-mono font-bold text-slate-800 dark:text-slate-200">
                      {new Date(mov.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                    <span className="text-[10px] text-slate-400 block">
                      {mov.status}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>

      </div>

    </div>
  );
};
