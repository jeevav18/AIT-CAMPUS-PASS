import React from "react";
import { LateReturnIncident, PassRequest } from "@/types/campuspass";
import { 
  AlertTriangle, 
  PhoneCall, 
  Clock, 
  ShieldAlert, 
  Building, 
  CheckCircle2, 
  Send,
  MessageSquare,
  Users
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";

interface LateReturnAlertCenterProps {
  incidents: LateReturnIncident[];
  passes: PassRequest[];
  onResolveIncident?: (incidentId: string) => void;
}

export const LateReturnAlertCenter: React.FC<LateReturnAlertCenterProps> = ({
  incidents,
  passes,
  onResolveIncident,
}) => {
  const activeIncidents = incidents.filter((i) => i.status !== "RESOLVED");

  const handleAction = (incident: LateReturnIncident, actionType: string) => {
    toast.success(`Action Executed: ${actionType} for ${incident.studentName}. Log updated.`);
  };

  return (
    <div className="space-y-6">
      
      {/* Banner */}
      <div className="bg-gradient-to-r from-red-800 via-rose-900 to-slate-900 rounded-2xl p-6 text-white shadow-lg flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="h-14 w-14 rounded-2xl bg-white/10 backdrop-blur flex items-center justify-center text-white border border-white/20">
            <ShieldAlert className="h-7 w-7 text-red-200 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-bold tracking-tight">
                Curfew Watchdog & Late-Return Radar
              </h2>
              <Badge className="bg-red-500/30 text-red-100 border-white/20 text-xs">
                Real-Time Watchdog
              </Badge>
            </div>
            <p className="text-xs text-red-100/90 mt-0.5">
              Automated background monitor detecting unverified arrivals past curfew cutoffs
            </p>
          </div>
        </div>

        <div className="bg-black/30 backdrop-blur px-4 py-2 rounded-xl border border-white/10 text-center">
          <span className="text-[10px] text-red-200 uppercase font-bold block">
            Active Overdue Alerts
          </span>
          <span className="text-xl font-extrabold text-red-400">
            {activeIncidents.length}
          </span>
        </div>
      </div>

      {/* Incident Cards */}
      {activeIncidents.length > 0 ? (
        <div className="space-y-4">
          {activeIncidents.map((inc) => (
            <div
              key={inc.id}
              className="bg-white rounded-2xl border-2 border-red-300 p-6 shadow-md dark:bg-slate-900 dark:border-red-900/60"
            >
              <div className="flex flex-col md:flex-row md:items-start justify-between gap-4">
                <div className="flex items-start gap-4">
                  <div className="p-3 rounded-2xl bg-red-100 text-red-700 dark:bg-red-950/40 dark:text-red-400">
                    <AlertTriangle className="h-7 w-7" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2.5">
                      <h3 className="font-extrabold text-lg text-slate-900 dark:text-white">
                        {inc.studentName}
                      </h3>
                      <Badge className="font-mono text-xs bg-slate-100 text-slate-800 dark:bg-slate-800 dark:text-slate-300">
                        {inc.rollNumber}
                      </Badge>
                      <Badge className="bg-red-600 text-white text-xs font-bold animate-pulse">
                        +{inc.overdueMinutes} MINS OVERDUE
                      </Badge>
                      <Badge variant="outline" className="text-[10px] border-red-400 text-red-600">
                        {inc.severity} SEVERITY
                      </Badge>
                    </div>

                    <p className="text-xs text-slate-600 mt-1 dark:text-slate-400">
                      Hostel: <strong className="text-slate-800 dark:text-slate-200">{inc.hostelBlock}</strong> • Room {inc.roomNumber} • Pass #{inc.passNumber}
                    </p>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-3 text-xs bg-slate-50 p-3 rounded-xl border border-slate-200 dark:bg-slate-800/50 dark:border-slate-700">
                      <div>
                        <span className="text-slate-400 text-[10px] font-bold uppercase block">STUDENT PHONE</span>
                        <div className="font-mono font-semibold text-slate-800 flex items-center justify-between dark:text-slate-200">
                          <span>{inc.studentPhone}</span>
                          <a
                            href={`tel:${inc.studentPhone}`}
                            className="inline-flex items-center gap-1 text-[11px] text-blue-600 font-bold hover:underline"
                          >
                            <PhoneCall className="h-3 w-3" /> Call Student
                          </a>
                        </div>
                      </div>
                      <div>
                        <span className="text-slate-400 text-[10px] font-bold uppercase block">PARENT / GUARDIAN CONTACT</span>
                        <div className="font-mono font-semibold text-slate-800 flex items-center justify-between dark:text-slate-200">
                          <span>{inc.guardianName} ({inc.guardianPhone})</span>
                          <a
                            href={`tel:${inc.guardianPhone}`}
                            className="inline-flex items-center gap-1 text-[11px] text-red-600 font-bold hover:underline"
                          >
                            <PhoneCall className="h-3 w-3" /> Alert Parent
                          </a>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Escalation Actions */}
                <div className="space-y-2 shrink-0 md:text-right">
                  <div className="flex flex-wrap md:flex-col gap-2">
                    <Button
                      size="sm"
                      onClick={() => handleAction(inc, "Dialed Parent Murugan Palanisamy")}
                      className="bg-red-600 hover:bg-red-700 text-white text-xs font-semibold gap-1.5"
                    >
                      <PhoneCall className="h-3.5 w-3.5" />
                      Emergency Call to Parent
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleAction(inc, "Dispatched Campus Flying Squad")}
                      className="text-xs border-slate-300 text-slate-700 dark:text-slate-300"
                    >
                      Alert Security Patrol
                    </Button>
                  </div>
                </div>
              </div>

              {/* Action Trail */}
              <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800">
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-2">
                  Automated Escalation Audit Trail:
                </span>
                <div className="space-y-1.5">
                  {inc.actionsTaken.map((act, idx) => (
                    <div
                      key={idx}
                      className="text-xs text-slate-600 flex items-center justify-between bg-slate-50 p-2 rounded-lg dark:bg-slate-800/40 dark:text-slate-400"
                    >
                      <span>• {act.action} ({act.officer})</span>
                      <span className="font-mono text-[10px] text-slate-400">
                        {new Date(act.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center text-slate-500 dark:bg-slate-900 dark:border-slate-800">
          <CheckCircle2 className="h-12 w-12 text-emerald-500 mx-auto mb-2" />
          <h3 className="font-bold text-base text-slate-800 dark:text-slate-200">
            Zero Active Curfew Incidents
          </h3>
          <p className="text-xs text-slate-400 mt-1">
            All students who exited campus have returned on time or are within authorized departure hours.
          </p>
        </div>
      )}

    </div>
  );
};
