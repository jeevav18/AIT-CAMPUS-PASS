import React from "react";

interface AdithyaLogoProps {
  className?: string;
  size?: "sm" | "md" | "lg" | "xl";
  showText?: boolean;
  theme?: "light" | "dark" | "auto";
}

export const AdithyaLogo: React.FC<AdithyaLogoProps> = ({
  className = "",
  size = "md",
  showText = true,
  theme = "auto",
}) => {
  const sizeMap = {
    sm: "h-8 w-8",
    md: "h-11 w-11",
    lg: "h-16 w-16",
    xl: "h-24 w-24",
  };

  return (
    <div className={`flex items-center gap-2.5 ${className}`}>
      {/* Sun & 'A' Emblem */}
      <svg
        viewBox="0 0 500 320"
        className={`${sizeMap[size]} shrink-0 drop-shadow-sm`}
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        {/* Top Radiating Flame/Sun Petals */}
        <path d="M 250 15 C 265 55 275 85 250 120 C 225 85 235 55 250 15 Z" fill="#F97316" />
        <path d="M 145 65 C 180 90 205 110 195 150 C 160 135 140 105 145 65 Z" fill="#F97316" />
        <path d="M 355 65 C 360 105 340 135 305 150 C 295 110 320 90 355 65 Z" fill="#F97316" />
        <path d="M 80 160 C 120 160 150 170 160 210 C 120 210 95 190 80 160 Z" fill="#F97316" />
        <path d="M 420 160 C 405 190 380 210 340 210 C 350 170 380 160 420 160 Z" fill="#F97316" />

        {/* Orange Arch Ring */}
        <path d="M 140 270 A 135 135 0 0 1 360 270 L 325 270 A 100 100 0 0 0 175 270 Z" fill="#F97316" />

        {/* Navy Blue Stylized 'A' */}
        <path d="M 250 140 L 295 235 L 265 235 L 250 195 L 235 235 L 205 235 Z" fill="#1E293B" />
        <path d="M 175 270 C 190 235 220 223 250 223 C 280 223 310 235 325 270 C 295 247 265 243 250 243 C 235 243 205 247 175 270 Z" fill="#1E293B" />
      </svg>

      {/* Typography */}
      {showText && (
        <div className="flex flex-col select-none">
          <div className="font-serif font-black tracking-wider text-orange-600 leading-none text-base sm:text-lg">
            ADITHYA
          </div>
          <div className="font-serif font-extrabold tracking-widest text-slate-900 leading-tight text-[10px] sm:text-[11px] uppercase dark:text-slate-100">
            INSTITUTIONS
          </div>
          <div className="text-[9px] font-sans font-semibold tracking-wider text-slate-500 uppercase dark:text-slate-400">
            Coimbatore • TNEA 2744
          </div>
        </div>
      )}
    </div>
  );
};
