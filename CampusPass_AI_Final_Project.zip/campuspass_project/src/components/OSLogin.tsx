import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { ShieldAlert, Fingerprint, RefreshCw, KeyRound, User, Lock, Eye, EyeOff } from "lucide-react";
import { playTick, playHover, playGlitchSweep, playSuccessChime } from "@/lib/cyberAudio";

interface OSLoginProps {
  onAuthSuccess: () => void;
}

const OSLogin = ({ onAuthSuccess }: OSLoginProps) => {
  const [username, setUsername] = useState("RECRUITER_GUEST");
  const [password, setPassword] = useState("••••••••");
  const [showPassword, setShowPassword] = useState(false);
  const [scanState, setScanState] = useState<"idle" | "scanning" | "matching" | "success" | "failed">("idle");
  const [scanProgress, setScanProgress] = useState(0);
  const [loginStepMessage, setLoginStepMessage] = useState("Enter credentials or initiate biometrics");

  const startBioScan = () => {
    if (scanState === "scanning" || scanState === "matching" || scanState === "success") return;
    playGlitchSweep();
    setScanState("scanning");
    setScanProgress(0);
    setLoginStepMessage("Analyzing thumbprint ridge metrics...");

    const interval = setInterval(() => {
      setScanProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setScanState("matching");
          setLoginStepMessage("Synthesizing signature keys with Jeeva cryptographic matrix...");
          setTimeout(() => {
            playSuccessChime();
            setScanState("success");
            setLoginStepMessage("ACCESS GRANTED: Token decrypted successfully.");
            setTimeout(() => {
              onAuthSuccess();
            }, 1000);
          }, 1500);
          return 100;
        }
        return prev + Math.floor(Math.random() * 12) + 4;
      });
    }, 100);
  };

  const handlePasswordLogin = (e: React.FormEvent) => {
    e.preventDefault();
    playTick();
    setScanState("scanning");
    setScanProgress(0);
    setLoginStepMessage("Validating RSA payload signature...");

    const interval = setInterval(() => {
      setScanProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setScanState("matching");
          setTimeout(() => {
            playSuccessChime();
            setScanState("success");
            setLoginStepMessage("DECRYPT SUCCESS: Custom terminal buffer active.");
            setTimeout(() => {
              onAuthSuccess();
            }, 1000);
          }, 1000);
          return 100;
        }
        return prev + 25;
      });
    }, 150);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black font-mono overflow-hidden">
      {/* Immersive Scanlines and grid overlay */}
      <div className="absolute inset-0 bg-scanlines opacity-[0.07] pointer-events-none" />
      <div className="absolute inset-0 bg-grid opacity-[0.03] pointer-events-none" />

      {/* Floating orbital glow nodes */}
      <div className="absolute -top-[30%] -left-[20%] w-[60vw] h-[60vw] bg-[#00FF66]/5 rounded-full filter blur-[120px] pointer-events-none animate-pulse-slow" />
      <div className="absolute -bottom-[30%] -right-[20%] w-[60vw] h-[60vw] bg-[#00E5FF]/5 rounded-full filter blur-[120px] pointer-events-none animate-pulse-slow" />

      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        className="w-full max-w-md bg-[#050505]/90 border border-[#00FF66]/25 hover:border-[#00FF66]/40 p-6 md:p-8 rounded-xl shadow-[0_0_50px_rgba(0,255,102,0.1)] relative z-10 m-4"
      >
        {/* Animated facial target layout */}
        <div className="absolute top-4 right-4 text-[9px] text-[#00E5FF] flex items-center space-x-1.5 pointer-events-none uppercase">
          <span className="w-1.5 h-1.5 bg-[#00E5FF] rounded-full animate-ping" />
          <span>SCANNER_ONLINE_0x9A</span>
        </div>

        {/* Brand System Tag */}
        <div className="text-center space-y-2 mb-8">
          <h2 className="text-2xl md:text-3xl font-extrabold font-oxanium text-white tracking-widest uppercase text-glow-green">
            &gt;_JEEVA_18 OS
          </h2>
          <p className="text-[10px] text-gray-500 uppercase tracking-widest font-semibold">
            SECURE DECRYPT MATRIX SYSTEM v4.0
          </p>
        </div>

        {/* Security Alert Header */}
        <div className="bg-[#FFC107]/5 border border-[#FFC107]/25 rounded-lg p-3 flex items-start space-x-3 mb-6">
          <ShieldAlert className="w-5 h-5 text-[#FFC107] shrink-0 animate-pulse" />
          <div className="text-[10px] text-gray-400 leading-relaxed font-semibold uppercase">
            <span className="text-[#FFC107] font-bold">WARNING:</span> This portfolio node contains highly confidential engineering credentials. Initiate authorization flow to unlock.
          </div>
        </div>

        {/* Authentication Options Tab */}
        <div className="space-y-6">
          {scanState === "idle" ? (
            <form onSubmit={handlePasswordLogin} className="space-y-4">
              <div className="space-y-1.5">
                <label className="text-[10px] text-gray-500 font-bold uppercase tracking-wider block">Username ID</label>
                <div className="relative flex items-center">
                  <User className="absolute left-3 w-4 h-4 text-gray-500" />
                  <input
                    type="text"
                    required
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    className="w-full bg-black/60 border border-[#00FF66]/20 focus:border-[#00FF66]/60 rounded-md py-2 pl-10 pr-4 text-sm text-white focus:outline-none focus:ring-1 focus:ring-[#00FF66]/20 transition-all font-mono"
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] text-gray-500 font-bold uppercase tracking-wider block">Decryption Password</label>
                <div className="relative flex items-center">
                  <Lock className="absolute left-3 w-4 h-4 text-gray-500" />
                  <input
                    type={showPassword ? "text" : "password"}
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full bg-black/60 border border-[#00FF66]/20 focus:border-[#00FF66]/60 rounded-md py-2 pl-10 pr-10 text-sm text-white focus:outline-none focus:ring-1 focus:ring-[#00FF66]/20 transition-all font-mono"
                  />
                  <button
                    type="button"
                    onMouseEnter={playHover}
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 p-0.5 text-gray-500 hover:text-[#00FF66]"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <button
                type="submit"
                onMouseEnter={playHover}
                className="w-full py-2.5 bg-[#00FF66]/10 hover:bg-[#00FF66]/20 border border-[#00FF66]/30 text-[#00FF66] font-bold text-xs uppercase tracking-widest rounded-md cursor-pointer transition-all shadow-[0_0_12px_rgba(0,255,102,0.1)] flex items-center justify-center space-x-2"
              >
                <KeyRound className="w-4 h-4" />
                <span>Decrypt Portfolio Buffer</span>
              </button>

              {/* OR Divider */}
              <div className="relative flex items-center py-2">
                <div className="flex-grow border-t border-zinc-800" />
                <span className="flex-shrink mx-3 text-[9px] text-gray-500 font-bold tracking-widest uppercase">OR BYPASS</span>
                <div className="flex-grow border-t border-zinc-800" />
              </div>

              {/* Fingerprint bypass button */}
              <button
                type="button"
                onMouseEnter={playHover}
                onClick={startBioScan}
                className="w-full py-2.5 bg-[#00E5FF]/10 hover:bg-[#00E5FF]/20 border border-[#00E5FF]/30 text-[#00E5FF] font-bold text-xs uppercase tracking-widest rounded-md cursor-pointer transition-all shadow-[0_0_12px_rgba(0,229,255,0.1)] flex items-center justify-center space-x-2"
              >
                <Fingerprint className="w-4 h-4 text-[#00E5FF]" />
                <span>Initiate Fingerprint Bio-Scan</span>
              </button>
            </form>
          ) : (
            /* Bio Scanning Overlay */
            <div className="py-6 flex flex-col items-center justify-center space-y-6">
              <div className="relative flex items-center justify-center">
                {/* Glowing biometric target box */}
                <div className={`p-5 rounded-2xl border-2 transition-all duration-300 ${
                  scanState === "success" 
                    ? "border-[#00FF66] bg-[#00FF66]/5" 
                    : "border-[#00E5FF] bg-[#00E5FF]/5 animate-pulse"
                }`}>
                  <Fingerprint className={`w-16 h-16 transition-colors duration-300 ${
                    scanState === "success" ? "text-[#00FF66]" : "text-[#00E5FF]"
                  }`} />
                </div>
                {/* Laser scan line overlay */}
                {scanState === "scanning" && (
                  <motion.div
                    animate={{ top: ["20%", "80%", "20%"] }}
                    transition={{ repeat: Infinity, duration: 1.5, ease: "linear" }}
                    className="absolute left-4 right-4 h-0.5 bg-[#00E5FF] shadow-[0_0_8px_#00E5FF]"
                  />
                )}
              </div>

              {/* Scan status gauges */}
              <div className="w-full max-w-xs font-mono text-xs text-center space-y-2">
                <div className="flex justify-between items-center text-[10px]">
                  <span className="text-gray-500 font-bold uppercase">SCANNER_FLUX:</span>
                  <span className={scanState === "success" ? "text-[#00FF66]" : "text-[#00E5FF]"}>
                    {scanState === "success" ? "VERIFIED" : `${Math.min(scanProgress, 100)}%`}
                  </span>
                </div>
                <div className="h-2 w-full bg-black border border-zinc-800 rounded-full overflow-hidden p-0.5">
                  <motion.div
                    className={`h-full rounded-full ${scanState === "success" ? "bg-[#00FF66]" : "bg-[#00E5FF]"}`}
                    animate={{ width: `${Math.min(scanProgress, 100)}%` }}
                  />
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Live diagnostics status feed */}
        <div className="mt-6 border-t border-[#00FF66]/10 pt-4 flex items-center justify-between text-[9px] text-gray-500 font-bold uppercase">
          <span className="truncate max-w-[280px] text-[#00FF66]/80 text-glow-green">STATUS: {loginStepMessage}</span>
          {scanState === "scanning" && <RefreshCw className="w-3 h-3 text-[#00E5FF] animate-spin" />}
        </div>
      </motion.div>
    </div>
  );
};

export default OSLogin;
