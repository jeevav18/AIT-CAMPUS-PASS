# CampusPass AI — Final Project Delivery Notes

## Project stack
- React + TypeScript + Vite
- Supabase Auth / database integration
- Tailwind CSS and UI components
- Adithya Institutions logo asset: `public/adithya_logo.svg`

## Run locally
1. Install Node.js LTS.
2. Copy `.env.example` to `.env` and set the real Supabase project URL and publishable key.
3. Run `npm install`.
4. Run `npm run dev`.
5. Verify login, student pass request, approval dashboards, QR scanning and role restrictions against the configured Supabase project.
6. Run `npm run build` before publishing.

## Lovable deployment
Open the existing Lovable project, sync/push these source changes to that project if needed, review the environment variables, then use **Share / Publish**. Test the resulting public URL in a private browser window.

## Important verification status
This package is the source project delivery; it is not proof of a successful production deployment. A production build and live-site test have not been verified in this environment. Before real student data is used, review the Supabase migrations and Row Level Security policies, ensure the pass-request/approval/QR/gate-event tables and server-side validation exist, and move private Gemini API calls out of the browser into a secure server-side function. Never place service-role keys or private API keys in `VITE_*` frontend variables.
