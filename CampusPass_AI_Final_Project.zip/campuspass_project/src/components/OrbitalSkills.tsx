import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Cloud, Layout, Server, Settings, Cpu, Orbit, Compass, Zap, Activity, Info, Sliders, Play, Pause, Terminal, RefreshCw } from "lucide-react";
import { playTick, playHover, playGlitchSweep, playSuccessChime } from "@/lib/cyberAudio";

interface SkillNode {
  name: string;
  level: number;
  category: "salesforce" | "frontend" | "backend" | "tools";
  desc: string;
  angleOffset: number; // custom base angle
}

const OrbitalSkills = () => {
  const [selectedSkill, setSelectedSkill] = useState<SkillNode | null>(null);
  const [rotationActive, setRotationActive] = useState(true);
  const [orbitalSpeed, setOrbitalSpeed] = useState(1); // multiplier
  const [pitch, setPitch] = useState(55); // Vertical tilt angle (deg)
  const [yaw, setYaw] = useState(-20); // Horizontal rotation angle (deg)
  const [quantumDecay, setQuantumDecay] = useState(98.6);
  const [sysLogs, setSysLogs] = useState<string[]>([
    "SYS_INIT: Quantum Core loading...",
    "SHELL_GRID: Status NOMINAL",
  ]);

  const requestRef = useRef<number | null>(null);
  const [time, setTime] = useState(0);

  // Expanded Skills Database to show advanced professional capability
  const skillsList: SkillNode[] = [
    // Salesforce Core (Inner Shell)
    { name: "APEX", level: 96, category: "salesforce", desc: "Object-oriented language for robust server-side controllers, queueable async chains, and trigger handlers.", angleOffset: 0 },
    { name: "LWC", level: 95, category: "salesforce", desc: "Performance-tuned Lightning Web Components with customized shadow DOM, reactive properties, and LMS.", angleOffset: 72 },
    { name: "Triggers", level: 97, category: "salesforce", desc: "Event-driven Apex trigger architecture, bulkified operations, context variable routing, and recursion guards.", angleOffset: 144 },
    { name: "Visualforce (Legacy)", level: 88, category: "salesforce", desc: "Classic component-based rendering, custom controllers, PDF generation, and legacy migration.", angleOffset: 216 },
    { name: "REST API Integrations", level: 95, category: "salesforce", desc: "Secure OAuth-coupled integration pipelines sync external databases and server APIs with CRM data pools.", angleOffset: 288 },

    // Frontend & Languages (Middle Shell)
    { name: "JavaScript", level: 94, category: "frontend", desc: "Type-safe asynchronous loops, module mappings, map-reduce array processing, and clean functional structures.", angleOffset: 0 },
    { name: "HTML", level: 96, category: "frontend", desc: "Structured semantic document models, accessibility standards (WCAG AA), and modern Web Components DOM.", angleOffset: 120 },
    { name: "CSS", level: 93, category: "frontend", desc: "Bespoke styling systems utilizing SLDS design tokens, CSS Grid, Flexbox, and hardware-accelerated animations.", angleOffset: 240 },

    // Automation, DB & Security (Outer Shell)
    { name: "Ethical Hacker", level: 95, category: "tools", desc: "Red-team offensive penetration testing, SOQL/SQLi mitigation, vulnerability scans, and zero-trust cloud hardening.", angleOffset: 0 },
    { name: "Flow (Low-Code)", level: 96, category: "tools", desc: "Declarative orchestration of automated pipelines, high-efficiency record triggers, and Invocable Apex sub-flows.", angleOffset: 90 },
    { name: "SOQL", level: 95, category: "tools", desc: "Surgical database querying optimized with custom index keys to cleanly bypass critical Governor limits.", angleOffset: 180 },
    { name: "SOSL", level: 91, category: "tools", desc: "High-speed multi-object text indexing and search execution across heterogeneous database entities.", angleOffset: 270 },
  ];

  // System logs simulation
  useEffect(() => {
    const logInterval = setInterval(() => {
      const logs = [
        "TRANSMISSION_FLUX: Delta calibrated to " + (Math.random() * 0.05 + 0.98).toFixed(4) + " GHz",
        "COUPLE_EFFICIENCY: Calibrated at " + (95 + Math.random() * 4.9).toFixed(1) + "%",
        "GRID_COORDS: Synchronized on quantum shell r=" + (100 + Math.random() * 5).toFixed(0),
        "ELECTRON_PULSE: Charge cycle active in outer matrix",
        "BYPASS_STATUS: Active governor bypasses verified",
      ];
      const randomLog = logs[Math.floor(Math.random() * logs.length)];
      setSysLogs((prev) => [randomLog, ...prev.slice(0, 4)]);
      setQuantumDecay((prev) => {
        const val = prev + (Math.random() * 0.4 - 0.2);
        return Math.min(Math.max(parseFloat(val.toFixed(2)), 95), 100);
      });
    }, 4500);

    return () => clearInterval(logInterval);
  }, []);

  // Frame timer looping
  useEffect(() => {
    const animate = () => {
      if (rotationActive) {
        setTime((prev) => prev + 0.01 * orbitalSpeed);
      }
      requestRef.current = requestAnimationFrame(animate);
    };

    requestRef.current = requestAnimationFrame(animate);
    return () => {
      if (requestRef.current) cancelAnimationFrame(requestRef.current);
    };
  }, [rotationActive, orbitalSpeed]);

  // Orbit radius settings
  const shellRadii = {
    salesforce: 90,   // Inner Shell
    frontend: 155,    // Middle Shell
    tools: 220,       // Outer Shell
  };

  // ADVANCED 3D TO 2D PERSPECTIVE PROJECTION
  // Rotates flat XY coordinates around Y axis (Yaw) and X axis (Pitch)
  const getProjectedCoordinates = (
    category: "salesforce" | "frontend" | "backend" | "tools",
    baseAngle: number,
    extraOffset: number = 0
  ) => {
    const radius = shellRadii[category === "backend" ? "tools" : category] || 150;
    
    // Determine dynamic orbital rotation angle
    const spinDirection = category === "salesforce" ? 1 : category === "frontend" ? -0.8 : 0.6;
    const currentAngle = baseAngle + time * 35 * spinDirection + extraOffset;
    const angleRad = (currentAngle * Math.PI) / 180;

    // 1. Coordinates on flat XY plane relative to center (0, 0, 0)
    const x3d = radius * Math.cos(angleRad);
    const y3d = radius * Math.sin(angleRad);
    const z3d = 0;

    // 2. Yaw (rotation around Y-axis)
    const yawRad = (yaw * Math.PI) / 180;
    const x1 = x3d * Math.cos(yawRad) - z3d * Math.sin(yawRad);
    const z1 = x3d * Math.sin(yawRad) + z3d * Math.cos(yawRad);
    const y1 = y3d;

    // 3. Pitch (rotation around X-axis / Tilt)
    const pitchRad = (pitch * Math.PI) / 180;
    const x2 = x1;
    const y2 = y1 * Math.cos(pitchRad) - z1 * Math.sin(pitchRad);
    const z2 = y1 * Math.sin(pitchRad) + z1 * Math.cos(pitchRad);

    // 4. Perspective Projection Scaling (D is the camera distance helper)
    const D = 450;
    const scale = D / (D + z2);

    // Center at (250, 230) inside our SVG viewport
    return {
      x: 250 + x2 * scale,
      y: 230 + y2 * scale,
      scale,
      depth: z2, // useful to determine drawing orders if needed
    };
  };

  // Generate continuous SVG paths representing elliptical projected rings
  const getProjectedRingPath = (radius: number) => {
    const points: string[] = [];
    // Samples 60 points along the circle to project perfectly in 3D
    for (let i = 0; i <= 360; i += 6) {
      const angleRad = (i * Math.PI) / 180;
      const x3d = radius * Math.cos(angleRad);
      const y3d = radius * Math.sin(angleRad);
      const z3d = 0;

      const yawRad = (yaw * Math.PI) / 180;
      const x1 = x3d * Math.cos(yawRad) - z3d * Math.sin(yawRad);
      const z1 = x3d * Math.sin(yawRad) + z3d * Math.cos(yawRad);
      const y1 = y3d;

      const pitchRad = (pitch * Math.PI) / 180;
      const x2 = x1;
      const y2 = y1 * Math.cos(pitchRad) - z1 * Math.sin(pitchRad);
      const z2 = y1 * Math.sin(pitchRad) + z1 * Math.cos(pitchRad);

      const D = 450;
      const scale = D / (D + z2);
      const px = 250 + x2 * scale;
      const py = 230 + y2 * scale;

      points.push(`${i === 0 ? "M" : "L"} ${px.toFixed(1)} ${py.toFixed(1)}`);
    }
    return points.join(" ");
  };

  // Electron particles moving fast on orbital paths
  const electrons = [
    { category: "salesforce", color: "#00E5FF", offset: 120, size: 3.5 },
    { category: "frontend", color: "#00FF66", offset: 240, size: 3.5 },
    { category: "tools", color: "#FFC107", offset: 45, size: 3.5 },
  ];

  const triggerGlitchedReSync = () => {
    playGlitchSweep();
    setPitch(55);
    setYaw(-20);
    setOrbitalSpeed(1);
    setRotationActive(true);
    setSysLogs((prev) => ["OS_RESET: Standardizing spatial parameters...", ...prev.slice(0, 3)]);
    setTimeout(() => playSuccessChime(), 300);
  };

  return (
    <div className="w-full bg-[#080808]/95 border border-[#00FF66]/20 rounded-xl overflow-hidden shadow-elegant p-4 md:p-8 font-mono relative">
      {/* Dynamic scanline overlay */}
      <div className="absolute inset-0 bg-grid pointer-events-none opacity-[0.02]" />

      {/* Top Interactive Banner Control Area */}
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center border-b border-[#00FF66]/15 pb-6 mb-6 space-y-4 lg:space-y-0">
        <div className="flex items-center space-x-3">
          <div className="p-2.5 rounded-lg bg-[#00FF66]/5 border border-[#00FF66]/20 relative">
            <Orbit className="w-5.5 h-5.5 text-[#00FF66] animate-spin-slow" />
            <div className="absolute inset-0 bg-[#00FF66]/10 rounded-lg animate-ping pointer-events-none" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-white tracking-widest uppercase font-oxanium text-glow-green">[ SPACE_QUANTUM_CORE v4.0 ]</h3>
            <p className="text-[10px] text-gray-500 uppercase tracking-wider">3D Holographic Angular projection & telemetry analyzer</p>
          </div>
        </div>

        {/* Core Controls Console */}
        <div className="flex flex-wrap items-center gap-3 text-xs">
          <div className="flex items-center space-x-2 border border-[#00FF66]/20 bg-black/60 px-3 py-1.5 rounded-md">
            <span className="text-[10px] text-gray-500 uppercase font-bold">SPIN_DRIVE:</span>
            <button
              onMouseEnter={playHover}
              onClick={() => {
                playGlitchSweep();
                setRotationActive(!rotationActive);
                setSysLogs((prev) => [`SPIN_DRIVE: ${!rotationActive ? "ENABLED" : "HALTED"}`, ...prev.slice(0, 3)]);
              }}
              className={`p-1 rounded uppercase font-bold text-[9px] flex items-center space-x-1 cursor-pointer ${
                rotationActive ? "text-[#00FF66] bg-[#00FF66]/15" : "text-gray-500 bg-zinc-900"
              }`}
            >
              {rotationActive ? <Pause className="w-3 h-3" /> : <Play className="w-3 h-3" />}
              <span>{rotationActive ? "RUNNING" : "HALTED"}</span>
            </button>
          </div>

          <div className="flex items-center space-x-2 border border-[#00FF66]/20 bg-black/60 px-3 py-1.5 rounded-md">
            <span className="text-[10px] text-gray-500 uppercase font-bold">FLUX_SPD:</span>
            <button
              onMouseEnter={playHover}
              onClick={() => {
                playTick();
                setOrbitalSpeed((prev) => (prev === 1 ? 2.5 : prev === 2.5 ? 0.3 : 1));
              }}
              className="text-[#00E5FF] font-bold cursor-pointer hover:bg-white/5 px-1.5 py-0.5 rounded transition"
            >
              {orbitalSpeed === 1 ? "1.0X" : orbitalSpeed === 2.5 ? "2.5X" : "0.3X"}
            </button>
          </div>

          <button
            onMouseEnter={playHover}
            onClick={triggerGlitchedReSync}
            className="border border-[#00FF66]/30 bg-[#00FF66]/5 hover:bg-[#00FF66]/15 text-[#00FF66] p-1.5 rounded-md flex items-center justify-center cursor-pointer transition-all shadow-[0_0_8px_rgba(0,255,102,0.1)]"
            title="Calibrate Quantum System Alignment"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
        {/* Left Side: 3D Holographic SVG Render Canvas */}
        <div className="lg:col-span-7 flex flex-col items-center justify-center relative bg-black/35 border border-[#00FF66]/15 rounded-xl p-4 w-full">
          {/* Top telemetry specs overlay */}
          <div className="absolute top-3 left-4 right-4 flex justify-between items-center text-[9px] text-gray-500 pointer-events-none">
            <span className="flex items-center space-x-1">
              <span className="w-1.5 h-1.5 rounded-full bg-[#00FF66] animate-pulse" />
              <span>YAW: {yaw}° / PITCH: {pitch}°</span>
            </span>
            <span>DECAY: {quantumDecay}%</span>
          </div>

          {/* Holographic Projection SVG */}
          <div className="relative aspect-square max-w-[440px] w-full flex items-center justify-center">
            <svg viewBox="0 0 500 460" className="w-full h-full select-none relative z-10 overflow-visible">
              <defs>
                {/* Glow Filter logic */}
                <filter id="hologram-glow" x="-20%" y="-20%" width="140%" height="140%">
                  <feGaussianBlur stdDeviation="4" result="blur" />
                  <feMerge>
                    <feMergeNode in="blur" />
                    <feMergeNode in="SourceGraphic" />
                  </feMerge>
                </filter>
              </defs>

              {/* Orbital Elliptical 3D Projection Rings */}
              {Object.entries(shellRadii).map(([key, r]) => {
                const ringColor = key === "salesforce" ? "#00E5FF" : key === "frontend" ? "#00FF66" : "#FFC107";
                return (
                  <path
                    key={key}
                    d={getProjectedRingPath(r)}
                    className="fill-none stroke-1"
                    stroke={ringColor}
                    strokeDasharray="3, 5"
                    strokeOpacity="0.25"
                  />
                );
              })}

              {/* 3D Connecting Grid Axes line sweepers */}
              <line
                x1={250 + 230 * Math.cos((time * 20 * Math.PI) / 180)}
                y1={230 + 100 * Math.sin((time * 20 * Math.PI) / 180)}
                x2="250"
                y2="230"
                stroke="#00FF66"
                strokeOpacity="0.08"
                strokeWidth="1"
              />

              {/* Center Core Hub (Jeeva 18) */}
              <g className="filter drop-shadow-[0_0_10px_#00FF66]">
                <circle cx="250" cy="230" r="28" className="fill-black/90 stroke-[#00FF66] stroke-2" />
                <circle cx="250" cy="230" r="32" className="fill-none stroke-[#00FF66]/20 stroke-1 animate-ping" />
                <text
                  x="250"
                  y="233"
                  textAnchor="middle"
                  className="fill-[#00FF66] text-[8px] font-bold font-oxanium text-glow-green"
                >
                  &gt;_JEEVA_18
                </text>
              </g>

              {/* Orbiting Quantum Electrons (moving fast on rings) */}
              {electrons.map((elec, idx) => {
                // Dynamically spin the electron particles relative to time
                const cycleAngle = time * 210 + elec.offset;
                const ecoords = getProjectedCoordinates(
                  elec.category as "salesforce" | "frontend" | "backend" | "tools",
                  0,
                  cycleAngle
                );

                return (
                  <g key={idx} className="filter drop-shadow-[0_0_5px_currentColor]" style={{ color: elec.color }}>
                    <circle
                      cx={ecoords.x}
                      cy={ecoords.y}
                      r={elec.size}
                      fill={elec.color}
                      opacity={0.85}
                    />
                    <circle
                      cx={ecoords.x}
                      cy={ecoords.y}
                      r={elec.size * 2}
                      fill="none"
                      stroke={elec.color}
                      strokeWidth="0.5"
                      opacity="0.5"
                      className="animate-ping"
                    />
                  </g>
                );
              })}

              {/* Interactive Technical Skill Node Matrix */}
              {skillsList.map((skill, index) => {
                const coords = getProjectedCoordinates(skill.category, skill.angleOffset);
                const isSelected = selectedSkill?.name === skill.name;
                
                // Color mappings
                const nodeColor = 
                  skill.category === "salesforce" ? "#00E5FF" : 
                  skill.category === "frontend" ? "#00FF66" : "#FFC107";

                return (
                  <g
                    key={index}
                    className="cursor-pointer group"
                    onMouseEnter={playHover}
                    onClick={() => {
                      playTick();
                      setSelectedSkill(skill);
                      setSysLogs((prev) => [`NODE_DECRYPTED: ${skill.name.toUpperCase()}`, ...prev.slice(0, 3)]);
                    }}
                  >
                    {/* Active vector connecting line if selected */}
                    {isSelected && (
                      <line
                        x1="250"
                        y1="230"
                        x2={coords.x}
                        y2={coords.y}
                        className="stroke-[#00E5FF] stroke-1.5 animate-pulse"
                        strokeDasharray="4, 4"
                      />
                    )}

                    {/* Outer glowing pulsing orbit shell */}
                    <circle
                      cx={coords.x}
                      cy={coords.y}
                      r={isSelected ? 16 * coords.scale : 9 * coords.scale}
                      className="fill-none transition-all duration-300"
                      stroke={nodeColor}
                      strokeWidth={isSelected ? 2 : 1}
                      strokeOpacity={isSelected ? 0.9 : 0.3}
                    />

                    {/* Node Core Vector */}
                    <circle
                      cx={coords.x}
                      cy={coords.y}
                      r={isSelected ? 8.5 * coords.scale : 5 * coords.scale}
                      className="transition-all duration-300"
                      fill={isSelected ? "#050505" : nodeColor}
                      stroke={isSelected ? nodeColor : "none"}
                      strokeWidth={isSelected ? 2.5 : 0}
                    />

                    {/* 3D Perspective Scaling Text Node Names */}
                    {(isSelected || rotationActive === false || coords.scale > 1.05) && (
                      <text
                        x={coords.x}
                        y={coords.y - (14 * coords.scale)}
                        textAnchor="middle"
                        className="fill-white text-[9px] font-bold tracking-widest text-glow-green"
                        style={{
                          textShadow: "0 0 6px rgba(0,0,0,0.95)",
                          fontSize: `${Math.max(8, 9 * coords.scale)}px`,
                        }}
                      >
                        {skill.name.split(" ")[0]}
                      </text>
                    )}
                  </g>
                );
              })}
            </svg>
          </div>

          {/* Interactive Tilt Sliders HUD to manually manipulate 3D core space */}
          <div className="w-full mt-2 pt-3 border-t border-[#00FF66]/10 grid grid-cols-2 gap-4 text-[9px] text-gray-500 bg-black/25 p-2.5 rounded-lg">
            <div className="space-y-1">
              <div className="flex justify-between items-center font-bold">
                <span>YAW_SPATIAL_ROTATION:</span>
                <span className="text-white">{yaw}°</span>
              </div>
              <input
                type="range"
                min="-80"
                max="80"
                value={yaw}
                onChange={(e) => {
                  setYaw(Number(e.target.value));
                  if (Math.random() < 0.15) playTick();
                }}
                className="w-full accent-[#00FF66] h-1 bg-zinc-900 rounded-lg cursor-pointer"
              />
            </div>

            <div className="space-y-1">
              <div className="flex justify-between items-center font-bold">
                <span>PITCH_Z_AXIS_TILT:</span>
                <span className="text-white">{pitch}°</span>
              </div>
              <input
                type="range"
                min="10"
                max="80"
                value={pitch}
                onChange={(e) => {
                  setPitch(Number(e.target.value));
                  if (Math.random() < 0.15) playTick();
                }}
                className="w-full accent-[#00E5FF] h-1 bg-zinc-900 rounded-lg cursor-pointer"
              />
            </div>
          </div>
        </div>

        {/* Right Side: Cybernetic Real-Time Diagnostics Interface */}
        <div className="lg:col-span-5 flex flex-col justify-between h-full space-y-6">
          <div className="bg-black/60 border border-[#00FF66]/15 rounded-xl p-5 space-y-5 flex-1 flex flex-col justify-between">
            
            {/* Sector Monitor Heading */}
            <div className="space-y-4">
              <div className="flex items-center justify-between border-b border-[#00FF66]/15 pb-3">
                <div className="flex items-center space-x-2">
                  <Activity className="w-4 h-4 text-[#00E5FF] animate-pulse" />
                  <span className="text-xs font-bold text-[#00E5FF] uppercase font-oxanium tracking-widest">SHELL_DIAGNOSTICS</span>
                </div>
                <div className="flex items-center space-x-1 text-[8px] text-gray-500 font-bold uppercase">
                  <span>SEC_ADDR: 0x2A9C</span>
                </div>
              </div>

              {/* Dynamic Skill decrypter monitor block */}
              <AnimatePresence mode="wait">
                {selectedSkill ? (
                  <motion.div
                    key={selectedSkill.name}
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    className="space-y-4 text-xs md:text-sm"
                  >
                    <div className="flex justify-between items-start gap-2">
                      <span className="text-[#FFC107] font-bold text-base font-oxanium tracking-wide leading-tight text-glow-green">
                        {selectedSkill.name.toUpperCase()}
                      </span>
                      <span className="text-[9px] bg-[#00FF66]/10 border border-[#00FF66]/30 text-[#00FF66] px-2 py-0.5 rounded uppercase font-bold tracking-wider shrink-0">
                        {selectedSkill.category}
                      </span>
                    </div>

                    <div className="bg-[#050505]/90 border-l-2 border-[#00E5FF] p-3 text-gray-300 text-xs leading-relaxed font-mono">
                      <span className="text-[10px] text-[#00E5FF] font-bold block mb-1">CORE_DESCR:~$</span>
                      {selectedSkill.desc}
                    </div>

                    {/* Skill Index Level Gauges */}
                    <div className="space-y-1.5">
                      <div className="flex justify-between text-[11px] font-bold">
                        <span className="text-gray-500 uppercase">PROFICIENCY_INDEX:</span>
                        <span className="text-[#00FF66] text-glow-green">{selectedSkill.level}%</span>
                      </div>
                      <div className="h-2.5 w-full bg-[#050505] border border-[#00FF66]/10 rounded-full overflow-hidden p-0.5">
                        <motion.div
                          initial={{ width: 0 }}
                          animate={{ width: `${selectedSkill.level}%` }}
                          transition={{ duration: 0.5 }}
                          className="h-full bg-gradient-to-r from-[#00E5FF] to-[#00FF66] rounded-full"
                        />
                      </div>
                    </div>

                    {/* Sector details */}
                    <div className="grid grid-cols-2 gap-2 text-[9px] text-gray-500 bg-[#050505]/80 p-2.5 rounded-lg border border-[#00FF66]/10">
                      <div>CYCLES: 4.8 THz</div>
                      <div>LATENCY: 0.8ms</div>
                      <div>COUPLING_EFF: {(96 + selectedSkill.level/20).toFixed(2)}%</div>
                      <div>ADDR: 0x{((selectedSkill.level * 3) + 214).toString(16).toUpperCase()}</div>
                    </div>
                  </motion.div>
                ) : (
                  <div className="min-h-[170px] flex flex-col items-center justify-center text-center text-gray-500 py-6 space-y-3">
                    <Info className="w-8 h-8 text-gray-600 animate-pulse" />
                    <div className="space-y-1.5">
                      <p className="text-xs font-bold text-white uppercase tracking-widest">COGNITIVE_GRID_OFFLINE</p>
                      <p className="text-[10px] max-w-xs leading-relaxed">
                        Select a revolving orbital skill node on the left coordinate plane to connect a diagnostic link and decrypt professional intelligence.
                      </p>
                    </div>
                  </div>
                )}
              </AnimatePresence>
            </div>

            {/* Real-time system log ticker feeds inside Diagnostics */}
            <div className="border-t border-[#00FF66]/10 pt-3 mt-auto space-y-2">
              <div className="flex items-center space-x-1.5 text-[9px] text-gray-500 font-bold uppercase">
                <Terminal className="w-3.5 h-3.5 text-[#00FF66]" />
                <span>CORE_TELEMETRY_LOGS:</span>
              </div>
              <div className="bg-[#030303]/90 rounded-lg p-2.5 border border-[#00FF66]/10 space-y-1.5 h-20 overflow-y-auto font-mono text-[9px] text-[#00FF66]/80 text-glow-green scrollbar-thin">
                {sysLogs.map((log, idx) => (
                  <div key={idx} className="flex justify-between">
                    <span>{`> ${log}`}</span>
                    <span className="text-gray-600 text-[8px]">{new Date().toLocaleTimeString().split(" ")[0]}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Core Level Legend Info HUD */}
          <div className="grid grid-cols-3 gap-2 text-[9px] text-center">
            <div className="border border-[#00E5FF]/20 p-2.5 rounded-xl bg-black/40">
              <span className="w-1.5 h-1.5 rounded-full bg-[#00E5FF] inline-block mr-1.5" />
              <div className="font-bold text-white">CORE SFDC</div>
              <div className="text-gray-500 uppercase text-[8px] mt-0.5">Inner Ring</div>
            </div>
            <div className="border border-[#00FF66]/20 p-2.5 rounded-xl bg-black/40">
              <span className="w-1.5 h-1.5 rounded-full bg-[#00FF66] inline-block mr-1.5" />
              <div className="font-bold text-white">FRONT_END</div>
              <div className="text-gray-500 uppercase text-[8px] mt-0.5">Middle Ring</div>
            </div>
            <div className="border border-[#FFC107]/20 p-2.5 rounded-xl bg-black/40">
              <span className="w-1.5 h-1.5 rounded-full bg-[#FFC107] inline-block mr-1.5" />
              <div className="font-bold text-white">TOOLS/DEV</div>
              <div className="text-gray-500 uppercase text-[8px] mt-0.5">Outer Ring</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default OrbitalSkills;
