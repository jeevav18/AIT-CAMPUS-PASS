import React from "react";
import {
  Compass,
  ArrowRight,
  BookOpen,
  Hammer,
  Rocket,
  RefreshCw,
  Sparkles,
  CheckCircle2,
} from "lucide-react";
import { PORTFOLIO_DATA, LearningItem } from "@/data/portfolioData";

export const LearningJourneySection: React.FC = () => {
  const getStageBadge = (stage: LearningItem["stage"]) => {
    switch (stage) {
      case "Learning":
        return {
          icon: <BookOpen className="w-3.5 h-3.5" />,
          classes: "bg-amber-50 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300 border-amber-200 dark:border-amber-800",
        };
      case "Building":
        return {
          icon: <Hammer className="w-3.5 h-3.5" />,
          classes: "bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 border-blue-200 dark:border-blue-800",
        };
      case "Deploying":
        return {
          icon: <Rocket className="w-3.5 h-3.5" />,
          classes: "bg-purple-50 dark:bg-purple-950/60 text-purple-700 dark:text-purple-300 border-purple-200 dark:border-purple-800",
        };
      case "Improving":
        return {
          icon: <RefreshCw className="w-3.5 h-3.5" />,
          classes: "bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-400 border-emerald-200 dark:border-emerald-800",
        };
      default:
        return {
          icon: <Sparkles className="w-3.5 h-3.5" />,
          classes: "bg-slate-100 text-slate-700 border-slate-200",
        };
    }
  };

  return (
    <section id="learning" className="py-20 sm:py-28 bg-white dark:bg-slate-900 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-50 dark:bg-blue-950/60 border border-blue-200 dark:border-blue-800 text-blue-700 dark:text-blue-300 text-xs font-semibold uppercase tracking-wider mb-3">
            <span>Continuous Improvement</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            Currently Learning & Engineering Focus
          </h2>
          <p className="mt-3 text-base sm:text-lg text-slate-600 dark:text-slate-300">
            A developer who continuously expands boundaries across cloud systems, AI engineering, distributed architectures, and competitive algorithms.
          </p>
        </div>

        {/* 4-Stage Lifecycle Process Bar */}
        <div className="max-w-4xl mx-auto mb-14 p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-800">
          <p className="text-[11px] font-bold uppercase tracking-wider text-center text-slate-400 dark:text-slate-500 mb-3">
            Active Engineering Lifecycle Flow
          </p>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-center">
            <div className="p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-700/80 flex items-center justify-center gap-2 text-xs font-bold text-amber-600 dark:text-amber-400">
              <BookOpen className="w-4 h-4" />
              <span>1. Learning</span>
            </div>
            <div className="p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-700/80 flex items-center justify-center gap-2 text-xs font-bold text-blue-600 dark:text-blue-400">
              <Hammer className="w-4 h-4" />
              <span>2. Building</span>
            </div>
            <div className="p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-700/80 flex items-center justify-center gap-2 text-xs font-bold text-purple-600 dark:text-purple-400">
              <Rocket className="w-4 h-4" />
              <span>3. Deploying</span>
            </div>
            <div className="p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-700/80 flex items-center justify-center gap-2 text-xs font-bold text-emerald-600 dark:text-emerald-400">
              <RefreshCw className="w-4 h-4" />
              <span>4. Improving</span>
            </div>
          </div>
        </div>

        {/* Grid of Learning Topics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {PORTFOLIO_DATA.learningJourney.map((item) => {
            const stageInfo = getStageBadge(item.stage);
            return (
              <div
                key={item.id}
                className="p-6 rounded-3xl bg-slate-50/70 dark:bg-slate-800/40 border border-slate-200/80 dark:border-slate-800 shadow-2xs hover:shadow-lg transition-all duration-300 flex flex-col justify-between group"
              >
                <div className="space-y-4">
                  <div className="flex items-start justify-between gap-2">
                    <h3 className="text-base font-bold text-slate-900 dark:text-white tracking-tight group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
                      {item.title}
                    </h3>
                    <span
                      className={`text-[11px] font-bold px-2.5 py-0.5 rounded-full border shrink-0 inline-flex items-center gap-1.5 ${stageInfo.classes}`}
                    >
                      {stageInfo.icon}
                      <span>{item.stage}</span>
                    </span>
                  </div>

                  <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
                    {item.description}
                  </p>

                  <div className="p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200/60 dark:border-slate-700/60 space-y-1">
                    <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500">
                      Current Milestone
                    </p>
                    <p className="text-xs font-medium text-slate-800 dark:text-slate-200">
                      {item.currentFocus}
                    </p>
                  </div>
                </div>

                <div className="pt-4 mt-4 border-t border-slate-200/60 dark:border-slate-700/60 flex flex-wrap gap-1.5">
                  {item.topics.map((t, idx) => (
                    <span
                      key={idx}
                      className="px-2 py-0.5 rounded-md text-[11px] font-medium bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300"
                    >
                      {t}
                    </span>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default LearningJourneySection;
