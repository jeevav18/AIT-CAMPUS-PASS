import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Cloud, Layout, Server, Cpu, Database, Eye, Zap, GitBranch, Settings, Orbit, Activity } from "lucide-react";
import OrbitalSkills from "./OrbitalSkills";
import { playTick, playHover } from "@/lib/cyberAudio";

interface SkillItem {
  name: string;
  level: number;
}

interface SkillCategory {
  title: string;
  icon: React.ComponentType<{ className?: string }>;
  color: string;
  items: SkillItem[];
}

const Skills = () => {
  const [viewMode, setViewMode] = useState<"orbital" | "grid">("orbital");

  const skillGroups: SkillCategory[] = [
    {
      title: "Salesforce Development",
      icon: Cloud,
      color: "#00E5FF", // Electric Cyan
      items: [
        { name: "Apex Programming", level: 85 },
        { name: "Lightning Web Components (LWC)", level: 80 },
        { name: "Flow Builder / Automation", level: 90 },
        { name: "Apex Triggers / Validations", level: 85 },
        { name: "SOQL & SOSL Querying", level: 80 },
        { name: "REST API Integrations", level: 75 },
        { name: "Visualforce / Traditional CRM", level: 65 }
      ]
    },
    {
      title: "Frontend Development",
      icon: Layout,
      color: "#00FF66", // Neon Green
      items: [
        { name: "HTML5 Structure", level: 90 },
        { name: "CSS3 / Custom Styling", level: 85 },
        { name: "JavaScript ES6+", level: 80 },
        { name: "React.js Framework", level: 75 },
        { name: "TailwindCSS Design", level: 90 }
      ]
    },
    {
      title: "Backend Technologies",
      icon: Server,
      color: "#FFC107", // Amber
      items: [
        { name: "RESTful Web APIs", level: 80 },
        { name: "Node.js Environment", level: 70 },
        { name: "Express Server Architecture", level: 65 }
      ]
    },
    {
      title: "Development Tools",
      icon: Settings,
      color: "#FFFFFF", // White
      items: [
        { name: "Git Version Control", level: 85 },
        { name: "GitHub Platform Syncing", level: 90 },
        { name: "VS Code Editor Configs", level: 95 },
        { name: "Salesforce Dev Console", level: 85 }
      ]
    }
  ];

  return (
    <section id="skills" className="py-24 px-4 relative">
      <div className="container mx-auto max-w-6xl relative z-10 space-y-12">
        {/* Section Heading */}
        <motion.div
          initial={{ y: 30, opacity: 0 }}
          whileInView={{ y: 0, opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center"
        >
          <h2 className="text-3xl md:text-5xl font-bold font-oxanium text-white tracking-widest uppercase text-glow-green">
            [ SKILLS_MATRIX ]
          </h2>
          <div className="w-24 h-1 bg-[#00FF66] mx-auto mt-3 rounded-full shadow-[0_0_10px_#00FF66]" />
        </motion.div>

        {/* Premium Cyber View Toggles */}
        <div className="flex justify-center font-mono">
          <div className="flex border border-[#00FF66]/20 bg-[#050505]/85 p-1 rounded-xl shadow-[0_0_15px_rgba(0,255,102,0.02)]">
            <button
              onMouseEnter={playHover}
              onClick={() => {
                playTick();
                setViewMode("orbital");
              }}
              className={`px-4 py-2.5 rounded-lg text-xs font-bold tracking-wider uppercase transition-all duration-300 flex items-center space-x-2 cursor-pointer ${
                viewMode === "orbital"
                  ? "bg-[#00FF66]/15 text-[#00FF66] border border-[#00FF66]/30 shadow-[0_0_10px_rgba(0,255,102,0.1)]"
                  : "text-gray-500 hover:text-[#00FF66]/80"
              }`}
            >
              <Orbit className="w-4 h-4 animate-spin-slow" />
              <span>ORBITAL_ENGINE</span>
            </button>
            <button
              onMouseEnter={playHover}
              onClick={() => {
                playTick();
                setViewMode("grid");
              }}
              className={`px-4 py-2.5 rounded-lg text-xs font-bold tracking-wider uppercase transition-all duration-300 flex items-center space-x-2 cursor-pointer ${
                viewMode === "grid"
                  ? "bg-[#00E5FF]/15 text-[#00E5FF] border border-[#00E5FF]/30 shadow-[0_0_10px_rgba(0,229,255,0.1)]"
                  : "text-gray-500 hover:text-[#00E5FF]/80"
              }`}
            >
              <Activity className="w-4 h-4" />
              <span>DOCK_MATRIX</span>
            </button>
          </div>
        </div>

        {/* Display Wrapper */}
        <div className="relative min-h-[500px]">
          <AnimatePresence mode="wait">
            {viewMode === "orbital" ? (
              <motion.div
                key="orbital"
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.98 }}
                transition={{ duration: 0.4 }}
              >
                <OrbitalSkills />
              </motion.div>
            ) : (
              <motion.div
                key="grid"
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -15 }}
                transition={{ duration: 0.4 }}
                className="grid grid-cols-1 md:grid-cols-2 gap-8"
              >
                {skillGroups.map((group, groupIdx) => (
                  <div
                    key={groupIdx}
                    className="bg-[#080808]/90 border border-[#00FF66]/20 rounded-xl overflow-hidden p-6 hover:border-[#00FF66]/40 hover:shadow-[0_0_15px_rgba(0,255,102,0.05)] transition-all duration-300"
                  >
                    {/* Category Header */}
                    <div className="flex items-center space-x-3.5 mb-6 border-b border-[#00FF66]/10 pb-4">
                      <div
                        className="p-2.5 rounded-lg text-black font-bold"
                        style={{ backgroundColor: group.color }}
                      >
                        <group.icon className="w-5 h-5 text-black" />
                      </div>
                      <h3 className="text-lg font-oxanium font-bold text-white tracking-wider uppercase">
                        {group.title}
                      </h3>
                    </div>

                    {/* Skills Progress Lines */}
                    <div className="space-y-4">
                      {group.items.map((skill, skillIdx) => (
                        <div key={skillIdx} className="space-y-1.5 font-mono">
                          <div className="flex justify-between items-center text-xs">
                            <span className="text-gray-300 font-semibold">{`> ${skill.name}`}</span>
                            <span className="text-glow-green font-bold text-[#00FF66]">
                              {skill.level}%
                            </span>
                          </div>

                          {/* Custom Glowing Progress Bar */}
                          <div className="h-2 w-full bg-black/60 border border-[#00FF66]/10 rounded-full overflow-hidden">
                            <motion.div
                              initial={{ width: 0 }}
                              animate={{ width: `${skill.level}%` }}
                              transition={{ duration: 0.8, delay: skillIdx * 0.05 }}
                              className="h-full rounded-full"
                              style={{
                                background: `linear-gradient(to right, ${group.color}, #00FF66)`,
                                boxShadow: `0 0 8px ${group.color}`
                              }}
                            />
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </section>
  );
};

export default Skills;
