import React, { useState } from "react";
import { StudentProfile, PassRequest } from "@/types/campuspass";
import { 
  HeartHandshake, 
  MapPin, 
  Clock, 
  ShieldCheck, 
  Phone, 
  CheckCircle, 
  XCircle, 
  MessageCircle, 
  Bell, 
  Building, 
  AlertTriangle,
  History,
  Send,
  FileText
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { PaperPassSlipModal } from "./PaperPassSlipModal";
import { toast } from "sonner";

interface ParentPortalProps {
  student: StudentProfile;
  passes: PassRequest[];
  onRecordConsent: (passId: string, consent: "consented" | "rejected", notes: string, parentName: string) => void;
}

export const ParentPortal: React.FC<ParentPortalProps> = ({
  student,
  passes,
  onRecordConsent,
}) => {
  const [consentNotes, setConsentNotes] = useState("");
  const [selectedPassForAction, setSelectedPassForAction] = useState<PassRequest | null>(null);
  const [previewSlipPass, setPreviewSlipPass] = useState<PassRequest | null>(null);

  const studentPasses = passes.filter((p) => p.studentId === student.id);
  const pendingConsentPass = studentPasses.find(
    (p) => p.parentConsentStatus === "pending" || (p.passType === "home_pass" && p.parentConsentStatus !== "consented_portal" && p.parentConsentStatus !== "consented_sms" && p.parentConsentStatus !== "verified_by_call")
  );

  const activePass = studentPasses.find(
    (p) => p.status === "active_out" || p.status === "approved" || p.status === "overdue"
  );

  const handleConsentAction = (consent: "consented" | "rejected") => {
    if (!selectedPassForAction && !pendingConsentPass) return;
    const targetPass = selectedPassForAction || pendingConsentPass!;
    
    onRecordConsent(
      targetPass.id,
      consent,
      consentNotes || (consent === "consented" ? "Parent granted leave approval via Guardian Portal." : "Leave disapproved by parent."),
      student.guardian.name
    );

    setSelectedPassForAction(null);
    setConsentNotes("");
    toast.success(`Guardian response recorded: ${consent === "consented" ? "Consent Granted" : "Leave Refused"}`);
  };

  return (
    <div className="space-y-6">
      
      {/* Parent Welcome & Ward Status Banner */}
      <div className="bg-gradient-to-r from-teal-700 via-emerald-800 to-slate-900 rounded-2xl p-6 text-white shadow-lg relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="h-16 w-16 rounded-2xl bg-white/10 backdrop-blur border border-white/20 flex items-center justify-center text-white">
              <HeartHandshake className="h-8 w-8 text-teal-200" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-bold tracking-tight">
                  Welcome, {student.guardian.name}
                </h2>
                <Badge className="bg-teal-500/30 text-teal-100 border-white/20 text-xs">
                  {student.guardian.relation} of {student.name}
                </Badge>
              </div>
              <p className="text-xs text-teal-100/90 mt-0.5">
                Official Parent Portal for Hostel Outing, Leave Consent & Live Safety Tracking
              </p>
              
              <div className="flex flex-wrap items-center gap-3 mt-2 text-xs text-teal-100/80 font-mono">
                <span>Verified Mobile: {student.guardian.phone}</span>
                <span>•</span>
                <span className="flex items-center gap-1 text-emerald-300">
                  WhatsApp Notifications: Active ✓
                </span>
              </div>
            </div>
          </div>

          {/* Current Ward Location Pill */}
          <div className="bg-black/30 backdrop-blur rounded-xl p-3 border border-white/10 text-right">
            <span className="text-[10px] text-teal-200 uppercase tracking-wider block font-semibold">
              Ward Current Location
            </span>
            <div className="text-sm font-bold text-white flex items-center gap-1.5 justify-end mt-0.5">
              <div className={`h-2.5 w-2.5 rounded-full ${
                student.currentStatus === "IN_HOSTEL" ? "bg-emerald-400" :
                student.currentStatus === "ON_OUTING" ? "bg-amber-400" :
                student.currentStatus === "OVERDUE" ? "bg-red-400 animate-ping" : "bg-blue-400"
              }`} />
              <span>
                {student.currentStatus === "IN_HOSTEL" && `Inside Campus (Room ${student.roomNumber})`}
                {student.currentStatus === "ON_OUTING" && "On Authorized City Outing"}
                {student.currentStatus === "ON_HOME_PASS" && "On Authorized Home Leave"}
                {student.currentStatus === "OVERDUE" && "⚠️ Return Overdue (Warden Alerted)"}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Action Required: Pass Awaiting Parent Consent */}
      {pendingConsentPass && (
        <div className="bg-amber-50 rounded-2xl border-2 border-amber-300 p-6 shadow-md dark:bg-amber-950/20 dark:border-amber-700">
          <div className="flex items-start justify-between gap-4">
            <div className="flex items-start gap-3">
              <div className="p-2.5 rounded-xl bg-amber-500 text-white shrink-0 shadow">
                <AlertTriangle className="h-6 w-6" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="font-bold text-base text-amber-900 dark:text-amber-200">
                    Action Required: Student Leave Consent
                  </h3>
                  <Badge className="bg-amber-600 text-white text-[10px]">
                    Pass {pendingConsentPass.passNumber}
                  </Badge>
                </div>
                <p className="text-xs text-amber-800 mt-1 max-w-xl dark:text-amber-300/90">
                  Your ward <strong>{student.name}</strong> has applied for a{" "}
                  <strong>{pendingConsentPass.passType.replace("_", " ")}</strong>. The college requires your confirmation before final clearance is issued by the Chief Warden.
                </p>

                {/* Leave Details Box */}
                <div className="mt-3 grid grid-cols-1 sm:grid-cols-3 gap-2.5 bg-white p-3.5 rounded-xl border border-amber-200 text-xs dark:bg-slate-900 dark:border-amber-800">
                  <div>
                    <span className="text-slate-400 text-[10px] uppercase font-bold block">DESTINATION</span>
                    <p className="font-semibold text-slate-800 dark:text-slate-200">{pendingConsentPass.destination}</p>
                    <p className="text-slate-500 text-[11px]">{pendingConsentPass.reason}</p>
                  </div>
                  <div>
                    <span className="text-slate-400 text-[10px] uppercase font-bold block">DEPARTURE</span>
                    <p className="font-semibold text-slate-800 dark:text-slate-200">
                      {new Date(pendingConsentPass.departureDateTime).toLocaleDateString([], { month: "short", day: "numeric" })}{" "}
                      {new Date(pendingConsentPass.departureDateTime).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                    </p>
                  </div>
                  <div>
                    <span className="text-slate-400 text-[10px] uppercase font-bold block">EXPECTED RETURN</span>
                    <p className="font-semibold text-red-600 font-mono">
                      {new Date(pendingConsentPass.expectedReturnDateTime).toLocaleDateString([], { month: "short", day: "numeric" })}{" "}
                      {new Date(pendingConsentPass.expectedReturnDateTime).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                    </p>
                  </div>
                </div>

                {/* Consent Remarks & Buttons */}
                <div className="mt-4 flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
                  <input
                    type="text"
                    placeholder="Optional message to College Tutor (e.g. 'I approve my child attending the wedding')"
                    value={consentNotes}
                    onChange={(e) => setConsentNotes(e.target.value)}
                    className="flex-1 text-xs px-3 py-2 rounded-xl border border-amber-300 bg-white focus:outline-none focus:ring-2 focus:ring-teal-500 dark:bg-slate-900 dark:border-amber-700 dark:text-white"
                  />
                  <div className="flex items-center gap-2">
                    <Button
                      onClick={() => handleConsentAction("consented")}
                      className="bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold gap-1.5 shadow"
                    >
                      <CheckCircle className="h-4 w-4" />
                      Grant Leave Consent
                    </Button>
                    <Button
                      variant="outline"
                      onClick={() => handleConsentAction("rejected")}
                      className="border-red-300 text-red-700 hover:bg-red-50 text-xs font-semibold gap-1.5"
                    >
                      <XCircle className="h-4 w-4" />
                      Decline
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Main Grid: Active Pass Details + Contact Directory */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left 2 Cols: Live Movement & Active Pass Safety Details */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* Active Pass Card */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm dark:bg-slate-900 dark:border-slate-800">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <ShieldCheck className="h-5 w-5 text-blue-600" />
                <h3 className="font-bold text-sm text-slate-900 dark:text-white">
                  Active Pass Verification & Safety Details
                </h3>
              </div>
              {activePass && (
                <div className="flex items-center gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => setPreviewSlipPass(activePass)}
                    className="border-orange-300 text-orange-700 bg-orange-50 hover:bg-orange-100 text-xs font-semibold gap-1.5 h-8 dark:bg-orange-950/30 dark:border-orange-800 dark:text-orange-300"
                  >
                    <FileText className="h-3.5 w-3.5 text-orange-600" />
                    <span>Paper Slip</span>
                  </Button>
                  <Badge className="font-mono text-xs">
                    {activePass.passNumber}
                  </Badge>
                </div>
              )}
            </div>

            {activePass ? (
              <div className="mt-4 space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between p-3.5 bg-slate-50 rounded-xl border border-slate-200 gap-3 dark:bg-slate-800/50 dark:border-slate-700">
                  <div>
                    <span className="text-[10px] text-slate-400 font-bold uppercase block">
                      OUTING STATUS
                    </span>
                    <span className="text-sm font-bold text-slate-900 dark:text-white capitalize">
                      {activePass.status.replace("_", " ")}
                    </span>
                    <p className="text-xs text-slate-500 mt-0.5">
                      Destination: {activePass.destination}
                    </p>
                  </div>
                  <div className="text-left sm:text-right">
                    <span className="text-[10px] text-slate-400 font-bold uppercase block">
                      RETURN DEADLINE
                    </span>
                    <span className="text-sm font-bold font-mono text-red-600">
                      {new Date(activePass.expectedReturnDateTime).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                    </span>
                    <p className="text-[11px] text-slate-500">
                      {new Date(activePass.expectedReturnDateTime).toLocaleDateString([], { month: "short", day: "numeric" })}
                    </p>
                  </div>
                </div>

                {/* Gate Movements */}
                <div>
                  <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">
                    Verified Gate Movements Log
                  </h4>
                  {activePass.movements && activePass.movements.length > 0 ? (
                    <div className="space-y-2">
                      {activePass.movements.map((mov) => (
                        <div
                          key={mov.id}
                          className="p-3 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between text-xs dark:bg-slate-800/40 dark:border-slate-800"
                        >
                          <div className="flex items-center gap-2.5">
                            <div className={`h-8 w-8 rounded-lg flex items-center justify-center font-bold text-white text-xs ${
                              mov.movementType === "EXIT" ? "bg-amber-600" : "bg-emerald-600"
                            }`}>
                              {mov.movementType}
                            </div>
                            <div>
                              <div className="font-semibold text-slate-800 dark:text-slate-200">
                                {mov.gateName}
                              </div>
                              <div className="text-[11px] text-slate-500">
                                Verified by {mov.securityOfficerName}
                              </div>
                            </div>
                          </div>
                          <div className="text-right font-mono font-semibold text-slate-700 dark:text-slate-300">
                            {new Date(mov.timestamp).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-xs text-slate-500 italic py-2">
                      No gate movement recorded yet. Ward has not departed through security gate.
                    </p>
                  )}
                </div>
              </div>
            ) : (
              <p className="text-xs text-slate-500 py-6 text-center">
                Ward has no active passes outside campus right now. All movements are normal.
              </p>
            )}
          </div>

          {/* Past Passes History */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm dark:bg-slate-900 dark:border-slate-800">
            <div className="flex items-center gap-2 mb-4">
              <History className="h-4 w-4 text-slate-500" />
              <h3 className="font-bold text-sm text-slate-900 dark:text-white">
                Historical Outing & Leave Records
              </h3>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-100 text-slate-400 uppercase text-[10px] tracking-wider dark:border-slate-800">
                    <th className="pb-2.5">Pass ID</th>
                    <th className="pb-2.5">Type</th>
                    <th className="pb-2.5">Destination</th>
                    <th className="pb-2.5">Return Date</th>
                    <th className="pb-2.5">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {studentPasses.map((p) => (
                    <tr key={p.id}>
                      <td className="py-2.5 font-mono font-bold text-blue-600">
                        <button
                          onClick={() => setPreviewSlipPass(p)}
                          className="hover:underline flex items-center gap-1 text-left"
                          title="View Official Paper Slip"
                        >
                          <FileText className="h-3 w-3 text-orange-600 inline" />
                          <span>{p.passNumber}</span>
                        </button>
                      </td>
                      <td className="py-2.5 capitalize">{p.passType.replace("_", " ")}</td>
                      <td className="py-2.5 text-slate-600 max-w-[150px] truncate">{p.destination}</td>
                      <td className="py-2.5 font-mono text-slate-500">
                        {new Date(p.expectedReturnDateTime).toLocaleDateString([], { month: "short", day: "numeric" })}
                      </td>
                      <td className="py-2.5">
                        <Badge variant="outline" className="text-[10px] capitalize">
                          {p.status}
                        </Badge>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

        </div>

        {/* Right Col: College Officials Direct Contacts */}
        <div className="space-y-6">
          
          {/* Official Staff Directory Card */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm dark:bg-slate-900 dark:border-slate-800">
            <h3 className="font-bold text-sm text-slate-900 mb-1 dark:text-white">
              Institutional Contact Directory
            </h3>
            <p className="text-xs text-slate-500 mb-4 dark:text-slate-400">
              Direct line to your ward's assigned college mentors and hostel authorities:
            </p>

            <div className="space-y-3 text-xs">
              
              {/* Class Tutor */}
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 space-y-1.5 dark:bg-slate-800/60 dark:border-slate-700">
                <span className="text-[10px] text-indigo-600 font-bold uppercase tracking-wider block">
                  CLASS TUTOR (ACADEMIC MENTOR)
                </span>
                <p className="font-bold text-slate-800 dark:text-slate-200">{student.tutorName}</p>
                <div className="flex items-center justify-between text-slate-500 pt-1">
                  <span className="font-mono text-[11px]">+91 94441 22334</span>
                  <a
                    href="tel:+919444122334"
                    className="inline-flex items-center gap-1 text-[11px] font-semibold text-blue-600 hover:underline"
                  >
                    <Phone className="h-3 w-3" /> Call
                  </a>
                </div>
              </div>

              {/* Hostel Warden */}
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 space-y-1.5 dark:bg-slate-800/60 dark:border-slate-700">
                <span className="text-[10px] text-amber-600 font-bold uppercase tracking-wider block">
                  HOSTEL CHIEF WARDEN
                </span>
                <p className="font-bold text-slate-800 dark:text-slate-200">{student.wardenName}</p>
                <p className="text-[11px] text-slate-500">{student.hostelBlock}</p>
                <div className="flex items-center justify-between text-slate-500 pt-1">
                  <span className="font-mono text-[11px]">+91 94441 55667</span>
                  <a
                    href="tel:+919444155667"
                    className="inline-flex items-center gap-1 text-[11px] font-semibold text-blue-600 hover:underline"
                  >
                    <Phone className="h-3 w-3" /> Call
                  </a>
                </div>
              </div>

              {/* Gate Security 24/7 Helpline */}
              <div className="p-3 rounded-xl bg-red-50 border border-red-200 space-y-1.5 dark:bg-red-950/20 dark:border-red-800">
                <span className="text-[10px] text-red-600 font-bold uppercase tracking-wider block">
                  24/7 AIT CAMPUS SECURITY & ADMISSION HELPLINE
                </span>
                <p className="font-bold text-slate-800 dark:text-slate-200">Kurumbapalayam Main Gate Desk</p>
                <div className="flex items-center justify-between text-slate-500 pt-1">
                  <span className="font-mono text-[11px] text-red-700 font-bold dark:text-red-400">
                    +91 73737 00933 / 0422-2654504
                  </span>
                  <a
                    href="tel:+917373700933"
                    className="inline-flex items-center gap-1 text-[11px] font-semibold text-red-600 hover:underline"
                  >
                    <Phone className="h-3 w-3" /> Dial
                  </a>
                </div>
              </div>

            </div>
          </div>

          {/* SMS & WhatsApp Notification Settings */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm text-xs space-y-3 dark:bg-slate-900 dark:border-slate-800">
            <h4 className="font-bold text-sm text-slate-900 dark:text-white">
              Notification Preferences
            </h4>
            <div className="space-y-2 text-slate-600 dark:text-slate-400">
              <label className="flex items-center gap-2">
                <input type="checkbox" defaultChecked disabled className="rounded text-teal-600" />
                <span>Instant WhatsApp alert on gate departure</span>
              </label>
              <label className="flex items-center gap-2">
                <input type="checkbox" defaultChecked disabled className="rounded text-teal-600" />
                <span>Instant WhatsApp alert on gate arrival</span>
              </label>
              <label className="flex items-center gap-2">
                <input type="checkbox" defaultChecked disabled className="rounded text-teal-600" />
                <span>Curfew deadline reminder (-30 mins)</span>
              </label>
              <label className="flex items-center gap-2">
                <input type="checkbox" defaultChecked disabled className="rounded text-teal-600" />
                <span>Emergency overdue escalation alerts</span>
              </label>
            </div>
            <p className="text-[11px] text-slate-400 pt-2 border-t border-slate-100 dark:border-slate-800">
              Powered by College Official Twilio SMS & Meta WhatsApp Business Cloud API.
            </p>
          </div>

        </div>

      </div>

      {/* Official Paper Pass Slip Modal */}
      <PaperPassSlipModal
        pass={previewSlipPass}
        isOpen={!!previewSlipPass}
        onClose={() => setPreviewSlipPass(null)}
      />

    </div>
  );
};
