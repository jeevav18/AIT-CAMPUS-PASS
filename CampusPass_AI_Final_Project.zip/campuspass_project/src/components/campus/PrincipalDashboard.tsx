import React, { useState } from "react";
import { PassRequest, HostelSummary, LateReturnIncident } from "@/types/campuspass";
import { 
  Crown, 
  Sparkles, 
  TrendingUp, 
  AlertTriangle, 
  ShieldAlert, 
  Building, 
  Users, 
  Sliders, 
  FileText, 
  CheckCircle2,
  Clock,
  Printer
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  ResponsiveContainer, 
  PieChart, 
  Pie, 
  Cell 
} from "recharts";
import { generateDailyOperationsSummaryAI } from "@/services/geminiService";
import { toast } from "sonner";

interface PrincipalDashboardProps {
  principalName: string;
  passes: PassRequest[];
  hostels: HostelSummary[];
  incidents: LateReturnIncident[];
  onBypassApprove: (passId: string, remarks: string) => void;
}

export const PrincipalDashboard: React.FC<PrincipalDashboardProps> = ({
  principalName,
  passes,
  hostels,
  incidents,
  onBypassApprove,
}) => {
  const [aiBrief, setAiBrief] = useState<string>("");
  const [isGeneratingAi, setIsGeneratingAi] = useState<boolean>(false);

  // Policy settings state
  const [weekdayCurfew, setWeekdayCurfew] = useState("19:30");
  const [weekendCurfew, setWeekendCurfew] = useState("20:30");
  const [mandateParentCall, setMandateParentCall] = useState(true);

  // Metric computations
  const totalResidents = hostels.reduce((acc, h) => acc + h.currentResidents, 0);
  const currentlyOut = passes.filter((p) => p.status === "active_out").length;
  const overdueCount = passes.filter((p) => p.status === "overdue").length;
  const approvedToday = passes.filter((p) => p.status === "approved" || p.status === "active_out" || p.status === "completed").length;

  // Chart data: Passes by Department
  const deptMap: Record<string, number> = {};
  passes.forEach((p) => {
    const dept = p.department.split(" ")[0];
    deptMap[dept] = (deptMap[dept] || 0) + 1;
  });
  const deptChartData = Object.keys(deptMap).map((k) => ({
    name: k,
    passes: deptMap[k],
  }));

  // Chart data: Passes by Category
  const typeMap: Record<string, number> = {};
  passes.forEach((p) => {
    const t = p.passType === "outing" ? "Outing" : p.passType === "home_pass" ? "Home Pass" : "Medical";
    typeMap[t] = (typeMap[t] || 0) + 1;
  });
  const typeChartData = [
    { name: "Day Outing", value: typeMap["Outing"] || 3, color: "#2563eb" },
    { name: "Home Pass", value: typeMap["Home Pass"] || 2, color: "#7c3aed" },
    { name: "Medical / Emer.", value: typeMap["Medical"] || 1, color: "#e11d48" },
  ];

  const handleGenerateAiBrief = async () => {
    setIsGeneratingAi(true);
    try {
      const brief = await generateDailyOperationsSummaryAI({
        totalResidents,
        currentlyOut,
        expectedReturnsTonight: currentlyOut + 2,
        overdueCount,
        approvedToday,
        parentCallsMade: passes.filter((p) => p.approvalWorkflow.tutor.parentContacted).length,
      });
      setAiBrief(brief);
      toast.success("AI Executive Operations Brief generated.");
    } catch (err) {
      toast.error("Failed to generate AI brief.");
    } finally {
      setIsGeneratingAi(false);
    }
  };

  const handleSavePolicy = () => {
    toast.success("Institutional Curfew & Safety Policy updated successfully.");
  };

  return (
    <div className="space-y-6">
      
      {/* Banner */}
      <div className="bg-gradient-to-r from-rose-800 via-purple-900 to-slate-900 rounded-2xl p-6 text-white shadow-lg flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="h-14 w-14 rounded-2xl bg-white/10 backdrop-blur flex items-center justify-center text-white border border-white/20">
            <Crown className="h-7 w-7 text-rose-300" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-bold tracking-tight">
                Principal Executive Command Center
              </h2>
              <Badge className="bg-rose-500/30 text-rose-100 border-white/20 text-xs">
                College-Wide Oversight
              </Badge>
            </div>
            <p className="text-xs text-rose-100/90 mt-0.5">
              Officer: {principalName} • Adithya Institute of Technology Institutional Administration (TNEA 2744)
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <Button
            onClick={handleGenerateAiBrief}
            disabled={isGeneratingAi}
            className="bg-white text-rose-900 hover:bg-rose-50 text-xs font-semibold gap-1.5 shadow"
          >
            <Sparkles className="h-4 w-4 text-rose-600 animate-pulse" />
            {isGeneratingAi ? "Generating AI Brief..." : "AI Operations Brief"}
          </Button>
        </div>
      </div>

      {/* AI Daily Operations Brief Banner */}
      {aiBrief && (
        <div className="bg-gradient-to-r from-indigo-50 to-rose-50 border-2 border-indigo-200 rounded-2xl p-5 shadow-sm text-xs dark:from-indigo-950/30 dark:to-rose-950/30 dark:border-indigo-800">
          <div className="flex items-center justify-between mb-2">
            <span className="font-bold text-sm text-indigo-950 flex items-center gap-2 dark:text-indigo-200">
              <Sparkles className="h-4 w-4 text-indigo-600" />
              AI Daily Executive Operations Brief
            </span>
            <Badge className="bg-indigo-600 text-white text-[10px]">
              Gemini 3.8 Flash Verified
            </Badge>
          </div>
          <p className="text-slate-700 leading-relaxed dark:text-slate-300 whitespace-pre-line font-medium">
            {aiBrief}
          </p>
        </div>
      )}

      {/* Campus KPI Metrics Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-1 dark:bg-slate-900 dark:border-slate-800">
          <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">
            TOTAL HOSTEL RESIDENTS
          </span>
          <div className="text-2xl font-extrabold text-slate-900 dark:text-white">
            {totalResidents}
          </div>
          <span className="text-xs text-slate-500">Across 4 campus blocks</span>
        </div>

        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-1 dark:bg-slate-900 dark:border-slate-800">
          <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">
            CURRENTLY OUT ON PASS
          </span>
          <div className="text-2xl font-extrabold text-blue-600 dark:text-blue-400">
            {currentlyOut}
          </div>
          <span className="text-xs text-slate-500">Scheduled for tonight return</span>
        </div>

        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-1 dark:bg-slate-900 dark:border-slate-800">
          <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">
            PASSES CLEARED TODAY
          </span>
          <div className="text-2xl font-extrabold text-emerald-600 dark:text-emerald-400">
            {approvedToday}
          </div>
          <span className="text-xs text-slate-500">100% Parent alert coverage</span>
        </div>

        <div className="p-5 rounded-2xl bg-white border border-slate-200 shadow-sm space-y-1 dark:bg-slate-900 dark:border-slate-800">
          <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">
            CURFEW VIOLATIONS
          </span>
          <div className="text-2xl font-extrabold text-red-600 dark:text-red-400">
            {overdueCount}
          </div>
          <span className="text-xs text-slate-500">Under security escalation</span>
        </div>
      </div>

      {/* Analytics Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Pass Requests by Department */}
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm dark:bg-slate-900 dark:border-slate-800">
          <h3 className="font-bold text-sm text-slate-900 mb-4 dark:text-white">
            Pass Requests by Academic Department
          </h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={deptChartData.length > 0 ? deptChartData : [{ name: "CSE", passes: 4 }, { name: "ECE", passes: 3 }, { name: "Mech", passes: 2 }]}>
                <XAxis dataKey="name" stroke="#94a3b8" fontSize={12} />
                <YAxis stroke="#94a3b8" fontSize={12} />
                <Tooltip />
                <Bar dataKey="passes" fill="#6366f1" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Pass Breakdown by Category */}
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm dark:bg-slate-900 dark:border-slate-800">
          <h3 className="font-bold text-sm text-slate-900 mb-4 dark:text-white">
            Movement Distribution by Pass Category
          </h3>
          <div className="h-64 flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={typeChartData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={85}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {typeChartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="flex justify-center gap-4 text-xs mt-2">
            {typeChartData.map((d) => (
              <div key={d.name} className="flex items-center gap-1.5">
                <div className="h-3 w-3 rounded-full" style={{ backgroundColor: d.color }} />
                <span className="text-slate-600 dark:text-slate-400">{d.name}</span>
              </div>
            ))}
          </div>
        </div>

      </div>

      {/* Exceptional Case Approvals & Policy Config */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Exceptional Emergency Bypass */}
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm dark:bg-slate-900 dark:border-slate-800">
          <h3 className="font-bold text-sm text-slate-900 mb-1 flex items-center gap-2 dark:text-white">
            <ShieldAlert className="h-4 w-4 text-rose-600" />
            Exceptional Case Review & Executive Bypass
          </h3>
          <p className="text-xs text-slate-500 mb-4">
            Principal discretionary clearance for urgent medical, academic conference, or emergency leaves bypassing multi-stage delays:
          </p>

          <div className="space-y-3">
            {passes.filter((p) => p.status.startsWith("pending") || p.passType === "emergency_medical").map((p) => (
              <div key={p.id} className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between text-xs dark:bg-slate-800/50 dark:border-slate-700">
                <div>
                  <span className="font-bold text-slate-900 dark:text-white">
                    {p.studentName} ({p.rollNumber})
                  </span>
                  <p className="text-slate-500 mt-0.5">
                    {p.passType.replace("_", " ")}: {p.destination} ({p.reason})
                  </p>
                </div>
                <Button
                  size="sm"
                  onClick={() => {
                    onBypassApprove(p.id, "Executive Discretionary Bypass granted by Principal.");
                    toast.success(`Executive bypass issued for ${p.studentName}! Digital QR pass generated.`);
                  }}
                  className="text-xs bg-rose-600 hover:bg-rose-700 text-white font-semibold"
                >
                  Direct Bypass Approve
                </Button>
              </div>
            ))}
          </div>
        </div>

        {/* Institutional System Policy Configuration */}
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-sm dark:bg-slate-900 dark:border-slate-800 space-y-4">
          <h3 className="font-bold text-sm text-slate-900 flex items-center gap-2 dark:text-white">
            <Sliders className="h-4 w-4 text-slate-600" />
            Institutional Curfew & Safety Configuration
          </h3>

          <div className="space-y-3 text-xs">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="font-semibold text-slate-700 block mb-1 dark:text-slate-300">
                  Weekday Return Curfew
                </label>
                <input
                  type="time"
                  value={weekdayCurfew}
                  onChange={(e) => setWeekdayCurfew(e.target.value)}
                  className="w-full px-3 py-1.5 rounded-lg border border-slate-200 bg-slate-50 dark:bg-slate-800 dark:border-slate-700 dark:text-white"
                />
              </div>
              <div>
                <label className="font-semibold text-slate-700 block mb-1 dark:text-slate-300">
                  Weekend Return Curfew
                </label>
                <input
                  type="time"
                  value={weekendCurfew}
                  onChange={(e) => setWeekendCurfew(e.target.value)}
                  className="w-full px-3 py-1.5 rounded-lg border border-slate-200 bg-slate-50 dark:bg-slate-800 dark:border-slate-700 dark:text-white"
                />
              </div>
            </div>

            <div className="space-y-2 pt-2 border-t border-slate-100 dark:border-slate-800">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={mandateParentCall}
                  onChange={(e) => setMandateParentCall(e.target.checked)}
                  className="rounded text-rose-600"
                />
                <span className="font-semibold text-slate-800 dark:text-slate-200">
                  Mandate verbal parent call verification for overnight Home Passes
                </span>
              </label>
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  defaultChecked
                  disabled
                  className="rounded text-rose-600"
                />
                <span className="text-slate-600 dark:text-slate-400">
                  Automated SMS & WhatsApp dispatch on gate entry and exit scans
                </span>
              </label>
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  defaultChecked
                  disabled
                  className="rounded text-rose-600"
                />
                <span className="text-slate-600 dark:text-slate-400">
                  Auto-escalate late returns past +30 mins to Chief Warden and Parents
                </span>
              </label>
            </div>

            <div className="pt-2 text-right">
              <Button
                onClick={handleSavePolicy}
                className="text-xs bg-slate-900 hover:bg-slate-800 text-white dark:bg-slate-700"
              >
                Save Policy Parameters
              </Button>
            </div>
          </div>
        </div>

      </div>

    </div>
  );
};
