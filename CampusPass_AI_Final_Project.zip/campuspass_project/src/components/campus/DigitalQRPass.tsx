import React, { useState, useEffect } from "react";
import { QRCodeSVG } from "qrcode.react";
import { PassRequest } from "@/types/campuspass";
import { 
  ShieldCheck, 
  Clock, 
  MapPin, 
  User, 
  Phone, 
  Calendar, 
  CheckCircle2, 
  AlertTriangle, 
  Printer, 
  Copy, 
  ExternalLink,
  Building,
  HeartHandshake,
  FileText
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { AdithyaLogo } from "./AdithyaLogo";
import { PaperPassSlipModal } from "./PaperPassSlipModal";
import { toast } from "sonner";

interface DigitalQRPassProps {
  pass: PassRequest;
  onNavigateToScanner?: (token: string) => void;
}

export const DigitalQRPass: React.FC<DigitalQRPassProps> = ({
  pass,
  onNavigateToScanner,
}) => {
  const [currentTimestamp, setCurrentTimestamp] = useState<string>(new Date().toLocaleTimeString());
  const [isPaperSlipOpen, setIsPaperSlipOpen] = useState(false);

  // Live anti-screenshot clock update every second
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTimestamp(new Date().toLocaleTimeString());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const qrPayload = JSON.stringify({
    passNumber: pass.passNumber,
    token: pass.qrToken || `CP-${pass.passNumber}`,
    studentId: pass.studentId,
    rollNumber: pass.rollNumber,
    validUntil: pass.expectedReturnDateTime,
    signature: "AIT-COIMBATORE-AUTH-DIGITAL-SIGN-2026-V3",
  });

  const isApproved = pass.status === "approved" || pass.status === "active_out";
  const isOut = pass.status === "active_out";
  const isOverdue = pass.status === "overdue";
  const isCompleted = pass.status === "completed";

  const copyToken = () => {
    if (pass.qrToken) {
      navigator.clipboard.writeText(pass.qrToken);
      toast.success("Security token copied to clipboard");
    }
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200 shadow-xl overflow-hidden max-w-md mx-auto transition-all dark:bg-slate-900 dark:border-slate-800">
      
      {/* Institutional Header with Security Hologram look */}
      <div className="bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 text-white p-5 relative overflow-hidden">
        {/* Animated Security Watermark Background */}
        <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#fff_1px,transparent_1px)] [background-size:12px_12px]" />
        
        <div className="relative z-10 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <AdithyaLogo size="sm" showText={false} />
            <div>
              <h3 className="font-bold text-sm tracking-tight leading-tight">
                ADITHYA INSTITUTE OF TECHNOLOGY
              </h3>
              <p className="text-[10px] text-orange-300 uppercase tracking-widest font-mono">
                COIMBATORE • TNEA CODE: 2744
              </p>
            </div>
          </div>
          <Badge className="bg-orange-500/20 text-orange-200 border-orange-400/30 text-[10px] font-mono">
            {pass.passNumber}
          </Badge>
        </div>

        {/* Live Anti-Screenshot Dynamic Security Ribbon */}
        <div className="mt-3 py-1 px-2.5 bg-black/40 rounded-lg flex items-center justify-between text-[11px] font-mono text-emerald-300 border border-emerald-500/30">
          <div className="flex items-center gap-1.5">
            <div className="h-2 w-2 rounded-full bg-emerald-400 animate-ping" />
            <span>LIVE VERIFIED</span>
          </div>
          <div className="font-bold tracking-wider">{currentTimestamp}</div>
        </div>
      </div>

      <div className="p-5 space-y-4">
        
        {/* Student Identification Profile Card */}
        <div className="flex items-center gap-3.5 pb-3 border-b border-slate-100 dark:border-slate-800">
          <img
            src={pass.avatarUrl}
            alt={pass.studentName}
            className="h-16 w-16 rounded-xl object-cover border-2 border-blue-500 shadow-sm"
          />
          <div className="flex-1 min-w-0">
            <h4 className="font-bold text-slate-900 text-base leading-tight truncate dark:text-white">
              {pass.studentName}
            </h4>
            <div className="flex items-center gap-2 text-xs text-slate-600 mt-0.5 dark:text-slate-400">
              <span className="font-mono font-semibold text-blue-600 dark:text-blue-400">{pass.rollNumber}</span>
              <span>•</span>
              <span className="truncate">{pass.department.split(" ")[0]} Year {pass.year}</span>
            </div>
            <div className="text-[11px] text-slate-500 flex items-center gap-1 mt-0.5 dark:text-slate-400">
              <Building className="h-3 w-3 text-slate-400" />
              <span>{pass.hostelBlock.split("(")[0]} (Room {pass.roomNumber})</span>
            </div>
          </div>
        </div>

        {/* QR Code Security Scanner Card */}
        <div className="text-center py-2 px-3 bg-slate-50 rounded-xl border border-dashed border-slate-200 relative dark:bg-slate-800/50 dark:border-slate-700">
          {isApproved ? (
            <div className="flex flex-col items-center">
              <div className="p-3 bg-white rounded-xl shadow-sm border border-slate-200 inline-block relative dark:bg-white">
                <QRCodeSVG
                  value={pass.qrToken || qrPayload}
                  size={168}
                  level="H"
                  includeMargin={true}
                />
              </div>

              {/* Status Ribbon below QR */}
              <div className="mt-2.5 flex items-center justify-center gap-2">
                {isOut ? (
                  <Badge className="bg-amber-600 text-white text-xs px-2.5 py-0.5">
                    ● CURRENTLY OUT (CAMPUS EXIT RECORDED)
                  </Badge>
                ) : isOverdue ? (
                  <Badge className="bg-red-600 text-white text-xs px-2.5 py-0.5 animate-pulse">
                    ⚠️ RETURN OVERDUE (ESCALATED)
                  </Badge>
                ) : (
                  <Badge className="bg-emerald-600 text-white text-xs px-2.5 py-0.5">
                    ✓ AUTHORIZED FOR GATE SCAN
                  </Badge>
                )}
              </div>

              <p className="text-[10px] text-slate-400 font-mono mt-1">
                Token: {(pass.qrToken || '').slice(0, 24)}...
              </p>
            </div>
          ) : isCompleted ? (
            <div className="py-8 space-y-2">
              <CheckCircle2 className="h-12 w-12 text-emerald-500 mx-auto" />
              <h5 className="font-bold text-slate-800 text-sm dark:text-slate-200">
                Pass Successfully Completed
              </h5>
              <p className="text-xs text-slate-500">
                Returned safely via Gate at {pass.actualEntryDateTime ? new Date(pass.actualEntryDateTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : 'Verified'}.
              </p>
            </div>
          ) : (
            <div className="py-8 space-y-2">
              <AlertTriangle className="h-12 w-12 text-amber-500 mx-auto" />
              <h5 className="font-bold text-slate-800 text-sm dark:text-slate-200">
                Approval Pending ({pass.currentStage.toUpperCase()})
              </h5>
              <p className="text-xs text-slate-500 max-w-xs mx-auto">
                Dynamic QR token will be generated once Chief Warden grants final clearance.
              </p>
            </div>
          )}
        </div>

        {/* Schedule & Destination Details */}
        <div className="grid grid-cols-2 gap-2.5 text-xs">
          <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-100 dark:bg-slate-800/60 dark:border-slate-800">
            <span className="text-[10px] text-slate-400 font-medium block">DEPARTURE</span>
            <div className="font-semibold text-slate-800 mt-0.5 dark:text-slate-200">
              {new Date(pass.departureDateTime).toLocaleDateString([], { month: 'short', day: 'numeric' })}
            </div>
            <div className="text-blue-600 font-mono font-bold dark:text-blue-400">
              {new Date(pass.departureDateTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
            </div>
          </div>

          <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-100 dark:bg-slate-800/60 dark:border-slate-800">
            <span className="text-[10px] text-slate-400 font-medium block">CURFEW RETURN</span>
            <div className="font-semibold text-slate-800 mt-0.5 dark:text-slate-200">
              {new Date(pass.expectedReturnDateTime).toLocaleDateString([], { month: 'short', day: 'numeric' })}
            </div>
            <div className="text-red-600 font-mono font-bold dark:text-red-400">
              {new Date(pass.expectedReturnDateTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
            </div>
          </div>
        </div>

        {/* Destination & Reason */}
        <div className="text-xs space-y-1.5 p-3 rounded-lg bg-blue-50/50 border border-blue-100 dark:bg-blue-950/20 dark:border-blue-900/40">
          <div className="flex items-start gap-1.5">
            <MapPin className="h-3.5 w-3.5 text-blue-600 shrink-0 mt-0.5 dark:text-blue-400" />
            <div>
              <span className="font-semibold text-slate-800 dark:text-slate-200">Destination: </span>
              <span className="text-slate-600 dark:text-slate-400">{pass.destination}</span>
            </div>
          </div>
          <div className="text-slate-600 text-[11px] pl-5 dark:text-slate-400">
            <span className="font-medium text-slate-700 dark:text-slate-300">Purpose: </span>
            {pass.reason}
          </div>
        </div>

        {/* Parent Verification Section */}
        <div className="p-2.5 rounded-lg bg-emerald-50/70 border border-emerald-200 text-xs text-emerald-900 dark:bg-emerald-950/30 dark:border-emerald-800 dark:text-emerald-300">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5 font-bold">
              <HeartHandshake className="h-3.5 w-3.5 text-emerald-700 dark:text-emerald-400" />
              <span>Parent Consent Verified</span>
            </div>
            <Badge variant="outline" className="text-[10px] border-emerald-400 text-emerald-700 dark:text-emerald-300">
              {pass.guardian.relation}: {pass.guardian.name.split(" ")[0]}
            </Badge>
          </div>
          <div className="text-[11px] text-emerald-800 mt-1 flex items-center justify-between dark:text-emerald-300/80">
            <span>Primary Phone: <span className="font-mono">{pass.guardian.phone}</span></span>
            <span className="font-medium text-[10px]">WhatsApp Live ✓</span>
          </div>
        </div>

        {/* Official Institutional Verification Seals */}
        <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[10px] text-slate-400 dark:border-slate-800">
          <div className="text-center">
            <div className={`font-bold ${pass.approvalWorkflow.tutor.status === 'approved' ? 'text-emerald-600' : 'text-slate-400'}`}>
              {pass.approvalWorkflow.tutor.status === 'approved' ? '✓ TUTOR' : '○ TUTOR'}
            </div>
            <div className="truncate max-w-[80px]">{pass.approvalWorkflow.tutor.officerName?.split(" ")[1] || 'Pending'}</div>
          </div>
          <div className="text-center">
            <div className={`font-bold ${pass.approvalWorkflow.hod.status === 'approved' ? 'text-emerald-600' : 'text-slate-400'}`}>
              {pass.approvalWorkflow.hod.status === 'approved' ? '✓ HOD' : '○ HOD'}
            </div>
            <div className="truncate max-w-[80px]">{pass.approvalWorkflow.hod.officerName?.split(" ")[1] || 'Pending'}</div>
          </div>
          <div className="text-center">
            <div className={`font-bold ${pass.approvalWorkflow.warden.status === 'approved' ? 'text-emerald-600' : 'text-slate-400'}`}>
              {pass.approvalWorkflow.warden.status === 'approved' ? '✓ WARDEN' : '○ WARDEN'}
            </div>
            <div className="truncate max-w-[80px]">{pass.approvalWorkflow.warden.officerName?.split(" ")[1] || 'Pending'}</div>
          </div>
        </div>

        {/* Quick Testing Actions */}
        <div className="pt-2 flex flex-wrap items-center gap-2">
          {pass.qrToken && onNavigateToScanner && (
            <Button
              size="sm"
              className="flex-1 text-xs bg-orange-600 hover:bg-orange-700 text-white font-semibold"
              onClick={() => onNavigateToScanner(pass.qrToken!)}
            >
              Test Scan at Security Gate
            </Button>
          )}
          <Button
            size="sm"
            variant="outline"
            className="text-xs border-orange-300 text-orange-700 bg-orange-50 hover:bg-orange-100 gap-1 font-semibold dark:bg-orange-950/30 dark:border-orange-800 dark:text-orange-300"
            onClick={() => setIsPaperSlipOpen(true)}
            title="View Official Institutional Paper Pass Slip"
          >
            <FileText className="h-3.5 w-3.5 text-orange-600" />
            <span>Paper Slip Preview</span>
          </Button>
          {pass.qrToken && (
            <Button
              size="sm"
              variant="outline"
              className="text-xs"
              onClick={copyToken}
              title="Copy Security Token"
            >
              <Copy className="h-3.5 w-3.5" />
            </Button>
          )}
          <Button
            size="sm"
            variant="outline"
            className="text-xs"
            onClick={() => setIsPaperSlipOpen(true)}
            title="Print Official Slip"
          >
            <Printer className="h-3.5 w-3.5" />
          </Button>
        </div>

      </div>

      {/* Official Paper Pass Slip Modal */}
      <PaperPassSlipModal
        pass={pass}
        isOpen={isPaperSlipOpen}
        onClose={() => setIsPaperSlipOpen(false)}
      />

    </div>
  );
};
