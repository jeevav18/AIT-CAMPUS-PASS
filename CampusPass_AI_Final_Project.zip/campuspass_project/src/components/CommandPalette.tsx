import React, { useState, useEffect } from "react";
import {
  Search,
  X,
  FileText,
  Briefcase,
  GraduationCap,
  Award,
  Code2,
  Mail,
  ExternalLink,
  Layers,
  ArrowRight,
} from "lucide-react";
import { PORTFOLIO_DATA } from "@/data/portfolioData";

interface CommandPaletteProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenResumeModal: () => void;
}

export const CommandPalette: React.FC<CommandPaletteProps> = ({
  isOpen,
  onClose,
  onOpenResumeModal,
}) => {
  const [query, setQuery] = useState("");

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === "k") {
        e.preventDefault();
        if (isOpen) {
          onClose();
        } else {
          // Open
        }
      }
      if (e.key === "Escape" && isOpen) {
        onClose();
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const navigateTo = (sectionId: string) => {
    onClose();
    const elem = document.getElementById(sectionId);
    if (elem) {
      const offset = 76;
      const bodyRect = document.body.getBoundingClientRect().top;
      const elementRect = elem.getBoundingClientRect().top;
      const elementPosition = elementRect - bodyRect;
      const offsetPosition = elementPosition - offset;

      window.scrollTo({
        top: offsetPosition,
        behavior: "smooth",
      });
    }
  };

  const navItems = [
    { label: "Home / Profile Overview", id: "home", icon: <Layers className="w-4 h-4 text-blue-500" /> },
    { label: "Engineering Story & Philosophy", id: "about", icon: <Layers className="w-4 h-4 text-blue-500" /> },
    { label: "Technical Skills Matrix (Salesforce, Full-Stack, Cloud)", id: "skills", icon: <Code2 className="w-4 h-4 text-emerald-500" /> },
    { label: "Featured Projects & Architectures", id: "projects", icon: <Layers className="w-4 h-4 text-purple-500" /> },
    { label: "Work Experience & History", id: "experience", icon: <Briefcase className="w-4 h-4 text-amber-500" /> },
    { label: "Education & Coursework", id: "education", icon: <GraduationCap className="w-4 h-4 text-sky-500" /> },
    { label: "Certifications & Credentials", id: "certifications", icon: <Award className="w-4 h-4 text-indigo-500" /> },
    { label: "Hackathons & Achievements", id: "achievements", icon: <Award className="w-4 h-4 text-amber-500" /> },
    { label: "Capabilities & Services", id: "capabilities", icon: <Layers className="w-4 h-4 text-pink-500" /> },
    { label: "GitHub & Open Source Repositories", id: "github", icon: <Code2 className="w-4 h-4 text-slate-700 dark:text-slate-300" /> },
    { label: "Contact & Direct Hiring Inquiry", id: "contact", icon: <Mail className="w-4 h-4 text-blue-600" /> },
  ];

  const filteredItems = navItems.filter((item) =>
    item.label.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <div
      className="fixed inset-0 z-50 flex items-start justify-center pt-16 sm:pt-24 p-4 bg-slate-950/70 backdrop-blur-sm animate-in fade-in duration-150"
      onClick={onClose}
    >
      <div
        className="w-full max-w-xl bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Search Input */}
        <div className="flex items-center px-4 py-3.5 border-b border-slate-200 dark:border-slate-800 gap-3">
          <Search className="w-5 h-5 text-slate-400 shrink-0" />
          <input
            type="text"
            autoFocus
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Type a section name or command..."
            className="w-full bg-transparent text-sm text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none"
          />
          <button
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-white rounded-lg"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Quick Actions Bar */}
        <div className="p-2 bg-slate-50 dark:bg-slate-800/40 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 px-4">
          <span>Quick Actions</span>
          <button
            onClick={() => {
              onClose();
              onOpenResumeModal();
            }}
            className="inline-flex items-center gap-1.5 font-bold text-blue-600 dark:text-blue-400 hover:underline cursor-pointer"
          >
            <FileText className="w-3.5 h-3.5" />
            <span>Open Resume PDF</span>
          </button>
        </div>

        {/* Results List */}
        <div className="max-h-80 overflow-y-auto p-2 space-y-1">
          {filteredItems.length > 0 ? (
            filteredItems.map((item) => (
              <button
                key={item.id}
                onClick={() => navigateTo(item.id)}
                className="w-full flex items-center justify-between p-3 rounded-2xl text-left text-xs sm:text-sm font-semibold text-slate-700 dark:text-slate-300 hover:bg-blue-50 dark:hover:bg-slate-800 hover:text-blue-600 dark:hover:text-blue-400 transition-colors group cursor-pointer"
              >
                <div className="flex items-center gap-3">
                  {item.icon}
                  <span>{item.label}</span>
                </div>
                <ArrowRight className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-opacity text-blue-500" />
              </button>
            ))
          ) : (
            <div className="p-6 text-center text-xs text-slate-500">
              No matching sections found for "{query}"
            </div>
          )}
        </div>

        {/* Command Helper Footer */}
        <div className="p-3 bg-slate-50 dark:bg-slate-950 border-t border-slate-200 dark:border-slate-800 text-[11px] text-slate-400 flex items-center justify-between px-4">
          <span>Tip: Press ESC to close</span>
          <span className="font-mono">Jeeva V • Engineering Portfolio</span>
        </div>
      </div>
    </div>
  );
};

export default CommandPalette;
