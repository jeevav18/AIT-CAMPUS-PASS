import React from "react";
import {
  GraduationCap,
  Code2,
  Layers,
  Sparkles,
  ArrowRight,
  Compass,
  Cpu,
  BrainCircuit,
  Cloud,
} from "lucide-react";
import { PORTFOLIO_DATA } from "@/data/portfolioData";
import TechSphereCanvas from "@/components/TechSphereCanvas";

export const AboutSection: React.FC = () => {
  const getCardIcon = (iconName: string) => {
    switch (iconName) {
      case "GraduationCap":
        return <GraduationCap className="w-5 h-5 text-blue-500" />;
      case "Code2":
        return <Code2 className="w-5 h-5 text-sky-500" />;
      case "Layers":
        return <Layers className="w-5 h-5 text-indigo-500" />;
      case "Sparkles":
        return <Sparkles className="w-5 h-5 text-emerald-500" />;
      default:
        return <Code2 className="w-5 h-5 text-blue-500" />;
    }
  };

  return (
    <section id="about" className="py-20 sm:py-28 bg-slate-50/50 dark:bg-[#0B1120] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-50 dark:bg-blue-950/60 border border-blue-200 dark:border-blue-800 text-blue-700 dark:text-blue-300 text-xs font-semibold uppercase tracking-wider mb-3">
            <span>About Me</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            Electronics Engineer Turned Software & Cloud Builder
          </h2>
          <p className="mt-3 text-base sm:text-lg text-slate-600 dark:text-slate-300">
            Passionate about bridging hardware fundamentals with enterprise Salesforce architectures, full-stack systems, and Artificial Intelligence.
          </p>
        </div>

        {/* 4 Professional Highlight Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 mb-14">
          {PORTFOLIO_DATA.about.highlightCards.map((card) => (
            <div
              key={card.id}
              className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs hover:shadow-md hover:border-blue-500/40 dark:hover:border-blue-500/40 transition-all group"
            >
              <div className="w-10 h-10 rounded-xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center mb-4 group-hover:scale-105 transition-transform">
                {getCardIcon(card.icon)}
              </div>
              <p className="text-xs font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400 mb-1">
                {card.subtitle}
              </p>
              <h3 className="text-lg font-extrabold text-slate-900 dark:text-white mb-2">
                {card.title}
              </h3>
              <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
                {card.detail}
              </p>
            </div>
          ))}
        </div>

        {/* 2-Column Story & Interactive Canvas */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          {/* Left: Professional Story Narrative */}
          <div className="lg:col-span-7 space-y-6">
            <div className="p-7 sm:p-8 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs space-y-4">
              <div className="flex items-center gap-2 text-slate-900 dark:text-white font-bold text-lg">
                <Compass className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                <span>My Journey: Hardware Logic to Enterprise Cloud</span>
              </div>
              <p className="text-sm sm:text-base text-slate-600 dark:text-slate-300 leading-relaxed">
                {PORTFOLIO_DATA.about.story}
              </p>
              <p className="text-sm sm:text-base text-slate-600 dark:text-slate-300 leading-relaxed pt-2">
                As a student developer, I focus on building software that solves practical problems—from healthcare dispatch optimization and automated academic attendance to full-scale Salesforce CRM integrations and AI document processing engines.
              </p>

              {/* Core Pillars */}
              <div className="pt-4 border-t border-slate-100 dark:border-slate-800/80 grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="flex items-center gap-2 text-xs font-semibold text-slate-700 dark:text-slate-300">
                  <Cloud className="w-4 h-4 text-blue-500 shrink-0" />
                  <span>Salesforce Ecosystem</span>
                </div>
                <div className="flex items-center gap-2 text-xs font-semibold text-slate-700 dark:text-slate-300">
                  <Code2 className="w-4 h-4 text-sky-500 shrink-0" />
                  <span>Full-Stack Modern Web</span>
                </div>
                <div className="flex items-center gap-2 text-xs font-semibold text-slate-700 dark:text-slate-300">
                  <BrainCircuit className="w-4 h-4 text-indigo-500 shrink-0" />
                  <span>Applied AI Integration</span>
                </div>
              </div>
            </div>
          </div>

          {/* Right: Interactive 3D Tech Sphere */}
          <div className="lg:col-span-5">
            <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-xs">
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                  Interactive Technology Mesh
                </h3>
                <span className="text-[10px] font-semibold text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950/60 px-2 py-0.5 rounded-md">
                  Drag / Rotate
                </span>
              </div>
              <TechSphereCanvas />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
