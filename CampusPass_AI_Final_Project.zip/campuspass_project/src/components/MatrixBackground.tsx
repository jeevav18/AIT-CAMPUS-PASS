import { useEffect, useRef } from "react";

const MatrixBackground = () => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animationFrameId: number;

    const resizeCanvas = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };

    resizeCanvas();
    window.addEventListener("resize", resizeCanvas);

    // Matrix characters (Binary + Katakana + Hacker codes)
    const chars = "01010101ABCDEFGHIJKLMNOPQRSTUVWXYZｦｧｨｩｪｫｬｭｮｯｰｱｲｳｴｵｶｷｸｹｺｻｼｽｾｿﾀﾁﾂﾃﾄﾅﾆﾇﾈﾉﾊﾋﾌﾍﾎﾏﾐﾑﾒﾓﾔﾕﾖﾗﾘﾙﾚﾛﾜﾝ";
    const charArr = chars.split("");

    const fontSize = 14;
    const columns = Math.floor(canvas.width / fontSize);

    // Array to track the y positions of drops
    const drops: number[] = Array(columns).fill(1);

    const draw = () => {
      // Semi-transparent black to create trailing fade effect
      ctx.fillStyle = "rgba(5, 5, 5, 0.08)";
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      ctx.fillStyle = "#00FF66"; // Neon Green
      ctx.font = `${fontSize}px "JetBrains Mono", monospace`;

      for (let i = 0; i < drops.length; i++) {
        // Random character
        const text = charArr[Math.floor(Math.random() * charArr.length)];
        
        // Random opacity for a digital look
        const opacity = Math.random();
        ctx.fillStyle = `rgba(0, 255, 102, ${opacity > 0.5 ? opacity : 0.4})`;

        // First character sometimes glows in Electric Cyan
        if (Math.random() > 0.98) {
          ctx.fillStyle = "#00E5FF";
        }

        const x = i * fontSize;
        const y = drops[i] * fontSize;

        ctx.fillText(text, x, y);

        // Reset drop to the top with random delay once it hits the bottom
        if (y > canvas.height && Math.random() > 0.975) {
          drops[i] = 0;
        }

        drops[i]++;
      }
    };

    const interval = setInterval(draw, 33); // Cap around 30 FPS for perfect retro look and performance

    return () => {
      clearInterval(interval);
      window.removeEventListener("resize", resizeCanvas);
      cancelAnimationFrame(animationFrameId);
    };
  }, []);

  return (
    <div className="fixed inset-0 z-0 pointer-events-none overflow-hidden bg-[#050505]">
      <canvas ref={canvasRef} className="absolute inset-0 opacity-[0.25]" />
      
      {/* Perspective scanline overlay */}
      <div className="absolute inset-0 bg-scanlines pointer-events-none opacity-[0.04]" />
      
      {/* Futuristic glowing grid */}
      <div className="absolute inset-0 bg-grid pointer-events-none opacity-[0.03]" />

      {/* Cyberpunk ambient lighting */}
      <div className="absolute top-0 left-0 w-full h-full pointer-events-none bg-radial-vignette" />
    </div>
  );
};

export default MatrixBackground;
