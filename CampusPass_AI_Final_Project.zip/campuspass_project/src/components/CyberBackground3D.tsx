import { useEffect, useRef } from "react";
import * as THREE from "three";

interface CyberBackground3DProps {
  accentColor?: "green" | "cyan" | "purple";
  intensity?: number;
}

export const CyberBackground3D = ({
  accentColor = "green",
}: CyberBackground3DProps) => {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    // Check prefers-reduced-motion
    const prefersReducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    // Color mapper
    const colors = {
      green: { primary: 0x00ff66, secondary: 0x00e5ff, dark: 0x003311 },
      cyan: { primary: 0x00e5ff, secondary: 0x00ff66, dark: 0x002233 },
      purple: { primary: 0xbf5af2, secondary: 0x00e5ff, dark: 0x2b0d3d },
    }[accentColor];

    // Scene, Camera, Renderer
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(
      60,
      window.innerWidth / window.innerHeight,
      0.1,
      1000
    );
    camera.position.z = 85;

    const renderer = new THREE.WebGLRenderer({
      alpha: true,
      antialias: true,
      powerPreference: "low-power",
    });
    renderer.setSize(window.innerWidth, window.innerHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.5));
    renderer.setClearColor(0x000000, 0);

    container.appendChild(renderer.domElement);

    // ==========================================
    // 1. Central Wireframe Digital Shield / Core
    // ==========================================
    const shieldGroup = new THREE.Group();

    // Outer Octahedron / Icosahedron
    const geoOuter = new THREE.IcosahedronGeometry(18, 1);
    const matOuter = new THREE.MeshBasicMaterial({
      color: colors.primary,
      wireframe: true,
      transparent: true,
      opacity: 0.25,
    });
    const shieldOuter = new THREE.Mesh(geoOuter, matOuter);
    shieldGroup.add(shieldOuter);

    // Inner Core Shield Octahedron
    const geoInner = new THREE.OctahedronGeometry(9, 0);
    const matInner = new THREE.MeshBasicMaterial({
      color: colors.secondary,
      wireframe: true,
      transparent: true,
      opacity: 0.45,
    });
    const shieldInner = new THREE.Mesh(geoInner, matInner);
    shieldGroup.add(shieldInner);

    // Holographic Orbital Rings
    const ringGeo1 = new THREE.RingGeometry(24, 24.3, 48);
    const ringMat1 = new THREE.MeshBasicMaterial({
      color: colors.primary,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.2,
    });
    const ring1 = new THREE.Mesh(ringGeo1, ringMat1);
    ring1.rotation.x = Math.PI / 3;
    shieldGroup.add(ring1);

    const ringGeo2 = new THREE.RingGeometry(27, 27.2, 48);
    const ringMat2 = new THREE.MeshBasicMaterial({
      color: colors.secondary,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.15,
    });
    const ring2 = new THREE.Mesh(ringGeo2, ringMat2);
    ring2.rotation.y = Math.PI / 4;
    shieldGroup.add(ring2);

    scene.add(shieldGroup);

    // ==========================================
    // 2. Distributed Network Nodes & Data Lines
    // ==========================================
    const nodeCount = 45;
    const nodePositions: THREE.Vector3[] = [];
    const nodeVelocities: THREE.Vector3[] = [];

    for (let i = 0; i < nodeCount; i++) {
      const pos = new THREE.Vector3(
        (Math.random() - 0.5) * 140,
        (Math.random() - 0.5) * 90,
        (Math.random() - 0.5) * 60
      );
      nodePositions.push(pos);
      nodeVelocities.push(
        new THREE.Vector3(
          (Math.random() - 0.5) * 0.04,
          (Math.random() - 0.5) * 0.04,
          (Math.random() - 0.5) * 0.02
        )
      );
    }

    // Node Points
    const nodeGeo = new THREE.BufferGeometry();
    const nodePosArr = new Float32Array(nodeCount * 3);
    for (let i = 0; i < nodeCount; i++) {
      nodePosArr[i * 3] = nodePositions[i].x;
      nodePosArr[i * 3 + 1] = nodePositions[i].y;
      nodePosArr[i * 3 + 2] = nodePositions[i].z;
    }
    nodeGeo.setAttribute("position", new THREE.BufferAttribute(nodePosArr, 3));

    const nodeMat = new THREE.PointsMaterial({
      color: colors.primary,
      size: 1.8,
      transparent: true,
      opacity: 0.7,
    });
    const nodePoints = new THREE.Points(nodeGeo, nodeMat);
    scene.add(nodePoints);

    // Dynamic Connections Line Segments
    const maxConnections = 150;
    const linePositions = new Float32Array(maxConnections * 6);
    const lineGeo = new THREE.BufferGeometry();
    lineGeo.setAttribute(
      "position",
      new THREE.BufferAttribute(linePositions, 3).setUsage(THREE.DynamicDrawUsage)
    );

    const lineMat = new THREE.LineBasicMaterial({
      color: colors.primary,
      transparent: true,
      opacity: 0.12,
    });
    const connectionLines = new THREE.LineSegments(lineGeo, lineMat);
    scene.add(connectionLines);

    // ==========================================
    // 3. Cyber Data Packets (Travelling Blips)
    // ==========================================
    const packetCount = 12;
    interface Packet {
      fromIndex: number;
      toIndex: number;
      progress: number;
      speed: number;
    }
    const packets: Packet[] = [];
    for (let i = 0; i < packetCount; i++) {
      packets.push({
        fromIndex: Math.floor(Math.random() * nodeCount),
        toIndex: Math.floor(Math.random() * nodeCount),
        progress: Math.random(),
        speed: 0.008 + Math.random() * 0.012,
      });
    }

    const packetGeo = new THREE.BufferGeometry();
    const packetPosArr = new Float32Array(packetCount * 3);
    packetGeo.setAttribute("position", new THREE.BufferAttribute(packetPosArr, 3));

    const packetMat = new THREE.PointsMaterial({
      color: colors.secondary,
      size: 2.8,
      transparent: true,
      opacity: 0.9,
    });
    const packetPoints = new THREE.Points(packetGeo, packetMat);
    scene.add(packetPoints);

    // ==========================================
    // 4. Subtle Cyber Matrix Grid Plane (Bottom)
    // ==========================================
    const gridHelper = new THREE.GridHelper(200, 40, colors.primary, colors.dark);
    gridHelper.position.y = -35;
    (gridHelper.material as THREE.Material).transparent = true;
    (gridHelper.material as THREE.Material).opacity = 0.15;
    scene.add(gridHelper);

    // Mouse Parallax Interaction
    let mouseX = 0;
    let mouseY = 0;
    let targetX = 0;
    let targetY = 0;

    const handleMouseMove = (e: MouseEvent) => {
      mouseX = (e.clientX / window.innerWidth - 0.5) * 2;
      mouseY = (e.clientY / window.innerHeight - 0.5) * 2;
    };

    window.addEventListener("mousemove", handleMouseMove);

    // Resize Handler
    const handleResize = () => {
      camera.aspect = window.innerWidth / window.innerHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth, window.innerHeight);
    };
    window.addEventListener("resize", handleResize);

    // ==========================================
    // Animation Loop
    // ==========================================
    let animationFrameId: number;
    let isVisible = true;

    const handleVisibilityChange = () => {
      isVisible = !document.hidden;
    };
    document.addEventListener("visibilitychange", handleVisibilityChange);

    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);

      if (!isVisible) return;

      // Parallax smooth interpolation
      targetX += (mouseX * 12 - targetX) * 0.04;
      targetY += (-mouseY * 8 - targetY) * 0.04;

      camera.position.x = targetX;
      camera.position.y = targetY;
      camera.lookAt(0, 0, 0);

      if (!prefersReducedMotion) {
        // Rotate Shield
        shieldOuter.rotation.x += 0.003;
        shieldOuter.rotation.y += 0.004;
        shieldInner.rotation.x -= 0.005;
        shieldInner.rotation.z += 0.004;
        ring1.rotation.z += 0.006;
        ring2.rotation.z -= 0.004;

        // Move Nodes gently
        const posArray = nodeGeo.attributes.position.array as Float32Array;
        for (let i = 0; i < nodeCount; i++) {
          nodePositions[i].add(nodeVelocities[i]);

          // Boundary bounce
          if (Math.abs(nodePositions[i].x) > 70) nodeVelocities[i].x *= -1;
          if (Math.abs(nodePositions[i].y) > 45) nodeVelocities[i].y *= -1;
          if (Math.abs(nodePositions[i].z) > 30) nodeVelocities[i].z *= -1;

          posArray[i * 3] = nodePositions[i].x;
          posArray[i * 3 + 1] = nodePositions[i].y;
          posArray[i * 3 + 2] = nodePositions[i].z;
        }
        nodeGeo.attributes.position.needsUpdate = true;

        // Update Connections
        let lineIdx = 0;
        const linePosArray = lineGeo.attributes.position.array as Float32Array;

        for (let i = 0; i < nodeCount && lineIdx < maxConnections; i++) {
          for (let j = i + 1; j < nodeCount && lineIdx < maxConnections; j++) {
            const dist = nodePositions[i].distanceTo(nodePositions[j]);
            if (dist < 26) {
              linePosArray[lineIdx * 6] = nodePositions[i].x;
              linePosArray[lineIdx * 6 + 1] = nodePositions[i].y;
              linePosArray[lineIdx * 6 + 2] = nodePositions[i].z;

              linePosArray[lineIdx * 6 + 3] = nodePositions[j].x;
              linePosArray[lineIdx * 6 + 4] = nodePositions[j].y;
              linePosArray[lineIdx * 6 + 5] = nodePositions[j].z;

              lineIdx++;
            }
          }
        }
        lineGeo.setDrawRange(0, lineIdx * 2);
        lineGeo.attributes.position.needsUpdate = true;

        // Update Packets
        const packetArr = packetGeo.attributes.position.array as Float32Array;
        for (let i = 0; i < packetCount; i++) {
          const p = packets[i];
          p.progress += p.speed;
          if (p.progress >= 1) {
            p.progress = 0;
            p.fromIndex = p.toIndex;
            p.toIndex = Math.floor(Math.random() * nodeCount);
          }

          const fromPos = nodePositions[p.fromIndex];
          const toPos = nodePositions[p.toIndex];
          if (fromPos && toPos) {
            packetArr[i * 3] = fromPos.x + (toPos.x - fromPos.x) * p.progress;
            packetArr[i * 3 + 1] = fromPos.y + (toPos.y - fromPos.y) * p.progress;
            packetArr[i * 3 + 2] = fromPos.z + (toPos.z - fromPos.z) * p.progress;
          }
        }
        packetGeo.attributes.position.needsUpdate = true;
      }

      renderer.render(scene, camera);
    };

    animate();

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener("mousemove", handleMouseMove);
      window.removeEventListener("resize", handleResize);
      document.removeEventListener("visibilitychange", handleVisibilityChange);

      if (container && renderer.domElement) {
        container.removeChild(renderer.domElement);
      }
      renderer.dispose();
      geoOuter.dispose();
      matOuter.dispose();
      geoInner.dispose();
      matInner.dispose();
      ringGeo1.dispose();
      ringMat1.dispose();
      ringGeo2.dispose();
      ringMat2.dispose();
      nodeGeo.dispose();
      nodeMat.dispose();
      lineGeo.dispose();
      lineMat.dispose();
      packetGeo.dispose();
      packetMat.dispose();
      gridHelper.dispose();
    };
  }, [accentColor]);

  return (
    <div
      ref={containerRef}
      className="fixed inset-0 pointer-events-none z-0 opacity-80 overflow-hidden"
      aria-hidden="true"
    />
  );
};
export default CyberBackground3D;
