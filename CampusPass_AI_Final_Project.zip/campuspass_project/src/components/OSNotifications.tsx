import { motion } from "framer-motion";
import { X, ShieldCheck, Mail, Database, Terminal, Award } from "lucide-react";
import { playTick, playHover } from "@/lib/cyberAudio";

interface OSNotificationsProps {
  isOpen: boolean;
  onClose: () => void;
  onLaunchApp: (appId: string) => void;
}

const OSNotifications = ({ isOpen, onClose, onLaunchApp }: OSNotificationsProps) => {
  if (!isOpen) return null;

  const alerts = [
    {
      title: "Core Resume Decrypted",
      desc: "Jeeva V's professional resume decrypted using secure RSA SHA-256 tokens.",
      time: "Just Now",
      icon: ShieldCheck,
      color: "text-[#00FF66] bg-[#00FF66]/10 border-[#00FF66]/20",
      action: "resume",
    },
    {
      title: "Salesforce Cloud Active",
      desc: "Bypassed standard SOQL query indexes successfully to fetch 12 core works.",
      time: "2m ago",
      icon: Database,
      color: "text-[#00E5FF] bg-[#00E5FF]/10 border-[#00E5FF]/20",
      action: "dashboard",
    },
    {
      title: "Message Queue Empty",
      desc: "Ready to transmit secure guest proposals. Ready for Coimbatore/Remote roles.",
      time: "15m ago",
      icon: Mail,
      color: "text-[#FFC107] bg-[#FFC107]/10 border-[#FFC107]/20",
      action: "contact",
    },
    {
      title: "Hacker Shell Loaded",
      desc: "Direct Linux terminal virtual kernel mapped on active workspace.",
      time: "1h ago",
      icon: Terminal,
      color: "text-[#00FF66] bg-[#00FF66]/10 border-[#00FF66]/20",
      action: "terminal",
    },
  ];

  return (
    <motion.div
      initial={{ x: 300, opacity: 0 }}
      animate={{ x: 0, opacity: 1 }}
      exit={{ x: 300, opacity: 0 }}
      transition={{ type: "spring", damping: 25, stiffness: 220 }}
      className="fixed top-0 right-0 bottom-12 w-full max-w-[320px] bg-[#050505]/95 border-l border-[#00FF66]/25 shadow-[-10px_0_35px_rgba(0,0,0,0.85)] backdrop-blur-md z-[9998] p-4 flex flex-col font-mono text-xs text-white"
    >
      {/* Header alert panel bar */}
      <div className="flex items-center justify-between border-b border-[#00FF66]/15 pb-3 mb-4">
        <div className="flex items-center space-x-2">
          <Award className="w-4.5 h-4.5 text-[#00FF66] animate-pulse" />
          <span className="font-bold text-[#00FF66] tracking-wider uppercase font-oxanium text-glow-green">TELEMETRY_CENTER</span>
        </div>
        <button
          onMouseEnter={playHover}
          onClick={() => {
            playTick();
            onClose();
          }}
          className="p-1 rounded hover:bg-white/5 text-gray-500 hover:text-[#00FF66] transition cursor-pointer"
        >
          <X className="w-4.5 h-4.5" />
        </button>
      </div>

      {/* Notifications scroll list */}
      <div className="flex-1 overflow-y-auto scrollbar-thin space-y-3">
        {alerts.map((alt, idx) => (
          <div
            key={idx}
            className={`p-3.5 border rounded-lg space-y-2.5 transition hover:bg-white/5 ${alt.color}`}
          >
            <div className="flex items-start justify-between">
              <div className="flex items-center space-x-2 font-bold text-white leading-tight">
                <alt.icon className="w-4 h-4 text-[#00FF66]" />
                <span className="truncate max-w-[180px]">{alt.title}</span>
              </div>
              <span className="text-[8px] text-gray-500 uppercase">{alt.time}</span>
            </div>
            
            <p className="text-[10px] text-gray-400 leading-normal">{alt.desc}</p>

            {alt.action && (
              <button
                onMouseEnter={playHover}
                onClick={() => {
                  playTick();
                  onLaunchApp(alt.action);
                  onClose();
                }}
                className="text-[9px] text-[#00FF66] font-bold hover:underline cursor-pointer block uppercase tracking-wider"
              >
                Launch applet &gt;
              </button>
            )}
          </div>
        ))}
      </div>

      <div className="border-t border-zinc-900 pt-3 text-[9px] text-gray-600 text-center uppercase font-bold">
        Session Status: Verified Stable Log
      </div>
    </motion.div>
  );
};

export default OSNotifications;
